#!/usr/bin/env python3
"""Quick Mac compile + leanchecker of the 43 integrated Task J modules from a new empty output dir (sanity check before the Windows whole-tree replay). Claude, 2026-11-18."""
import json, os, re, subprocess, sys, time
P = '<workspace>'; W = f'{P}/work'
BIN = f'{W}/toolchains/lean-4.34.1-darwin_aarch64/bin'; PK = f'{W}/research-lean-v434/.lake/packages'
SRC = f'{P}/outputs/release/ai4math-results/lean'; OUT = sys.argv[1]; os.makedirs(OUT)
mods = [o['module'] for o in json.load(open(f'{W}/release-v1230/taskj-integration.json'))]
deps = {m: [x for x in re.findall(r'^import (\S+)$', open(f"{SRC}/{m.replace('.','/')}.lean").read(), re.M) if x.startswith('Research.')] for m in mods}
order, seen = [], set()
def visit(m):
    if m in seen: return
    seen.add(m); [visit(d) for d in deps[m]]; order.append(m)
[visit(m) for m in mods]
lp = os.pathsep.join([OUT] + [f'{PK}/{n}/.lake/build/lib/lean' for n in os.listdir(PK) if os.path.isdir(f'{PK}/{n}/.lake/build/lib/lean')] + [f'{BIN}/../lib/lean'])
env = dict(os.environ, LEAN_PATH=lp, LC_ALL='C', PATH=BIN + os.pathsep + os.environ['PATH'])
res = {}
for m in order:
    rel = m.replace('.', '/'); os.makedirs(os.path.dirname(f'{OUT}/{rel}'), exist_ok=True)
    t = time.time()
    c = subprocess.run([f'{BIN}/lean', '-DautoImplicit=false', '-DrelaxedAutoImplicit=false', '-R', SRC, '-o', f'{OUT}/{rel}.olean', f'{SRC}/{rel}.lean'], env=env, capture_output=True, text=True)
    k = subprocess.run([f'{BIN}/leanchecker', m], env=env, capture_output=True, text=True) if c.returncode == 0 else None
    out = c.stdout + c.stderr
    res[m] = dict(rc=c.returncode, check_rc=k.returncode if k else None, sec=round(time.time() - t, 1),
                  out_head=out[:1500], errors=bool(re.search(r':\d+:\d+: error|sorry', out)), warnings=len(re.findall(r': warning', out)),
                  axioms=re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]", out, re.M))
    print(m, res[m]['rc'], res[m]['check_rc'], res[m]['sec'], flush=True)
json.dump(res, open(f'{OUT}.json', 'w'), indent=1)
print('compile ok', sum(r['rc'] == 0 for r in res.values()), 'check ok', sum(r['check_rc'] == 0 for r in res.values()), 'of', len(res))
