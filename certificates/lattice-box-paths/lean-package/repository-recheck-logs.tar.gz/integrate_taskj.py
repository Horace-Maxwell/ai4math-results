#!/usr/bin/env python3
"""Copy Task J Lean files into the release tree under Research/TaskJ/, rewriting only local import lines. Claude, 2026-11-18.
rank/*.lean -> Research/TaskJ/Rank/, rank/extension/*.lean -> Research/TaskJ/Rank/Extension/, grid/*.lean -> Research/TaskJ/Grid/.
Writes a mapping with source and target SHA-256 to work/release-v1230/taskj-integration.json."""
import hashlib, json, os, re, sys
P = '<workspace>'
SRC = f'{P}/work/codex-r3/phase18/taskJ'; REL = f'{P}/outputs/release/ai4math-results/lean'
groups = [('rank', 'Research.TaskJ.Rank'), ('rank/extension', 'Research.TaskJ.Rank.Extension'), ('grid', 'Research.TaskJ.Grid')]
sha = lambda b: hashlib.sha256(b).hexdigest()
out = []
for d, mod in groups:
    names = sorted(f[:-5] for f in os.listdir(f'{SRC}/{d}') if f.endswith('.lean'))
    tdir = f"{REL}/{mod.replace('.', '/')}"; os.makedirs(tdir, exist_ok=True)
    for n in names:
        b = open(f'{SRC}/{d}/{n}.lean', 'rb').read(); t = b.decode()
        def fix(m):
            x = m.group(1)
            if x in names: return f'import {mod}.{x}'
            assert x.startswith('Mathlib'), (d, n, x)
            return m.group(0)
        t2 = re.sub(r'^import (\S+)$', fix, t, flags=re.M)
        # only import lines may differ
        a = [l for l in t.split('\n') if not l.startswith('import ')]; c = [l for l in t2.split('\n') if not l.startswith('import ')]
        assert a == c
        open(f'{tdir}/{n}.lean', 'w').write(t2)
        out.append(dict(source=f'{d}/{n}.lean', target=f"lean/{mod.replace('.', '/')}/{n}.lean", module=f'{mod}.{n}',
                        source_sha256=sha(b), target_sha256=sha(t2.encode()), identical=(t == t2)))
json.dump(out, open(f'{P}/work/release-v1230/taskj-integration.json', 'w'), indent=1)
print(len(out), 'files;', sum(o['identical'] for o in out), 'byte-identical (no local imports)')
