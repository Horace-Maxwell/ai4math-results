# Cross-family FINAL review 01: maximum modulus of domination roots of K_a ∨ mB (Task P)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The three frozen targets `Attainment`, `GeneralAsymptotic` and `FriendshipAsymptotic` are faithful to Alikhani–Brown–Jahari Question 3.2 (journal numbering; Question 2 in arXiv v2) and to the stated generalisation. They are fully Lean-verified: standard axioms only, and my independent rebuild and leanchecker pass. The MINOR items below concern `MATHEMATICS.md` only. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session (lock owner `claude-final-rootrad`). I wrote none of the reviewed files and took no part in Task O/P for this problem.
- Review started 2026-11-20T20:52:13Z; report written after 2026-11-20T20:58:11Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-rootrad/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= frozen snapshot, byte-identical) | d6663c9f3b098598132eca69d3d07a53e98b9a6c5bf3c1e35a56aee78233222d |
| CheckRootRadius.lean | 4c75276e1aab376aaa783ab7b0443eb2c4cdfcc234b62dc35b5cca37bad151c9 |
| Proof.lean | 1a4d7a1f1d7a32f24eabc970c7842c51dac291aa279cb9d83ba3bdfedd297746 |
| RootData.lean | 73767ef37a07e84979f38b67376f91ca7692297b5609fc11d4a67e95fc2eda4d |
| PetalCoefficient.lean | 304c90303973b36a62ed39fc2da6337ce69ef5d22f7e08ef31404ae69760036c |
| PetalEvaluation.lean | d1a86bcad743c61ddc7c5b5f0bdde9b6586eaf37dc07c687801dfab5b8e4b296 |
| JoinDecomposition.lean | 6bf5a135ef8544f65706c0e6592867a39fd9ab1c009dc985fa3ca903d46e300c |
| JoinPolynomial.lean | 37f4f04c0f9dab83780f320172e5069f5fe46369520c649a9be4181b445d4806 |
| Scale.lean | a0fd0f396e6ca4a6a4e0f1e7f4a921aedfff40d1bab72d22c442730e5355bb39 |
| LogLimit.lean | 44bfc927e5616bfeaf107e493f81dfcd3948c8bf1da6801bb4be294afc61831c |
| UpperEstimate.lean | 1a8a1429aa8463ba4aaa9e4b8ed270ef335cba480be7870f65b3dd69239d4eac |
| DiskZero.lean | 1107556cf2028f2caffba323fc6dceb8b62495f9e3234029bba27e04b482dccf |
| RootDisk.lean | b67aab9710fd9506599d171cd1db02e166bfe998da7244686b943b10ac1b6ff2 |
| LowerBound.lean | 63555d7ec987363e5d3d14e5d961c4729ddd3c0200b037873ddd805504b7cfcb |
| FREEZE.json | 2cf421add73c1b63b0d955913f551a5c10ebb3310f77543562219deddc08e5f3 |
| FREEZE-REVIEW.md | 86125912281039822f3756fbb9b784c375d5deae1e95b9aa4a436691a6b1aa32 |
| SOURCE-CHECK.md | 6d97be1c3afd8249303e0543551589fe4c9d9833a380d8b837411a205a23a25b |
| G2.md | 33b1e816f890e59e5a82741df2edac5e6bd31cc72cfc524a7f9ca6ceeb336fec |
| MATHEMATICS.md | 4508c8b96ce8b846f7866188c2e7ddee2974e887459adb79c9a3df5440d8c797 |
| FINAL-HANDOFF.md | 8bee8afa36f5f1cc9893b3ee85477897bc91c64c878a6f4caca8439917f58681 |
| acceptance/2026-11-20T182447Z/receipt.json | 633bb35ca30e69bbf029053109d0aa17fe20098decc3291b3b8129f9ab72b031 |
| My Audit.lean (scratch) | 4041307421441baac360f160961ef2ad1b5f1b71ec3d929950e4c239e4844115 |

- All 14 source hashes match `receipt.json.source_sha256`.
- The 14 `.lean` files in the task root are byte-identical to `acceptance/.../root1` and `root2`.
- The Challenge hash matches `FREEZE.json.challenge_sha256` and the `frozen/` snapshot.
- The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`.
- `receipt.freeze_sha256` equals the FREEZE.json hash, and the receipt hash matches FINAL-HANDOFF.

## 1. Are the statements faithful to the source?

**Source.** I read arXiv:1401.2092v2 (28 Aug 2014) myself. Its §3, Question 2, asks: "What is a good upper bound on the modulus of the roots of F_n?" It is followed by the numerical remark that the moduli grow "quite slowly, perhaps like ln n". The paper defines F_n as K_1 ∨ nK_2 (2n+1 vertices, 3n edges). A dominating set is one where every vertex outside S has a neighbour in S, and D(F_n,x) = (x²+2x)ⁿ + x(1+x)²ⁿ. The journal server (doiserbia) refused my connection, so I could not re-read the journal PDF. I rely on SOURCE-CHECK for the Filomat numbering "Question 3.2, p.176"; the arXiv wording is identical.

- **Domination polynomial.** `Dominates G S := ∀ v, v ∈ S ∨ ∃ u ∈ S, G.Adj v u` is the source definition. `dominationPolynomial G = ∑_{S : Finset V} if Dominates G S then X^|S| else 0` over ℂ[X] is the actual sum over dominating sets of the actual graph. There are no cardinality shortcuts and no `Nat.card`/`ncard`.
- **Graph construction.** `petalJoin a m B` lives on `Fin a ⊕ (Fin m × V)`:
  - centre–centre adjacent iff i ≠ j (K_a);
  - centre–petal always adjacent;
  - petal–petal adjacent iff same copy index and B-adjacent.

  This is exactly K_a ∨ mB, and the symm/loopless proofs are genuine. `friendshipGraph m = petalJoin 1 m ⊤_{Fin 2}` is K_1 ∨ mK_2 = F_m.
- **Maximum modulus.** `rootRadius G = sSup {‖z‖ : z ∈ ℂ, D(G,z)=0}` ranges over all complex roots, not only real ones. Taken alone, sSup could default to 0, but `Attainment` asserts `IsGreatest` of that very set at `rootRadius`, for every a ≥ 1, m ≥ 1 and every nonempty finite B. So the radius is a genuinely attained maximum: the set is nonempty since 0 is a root, and finite since D is monic of degree a+mb.
- **Constants.** `minimumSize B = B.minDegree + 1` = c (Nonempty V, so minDegree is the true minimum). `minimumCount` counts *distinct* closed neighbourhoods `insert v (neighborFinset v)` of size c, via `image` then `filter`. That is the right s. A vertex count would give the wrong constant: for B=K₂, K₃ my numerics below separate the two. `scale a c s m = (c·s·m/(a·log m))^(1/c)` uses the natural log and real rpow. For m ≤ 1 it evaluates to 0, which does not affect a limit at `atTop`.
- **Quantifiers.** `GeneralAsymptotic`: ∀ V : Type, Fintype, Nonempty; ∀ B (any simple graph: disconnected or with isolated vertices allowed); ∀ a > 0. Then rootRadius/scale → 1 along ℕ.
- **Lower bound is included.** Together with `Attainment`, the limit is two-sided and is witnessed by actual roots. For every ε > 0, eventually every root has ‖z‖ ≤ (1+ε)·scale *and some actual root* has ‖z‖ ≥ (1−ε)·scale. I proved this unfolded ε–M form for the friendship case from the frozen targets in my Audit.lean. It compiles, so the frozen statements really carry the matching-root content and are not only an upper bound.
- **Friendship target.** `FriendshipAsymptotic` is stated directly with `Real.sqrt (2m/log m)`. RootData proves c=2, s=1 for ⊤ on Fin 2 inside the Lean proof.
- **Small cases (Python/sympy, my code).**
  - Brute-force enumeration of dominating sets of the actual join equals ((1+z)^a−1)(1+z)^{bm} + D(B,z)^m. Checked for B ∈ {K1, K2, 2K1, P3, K1+K2, C4, K1,3, K3, P4}, a ∈ {1,2}, m ∈ {1,2,3}, up to 14 vertices.
  - D(F₁) = z³+3z²+3z.
- **Root moduli: exact polynomials.** I took mpmath `polyroots` of the exact polynomial for m = 5, 10, 20, 40, 80. Friendship max modulus is 2.502, 3.065, 3.843, 4.912, 6.378. The m=20 value matches Rather's Table 2.
- **Root moduli: large m.** The ratio to √(2m/log m) is about 1.055 for moderate m. A Newton solve of the root equation (residual < 1e-40; at m=80 it finds the same root as polyroots) gives these ratios:

  | m | 10⁴ | 10⁸ | 10²⁰ | 10⁵⁰ | 10¹⁰⁰ |
  |---|---|---|---|---|---|
  | ratio | 1.059 | 1.054 | 1.034 | 1.018 | 1.010 |

  So the ratio tends to 1, with the expected slow 1 + O(log log m / log m) rate.
- **General petals.** For K₃ (a=1, s=1), C₄ (a=2, s=4), 2K₁ (a=3, s=2) and K₁,₃ (a=1, s=3), the largest root I found at m = 10⁶, 10²⁰, 10⁶⁰ has ratio 1.052→1.009, 1.019→1.008, 1.255→1.040 and 1.018→1.011. For K₃, counting vertices (s=3) would instead give a ratio near 0.70. These Newton roots are lower-bound witnesses only; the upper bound is the Lean theorem.

The statements are not weaker than the source. They are a strictly sharper answer than "a good upper bound": a two-sided asymptotic with attained roots, generalised to every fixed petal and every fixed centre clique.

## 2. Is the proof chain clean?

- **CheckRootRadius.lean.** It contains exactly `theorem check_X : Challenge.X := Proof.X` for X ∈ {Attainment, GeneralAsymptotic, FriendshipAsymptotic}, plus 6 `#print axioms`.
- **No shadowing.** Only Challenge.lean opens `TaskP.GraphRootRadius.Challenge`. The proof modules use `...Proof` and define only helpers (`delta`, `warg`, `residual`, `logSlope`, `dWeight`, `bundle`, `familyEquiv`, `Misses`, `bad`, `normalized`). None shadows a frozen name.
- **Audit.lean.** It compiles all six fully qualified `example : TaskP.GraphRootRadius.Challenge.X := ...` against both `Proof.X` and `check_X`, plus the unfolded friendship ε-statement above.
- **Forbidden constructs.** I grepped all 14 files for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, set_option, initialize, run_cmd and ofReduceBool. The only hits are the `#print axioms` lines.
- **Attributes and `decide`.** The only attribute is one `@[simp]` on the helper lemma `mem_bundle`, which is harmless. There is one `decide`, for `0 < 1` in `friendship_of_general`.
- **Proof structure.**
  - Join decomposition gives D(J_m, y−1) = (y^a−1)y^{bm} + D(B,y−1)^m.
  - The complement/"bad set" expansion gives Q(w) = 1 − s w^c + w^{c+1}E(w), with y^b Q(1/y) = D(B, y−1).
  - Upper bound: a uniform estimate on |y| ≥ (1+ε/2)S.
  - Lower bound: a branch of the complex log, a joint limit H_m → (a/c)(p^{-c} − 1), and the maximum-modulus principle applied to 1/H_m on a small closed disk, which yields an actual zero near Sω.
  - `GeneralAsymptotic` is assembled with `tendsto_order`. `FriendshipAsymptotic` is a specialisation.
- **Axioms.** All 6 `#print axioms` in CheckRootRadius and the 3 in Audit give only `[propext, Classical.choice, Quot.sound]`.

## 3. Independent rebuild on this Mac

- **Setup.** In a new empty scratch directory I copied the 14 `.lean` files to `src/` and added `Audit.lean`. I did not use lake or any Codex build product. Each module was compiled with plain `lean -DautoImplicit=false -R src -o out/M.olean`, in dependency order. `LEAN_PATH` was my own `out/` plus the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
- **Toolchain.** Lean 4.34.1. The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…). Mathlib is at `d13f23b723b8a846827a245b89c10fc7d3f11612` (`git rev-parse`).
- **Lock.** I took `leanlock.sh acquire any claude-final-rootrad 60`, which gave slot A. Only one Lean process ran at a time. I released it with `release A claude-final-rootrad` → `released A`, and `status` then showed A: free.
- **Result.** All 15 modules (14 local + Audit) compiled with exit 0. There were no errors or warnings; the only output was the `#print axioms` info. `leanchecker` exited 0 with empty output on every module. My first Audit draft had an elaboration error in my own example (an implicit `V` was left unresolved). After I fixed it, the draft recompiled and passed the checker. Peak RSS for a single command was 6.0 GB.

## 4. Mathematical sanity of MATHEMATICS.md

- **Correctness.** The written proof is correct and matches the Lean structure. I checked the key upper-bound arithmetic: |Q(1/y)| ≤ 1 + (s+K/T)/T^c; m·s/T^c = a·log m/(c·B₀^c); and a/(c·B₀^c) < a/c. The lower-bound limit (a/c)(p^{-c}−1) also checks.
- **Prior work.** Rather (arXiv:2604.08998, v1 10 Apr 2026, v2 2 May 2026), §4 Theorem 4.1, gives (|z|−1)² log|z| ≤ n for |z| > 1. Corollary 4.2 gives |z| ≤ 1 + √(n/log 2), and Remark 4.3 gives the implicit R_n. I verified this myself. MATHEMATICS.md credits Theorem 4.1 and says that it already implies the upper-bound leading constant. SOURCE-CHECK spells out R_n/√(2n/log n) → 1. This is the correct attribution. The novelty claimed is the matching actual roots and the general-petal sharp asymptotic, which is the right boundary.
- **Other checks.** The text never says "first" or anything equivalent. My own quick searches found no later paper giving the sharp asymptotic or matching lower bounds. Alikhani–Griswold arXiv:2608.00109 (Jul 2026) is about integer roots only. Jahari–Alikhani arXiv:1501.05856 gives limiting curves only. Everything mathematical in MATHEMATICS.md is Lean-verified, except the remarks listed below.

## MINOR write-up fixes

1. **Rather credit.** MATHEMATICS.md §"原问题与贡献" cites only Theorem 4.1. Add Corollary 4.2 (1+√(m/log 2)) and Remark 4.3 (implicit R_m with (R_m−1)² log R_m = m). State that R_m ∼ √(2m/log m), so Rather's implicit bound already has the sharp leading constant; this step is a short derivation, not in Lean.
2. **Rather's open question.** Rather's v2 says the estimate is "not expected to be asymptotically sharp". The conclusion asks whether the friendship modulus bound is asymptotically optimal. The friendship case here shows that his implicit bound R_m is asymptotically sharp, and his explicit Corollary 4.2 is not. Mention this as part of what the result settles. Phrase it carefully: it answers the question for Remark 4.3's R_m and not for Corollary 4.2.
3. **Mark non-Lean statements.** Add one line saying that these are literature remarks, not Lean-verified: "Rather 的不等式蕴含上界主项系数" and the SOURCE-CHECK remark "Mₘ/log m→∞（原文的 ln n 印象偏低）". Everything else in MATHEMATICS.md is covered by the three Lean targets.
4. **Credit the join formula.** D(G∨H) = ((1+x)^{|G|}−1)((1+x)^{|H|}−1) + D(G) + D(H) is standard (e.g. Alikhani–Peng, "Introduction to domination polynomial of a graph"; also in Kotek–Preen–Simon–Tittmann–Trinks), as is multiplicativity over disjoint unions. Credit the decomposition D(J_m,y−1) = (y^a−1)y^{bm} + D(B,y−1)^m to these. Only its Lean derivation is new here.
5. **Optional: convergence rate.** Note that convergence is slow. The ratio to √(2m/log m) is about 1.055 at m=80, 1.034 at m=10²⁰ and 1.010 at m=10¹⁰⁰, consistent with 1 + O(log log m/log m). Without this, readers comparing with small-m tables may doubt the constant.
6. **Optional: numbering.** Give both numberings in one place: Filomat Question 3.2, p.176 = arXiv v2 §3 Question 2.
