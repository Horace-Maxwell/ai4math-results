"""Read a completed Task T machine receipt and its two replay roots. Emit JSON to stdout."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib

FORMAL = Path(__file__).resolve().parents[1]
WORK = next(p for p in FORMAL.parents if p.name == 'work')
PROJECT = WORK / 'research-lean-v434'
BIN = WORK / 'toolchains/lean-4.34.1-darwin_aarch64/bin'
NS = 'TaskT.HellyFive.'
FROZEN = 'faf32ea5b217b5ffdd8602b5d5787ceac010b3ef682a64d691444e9ac9636d26'
REVIEWED = 'b229c6438b7a98ddc524bb21c66968fa0529f2ec3b5cc0e331e49ea60402f5f7'
TARGETS = ('ExactHellyFive', 'ExactVertexFive')
EXPECTED = {NS + prefix + target for prefix in ('Proof.', 'check_') for target in TARGETS}
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
AXIOM = re.compile(r"info: TaskT/HellyFive/Check\.lean:\d+:\d+: '([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)")
LIMIT = 40_000_000_000


def require(ok, message):
    if not ok:
        raise ValueError(str(message))


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    with p.open('rb') as fp:
        return hashlib.file_digest(fp, 'sha256').hexdigest()


def bindings(r):
    freeze = FORMAL / 'FREEZE.json'
    data = read(freeze)
    require(sha(freeze) == r['freeze_sha256'] and data['targets'] == [NS + t for t in TARGETS], freeze)
    for rel, digest in data['pins'].items():
        require(sha(WORK.parent / rel) == digest, rel)
    src = r['source_sha256']
    order = r['order']
    require(len(order) == len(set(order)) == 31 and set(src) == set(order), 'local closure')
    require(src[NS + 'Challenge'] == FROZEN and order[-1] == NS + 'Check', 'frozen targets')
    manifest = ''
    for m in sorted(order):
        require(re.fullmatch(r'TaskT\.HellyFive\.[A-Za-z0-9]+', m), m)
        rel = m.replace('.', '/') + '.lean'
        require(sha(FORMAL / rel) == src[m], rel)
        manifest += f'{src[m]}  {rel}\n'
    require(hashlib.sha256(manifest.encode()).hexdigest() == REVIEWED, 'reviewed source closure')
    require(r['toolchain'] == (PROJECT / 'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.34.1' and 'version 4.34.1,' in r['lean_version'], 'toolchain')
    require(r['tools_sha256'] == {n: sha(BIN / n) for n in ('lean', 'lake', 'leanchecker')}, 'tool hashes')
    require(not any((BIN.parent / 'lib/lean').glob('TaskT*')), 'toolchain shadows TaskT namespace')
    runner_inputs = [FORMAL / 'accept.py', WORK / 'tools/leanlock.sh']
    runner_inputs += [WORK / 'codex-r3' / p for p in ('phase26/taskS/accept.py','phase26/taskS/dev.py','phase25/taskR/dev.py','phase17/taskH/mac-runtime-candidate04/contract.py','phase17/taskH/mac-runtime-candidate04/canonical_original.py')]
    require(r['runner_dependencies_sha256'] == {str(p.relative_to(WORK)): sha(p) for p in runner_inputs}, 'runner inputs')
    lake_manifest = PROJECT / 'lake-manifest.json'
    require(sha(lake_manifest) == r['dependency_manifest_sha256'], lake_manifest)
    commits = {pkg['name']: pkg['rev'] for pkg in read(lake_manifest)['packages']}
    require(commits == r['dependency_commits'], 'external package pins')
    links = {}
    for pkg, rev in commits.items():
        base = PROJECT / '.lake/packages' / pkg
        head = subprocess.check_output(['git', '-C', base, 'rev-parse', 'HEAD'], text=True).strip()
        require(head == rev, base)
        cache = base / '.lake/build/lib/lean'
        for p in cache.iterdir() if cache.is_dir() else ():
            if p.is_dir() or p.name.endswith(('.olean','.olean.private','.olean.server','.ilean','.ir','.ir.sig')):
                require(p.name.split('.')[0] != 'TaskT' and p.name not in links, p)
                links[p.name] = str(p)
    require('Mathlib.olean' in links, 'missing external Mathlib')
    return links


def check_root(root, r, links, lock_events):
    name, order = root.name, r['order']
    logs = root.with_name(name + '-logs')
    lib = root / '.lake/build/lib/lean'
    state = r['roots'][name]
    config = tomllib.loads((root / 'lakefile.toml').read_text())
    require(config['lean_lib'] == [{'name':'TaskT','roots':order}] and config['defaultTargets'] == ['TaskT'] and config['moreLeanArgs'] == ['-j1'] and config['leanOptions'] == {'warningAsError':True,'autoImplicit':False,'relaxedAutoImplicit':False}, root / 'lakefile.toml')
    require(read(root / 'lake-manifest.json')['packages'] == [] and not list((root / '.lake/packages').glob('*')) and (root / 'lean-toolchain').read_bytes() == (PROJECT / 'lean-toolchain').read_bytes(), root)
    require(read(logs / 'external-cache-links.json') == links and {p.name for p in lib.iterdir()} == {*links, 'TaskT'}, lib)
    for key, target in links.items():
        p = lib / key
        require(p.is_symlink() and p.readlink() == Path(target) and p.exists(), p)
    require(state['source_sha256'] == r['source_sha256'] and set(state['olean_sha256']) == set(order) and state['checker_count'] == 31, name)
    for top, ext, pins in ((root, '.lean', state['source_sha256']), (lib, '.olean', state['olean_sha256'])):
        actual = {p.relative_to(top).as_posix() for p in (top / 'TaskT').rglob('*' + ext)}
        require(actual == {m.replace('.', '/') + ext for m in order}, top)
        for m in order:
            p = top / (m.replace('.', '/') + ext)
            require(p.resolve() == p and sha(p) == pins[m], p)
            if name == 'root2':
                require(not p.samefile(root.with_name('root1') / p.relative_to(root)), 'shared local artifact ' + str(p))
    index_file = logs / 'SHA256.json'
    index = read(index_file)
    evidence = r['log_evidence'][name]
    require(sha(index_file) == evidence['command_log_index_sha256'], index_file)
    cmds = [(f'{i:03}-build', ['--no-cache','--wfail','build','+' + m + ':olean'], m) for i,m in enumerate(order)]
    cmds += [('all', ['--no-cache','--wfail','build'], None)]
    cmds += [(f'{i:03}-checker', ['env','leanchecker',m], m) for i,m in enumerate(order)]
    names = {stem + ext for stem, _, _ in cmds for ext in ('.log','.json')} | {'external-cache-links.json'}
    require(set(index) == names == {p.name for p in logs.iterdir() if p.name != 'SHA256.json'}, logs)
    for filename, digest in index.items():
        require(sha(logs / filename) == digest, logs / filename)
    axioms = {}
    peak = aggregate = 0
    for stem, args, module in cmds:
        rec = read(logs / (stem + '.json'))
        log = logs / (stem + '.log')
        raw = log.read_text()
        require(rec['command'] == [str(BIN / 'lake'), *args] and rec['cwd'] == str(root) and rec['exit'] == 0 and rec['resource_failure'] is None, log)
        require(rec['log_sha256'] == sha(log) and not re.search(r'\b(?:warning|error):',raw,re.I), log)
        require(0 < rec['peak_resident_bytes'] <= LIMIT and 0 <= rec['sampled_owned_peak_bytes'] <= rec['sampled_aggregate_peak_bytes'] <= LIMIT, log)
        peak = max(peak, rec['peak_resident_bytes'])
        aggregate = max(aggregate, rec['sampled_aggregate_peak_bytes'])
        if stem.endswith('-build'):
            require(re.search(r'\bBuilt ' + re.escape(module) + r'\s*\(', raw), log)
        if stem.endswith('-checker'):
            require(log.stat().st_size == 0, log)
        displayed = set()
        for line in raw.splitlines():
            if line.startswith('info: '):
                row = AXIOM.fullmatch(line)
                require(row is not None, line)
                key = row[1]
                used = sorted(s.strip() for s in (row[2] or '').split(',') if s.strip())
                require(key in EXPECTED and len(set(used)) == len(used) and set(used) <= ALLOWED and axioms.setdefault(key,used) == used, line)
                displayed.add(key)
        if stem.endswith('-build') and module == NS + 'Check':
            require(displayed == EXPECTED, 'incomplete Check audit')
        owner = f'taskT-helly-five-{root.parent.name}-{name}-{stem}'
        slots = rec['slots']
        require(rec['owner'] == owner and slots in ('A','B','AB'), owner)
        if module in (NS + 'PlanarTable', NS + 'UpperThreeTable'):
            require(slots == 'AB', owner)
        lock_events.append(('acquired',slots,owner))
        lock_events.extend(('released',s,owner) for s in reversed(slots))
    require(axioms == state['axioms'] and set(axioms) == EXPECTED, 'axiom receipts')
    require((len(cmds),peak,aggregate) == (evidence['commands'],evidence['max_command_peak_rss_bytes'],evidence['max_sampled_aggregate_peak_bytes']), evidence)
    return len(cmds)


def verify(receipt):
    r = read(receipt)
    require(r['status'] == 'MACHINE_PASS_PENDING_CLAUDE_FINAL', 'receipt status: ' + r['status'])
    dest = receipt.resolve().parent
    require(dest.parent == FORMAL / 'acceptance' and receipt.name == 'receipt.json', receipt)
    require(set(r['roots']) == set(r['log_evidence']) == {'root1','root2'} and r['roots']['root1'] == r['roots']['root2'], 'root agreement')
    links = bindings(r)
    events = []
    total = sum(check_root(dest / root, r, links, events) for root in ('root1','root2'))
    locks = dest / 'locks.log'
    require(sha(locks) == r['locks_log_sha256'] and total == 126, locks)
    rows = [line.split() for line in locks.read_text().splitlines()]
    require(all(len(row) == 4 and re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ',row[0]) for row in rows), locks)
    require([tuple(row[1:]) for row in rows] == events, 'lock history mismatches successful commands')
    return {'postcheck':'PASS','utc':subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip(),
            'receipt_sha256':sha(receipt),'modules_per_root':31,'commands':total,'heavy_tables_dual_slot':True,
            'external_package_count':len(r['dependency_commits']),'external_lib_entries':len(links),'axioms':r['roots']['root1']['axioms']}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('receipt', type=Path)
    try:
        print(json.dumps(verify(parser.parse_args().receipt), ensure_ascii=False))
    except (ValueError, OSError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        parser.exit(1, f'FAIL: {error}\n')
