"""Rebuild and replay the entire frozen five-point Helly proof twice on the Mac."""
from __future__ import annotations

import argparse
import ctypes
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
from contextlib import contextmanager

sys.dont_write_bytecode = True
FORMAL = Path(__file__).resolve().parent
TASKS = next(p for p in FORMAL.parents if p.name == 'codex-r3')
PHASE26 = TASKS / 'phase26/taskS'
sys.path.insert(0, str(PHASE26))
from accept import (ALLOWED, AXIOMS, BIN, PACKAGES, WORK, dependency_map, lean_code,
                    save, sha, utc)
from dev import support

NAMESPACE = 'TaskT.HellyFive'
CHECK = NAMESPACE + '.Check'
CHALLENGE = NAMESPACE + '.Challenge'
PROOF = NAMESPACE + '.Proof'
TARGETS = ('ExactHellyFive', 'ExactVertexFive')
EXPECTED = {NAMESPACE + '.' + prefix + t for prefix in ('Proof.', 'check_') for t in TARGETS}
PROJECT = WORK / 'research-lean-v434'
LOCK = WORK / 'tools/leanlock.sh'
RSS_LIMIT = 40_000_000_000
LIBPROC = ctypes.CDLL('/usr/lib/libproc.dylib', use_errno=True)
FROZEN = 'faf32ea5b217b5ffdd8602b5d5787ceac010b3ef682a64d691444e9ac9636d26'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def source_path(module):
    return Path(*module.split('.')).with_suffix('.lean')


def bindings():
    freeze = json.loads((FORMAL / 'FREEZE.json').read_text())
    require(freeze['targets'] == [NAMESPACE + '.' + t for t in TARGETS], 'wrong frozen goals')
    require(sha(FORMAL / source_path(CHALLENGE)) == FROZEN, 'frozen declaration drift')
    for rel, digest in freeze['pins'].items():
        require(sha(WORK.parent / rel) == digest, 'frozen artifact drift: ' + rel)
    manifest = PROJECT / 'lake-manifest.json'
    commits, external = {}, []
    for pkg in json.loads(manifest.read_text())['packages']:
        name = pkg['name']
        base = PACKAGES / name
        rev = subprocess.check_output(['git', '-C', base, 'rev-parse', 'HEAD'], text=True).strip()
        require(rev == pkg['rev'], 'package revision drift: ' + name)
        commits[name] = rev
        cache = base / '.lake/build/lib/lean'
        if cache.is_dir():
            external.append(cache)
    require(any((p / 'Mathlib.olean').is_file() for p in external), 'missing local Mathlib')
    return commits, external


def proof_closure():
    files, order = dependency_map(FORMAL, CHECK)
    require(CHALLENGE in files and PROOF in files, 'missing challenge or proof import')
    for module, path in files.items():
        require(module.startswith(NAMESPACE + '.'), 'unexpected local namespace: ' + module)
        require(not re.search(r'(?m)^\s*#eval\b', lean_code(path.read_text())), '#eval in ' + module)
    code = lean_code(files[CHECK].read_text())
    export = r'^\s*namespace\s+TaskT\.HellyFive\s+namespace\s+Challenge\s+export\s+TaskT\.HellyFive\s+\(ExactHellyFive\s+ExactVertexFive\)\s+end\s+Challenge\s*$'
    require(re.search(export, code, re.M), 'frozen namespace export missing')
    for target in TARGETS:
        scope = r'(?:(?:_root_\.)?TaskT\.HellyFive\.)?'
        witness = (rf'^\s*theorem\s+check_{target}\s*:\s*{scope}Challenge\.{target}'
                   rf'\s*:=\s*{scope}Proof\.{target}\s*$')
        require(len(re.findall(witness, code, re.M)) == 1, 'missing literal witness: ' + target)
    return files, order


def group_rss(pid):
    # Darwin rusage_info_v2 has a 16-byte UUID; slot 8 is ri_resident_size.
    pending, seen, total = [pid], set(), 0
    while pending:
        current = pending.pop()
        if current in seen:
            continue
        seen.add(current)
        usage = (ctypes.c_uint64 * 64)()
        if LIBPROC.proc_pid_rusage(current, 2, ctypes.byref(usage)) != 0:
            continue  # A short-lived subprocess may exit between enumeration and sampling.
        total += usage[8]
        children = (ctypes.c_int * 256)()
        n = LIBPROC.proc_listchildpids(current, children, ctypes.sizeof(children))
        if n > 0:
            pending.extend(q for q in children[:min(n, len(children))] if q > 0)
    return total or None


def memory_ok():
    # In the sandbox memory_pressure -Q
    # is available, while the sysctl pressure level and the global ps process table may be hidden.
    return support.pressure() < 4


@contextmanager
def command_slots(owner, receipts, heavy):
    start = time.monotonic()
    while time.monotonic() - start < 3600:
        if memory_ok():
            both = heavy or support.pressure() >= 2
            request = [LOCK, 'acquire-both'] if both else [LOCK, 'acquire', 'any']
            attempt = subprocess.run([*request, owner, '60'], capture_output=True, text=True)
            if attempt.returncode == 0:
                break
        time.sleep(3)
    else:
        raise RuntimeError('required Mac slots / sufficient memory unavailable for one hour')
    try:
        slots = attempt.stdout.strip()
        require(slots in ('A', 'B', 'AB'), 'unexpected lock claim')
        with receipts.open('a') as fp:
            fp.write(f'{utc()} acquired {slots} {owner}\n')
        yield slots
    finally:
        for slot in reversed(attempt.stdout.strip()):
            msg = subprocess.check_output([LOCK, 'release', slot, owner], text=True).strip()
            with receipts.open('a') as fp:
                fp.write(f'{utc()} {msg} {owner}\n')
            require(msg == 'released ' + slot, 'unexpected lock release')


def tracked(cmd, root, env, log, heavy=False):
    owner = f'taskT-helly-five-{root.parent.name}-{root.name}-{log.stem}'
    with command_slots(owner, root.parent / 'locks.log', heavy) as slots:
        return execute(cmd, root, env, log, owner, slots)


def execute(cmd, root, env, log, owner, slots):
    started, clock = utc(), time.monotonic()
    status, reason = None, None
    sampled_peak, aggregate_peak, pressure_since = 0, 0, None
    with log.open('w') as fp:
        proc = subprocess.Popen(cmd, cwd=root, env=env, stdout=fp, stderr=subprocess.STDOUT,
                                start_new_session=True)
        try:
            next_probe = clock
            next_pressure = clock
            while True:
                pid, status, usage = os.wait4(proc.pid, os.WNOHANG)
                if pid:
                    break
                now = time.monotonic()
                if now >= next_probe:
                    rss = group_rss(proc.pid)
                    if rss is not None:
                        sampled_peak = max(sampled_peak, rss)
                    own = rss or 0
                    others = {}
                    for slot in 'AB':
                        record = WORK / ('.lean-lock-' + slot) / 'owner.txt'
                        try:
                            holder = dict(re.findall(r'^(owner|pid): (.+)$', record.read_text(), re.M))
                            if holder.get('owner') not in (None, owner) and holder.get('pid', '').isdigit():
                                other_pid = int(holder['pid'])
                                others[other_pid] = group_rss(other_pid) or 0
                        except FileNotFoundError:
                            pass  # A neighboring task released its slot between the two reads.
                    aggregate_peak = max(aggregate_peak, own + sum(others.values()))
                    if aggregate_peak > RSS_LIMIT:
                        reason = 'active Mac Lean slot process trees exceeded 40 GB'
                    next_probe = now + 0.5
                if now >= next_pressure:
                    if memory_ok():
                        pressure_since = None
                    elif pressure_since is None:
                        pressure_since = now
                    next_pressure = now + 5
                if pressure_since is not None and now - pressure_since >= 60:
                    reason = 'sustained high host memory pressure for 60 seconds'
                if now - clock >= 3600:
                    reason = 'one-hour command limit'
                if reason:
                    os.killpg(proc.pid, signal.SIGKILL)
                    _, status, usage = os.wait4(proc.pid, 0)
                    break
                time.sleep(0.25)
        except BaseException:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            _, status, usage = os.wait4(proc.pid, 0)
            raise
        finally:
            if status is not None:
                proc.returncode = os.waitstatus_to_exitcode(status)
    peak = usage.ru_maxrss  # Darwin wait4 child-accounted maximum, bytes
    info = {'command': list(map(str, cmd)), 'cwd': str(root), 'slots': slots, 'owner': owner, 'start_utc': started, 'end_utc': utc(),
            'seconds': time.monotonic() - clock, 'exit': proc.returncode, 'peak_resident_bytes': peak,
            'sampled_owned_peak_bytes': sampled_peak, 'sampled_aggregate_peak_bytes': aggregate_peak, 'log_sha256': sha(log), 'resource_failure': reason}
    save(log.with_suffix('.json'), info)
    require(0 < peak <= RSS_LIMIT and proc.returncode == 0 and not reason, 'failed: ' + str(log))
    raw = log.read_text()
    require(not re.search(r'\b(?:error|warning):', raw, re.I), 'diagnostics: ' + str(log))
    return raw


def stage(root, logs, files, order, pins, caches):
    root.mkdir(exist_ok=False)
    require(not list(root.iterdir()), 'fresh root not empty')
    lib = root / '.lake/build/lib/lean'
    lib.mkdir(parents=True)
    links = {}
    for cache in caches:
        for p in sorted(cache.iterdir()):
            if not p.is_dir() and not p.name.endswith(('.olean', '.olean.private', '.olean.server',
                                                        '.ir', '.ir.sig', '.ilean')):
                continue
            require(p.name.split('.')[0] != 'TaskT' and p.name not in links, 'namespace collision: ' + str(p))
            (lib / p.name).symlink_to(p, target_is_directory=p.is_dir())
            links[p.name] = str(p)
    save(logs / 'external-cache-links.json', links)
    for name, p in files.items():
        out = root / source_path(name)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(p.read_bytes())
        require(sha(out) == pins[name], 'changed source: ' + name)
    (root / 'lean-toolchain').write_bytes((PROJECT / 'lean-toolchain').read_bytes())
    (root / 'lakefile.toml').write_text('name = "helly_five_replay"\ndefaultTargets = ["TaskT"]\n'
        'moreLeanArgs = ["-j1"]\n\n[leanOptions]\nwarningAsError = true\nautoImplicit = false\n'
        'relaxedAutoImplicit = false\n\n[[lean_lib]]\nname = "TaskT"\nroots = ' + json.dumps(order) + '\n')
    save(root / 'lake-manifest.json', {'version': '1.2.0', 'packagesDir': '.lake/packages', 'packages': [],
                                       'name': 'helly_five_replay', 'lakeDir': '.lake', 'fixedToolchain': False})
    return lib


def replay_root(root, files, order, pins, caches):
    logs = root.with_name(root.name + '-logs')
    logs.mkdir()
    lib = stage(root, logs, files, order, pins, caches)
    env = {'PATH': str(BIN) + ':/usr/bin:/bin:/usr/sbin:/sbin', 'HOME': os.environ['HOME'],
           'LC_ALL': 'C', 'LEAN_NUM_THREADS': '1', 'LEAN_PATH': os.pathsep.join(map(str, caches)),
           'LAKE_CACHE_DIR': str(root / '.isolated-cache'), 'LAKE_ARTIFACT_CACHE': 'false',
           'LAKE_RESTORE_ARTIFACTS': 'false', 'GIT_NO_LAZY_FETCH': '1', 'GIT_CONFIG_COUNT': '1',
           'GIT_CONFIG_KEY_0': 'protocol.allow', 'GIT_CONFIG_VALUE_0': 'never'}
    tables = {NAMESPACE + '.UpperThreeTable', NAMESPACE + '.PlanarTable'}
    axioms, modules = {}, {}
    for i, module in enumerate(order):
        print(f'{utc()} {root.name} {i + 1}/{len(order)} build {module}', flush=True)
        info = tracked([BIN / 'lake', '--no-cache', '--wfail', 'build', '+' + module + ':olean'],
                       root, env, logs / f'{i:03}-build.log', module in tables)
        require(re.search(r'\bBuilt ' + re.escape(module) + r'\s*\(', info), 'module not freshly built: ' + module)
        for line in info.splitlines():
            if line.startswith('info: '):
                diagnostic = re.fullmatch(r"info: (.+?):\d+:\d+: (.*)", line)
                match = AXIOMS.fullmatch(diagnostic[2]) if diagnostic else None
                require(match is not None, 'unexpected info output: ' + line)
                used = [a.strip() for a in (match[2] or '').split(',') if a.strip()]
                require(len(used) == len(set(used)) and set(used) <= ALLOWED, 'nonstandard axioms: ' + line)
                require(axioms.setdefault(match[1], sorted(used)) == sorted(used), 'inconsistent axiom audit')
        modules[module] = sha(lib / source_path(module).with_suffix('.olean'))
        if module == CHECK:
            actual = {k[1] for line in info.splitlines() if (k := re.fullmatch(
                r"info: TaskT/HellyFive/Check\.lean:\d+:\d+: '([^']+)' .*", line))}
            require(actual == EXPECTED, 'Check audit must print all four exact declarations: ' + str(actual))
    tracked([BIN / 'lake', '--no-cache', '--wfail', 'build'], root, env, logs / 'all.log')
    require(EXPECTED <= axioms.keys(), 'missing required axiom reports')
    for i, module in enumerate(order):
        print(f'{utc()} {root.name} {i + 1}/{len(order)} checker {module}', flush=True)
        out = tracked([BIN / 'lake', 'env', 'leanchecker', module], root, env, logs / f'{i:03}-checker.log', module in tables)
        require(out == '', 'unexpected kernel output: ' + module)
    return {'source_sha256': {m: sha(root / source_path(m)) for m in order}, 'olean_sha256': modules,
            'axioms': axioms, 'checker_count': len(order)}


def evidence(logs, order):
    records = sorted(logs.glob('*-build.json')) + sorted(logs.glob('*-checker.json')) + [logs / 'all.json']
    require(len(records) == 2 * len(order) + 1, 'command log count mismatch')
    maximum, aggregate = 0, 0
    for entry in records:
        run = json.loads(entry.read_text())
        require(run['exit'] == 0 and run['log_sha256'] == sha(entry.with_suffix('.log')), 'log drift: ' + str(entry))
        maximum = max(maximum, run['peak_resident_bytes'])
        aggregate = max(aggregate, run['sampled_aggregate_peak_bytes'])
    index = {p.name: sha(p) for p in sorted(logs.iterdir())}
    save(logs / 'SHA256.json', index)
    return {'commands': len(records), 'max_command_peak_rss_bytes': maximum,
            'max_sampled_aggregate_peak_bytes': aggregate,
            'command_log_index_sha256': sha(logs / 'SHA256.json')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', help='perform the two full Mac runs after author completion')
    args = parser.parse_args()
    commits, caches = bindings()
    print('Frozen artifacts and external package pins verified.', flush=True)
    files, order = proof_closure()
    pins = {m: sha(files[m]) for m in order}
    print(json.dumps(order, ensure_ascii=False), flush=True)
    if not args.run:
        return
    stamp = utc().replace(':', '') + f'-{os.getpid()}'
    dest = FORMAL / 'acceptance' / stamp
    dest.mkdir(parents=True, exist_ok=False)
    receipt = {'status': 'RUNNING', 'start_utc': utc(), 'order': order, 'dependency_commits': commits,
               'dependency_manifest_sha256': sha(PROJECT / 'lake-manifest.json'), 'source_sha256': pins,
               'toolchain': (PROJECT / 'lean-toolchain').read_text().strip(),
               'tools_sha256': {p: sha(BIN / p) for p in ('lean', 'lake', 'leanchecker')},
               'freeze_sha256': sha(FORMAL / 'FREEZE.json'), 'runner_dependencies_sha256':
               {str(p.relative_to(WORK)): sha(p) for p in (Path(__file__).resolve(), PHASE26 / 'accept.py',
                PHASE26 / 'dev.py', Path(support.__file__), LOCK, *(TASKS / 'phase17/taskH/mac-runtime-candidate04' / p
                for p in ('contract.py', 'canonical_original.py')))}, 'roots': {}, 'log_evidence': {}}
    print(dest / 'receipt.json', flush=True)
    save(dest / 'receipt.json', receipt)
    try:
        receipt['lean_version'] = subprocess.check_output([BIN / 'lean', '--version'], text=True).strip()
        require('version 4.34.1,' in receipt['lean_version'], 'toolchain version drift')
        for name in ('root1', 'root2'):
            result = replay_root(dest / name, files, order, pins, caches)
            receipt['roots'][name] = result
            receipt['log_evidence'][name] = evidence(dest / (name + '-logs'), order)
            save(dest / 'receipt.json', receipt)
        require(receipt['roots']['root1'] == receipt['roots']['root2'], 'root mismatch')
        require(pins == {m: sha(p) for m, p in files.items()}, 'source drift after replay')
        commits_after, _ = bindings()
        require(commits_after == commits, 'external packages changed during replay')
        receipt['locks_log_sha256'] = sha(dest / 'locks.log')
        receipt['status'] = 'MACHINE_PASS_PENDING_CLAUDE_FINAL'
    except BaseException as e:
        receipt.update(status='INCOMPLETE', failure=repr(e))
        raise
    finally:
        receipt['end_utc'] = utc()
        save(dest / 'receipt.json', receipt)


def interrupted(signum, frame):
    raise KeyboardInterrupt('received ' + signal.Signals(signum).name)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGHUP, interrupted)
    main()
