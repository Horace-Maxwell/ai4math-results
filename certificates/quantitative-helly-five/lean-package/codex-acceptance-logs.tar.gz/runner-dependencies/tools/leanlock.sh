#!/bin/zsh
# Lean lock slots A and B (shared by all agents). Never create or delete the
# lock directories by hand: use this script, which refuses to release a lock
# that someone else holds. Added on 2026-09-27 after a reviewer's `rm -rf`
# deleted slot A while the upgrade agent held it (playbook appendix A, lesson 53).
#
# Usage:
#   leanlock.sh acquire <A|B|any> <owner> [minutes]   take a free slot; prints the slot letter
#                                                     exit 1 if none is free (retry in 2-3 min)
#   leanlock.sh acquire-both <owner> [minutes]        take A and B together (jobs above ~12 GB)
#   leanlock.sh release <A|B> <owner>                 release, only if <owner> holds it
#   leanlock.sh status                                show who holds what
set -u
DIR=<workspace>/work
now() { date -u +%Y-%m-%dT%H:%M:%SZ }
take() {  # take <slot> <owner> <minutes>
  if mkdir "$DIR/.lean-lock-$1" 2>/dev/null; then
    printf 'owner: %s\npid: %s\nstart: %s\nexpected_minutes: %s\n' "$2" "$PPID" "$(now)" "$3" > "$DIR/.lean-lock-$1/owner.txt"
    return 0
  fi
  return 1
}
holder() { sed -n 's/^owner: //p' "$DIR/.lean-lock-$1/owner.txt" 2>/dev/null | head -1 }
case "${1:-}" in
  acquire)
    slot=${2:?slot}; owner=${3:?owner}; mins=${4:-30}
    if [ "$slot" = any ]; then
      for s in A B; do take $s "$owner" "$mins" && { echo $s; exit 0; }; done
    else
      take "$slot" "$owner" "$mins" && { echo "$slot"; exit 0; }
    fi
    echo "busy: A=$(holder A) B=$(holder B)" >&2; exit 1 ;;
  acquire-both)
    owner=${2:?owner}; mins=${3:-30}
    take A "$owner" "$mins" || { echo "busy: A=$(holder A)" >&2; exit 1; }
    take B "$owner" "$mins" || { rm -r "$DIR/.lean-lock-A"; echo "busy: B=$(holder B)" >&2; exit 1; }
    echo AB; exit 0 ;;
  release)
    slot=${2:?slot}; owner=${3:?owner}
    [ -d "$DIR/.lean-lock-$slot" ] || { echo "slot $slot is not held" >&2; exit 0; }
    h=$(holder "$slot")
    if [ "$h" != "$owner" ]; then
      echo "REFUSED: slot $slot is held by '$h', not by '$owner'. Never delete another agent's lock." >&2; exit 2
    fi
    rm -r "$DIR/.lean-lock-$slot"; echo "released $slot" ;;
  status)
    for s in A B; do
      if [ -d "$DIR/.lean-lock-$s" ]; then echo "$s: $(tr '\n' ' ' < "$DIR/.lean-lock-$s/owner.txt" 2>/dev/null)"; else echo "$s: free"; fi
    done ;;
  *) sed -n '2,15p' "$0"; exit 64 ;;
esac
