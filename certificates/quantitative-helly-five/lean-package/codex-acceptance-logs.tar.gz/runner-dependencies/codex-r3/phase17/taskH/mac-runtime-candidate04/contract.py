"""Static 717-source contract and exact Mac runtime identities; import has no effects."""
from pathlib import Path
import hashlib, json, re, graphlib, subprocess
from canonical_original import require, lean_code, canonical_prints

ROOT = Path('<workspace>')
PACKAGE = ROOT/'work/codex-r3/phase17/taskH/formal-original-allk-parallel-batch01'
BIN = ROOT/'work/toolchains/lean-4.34.1-darwin_aarch64/bin'
PROJECT = ROOT/'work/research-lean-v434'
LOCK = ROOT/'work/tools/leanlock.sh'
POLICY = ROOT/'work/codex-r3/phase12/paper5/final-package/verification-priority-v10/MEMORY-POLICY.json'
DEADLINE = '2026-11-20T18:13:40Z'
ORIGINAL_INVENTORY = PACKAGE.parent/'infrastructure-drafts/original-allk-current717-source-snapshot-candidate02/FULL-SOURCE-PATH-SHA-AND-LITERAL-IMPORT-INVENTORY.json'
ORIGINAL_INVENTORY_SHA = '2a938a83e93ca466bf807a27573cca03c4efc8f3441b9a88f3939a08e570c953'
TOOLS = {'lean':'1b370cfcbf44e80d1b004ab1b1ab9a4c73951f9f7c242140bcff9bc577576554',
         'leanchecker':'cfde41cb11dde58c84e9c60c551fd104bb2fc1104ad44dca932a923120272a35'}
ANCHORS = {
 'SOURCE-MANIFEST.json':'1cbc9edc262b044498d388e95bcacea55eef9cf84fb11cea010b82bea0e3f46a',
 'PROOF-FROZEN.json':'e681a58e0f3e973ca67a27a84d3884218bf77f7699330d883b8b3319368c527e',
 'FREEZE-REVIEW.json':'3afbad1012e44e192743485876f0ac3e81eab69ceef82228a0455b5fe49d327c',
 'PACKAGE-PINS-01.json':'f90b9a8d879da1c68e2f871dc6c7efee4f2e90662026fe40a306b114a2b902a4',
 'ORIGINAL-ALLK-CONTRACT-HEADS.json':'3569bef783f5c0f98f5c7c31d026760d1d3e078e2d218adf379066e82629d136'}
ALLOWED = {'propext','Classical.choice','Quot.sound'}
AXIOMS = re.compile(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", re.S)
FORBIDDEN = re.compile(r'\b(?:sorry|admit|sorryAx|native_decide|bv_decide|axiom|unsafe|implemented_by|extern)\b|\bdebug\.')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_text(encoding='utf8'))

def source_contract():
    for n,h in ANCHORS.items(): require(sha(PACKAGE/n)==h,('anchor drift',n))
    frozen=read(PACKAGE/'SOURCE-MANIFEST.json'); graph=frozen['source_import_closure']
    sm={n:h for n,h in frozen['files'].items() if n.startswith('src/')}
    expected=frozen['expected_axiom_prints_by_source']
    require(len(graph)==len(sm)==len(expected)==717,'source scope')
    require(sum(map(len,graph.values()))==1194,'edge scope')
    require(sum(map(len,expected.values()))==3960,'print scope')
    require(read(PACKAGE/'plan.json')=={'modules':graph},'original graph drift')
    require(set(p.relative_to(PACKAGE).as_posix() for p in (PACKAGE/'src').rglob('*.lean'))==set(sm),'source set')
    require(not list((PACKAGE/'src').rglob('*.olean')),'project prebuilt source')
    proof=read(PACKAGE/'PROOF-FROZEN.json'); review=read(PACKAGE/'FREEZE-REVIEW.json')
    require(proof['source_map']==review['source_map']==sm,'old source review scope')
    require(proof['source_manifest_sha256']==review['source_manifest_sha256']==ANCHORS['SOURCE-MANIFEST.json'],'source freeze identity')
    require(proof['freeze_review_sha256']==ANCHORS['FREEZE-REVIEW.json'] and review['decision']=='APPROVE_FREEZE','old freeze')
    order=list(graphlib.TopologicalSorter(graph).static_order())
    require(set(order)==set(graph),'missing local import')
    imports={}; canonical={}; externals=set(); files={}; hashes={}
    for m in order:
        rel=m.replace('.','/')+'.lean'; p=PACKAGE/'src'/rel; text=p.read_text(encoding='utf8')
        require(sha(p)==sm['src/'+rel],('source drift',m)); require(not FORBIDDEN.search(lean_code(text)),('forbidden source',m))
        im=re.findall(r'^\s*(?:public\s+)?import\s+([A-Za-z0-9_.]+)\s*$',text,re.M)
        require([x for x in im if x in graph]==graph[m],('local imports',m))
        raw=re.findall(r'^\s*#print\s+axioms\s+(\S+)\s*$',text,re.M)
        require(raw==expected[rel],('raw prints',m))
        cp=canonical_prints(text); require(len(cp)==len(raw),('canonical count',m))
        imports[m]=im; canonical[m]=cp; externals.update(x for x in im if x not in graph)
        files[m]=str(p); hashes[m]=sm['src/'+rel]
    require(sorted(externals)==sorted(frozen['external_fixed_import_names']),'exact frozen external allowlist')
    require(len(externals)==13 and all(x=='Mathlib' or x.startswith('Mathlib.') for x in externals),'Mathlib-only external scope')
    heads=read(PACKAGE/'ORIGINAL-ALLK-CONTRACT-HEADS.json')['records']
    require(len(heads)==7 and sum(len(r['heads']) for r in heads.values())==27,'7 contracts/27 heads')
    for name,old in heads.items():
        t=(PACKAGE/'src'/name).read_text(encoding='utf8'); starts=list(re.finditer(r'^theorem ([A-Za-z0-9_]+)',t,re.M))
        actual=[{'name':m.group(1),'raw_head':t[m.start():t.index(':=',m.end())]} for m in starts]
        require(starts and t[:starts[0].start()]==old['context'] and actual==old['heads'] and
                [l for l in t.splitlines() if l.startswith('#print')]==old['prints'],('original contract',name))
    packages=read(PACKAGE/'PACKAGE-PINS-01.json')['packages']; require(len(packages)==9,'nine packages')
    require(sha(ORIGINAL_INVENTORY)==ORIGINAL_INVENTORY_SHA,'original inventory drift')
    statements={x['relative_path']:x['source_sha256'] for x in read(ORIGINAL_INVENTORY)['sources'] if x['original9_statement_membership']}
    require(len(statements)==9 and all(sm['src/'+n]==h for n,h in statements.items()),'nine original statement bytes')
    return dict(schema='TASKH_MAC_717_PLAN_V1',purpose='Full frozen original all-k 717; machine evidence only',
                source_package=str(PACKAGE),source_manifest_sha256=ANCHORS['SOURCE-MANIFEST.json'],
                anchors=ANCHORS,modules=order,graph=graph,source_files=files,source_sha256=hashes,
                imports=imports,expected_axioms=canonical,external_allowlist=sorted(externals),
                original_contract_records=heads,original_contract_print_names=[n for f in heads for n in canonical[f[:-5].replace('/','.')]],original_statement_source_sha256=statements,
                original_inventory={'path':str(ORIGINAL_INVENTORY),'sha256':ORIGINAL_INVENTORY_SHA},
                packages=[{'name':x['name'],'head':x['head']} for x in packages],
                tools=TOOLS,deadline_utc=DEADLINE,expected_steps=2868,expected_prints_per_root=3960,
                roots=['normal','fresh'],attempt_limit=1,policy_sha256='c71f8103a1d85402654c90487aaeebd78caf4a62f969cc1aabbcb85781d71c81')

def log_result(path, expected, checker=False):
    raw=Path(path).read_bytes()
    if checker:
        require(raw==b'',('checker must be byte empty',str(path)))
        return dict(diagnostics=0,printed_names=[],axioms=[],axiom_outputs=0)
    text=raw.decode('utf8'); matches=list(AXIOMS.finditer(text))
    require(not AXIOMS.sub('',text).strip(),('unparsed compile output',str(path)))
    require([m.group(1) for m in matches]==expected,('ordered canonical prints',str(path)))
    rows=[]
    for m in matches:
        ax=[a.strip() for a in (m.group(2) or '').split(',') if a.strip()]
        require(len(ax)==len(set(ax)) and set(ax)<=ALLOWED,('nonstandard or duplicate axioms',m.group(1)))
        rows.append({'declaration':m.group(1),'axioms':sorted(ax)})
    return dict(diagnostics=0,printed_names=list(expected),axioms=rows,axiom_outputs=len(rows))

def package_heads():
    rows=[]
    for item in read(PACKAGE/'PACKAGE-PINS-01.json')['packages']:
        p=PROJECT/'.lake/packages'/item['name']
        head=subprocess.check_output(['/usr/bin/git','-C',str(p),'rev-parse','HEAD'],text=True,timeout=10).strip()
        require(head==item['head'],('package HEAD drift',item['name']))
        rows.append({'name':item['name'],'head':head})
    cache_layout()  # Nine HEADs remain mandatory; non-Mathlib caches may be unbuilt.
    return rows


def cache_layout():
    rows=[]
    for item in read(PACKAGE/'PACKAGE-PINS-01.json')['packages']:
        cache=PROJECT/'.lake/packages'/item['name']/'.lake/build/lib/lean'
        present=cache.exists() or cache.is_symlink()
        if present:
            require(cache.is_dir(),('existing cache is not a directory',item['name']))
            research=cache/'Research'
            require(not research.exists() and not research.is_symlink(),('project cache contamination',item['name']))
        require(item['name']!='mathlib' or (present and cache.is_dir()),'Mathlib cache must exist')
        rows.append({'name':item['name'],'path':str(cache.resolve()),'state':'present' if present else 'absent',
                     'is_directory':cache.is_dir(),'Research_present':(cache/'Research').exists() or (cache/'Research').is_symlink()})
    return rows
