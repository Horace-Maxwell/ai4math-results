"""Three unchanged helpers from audit_full_allk.py SHA 8fd97532f0ed6d0d1fe23799819ea65085621cc7e810a82967942ec9dd1d769a. No main or side effects."""
import re

def require(value, message):
    if not value:
        raise RuntimeError(message)

def lean_code(text):
    """Remove nested comments and string contents, preserving command lines."""
    result = []; i = 0; depth = 0; string = False
    while i < len(text):
        pair = text[i:i+2]; c = text[i]
        if depth:
            if pair == '/-': depth += 1; i += 2; continue
            if pair == '-/': depth -= 1; i += 2; continue
            result.append('\n' if c == '\n' else ' '); i += 1; continue
        if string:
            if c == '\\': result.extend('  '); i += 2; continue
            if c == '"': string = False
            result.append('\n' if c == '\n' else ' '); i += 1; continue
        if pair == '/-': depth = 1; i += 2; continue
        if pair == '--':
            end = text.find('\n', i)
            if end < 0: break
            result.append('\n'); i = end + 1; continue
        if c == '"': string = True; result.append(' '); i += 1; continue
        result.append(c); i += 1
    require(depth == 0 and not string, 'unclosed Lean comment/string in frozen source')
    return ''.join(result)

def canonical_prints(text):
    """Current sources print absolute TaskH names or names in their own namespace.

    Reject unsupported resolution instead of accepting arbitrary name suffixes.
    Section frames retain the enclosing namespace and are popped separately.
    """
    namespace = []; frames = []; result = []
    for line in lean_code(text).splitlines():
        command = line.strip()
        m = re.fullmatch(r'namespace\s+([A-Za-z0-9_.]+)', command)
        if m:
            frames.append((list(namespace), m[1]))
            if m[1].startswith('_root_.'): namespace = m[1][7:].split('.')
            else: namespace += m[1].split('.')
            continue
        m = re.fullmatch(r'(?:noncomputable\s+)?section(?:\s+([A-Za-z0-9_]+))?', command)
        if m:
            frames.append((list(namespace), m[1])); continue
        m = re.fullmatch(r'end(?:\s+([A-Za-z0-9_.]+))?', command)
        if m:
            require(frames, ('unmatched end', command))
            previous, name = frames.pop()
            require(m[1] is None or m[1] == name, ('mismatched namespace end', command, name))
            namespace = previous; continue
        m = re.fullmatch(r'#print\s+axioms\s+(\S+)', command)
        if m:
            name = m[1]
            if name.startswith('TaskH.'): result.append(name)
            else:
                require('.' not in name and namespace, ('unsupported print resolution', name, namespace))
                result.append('.'.join(namespace + [name]))
    require(not frames, 'unclosed namespace or section in frozen source')
    return result
