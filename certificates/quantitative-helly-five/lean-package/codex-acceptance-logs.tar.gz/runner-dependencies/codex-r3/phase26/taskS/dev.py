"""Task S uses the pinned toolchain and resource-controlled lock wrapper of Task R."""
from pathlib import Path
from importlib.util import spec_from_file_location, module_from_spec

HERE = Path(__file__).resolve().parent
prior = HERE.parents[1] / 'phase25/taskR/dev.py'
spec = spec_from_file_location('task_r_development', prior)
support = module_from_spec(spec)
spec.loader.exec_module(support)
BIN, WORK, PACKAGES = support.BIN, support.WORK, support.PACKAGES
local_slot, utc = support.local_slot, support.utc
