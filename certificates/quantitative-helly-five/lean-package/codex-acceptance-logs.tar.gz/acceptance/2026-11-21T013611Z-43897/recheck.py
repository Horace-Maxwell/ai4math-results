"""Read-only independent audit of the running acceptance runner's completed root(s)."""
from pathlib import Path
import hashlib, json, re, sys

run = Path(sys.argv[1]).resolve()
receipt = json.loads((run/'receipt.json').read_text())
formal = run.parent.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
order = receipt['order']
assert len(set(order))==len(order)==len(receipt['source_sha256'])
expected = set(receipt['source_sha256'])
queue = ['TaskT.HellyFive.Check']; observed=set()
while queue:
    name=queue.pop()
    if name in observed: continue
    observed.add(name)
    src = formal/Path(*name.split('.')).with_suffix('.lean')
    assert sha(src) == receipt['source_sha256'][name]
    queue.extend(x for x in re.findall(r'(?m)^import (TaskT\.[A-Za-z0-9_.]+)$',src.read_text()) if x not in observed)
assert observed == expected
assert receipt['source_sha256']['TaskT.HellyFive.Challenge'] == 'faf32ea5b217b5ffdd8602b5d5787ceac010b3ef682a64d691444e9ac9636d26'
locktext = (run/'locks.log').read_text()
results = {}
for name in ('root1','root2'):
    if name not in receipt['roots']: continue
    root=run/name
    logs=run/(name+'-logs')
    state=receipt['roots'][name]
    assert state['checker_count']==len(order)
    assert set(state['olean_sha256'])==expected
    assert state['source_sha256']==receipt['source_sha256']
    logs_index = json.loads((logs/'SHA256.json').read_text()); assert all(sha(logs/k)==v for k,v in logs_index.items())
    assert sha(logs/'SHA256.json') == receipt['log_evidence'][name]['command_log_index_sha256']
    full = ('TaskT.HellyFive.Proof.ExactHellyFive','TaskT.HellyFive.Proof.ExactVertexFive','TaskT.HellyFive.check_ExactHellyFive','TaskT.HellyFive.check_ExactVertexFive')
    checklines = (logs/f'{order.index("TaskT.HellyFive.Check"):03}-build.log').read_text().splitlines()
    reported=[]
    for line in checklines:
        if (match:=re.fullmatch(r"info: TaskT/HellyFive/Check\.lean:\d+:\d+: '([^']*)' depends on axioms: \[([^\]]*)\]",line)):
            assert set(match[2].split(', ')) <= {'propext','Classical.choice','Quot.sound'}
            reported.append(match[1])
    assert set(reported)==set(full) and len(reported)==4
    maxowned=agg=0
    def command(stem, argv):
        packet=json.loads((logs/(stem+'.json')).read_text()); raw=(logs/(stem+'.log')).read_text()
        assert packet['command'][1:]==argv and packet['cwd']==str(root) and packet['exit']==0
        assert not re.search(r'\b(?:warning|error):',raw,re.I)
        assert sha(logs/(stem+'.log'))==packet['log_sha256']
        slots=packet['slots']; owner=packet['owner']
        assert locktext.count(' acquired '+slots+' '+owner+'\n')==1
        for k in slots: assert locktext.count(' released '+k+' '+owner+'\n')==1
        assert 0<packet['peak_resident_bytes']<=40000000000 and packet['resource_failure'] is None
        assert packet['sampled_aggregate_peak_bytes']<=40000000000
        return raw,packet
    for i,module in enumerate(order):
        rel=Path(*module.split('.')); assert sha(root/rel.with_suffix('.lean'))==receipt['source_sha256'][module]
        assert sha(root/'.lake/build/lib/lean'/rel.with_suffix('.olean'))==state['olean_sha256'][module]
        out,p = command(f'{i:03}-build',['--no-cache','--wfail','build','+'+module+':olean']); assert 'Built '+module+' (' in out
        checker,k = command(f'{i:03}-checker',['env','leanchecker',module]); assert checker==''
        if module.endswith(('UpperThreeTable','PlanarTable')): assert p['slots']==k['slots']=='AB'
        maxowned=max(maxowned,p['sampled_owned_peak_bytes'],k['sampled_owned_peak_bytes'])
        agg=max(agg,p['sampled_aggregate_peak_bytes'],k['sampled_aggregate_peak_bytes'])
    aggregate,_ = command('all',['--no-cache','--wfail','build']); assert 'Build completed successfully' in aggregate
    assert (root/'.lake/build/lib/lean/Mathlib.olean').is_symlink()
    assert not (root/'.lake/build/lib/lean/TaskT').is_symlink()
    results[name]={'module_builds':len(order),'aggregate_lake_builds':1,'module_checkers':len(order),'four_axiom_reports':reported,'maximum_sampled_owned_bytes':maxowned,'maximum_sampled_total_bytes':agg}
if receipt['status']=='MACHINE_PASS_PENDING_CLAUDE_FINAL':
    assert set(results)=={'root1','root2'} and receipt['roots']['root1']==receipt['roots']['root2']
    assert sha(run/'locks.log')==receipt['locks_log_sha256']
print(json.dumps({'status':receipt['status'],'roots_reviewed':results},indent=2))
