# 五格点定量 Helly 两项冻结目标 · 交 Claude 跨族 FINAL

**2026-11-21T02:13:48Z，本地机器验收 2/2 通过。** Lean 4.34.1 和 Mathlib 4.34.1 在两个新空根重建了全部 31 个本题依赖模块，两次全库构建与 62 次逐模块 `lake env leanchecker` 全部退出 0。非作者同族源码审阅已通过。跨族 FINAL 由 Claude 安排。[机器收据](acceptance/2026-11-21T013611Z-43897/receipt.json) · [独立收据复核](acceptance/2026-11-21T013611Z-43897/postcheck.json) · [非作者源码审阅](continuation/INDEPENDENT-CODE-REVIEW.md)

## 冻结陈述与结果

| 冻结目标 | 本次证明的范围 | 对照 |
|---|---|---|
| ExactHellyFive | 每个正维数、正长度有限实凸集族，若公共格点恰为五个，确定仍保留五个公共格点所需子族大小的最小统一上界。 | [证明](TaskT/HellyFive/Proof.lean) · [逐条 Check](TaskT/HellyFive/Check.lean) |
| ExactVertexFive | 每个正维数，对恰含五个非极格点的格多胞体，确定可达到的最大极点数。包括非满维多胞体及边界非极点。 | [冻结定义](TaskT/HellyFive/Challenge.lean) · [冻结对照](SOURCE-CHECK.md) |

两项数值相同。维数 1、2、3 依次为 **2、7、18**，每个 n≥4 都是 **2^(n+1)+5**，例如四维为 **37**。`IsLeast` 同时证明可用和最优，`IsGreatest` 同时证明上界和达到。五个格点用 `encard = 5` 计数。原八项冻结绑定已逐一核实，[FREEZE.json](FREEZE.json) 对应的挑战文件 SHA-256 为 `faf32ea5b217b5ffdd8602b5d5787ceac010b3ef682a64d691444e9ac9636d26`。

## 四项缺口的去向

1. **整仿射搬运与达到。** 按坐标拼接四维空间与 r 维空间，证明实线性等价保持极点、与整数嵌入交换，逐层数出极点并辨认全部五个非顶点。由四维 37 个极点得到 37+32(2^r−1)。前三维使用实际格多胞体见证。[LiftAttainable](TaskT/HellyFive/LiftAttainable.lean) · [一维](TaskT/HellyFive/DimensionOne.lean) · [二维](TaskT/HellyFive/WitnessTwo.lean) · [三维](TaskT/HellyFive/WitnessThree.lean)
2. **各维上界。** 令 S 为多胞体内所有格点，X 为所有非极格点。同一模二类中的三个不同格点由其三个中点唯一确定。按余类计数给出 |S|≤2·2^n+C(|X|,3)，这在 n≥4 时已足够。三维用普通 `decide` 核验 792 个非降余类五元组，得 |S|≤23。二维对 1,024 个有标号五元组分类，借四个同类点的中点构型排除 |S|=13，得 |S|≤12。一维至多有两个实极点。[中点计数](TaskT/HellyFive/UpperCharge.lean) · [三维及以上](TaskT/HellyFive/UpperThree.lean) · [二维](TaskT/HellyFive/PlanarUpper.lean) · [二维构型排除](TaskT/HellyFive/PlanarObstruction.lean)
3. **从多胞体回到一般凸集族。** 取保留原五个公共格点的最小子族。每删去一个约束就出现新格点。把这些见证与原五点取凸包，在其中的有限格点集上扩张各约束，所得接触点两两不同，且都是新凸包的极点。新凸包至多有五个非极格点，总格点数恰为子族大小加五。因此多胞体总格点上界给出子族上界。反方向对可达多胞体逐一删去极点，产生迫使子族保留每个约束的例子。原凸集族允许无界和非闭。[上界转移](TaskT/HellyFive/UpperTransfer.lean) · [接触点计数](TaskT/HellyFive/UpperTransferCount.lean) · [下界转移](TaskT/HellyFive/LowerTransfer.lean)
4. **合成与核对。** 两条全维定理使用上述上下界。Check 内的 `Challenge` 通过 `export` 直接指向被冻结的原名，每条对照均按 `theorem check_X : Challenge.X := Proof.X` 编译。源码非作者另核了计数表、有限见证和量词。[非作者审阅与源码哈希](continuation/INDEPENDENT-CODE-REVIEW.md)

## 机器证据与复现

| 空根 | 实际命令时间（UTC） | 本题模块重编 | 全库构建 | 逐模块 checker | 单命令最大 RSS |
|---|---|---:|---|---:|---:|
| root1 | 2026-11-21T01:36:18Z 至 2026-11-21T01:58:30Z | 31/31 | 通过 | 31/31 | 14.01 GB |
| root2 | 2026-11-21T01:58:30Z 至 2026-11-21T02:13:44Z | 31/31 | 通过 | 31/31 | 14.01 GB |

126 条命令全部成功，编译零警告、零错误，62 份 checker 日志均为零字节。两个根分别生成的 31 份 `.olean` 逐字节相同。两条 Proof 与两条 check 在两个根中各自只依赖 `propext`、`Classical.choice`、`Quot.sound`。31 份本题源码的依赖扫描排除了 `sorry`、`axiom`、`native_decide`、`bv_decide` 等禁用项。只复用固定工具链和外部依赖缓存，九个外部包的提交及其可见路径均已核验，Mathlib 提交为 `d13f23b723b8a846827a245b89c10fc7d3f11612`。[首根日志索引](acceptance/2026-11-21T013611Z-43897/root1-logs/SHA256.json) · [第二根日志索引](acceptance/2026-11-21T013611Z-43897/root2-logs/SHA256.json) · [首根公理输出](acceptance/2026-11-21T013611Z-43897/root1-logs/030-build.log) · [第二根公理输出](acceptance/2026-11-21T013611Z-43897/root2-logs/030-build.log)

在本目录执行 `python3 -B accept.py --run` 可新建两根并复现全套验收。对本次保留的工件执行 `python3 -B continuation/verify_receipt.py acceptance/2026-11-21T013611Z-43897/receipt.json` 可独立复核 126 条命令、源文件、工件、日志、公理与取放锁记录。两张分类表的构建和核验均取双槽；全部命令均通过本机 leanlock.sh 取放自己的锁。[验收程序](accept.py) · [只读复核程序](continuation/verify_receipt.py) · [锁记录](acceptance/2026-11-21T013611Z-43897/locks.log)

## 交接边界

本次验证的对象是两个冻结的全维精确值。二维 7 和固定 k 的首阶渐近已有文献；此前查重尚未定位三维 18 与四维起精确公式的先证，首发性仍待审查。论文写作可直接采用这里给出的形式证明路线。正式发表前的跨族 FINAL 交由 Claude 安排。本任务只使用 Mac，本轮未执行外部写入或发布。[已有结果勘注](../PRIOR-ADDENDUM.md) · [独立文献检索](../../../prior/HELLY-PRIOR-INDEPENDENT.md)
