# 冻结前对齐

Averkov 等人 Definition 1 假设 m 为正，任意实凸集，公共整数点恰为 k；其定义给最小界。此合同固定 k=5，取所有 n≥1。commonGrid 用整数坐标而无边界限制；无穷集合的 encard 为无穷；选空子族时保留全部整数点。IsLeast 同时要求可用和最小，未预设有界性。原文多胞体定义容许非满维；凸包生成点可冗余，数的是实极点，其余格点包括边界非极点。IsGreatest 同时给上界和真正达到。两个原目标都在 Challenge；二维旧值只作范围闭合。[原文 Definition 1、Theorem 2、图 3](https://arxiv.org/pdf/1602.07839)
