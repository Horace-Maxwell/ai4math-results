# Cross-family FINAL review 02: five common lattice points, c(Z^n,5) (Task T, card TG01)

**Verdict: APPROVE_WITH_CHANGES.** There are no BLOCKER items and no MAJOR items.

The two frozen targets, `TaskT.HellyFive.ExactHellyFive` and `TaskT.HellyFive.ExactVertexFive`, faithfully state the values c(Z^n,5) and g(Z^n,5) from Averkov et al. (Definition 1, and the definition before Theorem 2). Both are fully Lean-verified: my independent rebuild compiled 36/36 modules, leanchecker passed 36/36, and the only axioms are propext, Classical.choice and Quot.sound. The claimed values 2, 7, 18 and 2^(n+1)+5 (n ≥ 4) are proved for every n ≥ 1.

My independent prior-work search found no publication that already gives c(Z^3,5)=18, g(Z^4,5)=37, the formula 2^(n+1)+5, or a general formula for c(Z^n,k) that covers k=5. So I raise no novelty MAJOR. One paywalled 2025 paper could not be read in full (MINOR 1). The changes requested below concern the write-up (ARGUMENT.md and the handoff) and attribution. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), reviewer 02 of two independent reviewers, running as a subagent of the user's Claude session. I wrote none of the reviewed files and did not read FINAL-CLAUDE-REVIEW-01.md.
- Review started 2026-11-21T03:20:49Z; report written after 2026-11-21T04:27:56Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/helly02/`.
- Lock owner `claude-final-helly-02`. I held slots A and B together (heavy tables) from 04:18:54Z to 04:27:44Z. Both were released, and `leanlock.sh status` then showed A and B free.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| TaskT/HellyFive/Challenge.lean (= FREEZE.json pin) | faf32ea5b217b5ffdd8602b5d5787ceac010b3ef682a64d691444e9ac9636d26 |
| TaskT/HellyFive/Check.lean | a5950fd9a2a89dd491272dea76649dfabf55d5c1e5c92994348e47e54422853a |
| TaskT/HellyFive/Proof.lean | 79ffcf5e085f74847f6ed642335e828723f43235a79bff232c41303b307556e9 |
| all 35 TaskT/HellyFive/*.lean, concatenated in `ls` order | 423df0cd4f63c160f354ded172d7d13f5bea7f2c74ad732b6990316e529efefd |
| FREEZE.json (= receipt `freeze_sha256`) | 88b93ce8c2166787a04e1c4ff66146d856323907ba821be40bc94f55da6b5a79 |
| FREEZE-REVIEW.md (= pin) | 8934d339116a4bd6ebf5f3727e44e967e1fa44e3e502a651c09d71525f79b9aa |
| SOURCE-CHECK.md (= pin) | 9311c8f805f094345820218616cfe2f2434dba93c7a48a53a378ade6b92cd315 |
| FINAL-HANDOFF.md | 2de38396a69830234165f908eab59d6d5063a4a844262ebb9cb3d17bfee2c8ef |
| acceptance/2026-11-21T013611Z-43897/receipt.json (= postcheck `receipt_sha256`) | 8959db302690a02eb5aa6613c549e0b64696710452a794b81ec8000cc9f6589e |
| ../ARGUMENT.md (= pin) | e7c5ea9407801754b5f5de5432d452210e41eb6ec001847095e2046d6c511c25 |
| ../ERRATA.md | 18ac906cde966a03bd12973bb08caaa8c2a5f46092c93b1e65438d1d07edd30a |
| ../PRIOR-ADDENDUM.md | 32577d7d7505261d9d2bbf2d842779bff5cca0390cc6cc750a07ea0af58202ba |
| prior/G1.md | 1895ccd5efe0aae70de7dbd903bd00b12c4213cfb78aa7b8475eb51a51da8538 |
| prior/HELLY-PRIOR-INDEPENDENT.md | 4964d741d3c42f5c32d1898dbf0abee5b9e9d2c2114096e6ee9de3b54380d6c7 |
| BRIEF.md / REPORT.md | b4937f54… / 974b7007… |
| arXiv 1602.07839v1 PDF (downloaded by me) | e1144bb1d3a639f1cb538641bb445844b3333a05635106a6514b700029512839 |
| arXiv 1512.07126v2 PDF (downloaded by me) | fc2c7de236707ab17c69f175aa58878797ca686507bfce63ebef9b34e482ee10 |
| arXiv 1405.2480v3 PDF (downloaded by me) | cf1ec516d8a8691f80473a80455102b2f4575200789ac83a6f20e9a5c79abaeb |
| my Audit02.lean (scratch) | 64e9630471e5ad58020a97f4677f09f10963bdfd11f1452d12a1983926ff4e36 |
| my witness_check.py (scratch) | dea460fc8b266db52a2771ccb318a9725010491633303803250dccf32ca7c12d |

Hash checks:
- All 8 FREEZE.json pins match the files on disk. These cover Challenge, SOURCE-CHECK, FREEZE-REVIEW, ARGUMENT, REVIEW-HELLY, and the three precompile receipt files.
- All 31 `source_sha256` entries in receipt.json match the current sources.
- The freeze was recorded at 01:11:55Z. The precompile receipt (01:10:41–01:11:05Z, rc=0, empty log) binds the same Challenge SHA.

Gaps in the materials:
- No `frozen/` folder, G2.md, SELECTION.md or `dev-logs/` exists for this task. The FREEZE.json pins and `receipts/` take their place.
- The receipt covers 31 modules. The four audit modules (`BridgeAudit`, `FiniteAudit`, `FiniteHellyLower`, `UpperTransferAudit`) are not in its closure. I compiled them myself (see §3).

## 1. Are the statements faithful to the source?

I extracted the source text myself from arXiv 1602.07839v1 (Averkov, González Merino, Henze, Paschke, Weltge; the journal version, Adv. Appl. Math. 89 (2017) 76–101, lists Schymura instead of Henze).

- **c(S,k).** Definition 1 defines c(S,k) as the smallest t ∈ N0 such that: "If convex sets C1, . . . , Cm (m ∈ N) have exactly k points of S in common, then there exists a subset I of {1, . . . , m} with at most t elements such that the sets Ci with i ∈ I already have exactly k points of S in common."
  - `PreservesFive n t` quantifies over every `m > 0` and every indexed family `C : Fin m → Set (Fin n → ℝ)` of convex sets.
  - The families may repeat sets, and the sets may be unbounded, non-closed or lower-dimensional.
  - The common lattice points are `commonGrid C s = {z : Fin n → ℤ | ∀ i ∈ s, embed z ∈ C i}`, where `embed` is the coordinatewise cast ℤ → ℝ.
  - "Exactly five" is `encard = 5`. An infinite set has `encard = ⊤ ≠ 5`, so no `Nat.card`/`ncard` 0-default can make the condition hold spuriously.
  - The empty subfamily is allowed. It gives all of Z^n, which is infinite and therefore never counts as five; this matches the paper's note that the empty intersection is the whole space.
  - `IsLeast {t | PreservesFive n t} (value n)` states both that `value n` works and that it is minimal. This is the paper's "smallest number t".
  - The −∞ case cannot occur: a segment containing five lattice points exists in every dimension n ≥ 1.
  - Vacuity is excluded: the minimality half is a real lower bound, proved from actual witnesses.
- **g(S,k).** The paper defines g(S,k) := max{|vert(P)| : P ∈ P(S), |S ∩ P \ vert(P)| = k}, where P(S) is the set of polytopes P with vert(P) ⊆ S, of any dimension.
  - `attainableCounts n` ranges over `convexHull ℝ (embed '' V)` for finite `V ⊆ Z^n`. This is exactly P(Z^n): redundant generators are allowed, and lower-dimensional polytopes are included.
  - It counts `extremePoints` (the true vertices) and the lattice points of P that are not extreme points (boundary non-vertices included). Both counts use `encard`.
  - `IsGreatest` gives both attainment and the upper bound.
- **Values.** `value n` is 2, 7, 18 for n = 1, 2, 3 and 2^(n+1)+5 otherwise. The n = 0 branch is outside the quantifier `0 < n`. My Audit02 also checks by `decide` that value 1, 2, 3, 4 = 2, 7, 18, 37.
- **Consistency with known values.**
  - n = 2: c(Z^2,5) = 7 is in Averkov et al. Figure 3 (g = c for k ≤ 30) and in CHZ §5 (Lemma 5.2: "c(2, 5) ≤ 7", with the matching example). OEIS A298755 and A298562 both list 7 at k = 5.
  - n = 1: g(Z,k) = 2 for every k, so the recursion (5) of Theorem 2 gives c = 2.
  - n ≥ 3: Theorem 5 gives c(Z^n,4) = 2^(n+1). The new g(Z^n,5) exceeds c(Z^n,4) − 1, so by (5), c(Z^n,5) = g(Z^n,5). This is consistent with the two targets having the same value, and Lean proves the c-side directly in any case.
- **Small cases tested with my own code.** `witness_check.py` parses the vertex lists directly from the Lean files. It uses two independent methods, both agreeing everywhere:
  - (A) qhull facets, each re-derived as an exact integer inequality and checked exactly on every generator, with vertices identified as the points whose tight-facet normals have full rank;
  - (B) HiGHS LP tests for vertex status and hull membership over the whole bounding box.

  | Polytope | Dimension | Facets | Vertices | Lattice points | Non-vertex lattice points |
  |---|---|---|---|---|---|
  | 2D witness | 2 | 7 | 7 | 12 | 5 |
  | 3D witness | 3 | 17 | **18** | 23 | 5: (0,0,0), (0,0,1), (0,1,0), (1,0,0), (1,1,0), equal to Lean `centers` |
  | 4D witness | 4 | 30 | **37** | 42 | 5: 0 and the four unit vectors, equal to Lean `centers` |
  | Q+ | 4 | 8 | 16 | 16 | 0 |
  | Q− | 4 | 14 | 16 | 16 | 0 |
  | Lifted polytope T, n = 5 | 5 | 57 | 69 = 2^6+5 | 74 | 5 |
  | Lifted polytope T, n = 6 | 6 | 103 | 133 = 2^7+5 | 138 | 5 |

  Notes on the table:
  - Q+ ∩ Q− is exactly the five centres.
  - T is built from the Lean `seeds` construction. In both lifted cases the non-vertex points are exactly the 4D centres padded with zeros.
  - I also recomputed the parity-capacity tables behind the upper bound. Over all multisets of five residues, the maximum of Σ_r cap(w_r) is 13 for n = 2 (Lean then removes 13 geometrically), 23 for n = 3 (tight: 18 + 5), and 42 = 37 + 5 for n = 4.

## 2. Is the proof chain clean?

- **Check.lean.** Inside `namespace Challenge` it does `export TaskT.HellyFive (ExactHellyFive ExactVertexFive)`, so `Challenge.X` is the frozen constant itself. It then has exactly `theorem check_ExactHellyFive : Challenge.ExactHellyFive := Proof.ExactHellyFive`, the same for `ExactVertexFive`, and 4 `#print axioms`.
  - No other file defines `ExactHellyFive`, `ExactVertexFive`, `value`, `PreservesFive`, `attainableCounts`, `commonGrid` or `embed`.
  - `Proof.ExactHellyFive` lives in `TaskT.HellyFive.Proof` and is typed explicitly as `TaskT.HellyFive.ExactHellyFive`. Nothing shadows a frozen name.
- **Audit02.lean (mine).** It states both targets fully unfolded and fully qualified, with `PreservesFive`, `commonGrid`, `embed`, `attainableCounts` and `value` written out inline. Both are closed by `TaskT.HellyFive.Proof.ExactHellyFive` / `ExactVertexFive`. It also has `example`s for both `check_*` theorems.
- **Forbidden constructs.** I grepped all 35 files for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, initialize, run_cmd and ofReduceBool. There are no hits.
  - `set_option` appears only as `maxRecDepth 100000` and `maxHeartbeats 0`, in the eight data/table/witness files (WitnessTwo/Three/Four, CorePositive/Negative, PlanarData/Table, UpperThreeData/Table). These are resource limits only.
  - The only attributes are two `@[simp]` lemmas in FiniteGeometry (`linearRow_apply`, `linearRow_embed`).
- **`decide`.** All uses are ordinary kernel `decide`, about 70 occurrences in 20 files. The substantive ones are:
  - the witness checks (card, bounds, exposing rows, midpoint pairs, box exclusion over `Fin 3 → Fin 4` and the 4D box);
  - `UpperThreeTable.sorted_table`, which covers all 792 sorted 5-tuples of `Fin 8`;
  - `PlanarTable`, the 2D 5-tuple classification;
  - `PlanarObstructionCross` and small arithmetic facts.
- **Proof structure.**
  - (a) LowerTransfer: for an attainable polytope with t vertices, delete one extreme point per set. A preserving subfamily must then keep every index, so any admissible bound is ≥ t.
  - (b) UpperTransfer: take a minimum preserving subfamily, take one witness lattice point per index, and form the finite hull "box". UpperTransferMaximal/Count then extend each constraint maximally within the box. This yields distinct contact points that are extreme points of a lattice polytope with at most five non-vertex lattice points.
  - (c) `PolyBound n b` says every lattice polytope with ≤ 5 non-vertex lattice points has at most b + 5 lattice points in total. This is the right strengthening (equation (6) of the paper).
  - (d) Upper bounds:
    - `all_dimensional_bound`: |S| ≤ 2·2^n + C(|X|,3), for any X. Each parity class of size m spends C(m,3) of the midpoint triples of X (whose sum ≡ r), using `recover_triangle`, and m ≤ 2 + C(m,3).
    - n = 3: the capacity table.
    - n = 2: the table plus the obstruction that excludes |S| = 13.
    - n = 1: at most 2 extreme points.
  - (e) Attainment: actual witnesses for n = 1, 2, 3, and for n ≥ 4 the product-layer lift (FiberProjection, LiftLayers, LiftAttainable) giving 37 + 32(2^r − 1).
- **Axioms.** In my build, `Proof.ExactHellyFive`, `Proof.ExactVertexFive`, `check_ExactHellyFive` and `check_ExactVertexFive` depend only on `[propext, Classical.choice, Quot.sound]`. This holds in Check and in Audit02, and it matches Codex's logs. In the audit modules, every printed lemma has the same three axioms or fewer (`recover_vertex`: propext and Quot.sound only).

## 3. Independent rebuild on this Mac

- **Setup.**
  - I copied the 35 sources (byte-identical, checked with `cmp`) to a new empty scratch `src/` and added `Audit02.lean`.
  - I did not use lake or any Codex build product.
  - Each module was compiled with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o out/....olean`, in topological order. `LEAN_PATH` was my `out/` plus the prebuilt package oleans under `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
  - `leanchecker <module>` ran after each successful compile. Only one Lean process of mine ran at a time.
- **Toolchain.** Lean 4.34.1, commit 5045d0056413266e57c625dcd7c365b10e377c52. Mathlib `git rev-parse` gives d13f23b723b8a846827a245b89c10fc7d3f11612, which equals `receipt.dependency_commits`.
- **Result.**
  - 36/36 modules compiled with rc 0: the 31 in the receipt, the 4 audit modules and Audit02. There were 0 errors and 0 warnings.
  - leanchecker returned rc 0 with empty output for all 36.
  - The largest RSS was 13.76 GB (UpperThreeTable, 62.6 s), then 12.45 GB (PlanarTable, 56.9 s). Every other module took ≤ 26 s and ≤ 8.2 GB.
  - The wall time with both slots held was 04:18:54Z–04:27:44Z.
- I did not re-run `accept.py` (the two-root lake replay). I relied on my own plain-`lean` rebuild, and I cross-checked the receipt only by its source hashes and the postcheck hash.

## 4. Mathematics, attribution and novelty

### 4a. Independent prior-work search (special focus)

What I searched, 2026-11-21:
- **Paper texts.** arXiv full text of 1602.07839, 1512.07126 and 1405.2480, plus 1706.05975 (De Loera–Goaoc–Meunier–Mustafa survey), 2008.06013 (Dillon) and 1603.05525.
- **Citing works.** OpenAlex citing works of all three papers (W2278042759: 12; W2212143440: 6; W1947254580: 20; no date limit, with abstracts). Semantic Scholar citations of the same three papers (13 / 7 / 26).
- **arXiv API** queries: abs:Doignon; "quantitative" AND "Helly"; "exactly k integer points"; "non-vertex lattice points"; and author searches.
- **zbMATH Open** queries: "quantitative Doignon", "discrete quantitative Helly", "quantitative Helly lattice".
- **Crossref.**
- **OEIS**: the strings 2,7,18,37,69; 7,18,37,69,133; 2,7,18,37; 7,18,37; "quantitative Helly".
- **GitHub** repository and issue search.
- **Several general web searches**, including "c(Z^n,5)", "2^{n+1}+5", "maximum vertices lattice polytope five non-vertex", theses (Paschke) and 2025–2026 work.

Every hit, with its exact relevant statement:

1. **Averkov et al., arXiv 1602.07839 / AAM 2017.**
   - Theorem 5 (n ≥ 2): "c(Zn, 0) = 2n, c(Zn, 1) = c(Zn, 2) = c(Zn, 3) = 2n+1 − 2 and c(Zn, 4) = 2n+1".
   - Figure 3: g(Z^2,k) = c(Z^2,k) for k ≤ 30. The text notes a drop at "k ∈ {5, 8, 11, 22, 28} (for the case k = 5 see also [13])".
   - This gives k ≤ 4 for all n, and k = 5 only for n = 2. There is nothing for n ≥ 3 at k = 5.
   - Open question 3 asks whether c(Z^n,k) > g(Z^n,k) can ever happen. The new result shows c = g also at k = 5 for every n, which is a data point but not a resolution.
2. **Chestnut–Hildebrand–Zenklusen, arXiv 1512.07126 / SIDMA 2018.**
   - Corollary 3.13: "If 1 ≤ k ≤ n, then 2n+1 − k ≤ c(n, k) ≤ c(k − 1, k) + 2(2n − 2)", and "|c(n, k) − 2n+1| = O(1), for each fixed k".
   - §5 proves c(2,5) = 7 < 8 = c(2,4).
   - For k = 5 this gives only 2^(n+1) − 5 ≤ c(n,5) ≤ c(4,5) + 2^(n+1) − 4 for n ≥ 5, with c(4,5) unknown there. There is no exact value for n ≥ 3. PRIOR-ADDENDUM already attributes the fixed-k asymptotics and c(2,5) = 7 to this paper; that attribution is correct.
3. **Aliev–Bassett–De Loera–Louveaux, arXiv 1405.2480 / Combinatorica.**
   - They prove c(n,1) = 2(2^n − 1) and state: "It is an interesting problem to find exact values of c(n, k) for k ≥ 2."
   - The paper has no k = 5 values.
4. **Huicochea–Navarro, "Midpoints of Vertex Pairs of Convex Polytopes", SIAM J. Discrete Math. 39(3) (2025) 1806–1825, DOI 10.1137/24M1714496.**
   - It cites all three papers. Its abstract says it "improves the lower bounds obtained by Chestnut, Hildebrand, and Zenklusen" on midpoint counts and that "our results have an application in a quantitative Helly-type theorem".
   - The full text is paywalled (SIAM 403), there is no arXiv version, and the zbMATH review is unavailable. I could not read the application. From the abstract it is a midpoint-count (asymptotic) improvement, so an exact c(Z^n,5) formula is unlikely but **not excluded by me**. See MINOR 1.
5. **Other citing works.** I checked the abstracts of Dillon 2021 (boxes), Ambrus–Balko–Frankl–Jung–Naszódi 2023 (exponential lattices), "Bounds on the lattice point enumerator via slices and projections" (2021), the Mélange/diameter paper, "Tverberg theorems over discrete sets", Averkov–Codenotti–Freyer–Huang 2026 (flatness), and Arun–Dillon (product sets). None concerns exact c(Z^n,k) for k ≥ 5.
6. **OEIS, GitHub, zbMATH.**
   - OEIS has no sequence containing 2,7,18,37 or 7,18,37,69,133 in this sense. A298562 and A298755 are 2D only.
   - The single GitHub repository hit, achemperety/helly-lattice-geometry, is about counting triangle intersections. It is unrelated.
   - zbMATH lists nothing beyond the items above.

**Conclusion.** I found no prior publication of c(Z^3,5) = 18, c(Z^4,5) = 37, c(Z^n,5) = 2^(n+1)+5, or a general c(Z^n,k) formula covering k = 5, so I raise no MAJOR. The general bound "total lattice points ≤ 2^(n+1) + C(k,3)" (Lean `all_dimensional_bound`) was not found in this form either. As already noted in the drafts, CHZ use the same parity-midpoint idea with sumset bounds. My search has the usual limits: Google Scholar, MathSciNet and paywalled full texts were not reachable, and unpublished work cannot be seen.

### 4b. The write-up (ARGUMENT.md, ERRATA, PRIOR-ADDENDUM, FINAL-HANDOFF)

- **Correctness.**
  - The recursion (5) is now quoted correctly (ERRATA).
  - The n ≥ 4 construction, the Q± kernels and the 3D witness are correct; I verified them myself (§1).
  - The written 3D and high-dimensional upper-bound proofs in ARGUMENT.md, a case analysis over collinear triples and parallelograms, are **not the proofs that Lean checks**. Lean uses the simpler parity-capacity argument: a C(5,3) budget for n ≥ 4, a 792-tuple table for n = 3, and a table plus an obstruction for n = 2. The written case analysis therefore carries no formal credit (MINOR 2).
- **"First" and overclaiming.**
  - Neither ARGUMENT.md nor FINAL-HANDOFF claims "first". FINAL-HANDOFF says priority is "still under review" (首发性仍待审查).
  - ARGUMENT.md says the three numbered open problems are not resolved; that is correct.
  - ARGUMENT says "二维 7 已见原文图 3" (the planar 7 already appears in Figure 3 of the source). It should also credit CHZ Lemma 5.2. PRIOR-ADDENDUM does credit CHZ, but the main text does not (MINOR 3).
- **What is not in Lean.** The asymptotic remark c(n,k)/2^n → 2 (in "更一般的旁证", the general side remark) is not formalized and is prior work (CHZ). The bound g(n,k) ≤ 2^(n+1) + C(k,3) is only partly in Lean (MINOR 4).
- **Author list.** The v1/journal difference (Henze vs Schymura) is handled correctly in HELLY-PRIOR-INDEPENDENT. The paper must cite the journal author list.

## Numbered MINOR fixes

1. Before publication, have the user (or someone with SIAM access) read the "application to a quantitative Helly-type theorem" in Huicochea–Navarro, SIDMA 39 (2025) 1806–1825. Confirm it gives no exact c(Z^n,5) or c(Z^3,5). Cite it as related work in either case.
2. Replace the 3D and n ≥ 4 upper-bound text in ARGUMENT.md with the route that is actually formalized, or mark the case analysis as an informal alternative not covered by Lean. The formalized route is: lattice points of the same parity class spend midpoint triples of X; with m ≤ 2 + C(m,3) this gives |S| ≤ 2^(n+1) + C(5,3) for n ≥ 4; n = 3 uses the 792-tuple capacity table (≤ 23); n = 2 uses the table plus the 13-exclusion. The formal route is shorter and fully checked.
3. In ARGUMENT.md "最终表述" (final statement) and the paper, attribute c(Z^2,5) = 7 to both Chestnut–Hildebrand–Zenklusen (§5, Lemma 5.2) and Averkov et al. (Figure 3).
4. In ARGUMENT.md "更一般的旁证" (general side remark), mark explicitly which parts are outside Lean:
   - The limit c(n,k)/2^n → 2 follows from CHZ Corollary 3.13 and is not formalized.
   - For g(n,k) ≤ 2^(n+1) + C(k,3), only the lattice-point count bound (`all_dimensional_bound`, any X) is in Lean. The statement in terms of g, for general k, is not.
5. In the paper, mention that the result gives c(Z^n,5) = g(Z^n,5) for all n. This extends the evidence for open question 3 of Averkov et al. (no counterexample at k = 5), but must not be described as resolving it.
6. The receipt's 31-module closure omits the four audit modules (BridgeAudit, FiniteAudit, FiniteHellyLower, UpperTransferAudit). They compile and check cleanly in my build. Either add them to the acceptance list or state that they are auxiliary.
7. ARGUMENT.md describes the lift in the affine lattice L = {Σx_i = 1} ⊂ Z^5, while Lean (and my check) uses direct Z^4 coordinates. Add one sentence saying the two are integrally affinely equivalent, so the paper's coordinates match the Lean witness lists.
