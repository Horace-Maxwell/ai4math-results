# Cross-family FINAL review 01: discrete quantitative Helly number for five lattice points (Task T, helly-five)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The frozen targets `TaskT.HellyFive.ExactHellyFive` and `TaskT.HellyFive.ExactVertexFive` match Averkov et al.'s Definition 1 (c(S,k)) and the g(S,k) defined before their Theorem 2, at S = Z^n and k = 5. The claimed n = 2 value 7 agrees with the source's Figure 3 and its text. Both targets are fully Lean-verified: standard axioms only, and my independent rebuild and leanchecker run pass. The MINOR items concern the write-up and attribution only. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), reviewer 01 of two, a subagent of the user's Claude session. I wrote none of the reviewed files. I did not read FINAL-CLAUDE-REVIEW-02.md.
- Review started 2026-11-21T03:20:49Z. Report written after 2026-11-21T03:34:12Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/helly01/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| TaskT/HellyFive/Challenge.lean (= FREEZE.json pin) | faf32ea5b217b5ffdd8602b5d5787ceac010b3ef682a64d691444e9ac9636d26 |
| TaskT/HellyFive/Proof.lean | 79ffcf5e085f74847f6ed642335e828723f43235a79bff232c41303b307556e9 |
| TaskT/HellyFive/Check.lean | a5950fd9a2a89dd491272dea76649dfabf55d5c1e5c92994348e47e54422853a |
| The other 32 TaskT/HellyFive/*.lean | listed in scratch `src-sha.txt`. All 31 files in Check's import closure equal `receipt.json.source_sha256` (31/31) and are byte-identical to `acceptance/.../root1` and `root2` |
| FREEZE.json | 88b93ce8c2166787a04e1c4ff66146d856323907ba821be40bc94f55da6b5a79 |
| FREEZE-REVIEW.md (= pin) | 8934d339116a4bd6ebf5f3727e44e967e1fa44e3e502a651c09d71525f79b9aa |
| SOURCE-CHECK.md (= pin) | 9311c8f805f094345820218616cfe2f2434dba93c7a48a53a378ade6b92cd315 |
| ../ARGUMENT.md (= pin) | e7c5ea9407801754b5f5de5432d452210e41eb6ec001847095e2046d6c511c25 |
| ../../../prior/REVIEW-HELLY.md (= pin) | a0ff9a7ec79ebeeb643194e0f6f7282c5fff34669c4fabd03075eac5f07354d9 |
| ../ERRATA.md | 18ac906cde966a03bd12973bb08caaa8c2a5f46092c93b1e65438d1d07edd30a |
| ../PRIOR-ADDENDUM.md | 32577d7d7505261d9d2bbf2d842779bff5cca0390cc6cc750a07ea0af58202ba |
| ../REVIEW-INDEX.md | 18b808ed2d3969e770113f6afb65f70438aa6d57962b91cadf34a247dbea0ad6 |
| ../../../prior/G1.md | 1895ccd5efe0aae70de7dbd903bd00b12c4213cfb78aa7b8475eb51a51da8538 |
| ../../../prior/HELLY-PRIOR-INDEPENDENT.md | 4964d741d3c42f5c32d1898dbf0abee5b9e9d2c2114096e6ee9de3b54380d6c7 |
| ../../../BRIEF.md | b4937f54f7971a412147232bbdfbde1351403079519f9c5245ae14197da3a2c9 |
| ../../../REPORT.md | 974b7007ea2c6fc46571bac9c99184dd458181b21c0d169057b5bdb114dfd513 |
| FINAL-HANDOFF.md (= DONE) | 2de38396a69830234165f908eab59d6d5063a4a844262ebb9cb3d17bfee2c8ef |
| acceptance/2026-11-21T013611Z-43897/receipt.json (= DONE) | 8959db302690a02eb5aa6613c549e0b64696710452a794b81ec8000cc9f6589e |
| acceptance/.../postcheck.json (= DONE) | babb9d052c16f13bc2fd678bf098bdc80f96cd17b0065396092013ee75b8dc82 |
| continuation/INDEPENDENT-CODE-REVIEW.md (= DONE) | 2c5bc27e870995bcb2a1029c60e9420617adae47b215f0c8633d74ab6a6b1751 |
| arXiv 1602.07839v1 PDF (downloaded by me) | e1144bb1d3a639f1cb538641bb445844b3333a05635106a6514b700029512839 |
| arXiv 1405.2480v3 PDF (downloaded by me) | cf1ec516d8a8691f80473a80455102b2f4575200789ac83a6f20e9a5c79abaeb |
| My Audit/HellyAudit.lean (scratch) | 4e7b12ad8a2ec754a0012a8ab7646eeb79e9451c112db918f956356512f370ba |

All eight FREEZE.json pins recompute correctly. There is no `frozen/` snapshot directory. The freeze is recorded only as the pinned hash plus the zero-diagnostic precompile receipt `receipts/20261121T011041Z-Challenge-17618.*`, which is also pinned. The four files outside Check's closure (BridgeAudit, FiniteAudit, FiniteHellyLower, UpperTransferAudit) are historical audit modules.

## 1. Are the statements faithful to the source?

I extracted the text of arXiv 1602.07839v1 and arXiv 1405.2480v3 myself. Crossref gives the journal version as Averkov, González Merino, Paschke, Schymura, Weltge, *Adv. Appl. Math.* 89 (2017) 76–101. arXiv v1 lists Henze in place of Schymura.

- **c(S,k).** Source Definition 1: c(S,k) is "the smallest number t ∈ N0" such that "If convex sets C1,…,Cm (m ∈ N) have exactly k points of S in common, then there exists a subset I of {1,…,m} with at most t elements such that the sets Ci with i ∈ I already have exactly k points of S in common." Here N = {1,2,…} (source §1). Lean's `PreservesFive n t` quantifies over every m with `0 < m` and every `C : Fin m → Set (Fin n → ℝ)` with each `C i` convex. The hypothesis is `(commonGrid C univ).encard = 5`, and the conclusion is `∃ s : Finset (Fin m), s.card ≤ t ∧ (commonGrid C s).encard = 5`. `ExactHellyFive` is `IsLeast {t | PreservesFive n t} (value n)` for every n > 0. This matches the definition exactly:
  - Families are finite, as in the source. Infinite families would make the number ∞.
  - Sets may repeat, and may be unbounded, non-closed or lower-dimensional.
  - The count is "exactly", not "at least". `encard` is a true cardinality, and an infinite set has `encard = ⊤ ≠ 5`.
  - The empty subfamily is allowed, as in the source. Its common set is all of Z^n, so it can never qualify.
  - `IsLeast` gives both feasibility and minimality. The source's degenerate values −∞ and ∞ do not arise: Lean proves a finite least element exists.
- **g(S,k).** The source defines g(S,k) = max{|vert(P)| : P ∈ P(S), |S ∩ P \ vert(P)| = k}, with P(S) the polytopes whose vertices lie in S. Lean's `attainableCounts n` contains t when some finite V ⊆ Z^n has P = convexHull ℝ (embed '' V) with `(P.extremePoints ℝ).encard = t` and `{z | embed z ∈ P ∧ embed z ∉ P.extremePoints ℝ}.encard = 5`. `ExactVertexFive` is `IsGreatest`. For a polytope, the extreme points are exactly its vertices, and the conv of a finite lattice set is exactly an element of P(Z^n), including lower-dimensional ones. Non-vertex lattice points include boundary points, as in the source. V = ∅ gives 0 non-vertex points, so it is harmless. This is faithful.
- **Aliev et al.** Their c(n,k) (1405.2480, Thm 1) is stated for a polyhedron {Ax ≤ b} and subsets of its rows; the abstract says "bounded polyhedron". The Lean target follows Averkov's Definition 1 (arbitrary convex sets), which is the standard modern definition. Averkov Lemma 8 shows the closed-halfspace restriction is equivalent. The bounded-polyhedron variant is not formalized; see MINOR 4.
- **Values and the n = 2 check.** `value n` is 2, 7, 18 for n = 1, 2, 3 and 2^(n+1)+5 otherwise. My Audit checks `value 4 = 37` and `value 5 = 69` by `decide`.
  - The source text says g(Z²,k) = g(Z²,k−1) − 1 at k = 5, and Theorem 5 gives c(Z²,4) = 8. So g(Z²,5) = c(Z²,5) = 7, which matches Figure 3. This is consistent; no BLOCKER.
  - By recursion (5), c(Z^n,5) = max{c(Z^n,4) − 1, g(Z^n,5)}. That gives 2 for n = 1, max(7,7) = 7 for n = 2, max(15,18) = 18 for n = 3, and max(2^(n+1)−1, 2^(n+1)+5) for n ≥ 4. So c = g in every dimension, which is what the two targets jointly claim.
  - The values agree with CHZ Cor 3.13 (2^(n+1) − k ≤ c(n,k) ≤ c(k−1,k) + 2(2^n − 2) for k ≤ n).
- **k ≤ 4 values not contradicted.**
  - (a) The Lean upper-bound mechanism, |S| ≤ 2·2^n + C(|X|,3), applied to k non-vertex points gives at most 2^(n+1) + C(k,3) − k vertices. That is 2^(n+1) for k = 4 and 2^(n+1) − 2 for k = 3 and k = 2, exactly the source's Theorem 5 values. For k = 0 and k = 1 it is a valid, non-tight bound.
  - (b) I enumerated every convex lattice polygon in [0,4]² (33,041 polygons, plus points and segments) with the frozen counting semantics: vertices are corners, and non-vertex lattice points include boundary points. This gives max vertices 4, 6, 6, 6, 8, 7, 8, 9, 8 for k = 0..8. The values for k = 0..8 match the source's g(Z²,k) (Theorem 5 and Figure 3), including the drop at k = 5 (`planar.py`).
- **Witnesses, checked independently** (`witcheck.py`, LP membership via HiGHS, independent of Lean):

  | Witness | Extreme points | Lattice points in P | Non-extreme lattice points |
  |---|---:|---:|---:|
  | n = 1, segment [0,6] | 2 | 7 | 5 |
  | n = 2 | 7 | 12 | 5 |
  | n = 3 | 18 | 23 | 5 |
  | n = 4 | 37 | 42 | 5 |
  | Q+ and Q− kernels | 16 each | 16 | 0 |
  | n = 5 lift (r = 1) | 69 | 74 | 5 |

  For n = 2, 3, 4 the non-extreme points equal the Lean `centers`.
- **3D table, recomputed** (`cap.py`). With the Lean `capacity`/`indexedWeight` definitions, I recomputed the maximum over all labellings of the per-class capacity sum. It is 13 for n = 2 (Lean needs `PlanarObstruction` to cut this to 12), 23 for n = 3, and 42 for n = 4. This agrees with the Lean tables and with the bound 2^(n+1) + 10.

## 2. Is the proof chain clean?

- **Check.lean.** It has exactly `theorem check_ExactHellyFive : Challenge.ExactHellyFive := Proof.ExactHellyFive` and the same for `ExactVertexFive`, plus four `#print axioms`. `Challenge` here is a local namespace with `export TaskT.HellyFive (ExactHellyFive ExactVertexFive)`, so the names resolve to the frozen constants.
- **Audit.lean.** My scratch `Audit/HellyAudit.lean` has `example`s with fully qualified names. It also restates **both targets fully inlined**, with no project names in the statement (only Mathlib's `Convex`, `convexHull`, `extremePoints`, `encard`, `IsLeast`, `IsGreatest`). It proves them by `exact TaskT.HellyFive.Proof.ExactHellyFive` and `exact TaskT.HellyFive.Proof.ExactVertexFive`. Both compile, so no shadowing or redefinition can hide a weaker statement. The `#print` output of the frozen definitions matches Challenge.lean.
- **Forbidden constructs.** I grepped all 35 local files for `sorry`, `admit`, `native_decide`, `bv_decide`, `axiom`, `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `initialize`, `run_cmd` and `ofReduceBool`. None occur (`axiom` occurs only in `#print axioms`).
  - There are only `set_option maxHeartbeats 0` and `maxRecDepth 100000`, in 9 data and witness files.
  - The `@[` uses are two `@[simp]` lemmas in FiniteGeometry.
  - There are 3 `instance`s: Decidable instances obtained by `unfold …; infer_instance` in PlanarData and UpperThreeData.
- **`decide`.** All uses are plain kernel `decide`. The large ones are:
  - the witness, exposer and separating-row checks (WitnessTwo/Three/Four, CorePositive/Negative, DimensionOne);
  - `PlanarTable.table` over 4^5 labels;
  - `UpperThreeTable.sorted_table` over sorted 8-class 5-tuples;
  - small `Fin` and `ZMod 2` facts.

  `sample` and `testRow` are not used in place of the full tables.
- **Proof structure.**
  - Lower bound: `LowerTransfer` deletes one extreme point per set, C_i = P \ {v_i}, which is convex by `mem_extremePoints_iff_convex_sdiff`. This works for any attainable t, so any feasible t is at least value n.
  - Attainment: DimensionOne, WitnessTwo, WitnessThree, and `Lift` for n ≥ 4. The lift is P×0 ∪ Q+×U ∪ Q−×(−U) carried by a real linear equivalence into Fin (4+r) → ℝ.
  - Upper bound: `UpperTransfer` takes a minimal preserving subfamily and witnesses for each index. It then extends inside a finite box to distinct contact points that are extreme in a new lattice polytope. `PolyBound` (at most 5 non-vertex points ⇒ |S| ≤ b+5) then bounds the subfamily size.
  - Polytope bound: midpoint-triple counting (UpperCharge/UpperGeom) for n ≥ 4; the 3D table; the 2D table plus obstruction; and the two-endpoint argument for n = 1.
- **ncard.** `ncard` appears only inside the internal `PolyBound`, on sets proved finite. The frozen statements use `encard`.
- **Axioms.** In my rebuild, all four declarations in Check, and the four in my Audit, depend only on `[propext, Classical.choice, Quot.sound]`.

## 3. Independent rebuild on this Mac

- **Setup.** I copied the 35 `.lean` files to a new empty scratch `srcsnap/` and added `Audit/HellyAudit.lean`. I used no lake and no Codex build product. Each module was compiled with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R srcsnap -o out1/...olean` in dependency order. `LEAN_PATH` was my `out1/` plus the prebuilt `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
- **Toolchain.** Lean 4.34.1. The SHA-256 of `lean` (1b370cfc…) and `leanchecker` (cfde41cb…) equal `receipt.tools_sha256`. Mathlib is at `d13f23b723b8a846827a245b89c10fc7d3f11612` (`git rev-parse`, GIT_NO_LAZY_FETCH=1). All 9 package commits equal `receipt.dependency_commits`.
- **Lock.** `leanlock.sh acquire any claude-final-helly-01 60` gave slot B at 03:22:55Z. I released it (`released B`) at 03:34:08Z. Slot A was held by another agent the whole time, so I could not take both slots. The 3D table peaked at 13.37 GB RSS and memory pressure stayed at level 1 (55–71% free). Only one Lean process of mine ran at a time; compiles and checker runs were strictly sequential.
- **Result.**
  - All 36 modules (35 local plus Audit) compiled with exit 0, 0 warnings and 0 errors. The only output was `#print`/`#print axioms` info.
  - `leanchecker <module>` ran on all 36, and every run exited 0 with empty output.
  - The heaviest modules were PlanarTable (69 s compile, 44 s check, 12.46 GB) and UpperThreeTable (68 s, 36 s, 13.37 GB).

## 4. Mathematics, attribution and claims

- **Mathematics.** The mathematics is sound, and the Lean result does not depend on ARGUMENT.md.
  - The core inequality is correct: the three midpoints of three distinct same-parity lattice points are distinct non-extreme lattice points and determine the triple. Hence |S| ≤ 2·2^n + C(|X|,3).
  - The ARGUMENT 3D case analysis (capacity ≤ 3 per class, the 18 count in the parallelogram and collinear cases) and the lift argument are correct as written.
  - The written upper-bound route differs from the Lean route. ARGUMENT counts vertices and cites the source's Lemma 9 for low-dimensional X. Lean counts all lattice points and uses exhaustive class tables plus a planar obstruction (see MINOR 1).
- **Claims.** Neither ARGUMENT.md nor FINAL-HANDOFF says "first". FINAL-HANDOFF correctly says novelty is still pending ("首发性仍待审查"). REVIEW-INDEX and ARGUMENT say none of the three open questions in the source is solved.
- **Prior work.** PRIOR-ADDENDUM and HELLY-PRIOR-INDEPENDENT correctly credit:
  - CHZ (arXiv 1512.07126, §5) for c(Z²,5) = 7;
  - CHZ Cor 3.13 for |c(n,k) − 2^(n+1)| = O(1) at fixed k.

  My own quick web search found no prior exact value of c(Z^n,5) for n ≥ 3, but it was not a full prior-work check.

## MINOR write-up fixes

1. **ARGUMENT.md status and route.**
   - Its status lines are stale: "文献和形式验收仍独立待定" in §全维闭合, and the historical paragraph. The publication text should say that both targets are now Lean-verified.
   - It should also say that the formal upper bound uses a different route: lattice-point counting with midpoint-triple class capacities, the exhaustive 2D (1,024) and 3D (792) tables, and the planar |S| = 13 obstruction. The written Lemma 9 case analysis should be presented as an alternative human proof that is not machine-checked.
   - ARGUMENT.md is frozen-pinned, so make this change in the paper or manuscript rather than in the pinned file.
2. **Attribution of side results.**
   - In the publication, credit c(Z²,5) = 7 to both Averkov et al. Figure 3 and CHZ §5.
   - The "更一般的旁证" paragraph (g(n,k) ≤ 2^(n+1) + C(k,3) and the limit c(n,k)/2^n → 2) still says "此旁证尚未单独查重". Replace that with the CHZ Cor 3.13 attribution from PRIOR-ADDENDUM. Mark the general-k bound as written-only: Lean proves only the k = 5 form, 2^(n+1)+10 total lattice points.
3. **Authors (REPORT.md TG01).** "Matthias Schymura 在预印本署名 Henze" is wrong: Henze and Schymura are different people. arXiv v1 lists Averkov, González Merino, Henze, Paschke, Weltge. The journal version (*Adv. Appl. Math.* 89 (2017) 76–101, doi 10.1016/j.aam.2017.04.003) lists Averkov, González Merino, Paschke, Schymura, Weltge. Cite each version with its own author list, and say that lemma numbers differ between the versions.
4. **Definition scope.** State that the result is for Averkov et al.'s Definition 1: finite families of arbitrary convex sets. Lean proves the c-value directly, not through Theorem 2. Aliev et al.'s original c(n,k) (rows of a bounded polyhedron Ax ≤ b) is a variant. It is linked to Definition 1 only through the source's Lemma 8 and boundedness considerations, which are not formalized. Cite Aliev et al. as the origin of the notion, not as the definition that was formalized.
5. Optional. ARGUMENT §最终表述 says the new values exceed "先前 g(n,4)". The condition that recursion (5) actually uses is g(n,5) ≥ c(n,4) − 1. It holds because g(n,4) = c(n,4) for n ≥ 2. Stating the exact condition is clearer.
6. Optional. FINAL-HANDOFF says "31 个模块". There are 35 local `.lean` files. The four extra audit modules (BridgeAudit, FiniteAudit, FiniteHellyLower, UpperTransferAudit) also compile and pass leanchecker in my rebuild. Mention them, or drop them from a release bundle.
