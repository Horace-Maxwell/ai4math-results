#!/usr/bin/env python3
"""v1.26.0 integration: copy one task's local Lean files into lean-staged/Research/<target>/, rewriting only import lines.
Usage: integrate_generic.py <name> <source dir with .lean files> <source module prefix> <target module prefix> <receipt.json> [receipt key path]
Every file listed in the receipt's source hash table must match; files not in the receipt are copied and flagged in_receipt=false.
Writes <name>-integration.json. Claude, 2026-11-22."""
import hashlib, json, os, re, sys
P = '<workspace>'; V = f'{P}/work/release-v1260'; ST = f'{V}/lean-staged'
only = '--only-receipt' in sys.argv; argv = [a for a in sys.argv if a != '--only-receipt']
name, src, spre, tpre, rec = argv[1:6]
sha = lambda b: hashlib.sha256(b).hexdigest()
r = json.load(open(rec)); raw = r.get('source_sha256') or r.get('source_hashes') or r.get('sources') or r
table = {}
for k, v in raw.items():
    if not (isinstance(v, str) or isinstance(v, dict)): continue
    kn = k[:-5] if k.endswith('.lean') else k
    if '.' in k and not k.endswith('.lean') and '/' not in k and not k.startswith(spre.split('.')[0]): pass
    table[kn.replace('/', '.')] = v if isinstance(v, str) else v.get('sha256')
table = {k: v for k, v in table.items() if isinstance(v, str) and len(v) == 64}
def key(m):
    for c in (m, m[len(spre) + 1:]):
        if c in table: return c
    return None
def recsha(m):
    k = key(m); return table[k] if k else None
fs = {}
for dp, _, files in os.walk(src):
    for f in files:
        if f.endswith('.lean'):
            rel = os.path.relpath(os.path.join(dp, f), src)[:-5].replace('/', '.')
            fs[f'{spre}.{rel}'] = os.path.join(dp, f)
out = []
for n, path in sorted(fs.items()):
    b = open(path, 'rb').read(); rs = recsha(n)
    if only and rs is None: continue
    if rs is not None: assert rs == sha(b), ('hash mismatch', n)
    t = b.decode()
    def fix(m):
        x = m.group(1)
        if x in fs:
            assert not only or recsha(x) is not None, ('imports non-receipt module', n, x)
            return 'import ' + tpre + x[len(spre):]
        assert x.split('.')[0] in ('Mathlib', 'Lean', 'Std', 'Init', 'Batteries'), (n, x); return m.group(0)
    t2 = re.sub(r'^import (\S+)$', fix, t, flags=re.M)
    assert [l for l in t.split('\n') if not l.startswith('import ')] == [l for l in t2.split('\n') if not l.startswith('import ')]
    tm = tpre + n[len(spre):]; tgt = f"{ST}/{tm.replace('.', '/')}.lean"; os.makedirs(os.path.dirname(tgt), exist_ok=True)
    open(tgt, 'w').write(t2)
    out.append(dict(source=os.path.relpath(path, P), target=f"lean/{tm.replace('.', '/')}.lean", module=tm, source_sha256=sha(b),
                    target_sha256=sha(t2.encode()), identical=(t == t2), in_receipt=rs is not None))
used = {key(n) for n in fs}; missing = [k for k in table if k not in used]
print('receipt entries not found as .lean files (ok if non-Lean config):', missing)
json.dump(out, open(f'{V}/{name}-integration.json', 'w'), indent=1)
print(name, len(out), 'files;', sum(o['in_receipt'] for o in out), 'in receipt;', [o['module'] for o in out if not o['in_receipt']])
