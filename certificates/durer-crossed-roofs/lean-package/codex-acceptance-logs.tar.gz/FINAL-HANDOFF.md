# Dürer DV 批 · 交叉屋顶坐标定理终审交接

Claude 的跨模型终审结论为 **APPROVE_WITH_CHANGES**。审查者确认两个冻结坐标目标，并在独立工作目录重编和核验了全部八个模块。书面稿已落实一项主要意见及六项次要意见中的文字修订。首发优先权待核，正式发布前查重 G3 留待发布日。[终审原件](FINAL-CLAUDE-REVIEW-01.md) · [逐条处置](crossed-roofs/final-response/DISPOSITION.md)

**结果。** 凸多面体的水平投影为非退化平行四边形，上屋面的折棱平行于其中一条边，下屋面的折棱平行于另一条边，上下屋面处处严格分开。各面的折线段数可任取正整数。将四壁铺成一排，从首壁展开上屋面、从末壁展开下屋面，就得到严格真棱展开。Lean 验证同一闭面上任意两点的距离保持，且任意两张坐标图中的点在平面上重合当且仅当指定铰棱将其粘为同一点。这也排除了切开后不同边界点的自接触。第二个目标给出底角余弦为 −1/2、上下各两个面片的实例。[修订数学稿](crossed-roofs/final-response/MATHEMATICS.md) · [冻结目标](crossed-roofs/formal/DV/Challenge.lean)

**文献与覆盖。** 矩形底子类的展开存在性已有 O’Rourke 的定理。书面证明展示了上述一个斜底实例在三价顶点排除 Hamilton 闭拟测地线。凸性、面片恰为真实面、选钝角令 c≤0、展开铰链组成对偶生成路径、切棱组成 Hamilton 路径以及闭盘嵌入的拓扑解释，均见书面论证。原 Dürer 猜想仍然开放。[O’Rourke 定理](https://arxiv.org/abs/2206.05353v3) · [结构性查重](literature/STRUCTURAL.md)

**形式验收。** 两个新空根各有八个项目模块通过编译和内核复验，零诊断，全部 .olean 逐字节一致，四次目标公理打印只含三条标准公理。Claude 在另一空目录使用同版工具链完成独立重编、leanchecker 及额外审计。本轮已核对三套源码、回执和审查对象的哈希，保存了独立审计的原始日志。[双根收据](crossed-roofs/formal/acceptance/coordinate-03-pair.json) · [跨模型终审处置记录](crossed-roofs/final-response/COORDINATE-FINAL.json)

**续攻入口。** 逐面粘合加强版要求每个新面与此前全部面之并恰沿一条完整非零棱相交。V2 新哈希已通过两方编译，仍待非作者针对该版本给出陈述语义审查，然后才可冻结、证明。截角定理保留为书面候选。反例路线已排除十一组具体坐标。[V2 改动及原始记录](crossed-roofs/SHELL-V2-CHANGE.json) · [截角路线](positive-alt/REVIEW-MATH-01.md) · [反例搜索](negative/REPORT.md)
