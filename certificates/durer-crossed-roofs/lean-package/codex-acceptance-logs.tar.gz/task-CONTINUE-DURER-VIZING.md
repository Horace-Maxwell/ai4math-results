# Task V 续（Claude 代用户下达）：Dürer 展开与 Vizing 积图支配数继续攻

用户原话："Dürer 和 Vizing 也让 Codex 继续攻"。两题各由一个独立 Codex 会话负责，与 Stanley、Markov、照明、H₅-B 会话并行，互不等待。

## 共同要求
- 起点：本目录 `REPORT.md`、卡片 `lanes/geometry/card-durer.md` / `lanes/graph/card-vizing.md`、`prior/` 下相关复核。
- 先查清文献最新进展与竞争者（含已验证范围、近 6 个月 arXiv、AI 团队与公开题库；Dürer 卡提到近期竞争者公开征集同型证书，Vizing 卡提到一份自称全解的原稿在四点图上失效），每 24 小时复查一次；若有人公开解决，立即停手并报告。
- **不设保守止损**：一条路线有障碍就换下一条，直到有结果或用户叫停。每 24 小时在 `attempts/<题>/STATUS.md` 写进度小结（已试路线、最好成绩、下一条路线）。
- 得到完整证明并经非作者核读，或找到反例并独立复核，就按手册第 3.5 节核对原文 → 冻结陈述（零诊断预编译 + 非作者审查）→ Lean（计算证书只用 `decide` 或反射，禁止 `native_decide`/`bv_decide`）→ 两个新空根验收 → `FINAL-HANDOFF.md`，并在 `CODEX-TASKS.md` 顶部报告。
- 部分结果（新的可证大类、改进的常数、已验证范围的扩展）也有价值：做到完整书面证明并经核读后同样可以冻结做 Lean，并写清它只是部分结果。

## ① Dürer–Shephard（每个凸多面体都有不重叠的棱展开）：`attempts/durer/`
- 方向：(a) 反例：有针对性地构造使所有切割生成树都重叠的凸多面体，用精确算术检查全部切树；(b) 正面：扩大已证类（新的多面体族）并给出可 Lean 的证明。

## ② Vizing 猜想（γ(G□H) ≥ γ(G)γ(H)）：`attempts/vizing/`
- 方向：(a) 改进通用下界的系数或证明新的图类；(b) 有限反例的系统搜索（按支配数和结构剪枝），用精确程序验证。

## 机器与限制
- Mac 共 18 核，现已有多个会话：本会话计算 ≤3 核、单任务 ≤60 分钟分段续跑；Lean 编译走 `work/tools/leanlock.sh`；内存紧张或 RSS 超 40 GB 降并发。Windows 禁用。
- 零对外动作；不碰 `outputs/release/`、`work/release-v*/`、`我的笔记/` 和其他任务目录；不读 `~/.codex/auth.json`；请求里不放邮箱；不下载数据集或软件、不安装东西；时间用 `date -u`。
- 做完或用户叫停时写 `attempts/<题>/DONE`。
