"""Build each local module in an empty Lake root and replay it with leanchecker."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
WS = next(p for p in HERE.parents if (p / "work/tools/leanlock.sh").is_file())
BIN = WS / "work/toolchains/lean-4.34.1-darwin_aarch64/bin"
MATH = WS / "work/research-lean-v434/.lake/packages"
LOCK = WS / "work/tools/leanlock.sh"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
FORBIDDEN = re.compile(r'\b(sorry|admit|axiom|native_decide|bv_decide|implemented_by|extern|unsafe)\b|#eval')

def utc():
    return subprocess.check_output(["date", "-u", "+%FT%TZ"], text=True).strip()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def ordered_modules():
    seen = set()
    ordered = []
    def visit(name):
        if name in seen:
            return
        seen.add(name)
        source = (HERE / "DV" / (name + ".lean")).read_text()
        for dep in re.findall(r'^import DV\.(\w+)$', source, re.M):
            visit(dep)
        ordered.append(name)
    visit("Audit")
    return ordered

def run(root):
    root.mkdir(exist_ok=False)
    logs = root / "logs"
    logs.mkdir()
    (root / "DV").mkdir()
    for name in ordered_modules():
        shutil.copyfile(HERE/"DV"/(name+".lean"), root/"DV"/(name+".lean"))
    for config in ["lakefile.toml", "lean-toolchain"]:
        shutil.copyfile(HERE / config, root / config)
    local = root / ".lake/build/lib/lean"
    deps = sorted(p for p in MATH.glob("*/.lake/build/lib/lean") if p.is_dir())
    # Lake replaces LEAN_PATH for its compiler subprocess. Expose only the
    # pinned third-party libraries there. The project DV subtree starts absent.
    local.mkdir(parents=True, exist_ok=False)
    cache_links = {}
    for dep in deps:
        for entry in sorted(dep.iterdir()):
            if entry.name.startswith("."):
                continue
            dest = local / entry.name
            if dest.exists():
                if dest.resolve() != entry.resolve():
                    raise RuntimeError(f"conflicting cache entry {dest}")
                continue
            dest.symlink_to(entry, target_is_directory=entry.is_dir())
            cache_links[entry.name] = str(entry.resolve())
    if (local/"DV").exists():
        raise RuntimeError("local project artifact present in fresh root")
    env = os.environ.copy()
    env.update(PATH=str(BIN)+os.pathsep+env["PATH"], LEAN_PATH=os.pathsep.join(map(str,deps)),
               LEAN_NUM_THREADS="1", LAKE_NO_CACHE="1")
    receipt = {"root": str(root), "start": utc(), "stages": [], "allowed_axioms": sorted(ALLOWED),
               "external_cache": list(map(str, deps)), "cache_links": cache_links, "modules": ordered_modules()}
    def record():
        (root/"receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")
    def step(label, argv, checker=False):
        start = utc()
        cp = subprocess.run(list(map(str,argv)), env=env, cwd=root,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=420)
        log=logs/(label+".log")
        log.write_bytes(cp.stdout)
        body=cp.stdout.decode(errors="replace")
        stage={"stage":label,"cmd":list(map(str,argv)),"start":start,"end":utc(),
               "exit":cp.returncode,"log_sha256":sha(log)}
        receipt["stages"].append(stage)
        record()
        if cp.returncode or re.search(r'\b(?:warning|error):|⚠',body,re.I) or (checker and body):
            raise RuntimeError(f"{label}: {body[-1500:]}")
        return body
    names=receipt["modules"]
    receipt["source_sha256"]={n:sha(root/"DV"/(n+".lean")) for n in names}
    receipt["configuration"]={p:sha(root/p) for p in ["lakefile.toml","lean-toolchain"]}
    for name in names:
        source=(root/"DV"/(name+".lean")).read_text()
        if FORBIDDEN.search(source):
            raise ValueError(f"forbidden source token in {name}")
    receipt["lean_version"]=step("lean-version",[BIN/"lean","--version"]).strip()
    receipt["checker_sha"]=sha(BIN/"leanchecker")
    receipt["package_heads"]={p.parent.name:subprocess.check_output(
        ["git","-C",str(p.parent),"rev-parse","HEAD"],text=True).strip()
        for p in sorted(MATH.glob("*/.git"))}
    for n in names:
        step("lake-"+n,[BIN/"lake","build","+DV."+n+":olean"])
    step("lake-build",[BIN/"lake","build"])
    env["LEAN_PATH"]=os.pathsep.join(map(str,[local,*deps]))
    for n in names:
        step("check-"+n,[BIN/"leanchecker","DV."+n],checker=True)
    receipt["olean_sha256"]={n:sha(local/"DV"/(n+".olean")) for n in names}
    audits={}
    for n in ["ExactTests","Audit"]:
        body=step("audit-"+n,[BIN/"lean","-j1","-R",".","DV/"+n+".lean"])
        for decl, axioms in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",body):
            values=[a.strip() for a in axioms.split(",") if a.strip()]
            if set(values)-ALLOWED:
                raise RuntimeError(f"unexpected axioms for {decl}")
            audits[decl]=values
    expected=set(re.findall(r'^#print axioms (?:DurerDV\.)?(\w+)$',
        (root/"DV/Audit.lean").read_text()+'\n'+(root/"DV/ExactTests.lean").read_text(),re.M))
    if {s.split('.')[-1] for s in audits}!=expected or not expected:
        raise RuntimeError(f"incomplete audit {audits}, expected {expected}")
    receipt["axioms"]=audits
    for name in names:
        if sha(HERE/"DV"/(name+".lean"))!=receipt["source_sha256"][name]:
            raise RuntimeError(f"source drift {name}")
    receipt.update(end=utc(),passed=True)
    record()

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("root")
    args=parser.parse_args()
    root=Path(args.root).resolve()
    if root.parent != HERE/"acceptance":
        sys.exit("root must be a new directory under formal/acceptance")
    root.parent.mkdir(exist_ok=True)
    owner="durer-replay-"+root.name+"-"+str(os.getpid())
    start=time.monotonic()
    while time.monotonic()-start<5400:
        lock=subprocess.run([LOCK,"acquire","any",owner,"30"],text=True,capture_output=True)
        if lock.returncode==0:
            break
        time.sleep(max(0, min(150, 5400-(time.monotonic()-start))))
    else:
        sys.exit("No free lock in this segment")
    slot=lock.stdout.strip()
    try:
        run(root)
    finally:
        cp=subprocess.run([LOCK,"release",slot,owner],capture_output=True,text=True)
        log=root.parent/(root.name+"-lock.json")
        log.write_text(json.dumps(dict(owner=owner,slot=slot,release=cp.stdout,exit=cp.returncode,
            end=utc()),indent=2)+"\n")
        cp.check_returncode()
