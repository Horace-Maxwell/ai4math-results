#!/bin/zsh -f
set -eu
d=${0:A:h}
ws=${d%/work/codex-r3/*}
tool=$ws/work/tools/leanlock.sh
tag=${1:?new pair name}
[[ "$tag" =~ '^[A-Za-z0-9-]+$' ]] || exit 64
cd "$d"; mkdir -p acceptance
base=$d/acceptance/$tag
[[ ! -e $base-lock.json && ! -e $base-root1 && ! -e $base-root2 ]]
owner=durer-serial-$tag-$$
limit=$(( $(date -u +%s) + 5400 ))
until slot=$("$tool" acquire any "$owner" 25 2>>"$base-queue.log"); do
  now=$(date -u +%s)
  date -u '+%FT%TZ' >> "$base-queue.log"
  (( now < limit )) || exit 75
  sleep $(( limit-now < 150 ? limit-now : 150 ))
done
trap '"$tool" release "$slot" "$owner" >> "$base-lock.log"' EXIT
print -r -- "$slot acquired $owner" > "$base-lock.log"
(cd .. && shasum -c FROZEN-01.sha256)
PYTHONDONTWRITEBYTECODE=1 python3 - "$base" <<'PY'
from pathlib import Path
import json,sys
import replay
base=Path(sys.argv[1])
roots=[]
for number in [1,2]:
    root=Path(str(base)+"-root"+str(number))
    print("Beginning",root.name,flush=True)
    replay.run(root)
    roots.append(json.loads((root/"receipt.json").read_text()))
    print("Passed",root.name,flush=True)
for key in ["modules","source_sha256","configuration","olean_sha256","axioms","package_heads","checker_sha","lean_version"]:
    if roots[0][key]!=roots[1][key]:
        raise ValueError("mismatch in "+key)
pair={"checked_utc":replay.utc(),"roots":[r["root"] for r in roots],"passed":True,
      "receipt_sha256":[replay.sha(Path(r["root"])/"receipt.json") for r in roots],
      "modules":roots[0]["modules"],"target_axioms":roots[0]["axioms"],
      "identical_oleans":len(roots[0]["olean_sha256"])}
Path(str(base)+"-pair.json").write_text(json.dumps(pair,indent=2)+"\n")
PY
(cd .. && shasum -c FROZEN-01.sha256)
