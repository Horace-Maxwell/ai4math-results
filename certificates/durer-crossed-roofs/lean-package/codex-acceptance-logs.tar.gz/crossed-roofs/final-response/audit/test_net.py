import numpy as np, random, math, sys
from scipy.spatial import ConvexHull
from shapely.geometry import Polygon, Point

def instance(rng, m, n, c, convex=True):
    a, b = rng.uniform(0.5, 3), rng.uniform(0.5, 3)
    xs = np.sort(np.concatenate([[0, a], rng.uniform(0, a, m-1)]))
    ys = np.sort(np.concatenate([[0, b], rng.uniform(0, b, n-1)]))
    su = rng.uniform(-2, 2, m); sl = rng.uniform(-2, 2, n)
    if convex:
        su = np.sort(su)[::-1]; sl = np.sort(sl)   # concave top, convex bottom
    f = np.concatenate([[0], np.cumsum(su*np.diff(xs))])
    g = np.concatenate([[0], np.cumsum(sl*np.diff(ys))])
    f = f - f.min() + (g.max() - g.min()) + rng.uniform(0.05, 1)  # strict gap
    g = g - g.min()
    return dict(a=a, b=b, c=c, xs=xs, ys=ys, f=f, g=g, su=su, sl=sl, m=m, n=n)

def emb(I, P):
    c = I['c']; P = np.asarray(P, float)
    return np.stack([P[...,0] + c*P[...,1], math.sqrt(1-c*c)*P[...,1], P[...,2]], -1)

def faces(I):
    """faces in oblique coordinates (x,y,z), as ordered vertex lists, in dual-path order"""
    a,b,xs,ys,f,g,m,n = I['a'],I['b'],I['xs'],I['ys'],I['f'],I['g'],I['m'],I['n']
    roof = [[(xs[i],0,f[i]),(xs[i+1],0,f[i+1]),(xs[i+1],b,f[i+1]),(xs[i],b,f[i])] for i in range(m)]
    floor = [[(0,ys[j],g[j]),(a,ys[j],g[j]),(a,ys[j+1],g[j+1]),(0,ys[j+1],g[j+1])] for j in range(n)]
    A = [(0,0,f[0])] + [(0,ys[j],g[j]) for j in range(n+1)] + [(0,b,f[0])]
    C = [(a,0,f[-1])] + [(a,ys[j],g[j]) for j in range(n+1)] + [(a,b,f[-1])]
    D = [(0,0,g[0])] + [(xs[i],0,f[i]) for i in range(m+1)] + [(a,0,g[0])]
    B = [(0,b,g[-1])] + [(xs[i],b,f[i]) for i in range(m+1)] + [(a,b,g[-1])]
    names = [('roof',i) for i in reversed(range(m))] + [('A',),('B',),('C',),('D',)] + [('floor',j) for j in range(n)]
    polys = list(reversed(roof)) + [A,B,C,D] + floor
    return names, polys

def hull_check(I):
    names, polys = faces(I)
    V = np.unique(np.round(np.array([p for P in polys for p in P]), 12), axis=0)
    E = emb(I, V)
    h = ConvexHull(E)
    # every vertex is a hull vertex
    allv = len(set(h.vertices)) == len(V)
    # distinct facet planes
    planes = np.unique(np.round(h.equations, 8), axis=0)
    return allv, len(planes), I['m'] + I['n'] + 4

def frame(P3):
    P3 = np.asarray(P3); o = P3[0]
    nrm = np.zeros(3)
    for k in range(1, len(P3)-1):
        nrm += np.cross(P3[k]-o, P3[k+1]-o)
    nrm /= np.linalg.norm(nrm)
    e1 = P3[1]-o; e1 /= np.linalg.norm(e1); e2 = np.cross(nrm, e1)
    return np.stack([(P3-o)@e1, (P3-o)@e2], -1)

def key(p): return tuple(np.round(p, 9))

def generic_unfold(I):
    """independent unfolding: place faces successively along the dual path, hinge = shared full edge"""
    names, polys = faces(I)
    out = []
    for k, P in enumerate(polys):
        P3 = emb(I, P); Q = frame(P3)
        if k == 0:
            out.append(Q); continue
        prev3 = emb(I, polys[k-1]); prevQ = out[-1]
        pk = {key(p): i for i, p in enumerate(prev3)}
        shared = [i for i, p in enumerate(P3) if key(p) in pk]
        # need full common edge: two shared vertices that span the hinge (take extreme pair)
        assert len(shared) >= 2, (names[k-1], names[k], shared)
        i0, i1 = shared[0], shared[-1]
        tgt0, tgt1 = prevQ[pk[key(P3[i0])]], prevQ[pk[key(P3[i1])]]
        best = None
        for refl in (1, -1):
            Qr = Q * np.array([1, refl])
            d_src = Qr[i1]-Qr[i0]; d_tgt = tgt1-tgt0
            ang = math.atan2(d_tgt[1], d_tgt[0]) - math.atan2(d_src[1], d_src[0])
            R = np.array([[math.cos(ang), -math.sin(ang)], [math.sin(ang), math.cos(ang)]])
            Qn = (Qr - Qr[i0]) @ R.T + tgt0
            # opposite side: interior overlap area with previous ~ 0
            ar = Polygon(Qn).intersection(Polygon(prevQ)).area
            if best is None or ar < best[0]: best = (ar, Qn)
        out.append(best[1])
    return names, polys, out

def L(I, which, t):
    c = I['c']
    ks, sl = (I['xs'], I['su']) if which == 'u' else (I['ys'], I['sl'])
    tot = 0.0
    for i in range(len(sl)):
        lo, hi = ks[i], ks[i+1]
        tot += math.sqrt(1 + sl[i]**2 - c*c) * (min(hi, max(lo, t)) - lo)
    return tot

def lean_flat(I, name, p):
    a, b, c = I['a'], I['b'], I['c']; x, y, z = p; per = 2*(a+b)
    f0, g0 = I['f'][0], I['g'][0]
    if name[0] == 'roof': return (y + c*x, f0 + L(I, 'u', x))
    if name[0] == 'A': return (y, z)
    if name[0] == 'B': return (b + x, z)
    if name[0] == 'C': return (2*b + a - y, z)
    if name[0] == 'D': return (per - x, z)
    # Lean: floor value is -lower.value, lower slope = -(convex slope); sqrt uses slope^2 so same
    return (per - x - c*y, g0 - L(I, 'v', y))

def check_net(names, Qs, tol=1e-8):
    """pairwise: area overlap 0; consecutive share only hinge; (roof0,B),(C,floor0) touch at a point; others disjoint"""
    import shapely
    P = [shapely.set_precision(Polygon(q), 1e-9) for q in Qs]
    bad = []
    idx = {nm: i for i, nm in enumerate(names)}
    special = {(idx[('roof',0)], idx[('B',)]), (idx[('C',)], idx[('floor',0)])}
    for i in range(len(P)):
        if not P[i].is_valid: bad.append(('invalid', names[i]))
        for j in range(i+1, len(P)):
            inter = P[i].intersection(P[j]); ar = inter.area
            if ar > tol: bad.append(('overlap', names[i], names[j], ar))
            d = P[i].distance(P[j])
            if j == i+1:
                if inter.length < 1e-6 or inter.area > tol: bad.append(('nohinge', names[i], names[j], inter.length))
            elif (i, j) in special:
                if d > tol or inter.length > tol: bad.append(('special', names[i], names[j], d, inter.length))
            else:
                if d <= tol: bad.append(('touch', names[i], names[j], d))
    return bad

def run(seed, m, n, c, convex=True):
    rng = np.random.default_rng(seed)
    I = instance(rng, m, n, c, convex)
    out = {}
    if convex:
        out['hull'] = hull_check(I)
    names, polys, G = generic_unfold(I)
    out['generic_bad'] = check_net(names, G)
    # Lean formulas
    F = [np.array([lean_flat(I, nm, p) for p in P]) for nm, P in zip(names, polys)]
    out['lean_bad'] = check_net(names, F)
    # isometry per face (all vertex pairs) for Lean formulas
    err = 0
    for nm, P, q in zip(names, polys, F):
        E = emb(I, P)
        for s in range(len(P)):
            for t in range(len(P)):
                err = max(err, abs(np.sum((q[s]-q[t])**2) - np.sum((E[s]-E[t])**2)))
    out['iso_err'] = err
    # Lean-formula net congruent to generic net (rigid motion incl. reflection)?
    X = np.concatenate(G); Y = np.concatenate(F)
    Xc, Yc = X - X.mean(0), Y - Y.mean(0)
    U, S, Vt = np.linalg.svd(Xc.T @ Yc); R = U @ Vt
    out['congruence_err'] = float(np.abs(Xc @ R - Yc).max())
    return out

if __name__ == '__main__':
    tot = 0; fails = []
    for seed in range(300):
        rng = random.Random(seed)
        m, n = rng.randint(1, 7), rng.randint(1, 7)
        c = rng.choice([0.0, -rng.uniform(0, 0.98)])
        r = run(seed, m, n, c)
        tot += 1
        ok = (r['hull'][0] and r['hull'][1] == r['hull'][2] and not r['generic_bad'] and not r['lean_bad']
              and r['iso_err'] < 1e-8 and r['congruence_err'] < 1e-7)
        if not ok: fails.append((seed, m, n, c, r))
    print('convex c<=0 instances', tot, 'failures', len(fails))
    for f in fails[:5]: print(f)
    # c>0 (outside contract): expect some overlaps for the same tree
    over = 0
    for seed in range(300):
        rng = random.Random(seed); m, n = rng.randint(1, 7), rng.randint(1, 7)
        r = run(seed, m, n, rng.uniform(0.3, 0.95))
        over += bool(r['generic_bad'])
    print('c>0 instances with defect in this fixed tree', over, 'of 300')
    # nonconvex profiles with c<=0 (convexity unused by the net argument?)
    nc = 0
    for seed in range(300):
        rng = random.Random(seed); m, n = rng.randint(1, 7), rng.randint(1, 7)
        r = run(seed, m, n, -rng.uniform(0, 0.98), convex=False)
        nc += bool(r['lean_bad'])
    print('nonconvex c<=0 instances with defect (Lean formulas)', nc, 'of 300')
