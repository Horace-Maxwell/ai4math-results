import DV.Proof

open DurerDV in
example : DurerDV.StrictRoofNet := DurerDV.strictRoofNet
example : DurerDV.ObliqueExample := DurerDV.obliqueExample

-- the target written out in full, checked against the frozen definitions
example : ∀ s : DurerDV.Solid, ∃ u v : ℝ → ℝ,
    DurerDV.arcValid s s.upper u ∧ DurerDV.arcValid s s.lower v ∧
    (∀ (k : DurerDV.Chart) (p q : DurerDV.V3), DurerDV.onChart s k p → DurerDV.onChart s k q →
      DurerDV.commonFacet s k p q →
      DurerDV.sq2 (DurerDV.flat s u v k p) (DurerDV.flat s u v k q) =
        DurerDV.sq3 (DurerDV.embed s p) (DurerDV.embed s q)) ∧
    (∀ (i j : DurerDV.Chart) (p q : DurerDV.V3), DurerDV.onChart s i p → DurerDV.onChart s j q →
      (DurerDV.flat s u v i p = DurerDV.flat s u v j q ↔ DurerDV.welded s i j p q)) :=
  DurerDV.strictRoofNet

-- consequences: AD vertical edge is cut (the A- and D-copies of (0,0,z) are distinct)
example (s : DurerDV.Solid) (p : DurerDV.V3) : ¬ DurerDV.welded s .a .d p p := by
  rintro ⟨-, h⟩
  have hb := (h .b (by decide) (by decide)).2
  have hc := (h .c (by decide) (by decide)).2
  have ha := (h .a (by decide) (by decide)).2
  simp at ha hc
  have := s.upper.length_pos
  linarith

#print axioms DurerDV.strictRoofNet
#print axioms DurerDV.obliqueExample
