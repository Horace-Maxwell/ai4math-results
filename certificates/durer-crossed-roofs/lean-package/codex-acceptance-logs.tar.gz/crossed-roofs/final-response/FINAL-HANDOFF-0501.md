# Dürer DV 批 · 斜底交叉屋顶的坐标定理

2026-11-21T05:01:26Z 两个已冻结目标均通过两个新空根的机器验收。Dürer 的一般猜想仍然开放。请将本次提交的形式范围限定在这两个目标，供 Claude 跨族 FINAL 核读。

**数学结果。** 多面体的底面投影是一个非退化平行四边形，上边界沿一个底边方向呈分段线性凹折线，下边界沿另一方向呈分段线性凸折线，两者处处严格分开。两条折线的段数、坡度和层间距离均可变化。四个侧面依次铺开，将两个屋面分别接到这一排侧面的两端。已验证每个闭面的所有点对保距，且两点在平面上重合，当且仅当它们是指定真棱粘接产生的同一空间点。另一目标给出底角余弦为 −1/2、上下各有两个真面片的具体实例。[书面证明](crossed-roofs/MATHEMATICS.md) · [原文与坐标陈述对照](crossed-roofs/STATEMENTS.md)

**机器范围。** 冻结源 SHA-256 为 `7729aa0000db875d912cbe8656d7823512ef0649b14465e64ffd923244407dfb`。两根各有 8 个项目模块经 Lake 编译，整体 `lake build` 通过，8 个 `leanchecker` 均退出 0 且日志为空。原目标及两条精确类型测试共 4 项公理打印仅含三条标准公理。全部项目源码和 8 个 .olean 在两根间逐字节一致，0 警告、0 错误。复用本机锁定的第三方 Mathlib 等依赖缓存。两次早期 Lake 配置失败原样保存，成功批次为 `coordinate-03`。[冻结与非作者语义核读](crossed-roofs/REVIEW-STATEMENT-01.md) · [双根收据](crossed-roofs/formal/acceptance/coordinate-03-pair.json) · [逐项复核](crossed-roofs/COORDINATE-MACHINE.json)

**下一节点。** 逐面粘合加强版另要求证明每个真实面与此前全部面之并恰好沿一条完整非零棱相交。旧版语义审查通过，预编译触发一条局部变量命名警告。V2 只改了该绑定变量名，已零诊断预编译，待非作者在 V2 新哈希上核读、冻结后再做证明。抽象拓扑圆盘同胚、Hamilton 切路及拟测地线排除均未作为本次独立 Lean 目标验收。[原审查](crossed-roofs/REVIEW-SHELL-STATEMENT.md) · [V2 改动与状态](crossed-roofs/SHELL-V2-CHANGE.json)

**其他证据。** 十个八顶点凸壳的 72,800 个“凸壳—切树”组合经两套实现分类；额外一个无 Hamilton 路径的 14 顶点凸壳也有分枝真棱展开。截角继承定理通过非作者书面核读，未进入本次机器验收。已核查近六个月文献、竞争团队与题库，优先权未确认，G3 未做。每日复查从 2026-11-21T03:51Z 起计。[负线证据](negative/REPORT.md) · [截角核读](positive-alt/REVIEW-MATH-01.md) · [结构性查重](literature/G2-CROSSED-ROOFS.md)
