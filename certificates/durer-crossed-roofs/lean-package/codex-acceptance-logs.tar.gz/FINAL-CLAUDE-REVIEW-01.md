# Cross-family FINAL review 01: Dürer crossed roofs over an oblique parallelogram (coordinate targets)

**Verdict: APPROVE_WITH_CHANGES.**

- **BLOCKER:** none.
- **Formal part:** the two frozen targets `DurerDV.StrictRoofNet` and `DurerDV.ObliqueExample` are fully Lean-verified. They use only the standard axioms. My independent rebuild and leanchecker runs pass.
- **What `StrictRoofNet` says:** it is a faithful, direct coordinate encoding of a *strict* edge net for the whole family, with any number of fold segments. It is not limited to specific instances.
- **One MAJOR item (M1, novelty and framing):** it concerns the public write-up, not the Lean result. I found no published class that contains the oblique family. But the construction is elementary, the right-angle subcase is already covered, and G3 has not been done. The public text must therefore be modest and precise.
- **MINOR items:** these are write-up fixes, listed at the end.

- Reviewer: Claude (Anthropic, Opus 5.5), a subagent of the user's Claude session. I wrote none of the reviewed files. Lock owner: `claude-final-durer-01`.
- Review started 2026-11-21T17:03:51Z. The report was written after 2026-11-21T17:12:29Z (Mac `date -u`).
- My only write in the task folder is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/durer-final/` (`src/`, `out/`, `compile*.py`, `py/test_net.py`, logs).

**Layout mapping to the common brief.** This folder uses different names from the common brief:

| Common brief | Here |
|---|---|
| Challenge.lean | `crossed-roofs/formal/DV/Challenge.lean` |
| FREEZE.json | `crossed-roofs/FROZEN-01.sha256` / `.utc` (there is no separate `frozen/` copy) |
| FREEZE-REVIEW | `REVIEW-STATEMENT-01.md` |
| Check*.lean | `DV/ExactTests.lean` |
| Proof | `DV/Proof.lean` (with Arc, Metric, Contacts, Example) |
| SOURCE-CHECK | `STATEMENTS.md` |
| G2 | `literature/G2-CROSSED-ROOFS.md` + `literature/STRUCTURAL.md` |
| receipts | `formal/acceptance/coordinate-03-root{1,2}/receipt.json` + `coordinate-03-pair.json` |

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| DV/Challenge.lean (= FROZEN-01.sha256, = both acceptance roots) | 7729aa0000db875d912cbe8656d7823512ef0649b14465e64ffd923244407dfb |
| DV/Arc.lean | 3a104b5f0fda6b225d709e2577361239fc0dd16c8a67d62520ccc29923e7cbbe |
| DV/Metric.lean | 477290da8dba6af48612f4b42bb427e3340f5b8a8b0900190b7f50a61485d8b9 |
| DV/Contacts.lean | 5c538cfcbccff177d0e2a502e8a350ed5c590ad441054b40c7475078f5fbb294 |
| DV/Example.lean | ddd2eb7eee4c0826eb748cbcb346b76a11aa8527bb198e9073dbf2f5ddc9d892 |
| DV/Proof.lean | 4e433d718a6968a7b1d14f1393fbfd7b5e316766e77b1e140cb7971a5c4a5229 |
| DV/ExactTests.lean | 55ba03efe19d0e97a19a8b749ab62ff2d6ed7c60330fd974124da8fdf54fb3ce |
| DV/Audit.lean | 9a347bb2c96afa777de8424bbc9dc28486cb71977e2ace93c9f248a3b281e70b |
| DV/ShellChallenge.lean (not a target) | be41f1bae0922b0df061357f4c040e06d7e99cfd9cbc39f25c2681da5074b717 |
| DV/ShellChallengeV2.lean (not a target, not frozen) | 57ca9661acd27eadb9a9fffeb450f2ad00cf4b4b0636e933e2d521f80a1cd68a |
| MATHEMATICS.md | 822dc73b18a9c38d3be5379a4a6b0a955a1f4d3d029a2817960ce583601adad9 |
| STATEMENTS.md | 55379a508a0a801c9c4ff0da83814d2489c7ef79c662bc65b3f5d352fd90d7d9 |
| REVIEW-STATEMENT-01.md | 150f779c289fbb8198f4f6b7f072ad9ec958483cb2f9809c3a65dcee65717a55 |
| REVIEW-MATH-01.md | 3f327baa5b40d925fe7b64595f9b2bd5c2a05d11820b5c3cfc198a1c20e0f893 |
| COORDINATE-MACHINE.json | 0fe1c2fa36ff9f6ed1c6092ec34cbc4ac3d1361888f60b578f827a8b7fea1e38 |
| FINAL-HANDOFF.md | ce4619128b529751317c25c52b5154a66642edacdcdf315f2f529a550e9921bc |
| literature/G2-CROSSED-ROOFS.md | dbe1fc453030d7207518c07b8be5ff4822f2ceace71470fbe83c949d76c2baf3 |
| literature/STRUCTURAL.md | 9e6ea362376ee9054cdab80adc49569348d6125980e5edbfd8ec906160601620 |
| acceptance/coordinate-03-root1/receipt.json | 8ab95dfb5ba4127c81ac0950657dcdc03f908ad8b18f2f47f67a7f9b899e1f66 |
| acceptance/coordinate-03-root2/receipt.json | f709460a1cbf760d093a09dac1fa97ca27ff3c9ec25468cdc22ea81871d50992 |
| acceptance/coordinate-03-pair.json | d145208da17a08bbd75a9ba254d5e2ef80adf665038011adbc7043cde9475d1d |
| My ClaudeAudit.lean (scratch) | e1e583f1e2bb2d5e9ed123fe949721d7f3bce9af7e2c7c28de93f8479531f253 |
| My py/test_net.py (scratch) | 14c2cea3c9926d75a6554d15d45151ecdbf341cb7363955067fe8bce74344a23 |

The 8 accepted `.lean` files in `formal/DV/` are byte-identical (`cmp`) to those in `coordinate-03-root1` and `coordinate-03-root2`. The receipt hashes match `coordinate-03-pair.json`, and the pair hash matches `COORDINATE-MACHINE.json`. The `lean` and `leanchecker` binaries match the receipt (1b370cfc…, cfde41cb…). Mathlib is at d13f23b723b8a846827a245b89c10fc7d3f11612.

## 1. Faithfulness

**Source.** TOPP Problem 9 asks: "Can every convex polyhedron be cut along its edges and unfolded flat to a single, nonoverlapping, simple polygon?" (topp.openproblem.net/p9). The claim here is a partial result for one family. The task asked five specific questions; they are answered below in order.

**(1a) Is it the whole family, or only specific instances?** It is the whole family.

`StrictRoofNet` is `∀ s : Solid, ∃ u v, …`. A `Solid` consists of:
- two `Profile`s with arbitrary `count : ℕ` (≥ 1), arbitrary real knots, lengths and slopes;
- a parameter c ∈ (−1, 0];
- a strict gap `-lower.value y < upper.value x` on the whole footprint.

Two consequences of the `Profile` axioms:
- `support` + `exposed` make the upper profile equal to the minimum of its supporting lines on [0, length], so it is concave. Each line is tight exactly on its own closed interval. This forbids equal consecutive slopes, so every knot is a true ridge.
- The floor is `-lower.value`, so it is convex.

`embed` (x, y, z) ↦ (x + c·y, √(1−c²)·y, z) is a genuine Euclidean model of an oblique unit basis with u·v = c. So the family is exactly as claimed:
- a parallelogram footprint;
- a concave polygonal roof whose ridges are parallel to one side direction (v);
- a convex polygonal floor whose ridges are parallel to the other side direction (u).

The fold counts are unrestricted. Nothing in the statement is instance-specific.

**(1b) Is it an edge unfolding in the standard Dürer–Shephard sense?** Yes, in a form that is in fact stronger than the standard one.

The charts are `roof` (all upper facets together), the walls `a`, `b`, `c`, `d`, and `floor`. The statement proves two things:
- **Isometry.** For any two points on one closed facet (same roof piece, same floor piece, or same wall), the squared planar distance equals the squared 3D Euclidean distance. Every face is therefore placed by a rigid motion.
- **Gluing.** For *all* closed points p on chart i and q on chart j: `flat i p = flat j q ↔ welded i j p q`. Here `welded` means p = q and p lies on every chart between i and j in the fixed chain roof–A–B–C–D–floor.

What this gives:
- The planar images coincide exactly on the uncut hinges: the internal roof and floor ridges, roof–A, A–B, B–C, C–D and D–floor. These are all full original edges.
- Nowhere else do images coincide, including boundary points. For example, `¬welded a d p p` (the A–D edge is cut). I checked this explicitly in my audit file.
- So the interiors are pairwise disjoint, and there is not even boundary contact. This is a strict net, stronger than the weak-overlap "net" of Demaine–O'Rourke.
- The uncut adjacency is a path through all m+n+4 faces, i.e. a spanning tree of the dual graph. Its complement, the cut set, is therefore a spanning tree of the 1-skeleton. MATHEMATICS.md correctly notes that it is a Hamiltonian path.

What Lean does *not* prove:
- that the charts and pieces are exactly the facets of the polytope;
- that the hinge graph is a dual spanning tree;
- the closed-disk / simple-polygon topology.

These follow from the fixed explicit combinatorics. They are prose only (REVIEW-STATEMENT-01 §4 already says so). I accept this as a direct coordinate encoding, but the public text must say it (MINOR 1).

**(1c) Is convexity a hypothesis, and is it proved?** It is built into the input, not proved in Lean.
- Convexity is implicit in the `Profile` support/exposed axioms: an H-representation. It is not proved as a separate Lean lemma, and the theorem does not need it.
- Notably, *the net argument does not use convexity at all.* The Lean proof uses only piecewise linearity, the positive arc-length rates √(1+m²−c²), and c ≤ 0.
- I confirmed this numerically: with non-concave and non-convex profiles, the same formulas still give a strict net (300/300 random cases, see §1e). That is fine for correctness, but it shows how special the mechanism is (see M1).

**(1d) Degeneracy.**
- There are no cardinalities, so nothing defaults to 0.
- `welded` cannot be vacuous: the ← direction (`agree` in Contacts) proves that welded points really coincide.
- The isometry clause is checked on all pairs of points of a closed facet, not just on edge lengths.
- `ObliqueExample` shows that `Solid` is inhabited by a genuinely oblique member (c = −1/2, two pieces each way). Arbitrary counts are obviously inhabited too (any concave PL function with distinct slopes).
- There are two scope restrictions, neither a defect:
  - **c ≤ 0.** MATHEMATICS.md's reduction is: choose an obtuse corner, then reflect x ↦ a−x, which keeps concavity and flips the sign of c. This reduction is prose (MINOR 3).
  - **Ridge directions.** The ridges must be parallel to the footprint sides. Roofs with ridges in other directions, or both roofs folding in the same direction, are not covered (MINOR 3).

**(1e) My Python tests** (`py/test_net.py`, floats with snapped geometry). For random members (m, n ∈ 1..7, c ∈ {0} ∪ (−0.98, 0], random concave/convex slopes, positive gap; 300 cases) I did the following:
- I built the 3D vertices and computed the convex hull with scipy, independently of the claimed face structure. Every constructed vertex is a hull vertex, and the number of distinct facet planes is m+n+4. So the family is convex, and the faces are exactly the claimed ones.
- I unfolded with an *independent* generic algorithm: I placed each face by its own rigid frame and hinged it to the previous face along the shared full edge, on the opposite side.
- I compared this with the Lean `flat` formulas (`u` = cumulative √(1+m²−c²)). The two layouts are congruent (max error 4e−15). The Lean formulas are isometric on every face (error < 1e−14).
- Pairwise check on all faces:
  - zero overlap area;
  - consecutive faces share exactly their hinge;
  - (roof₀, B) and (C, floor₀) touch only at the welded corner point;
  - all other pairs are at positive distance.
- **Result: 300/300 pass.** I added 100 large cases (m, n ∈ 10..30, including c = −0.999): all pass.
- The frozen example has hull facet count 8 = 2+2+4, and its net has no defect.
- Control runs:
  - With c > 0 (outside the contract), the same tree fails in 9 of 300 cases. This shows the sign normalisation matters.
  - With non-convex profiles and c ≤ 0, it fails in 0 of 300 cases. This is the "convexity unused" observation above.

**Quasigeodesic check.** At vertex (1, 2, 3) of the example, the face angles are 120°, 60.164° and 174.289°. Every two-angle sum is above 180°. I confirmed from arXiv 2206.05353v3 that a Hamiltonian quasigeodesic there is *closed* ("a simple closed quasigeodesic following edges of P, and passing through every vertex"). So the example is indeed outside O'Rourke's 2022 class, as MATHEMATICS.md claims.

## 2. Proof chain

- **The check file.** `ExactTests.lean` is exactly `theorem checkStrictRoofNet : StrictRoofNet := strictRoofNet` and `theorem checkObliqueExample : ObliqueExample := obliqueExample`, plus `#print axioms`.
- **Namespace and shadowing.** All modules share the namespace `DurerDV` (there is no separate Challenge namespace). Lean rejects redeclaring a name, and every proof module imports Challenge, so no frozen name can be shadowed.
- **My audit.** `ClaudeAudit.lean` checks, with fully qualified names:
  - both targets;
  - the *fully written-out* statement of `StrictRoofNet`, elaborated against the frozen definitions;
  - `¬ welded s .a .d p p`.
- **Forbidden-token grep** (sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, set_option, initialize, run_cmd, ofReduceBool, `@[`). The only hits are:
  - `set_option maxHeartbeats 4000000` in Contacts.lean (benign);
  - `#print axioms` lines.
- **`decide` uses.** All are small: comparisons of `rank` on the 6-element `Chart` enum in Contacts (`by decide` for `min/max ≤ rank`), and `0 < 2` / `0 < 2`, `1 < 2` in Example. There is no `native_decide`.
- **Proof structure.**
  - Arc: an explicit arc-length function u(t) = √(1−c²)·t + Σ extraⱼ·clippedⱼ(t). It is strictly increasing, and has the exact rate √(1+m²−c²) on each piece.
  - Metric: the Gram identity plus a per-piece `linear_combination`.
  - Contacts: case analysis over the 36 chart pairs, using strict monotonicity of u, v and c ≤ 0.
  - Example: an explicit two-piece profile.
  - This matches MATHEMATICS.md.

## 3. Independent rebuild on this Mac

- **Setup.**
  - New empty scratch folder. I copied all 10 `.lean` files to `src/DV/` and added `ClaudeAudit.lean`.
  - I compiled with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o …`, using Lean 4.34.1 (`work/toolchains/lean-4.34.1-darwin_aarch64`).
  - `LEAN_PATH` = my `out/` + the prebuilt `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
  - No lake, and no Codex build products.
- **Lock.**
  - My background loop retried until it got `leanlock.sh acquire any claude-final-durer-01 60`; it acquired slot B at 2026-11-21T17:08:55Z. It released B at 17:09:58Z (`released B`).
  - I re-acquired and released B twice more for the audit-only rerun. The last release was at 17:10:52Z (`release-done`).
  - Final status: B free. A is held by `claude-rel-h5`, not by me.
  - Only one Lean process ran at a time.
- **Results.**
  - Challenge, Arc, Metric, Contacts, Example, Proof, ExactTests and Audit all compiled with exit 0 and no warnings or errors. Each takes 5–9 s.
  - The shell statements also compiled with exit 0. ShellChallenge.lean (old, not a target) gives the known `constructorNameAsVariable` warning; ShellChallengeV2 is clean.
  - `leanchecker` exited 0 with empty output on all 10 modules and on ClaudeAudit.
  - My first ClaudeAudit attempt failed only because I imported both Shell files together (a duplicate `panelOn.match_1`). That was my audit's fault, not theirs. After removing those imports it compiles, and leanchecker passes.
  - `strictRoofNet`, `obliqueExample`, `checkStrictRoofNet` and `checkObliqueExample` depend only on `[propext, Classical.choice, Quot.sound]`.

## 4. Mathematics and prior work

**MATHEMATICS.md is correct.** I re-derived the following:
- the Gram identity (dy + c·dx)² + (k·dx)² = dx² + 2c·dx·dy + dy² + m²dx² with k² = 1+m²−c²;
- the separations U ⊂ {s ≤ b, h ≥ f(0)} and V ⊂ {s ≥ p−a, h ≤ g(0)};
- the corner contacts at (0, b, f(0)) and (a, 0, g(0));
- the case c = 0;
- the angle example.

It does not say "first". It credits O'Rourke's 2022 theorem for the right-angle subcase.

**Prior-work search.** I did my own search:
- the Demaine–O'Rourke update to GFALOP §22.5 (dated 2025-09-03), which lists every class proved edge-unfoldable since the book;
- arXiv 2206.05353v3;
- arXiv 2603.09813 (prismatoid band unfolding);
- arXiv 2607.09606;
- arXiv 2605.30373;
- general web searches.

The GFALOP update lists: pyramids, prisms, prismoids, domes, generalized deltahedra, Ghomi's affine stretching, nearly flat acute caps, tall or rectangular-base prismatoids, Hamiltonian closed quasigeodesics, polar zonohedra, nested prismatoids, tapered/skeletal polyhedra, and gridded orthogonal classes. None of these contains the oblique family:
- it is not a prismatoid: the vertices do not lie in two parallel planes, by the face-size argument in STRUCTURAL.md;
- it is not a dome;
- it is not a zonohedron;
- it is not orthogonal;
- the example is not tapered and has no Hamiltonian quasigeodesic.

"Pseudo-prismatoids" is not an established unfoldable class in the literature I found. I found no 2024–2026 paper on this family. STRUCTURAL.md's comparisons are sound.

## MAJOR

**M1 (novelty, significance and framing; this does not affect the formal verdict).** The novelty is plausible but unconfirmed, and the result is elementary. The public text must reflect all of the following:
1. **Right-angle case is not new.** The right-angle members (c = 0) are already covered by O'Rourke 2022. Only the oblique members are candidates for novelty, and only the frozen example is *shown* to lie outside the quasigeodesic class.
2. **The mechanism is special.** Every face is parallel to u or to v. The roof and the floor are each a developable cylindrical surface, which unrolls to a single monotone strip. The net is essentially a band unfolding of the four walls, with the two unrolled strips attached at A and D. The argument uses neither convexity nor concavity (confirmed numerically above). This is a small, special family, not a step toward the general Dürer problem.
3. **Priority checks are incomplete.** G3 has not been done, and priority is marked unconfirmed in the handoff.

Before publication, run G3 and present the result as: "an explicit, fully Lean-verified strict edge net for crossed developable roofs over an oblique parallelogram (a special family; the rectangular case was known)". Avoid language suggesting a significant new unfoldable class, and include the closest prior work (MINOR 2).

## MINOR fixes

1. **Mark Lean vs. prose.** MATHEMATICS.md has no Lean/prose boundary. Add a short paragraph listing what is prose only:
   - that the charts are exactly the facets of a convex polytope;
   - convexity itself;
   - that the hinge graph is a dual spanning path and the cut set is a Hamiltonian path in the 1-skeleton;
   - the closed-disk / simple-polygon conclusion;
   - the reduction to c ≤ 0;
   - the quasigeodesic obstruction, and the not-a-prismatoid / not-a-dome checks.

   State that Lean proves exactly the per-facet isometry and the "coincide iff welded" criterion.
2. **Cite the closest prior work in MATHEMATICS.md itself.** It currently cites only TOPP and O'Rourke 2022. Add:
   - prismoid band unfoldings (GFALOP §22.5);
   - the Demaine–O'Rourke 2025 class list;
   - a one-line comparison with prismatoids, domes, tapered polyhedra and orthogonal terrains, as already argued in STRUCTURAL.md;
   - the remark that the net is a wall band plus two unrolled developable strips.
3. **State the family precisely in the abstract and handoff.** The roof ridges are parallel to one side of the parallelogram footprint, and the floor ridges are parallel to the other side. The claim "folds along two different directions" could be misread as allowing arbitrary ridge directions.
4. **Credit the strictness.** The result is stronger than the usual net: there is no boundary contact. Saying so is accurate.
5. **Add a sentence that convexity is not used** by the unfolding argument. This is honest, and it pre-empts a referee's question.
6. **Shell statements.** ShellChallenge.lean (old) still emits a linter warning and is superseded by V2. Neither is a target of this release. Keep them out of the release bundle, or label them clearly as unaccepted.
