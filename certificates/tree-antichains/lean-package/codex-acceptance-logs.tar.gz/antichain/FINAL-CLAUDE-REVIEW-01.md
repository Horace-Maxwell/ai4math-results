# Cross-family FINAL review 01: antichains of equal-order trees (Task N)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The two frozen targets `WidthLowerBound` and `ArbitrarilyLarge` are faithful to Beaton–Cameron's question, and they are fully Lean-verified (standard axioms only, independent rebuild and leanchecker pass). The MINOR items below concern the write-up `MATHEMATICS.md` only. Fix them before publication. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session; wrote none of the reviewed files.
- Review started 2026-11-20T17:16:36Z; report written after 2026-11-20T17:26:39Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-antichain/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= frozen snapshot, byte-identical) | fb8861ac8b6a3d2f3f6709637b1164a03fe515b7486b7429a74fb1eefdff5d58 |
| CheckAntichain.lean | 90b0a28455f5746f8e4c8187be4386b9dd5ab0ccd4951a7a03dbc77919cdb176 |
| Proof.lean | c42594afe83e1b83ec37b43b79642726eb8dce0400368722b0fb6a562247f80a |
| CompareCore.lean | 24a61db36c49b20317dde81384a0956a1868563992e84ca033c949c0b87a585e |
| TreeRoot.lean | 09401dc15848ac21edb1b9130ddcd8164ee06f42ad244d9dfe63d7040820a73f |
| TreeCode.lean | caf4fdcecf1d3ad7168afd783efe51159ceef329a372fd1c9709cc49b52109ab |
| TreePolynomial.lean | 54957046082a2c08ac0f35339ce964d9dfb2c42549d73d2f993ebe7a3cb21725 |
| BridgeWeights.lean | 2215b32fd7b4b9035b5ee4e827ea7fcc237b7adcee76701add9a25bf95b6ebd2 |
| SequenceGraph.lean | a2624847457742883eee4740840ae8aa76c476b56b33dbb8f555a17c4d6c1a84 |
| Numeric.lean | b81b914c50caef7fc4aee5ee31a7001e36ec0009ecaab3a4ad4b620f65dd8b13 |
| GraphTransport.lean | f1e53d4a314bae9b48778b6b63d2ecdcdb1ec0ba7e864157a5626cbefc36c06a |
| FREEZE.json | 4bfc748a4c3d343b7706d57cdd5606a78873e75a7a0100f74e984ba3ac6acf28 |
| FREEZE-REVIEW.md | 79bb1667a793ccb37f04e5999179b473d57286b909330cf778a17f4566e4464d |
| SOURCE-CHECK.md | 40894ef140ede9b5384c70602e1de118633408f03777c5ac1a2950695fcfbdfe |
| G2.md | c6ca46be9f8a5530b84e397fd9d3cce92eab9af40c74fb0fa61ff295f808a4b6 |
| MATHEMATICS.md | 8295f91155ee4cd26eccfcce0a0cec82381b421c4911bf479ed1d4be54c7c511 |
| FINAL-HANDOFF.md | 872ec9616304e21507f7a1882fa5ca49da5699ec73b7d4c2acf7e9f9a3c13120 |
| acceptance/2026-11-20T143301Z/receipt.json | 67aa4aad8fa5e4087bddbbaa8e2b5fc47bc36a5201c2fc2a2d18b1530775961a |
| arXiv 2006.05511v2 PDF (downloaded by me) | 695d3990c2e8b896970bfec15da5c1576cb888c12741384e2aa825ce54dd3543 |
| Journal PDF, ODAM 5(3) 30–46 (downloaded by me from pisrt.org) | 700e606877f897c9fcedca1cf9bfef24661d8a4b6b13937c9abfc36d1f69bfe2 |
| My Audit.lean (scratch) | 075e7f2446409faaeb20f1595bbc394c85d3f1e8cb864c8d802be833001f892e |

All 11 source hashes match `receipt.json`. The 11 `.lean` files in the task root are byte-identical to `acceptance/.../root1` and `root2`. The Challenge hash matches `FREEZE.json.challenge_sha256` and the `frozen/` snapshot. FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`. The receipt hash matches FINAL-HANDOFF.

## 1. Are the statements faithful to the source?

I extracted the text of arXiv v2 and the journal PDF myself.

- **Polynomial.** The source defines I(G,x) = Σ i_k x^k, with i_k the number of independent sets of size k. Lean's `independencePolynomial` sums X^|s| over all independent Finsets, including the empty set. This is the same polynomial. Mathlib's `IsIndepSet` is the usual pairwise non-adjacency.
- **Endpoint ξ(G).** Journal p.30 and v2 p.2 say the smallest-modulus root "is always real and in the interval [−1, 0)" and that it "is equivalently referred to as the largest real independence root". Lean's `LargestRoot G r` is `IsGreatest {x | I(G,x)=0} r`. This is the largest real root, which is what the source itself names. It is unique when it exists.
- **Order.** Journal p.31: "H ⪯ G if and only if I(H, x) ≥ I(G, x) for all x ∈ [ξ(G), 0]". Lean's `Precedes H G` says: for every r with `LargestRoot G r`, and every x in `Set.Icc r 0`, `I(G,x) ≤ I(H,x)`. Same direction, the interval uses G's root, and x is negative as in the source. Lean does not prove that ⪯ is a preorder, and it does not need to (see the next point).
- **Not vacuous.** `HasAntichain` requires every member to be a tree *and* to have a largest root. So `¬ Precedes` cannot hold just because the root is missing. It forces a point x in [ξ(G),0] where the strict inequality holds. Every tree's polynomial is nonzero (constant term 1), so the root set is finite. The Lean proof shows this root exists and is < −1/6 for every tree it builds.
- **Distinctness and isomorphism.** `F : Fin k → SimpleGraph (Fin n)` is not required to be injective, but that is not needed. If two members had equal independence polynomials, both `Precedes` directions would hold (both roots exist). So pairwise incomparability forces pairwise different polynomials. That means non-isomorphic trees and distinct independence-equivalence classes. This matches the source's antichain in (A, ⪯), the poset of equivalence classes (v2 Thm 1.1, journal Thm 1). Isomorphic copies cannot be counted twice.
- **Question.** Journal p.44, Question 6 (= v2 p.23, Question 5.3): "Can there be arbitrarily large anti-chains with respect to ⪯ among trees of equal order?" `ArbitrarilyLarge : ∀ k, ∃ n, HasAntichain n k` answers this exactly: for each k, k trees all on `Fin n`, pairwise incomparable. `WidthLowerBound` (for every n ≥ 11, ⌊n/11⌋+1 such trees) is a strictly stronger, quantitative statement. Neither target has extra hypotheses.
- **Numbering.** I checked: journal Theorem 16 / Figure 16 / Question 6 = v2 Theorem 4.6 / Figure 17 / Question 5.3. Both give pairs of incomparable trees of order 2^(k+3) and leave unbounded antichains open. I did not re-read v1. SOURCE-CHECK reports the same numbering there.

## 2. Is the proof chain clean?

- **CheckAntichain.lean.** It has exactly `theorem check_WidthLowerBound : Challenge.WidthLowerBound := Proof.WidthLowerBound` and the same for `ArbitrarilyLarge`, plus 4 `#print axioms`. Only Challenge.lean opens `namespace TaskN.Antichain.Challenge`. The other modules use `TaskN.Antichain`, `TaskN.Antichain.Num` and `TaskN.Antichain.Proof`, so nothing shadows a frozen name. My `Audit.lean` compiles `example : TaskN.Antichain.Challenge.WidthLowerBound := TaskN.Antichain.check_WidthLowerBound` (and `ArbitrarilyLarge`, and both `Proof.*` theorems) with fully qualified names. It also checks by `Iff.rfl` that `WidthLowerBound` unfolds to the expected explicit statement, and `#print`s every frozen definition. The printed definitions match the source as described in §1.
- **Forbidden constructs.** I grepped all 11 files for `sorry`, `admit`, `native_decide`, `bv_decide`, `axiom` (as a declaration), `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `notation`, `set_option`, `initialize`, `run_cmd`, `ofReduceBool`, `@[` and `attribute`. None appear. There is one `instance` (`RT.instFintype`, a structural Fintype instance on the tree-code vertex type). There are two kernel-checked `decide` uses: `Fintype.card Unit = 1` (TreeCode) and the enumeration of `Finset Unit` (TreePolynomial). `private` declarations are ordinary helpers.
- **Proof structure (Lean).** Trees come from a binary rooted-tree code `RT` joined by "bridge" edges. Tree-ness is proved by induction (connected, and |E| = |V| − 1). The real independence polynomial equals a two-component recursion (TreePolynomial, BridgeWeights), and trees are relabelled onto `Fin n` by graph isomorphism (GraphTransport). TreeRoot proves that every coded tree has a largest real root. CompareCore shows that every root of a family member is < −1/6, using `val_pos` on [−1/6, 0] and positivity for x ≥ 0. So both −1/6 and −1/10 lie in every comparison interval. At these points the family values are strictly increasing / decreasing in j (Numeric, by exact rational evaluation and positive Taylor certificates). This rules out both `Precedes` directions. `ArbitrarilyLarge` takes n = 11(k+1) and restricts with `Fin.castLE`.
- **Axioms.** All 4 printed declarations in CheckAntichain, and the 2 in Audit, depend only on `[propext, Classical.choice, Quot.sound]`. This holds both in Codex's logs and in my rebuild.

## 3. Independent rebuild on this Mac

- **Setup.** New empty directory `.../scratchpad/final-antichain/`. I copied the 11 `.lean` files to `src/` and added `Audit.lean`. I did not use lake or any Codex build product. I compiled each module with `lean -o` in the receipt's order, using `-DautoImplicit=false -DrelaxedAutoImplicit=false -DwarningAsError=true` (as in the acceptance lakefile). `LEAN_PATH` pointed at my own `out/` plus the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`. Mathlib was not rebuilt.
- **Toolchain and dependencies.** Lean 4.34.1, commit 5045d005. The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…). Mathlib is at `d13f23b723b8a846827a245b89c10fc7d3f11612` (`git rev-parse`). All 9 package revisions equal `receipt.dependency_commits`.
- **Lock.** I acquired `leanlock.sh acquire any claude-final-antichain 60` (slot A) before compiling and released it (`released A`) after the last checker run. Only one Lean process ran at a time.
- **Result.** All 12 modules compiled with exit 0 and no warnings or errors. The only output was the `#print`/`#print axioms` info. `leanchecker` ran on each of the 12 modules (11 local + Audit): every run exited 0 with empty output. Peak RSS for a single command was 6.02 GB. Memory pressure stayed normal (52–60% free).
- **Numeric cross-check (Python/sympy, independent of Lean).** I built the trees as the prose describes them. Their polynomials equal Lean's `hEval`/`aEval`/`bEval`, and I_A − I_B = x³[(2+x)(1+x)⁴ − 1]. For n ∈ {11, 22, 23, 33, 34, 44} every family member is a tree on n vertices with maximum degree 5. The largest real root is in (−0.214, −0.195), so it is < −1/6. Values at −1/6 strictly increase in j and values at −1/10 strictly decrease. All polynomials are distinct. The stated D_A(1/6) = 140281/186006 and D_B(1/6) = 23230/31001 are exact.

## 4. Mathematical sanity of MATHEMATICS.md

The written proof is correct and matches what Lean proves. The gadgets, the swap identity, the uniform zero-free interval [−1/6, 0] (via D > 2/3, weights < 1/4, path ratios > 1/2), and the opposite monotonicity at −1/10 and −1/6 all match the Lean argument. The padding by n − 11m bare spine vertices also matches. The last section correctly says that max degree 5 and the complex-disk argument are prose only. The text never says "first". Prior-art credit goes correctly to the authors' Theorem 16 pair and to the known deletion recursion. The points below are presentation fixes.

## MINOR write-up fixes

1. MATHEMATICS.md, opening paragraph: it says "Beaton–Cameron 定义 H⪯G". The source says Csikvári introduced the relation and Beaton–Cameron use it (journal p.31; transitivity is also Csikvári's). Attribute the definition to Csikvári, as used by Beaton–Cameron.
2. MATHEMATICS.md, theorem statement: "最大度至多 5" appears in the boxed theorem with no qualifier. Add "（书面性质，未形式化）" there, not only in the closing Lean paragraph.
3. MATHEMATICS.md, heading "不依赖外部实根定理的形式化路线": this section is an unformalized prose sketch of the complex-disk argument, and the sketch is terse. The heading reads as if Lean does this. Rename it, e.g. "书面补充：树的最小模根即最大实根（未形式化）". Also say that the frozen statement uses the source's own identification ("equivalently referred to as the largest real independence root"), so the formal result does not depend on this sketch.
4. MATHEMATICS.md, last-but-two paragraph: "本题新增任意长度的部件拼接……" is a novelty claim. G2 approved only continuation and says the priority check is still pending. Add the scope "据截至 2026-11-20 的 G2 检索", or repeat the pre-release check before publishing.
5. Optional: when citing, give both numberings in one place (journal Question 6 / Theorem 16 / Figure 16 = arXiv v2 Question 5.3 / Theorem 4.6 / Figure 17). The current text names journal Figure 16 and Theorem 16 without the arXiv equivalents.
