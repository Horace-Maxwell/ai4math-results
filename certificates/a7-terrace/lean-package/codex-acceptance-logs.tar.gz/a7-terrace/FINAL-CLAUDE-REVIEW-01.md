# Cross-family FINAL review 01: an ordinary terrace for A₇ (Task R)

**Verdict: APPROVE_FORMAL.** I found no BLOCKER and no MAJOR items. The frozen target `HasTerrace` says exactly what Bailey's terrace definition says (in Ollis's wording), over Mathlib's real `alternatingGroup (Fin 7)`. It is fully Lean-verified: standard axioms only, and my own rebuild and leanchecker pass. I also checked the certificate in Python. I found no prior terrace or sequencing of A₇. The MINOR items concern the write-up and the pre-release priority check only. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), a subagent of the user's Claude session. I wrote none of the reviewed files and took no part in Task Q or R.
- Review started 2026-11-20T19:42:04Z. Report written after 2026-11-20T19:48:25Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-a7/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (byte-identical to the frozen snapshot) | 27895ac5df9b39265c66e5cf8cd4107e064fa590fae1048bbcdaa2d3b1e537bb |
| CheckA7.lean | d5858022200100310243b1f26851b6609a4c2154b008a216cca1e44941435ebd |
| Proof.lean | 97e5ac21e255c8e91bf2da999b5e50ac6451d2e061c005e31739e09ca3d9a8ab |
| Counting.lean | e9f22c402724ac0b496ceb94571e529f249b50b85a8ce4a8842812758f9c5b64 |
| Kernel.lean | 1c1b81ee874683c129846d7e62568aedac12dd316aa5ad5a473fa415c224b441 |
| Interpret.lean | 6003020da9ddac3eb57bb978b751ece9fe9c2fcd8825ab31b852407ee8367450 |
| Cert.lean | 3945f45a70b95898ca2337c377a49dcf212a1c7b05086b8342131bb4701afbd5 |
| Data.lean | a00e8ea10e48bc11fd4fbd473defe9c025b487b88acc8f98d82f5ce952289ab7 |
| FREEZE.json | 97c9f7b5b0c01e9b7a38511f06df9bf7b87f30c02c3b867b53544ec033b2b767 |
| FREEZE-REVIEW.md | 129883a480872903cce85f73c2bf5c5da0e8d56a5decee15492319b3576543de |
| SOURCE-CHECK.md | a41d7e2a50166f11637639cc1eaa3b57e9cd0e198d30968a336ecd99f524cc7e |
| G2.md | a449f64ca722d0927b0ce684429aadd34080d6981df89fcfe42a620cbc2c2eb6 |
| MATHEMATICS.md | 56b5a116ab5e64bb9574500782b26b940e0216362b194156e1afe8e91dbad0ba |
| FINAL-HANDOFF.md | 68ae27dee1599adbb7d7d032f2c384a0301eb359ab68172be43e24aea20f02bb |
| generate.py | e013d5748f4f01ddf03a5ebcda6c703b348cb2e4fce6cde74a75ded23bfeb734 |
| acceptance/2026-11-20T193616Z/receipt.json | 25de636790dcb91284f552b7c6743181adccd92776f24da6ea520dd44cc53498 |
| phase24 witness.txt | d281ee1b967ee79b45ddbab88a140c45171e019faff3bc68e9a3b03502c29a3b |
| Ollis, arXiv:1603.01496v1 PDF (downloaded by me) | 1164d9d5ab9b601da45ec74500d5045c43c4b31f4b9d71c515c40cc376a62d58 |
| Ollis, DS10v3 (2025) survey PDF (downloaded by me) | 8d066f51b36547f29dc0880820d91571061ca5360377d3904bdae79221bda07a |
| Müyesser–Pokrovskiy, arXiv:2204.09666 PDF (downloaded by me) | 903c6f813f97d22bd4c41b9575537287a805e2c04f785f66aeb8a482c872bfe2 |
| Javaheri, arXiv:2208.14334 PDF (downloaded by me) | dab3e244a684f68f70a99553229182329eba8dd23dcc27874dcdc0ee9880efaf |
| My Audit.lean (scratch) | 10e640abaa3ea862f44657de9b88152ba318c4705a18e9a3cfd7f65abfff7f8f |
| My verify.py (scratch) | 308e5f9448978deecc3740158aaac4e7ffc5fdeb7600f9c4aaf0a76cb9dd9350 |

**Hash cross-checks:**
- All 8 source hashes match `receipt.json`.
- The 8 `.lean` files in root1 and root2 are byte-identical to the task root (same combined hash).
- The Challenge hash matches `FREEZE.json` and `frozen/27895ac5…/Challenge.lean`.
- The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`.
- The FREEZE.json hash matches `receipt.freeze_sha256`.
- The receipt hash matches FINAL-HANDOFF.

## 1. Is the statement faithful to the source?

I extracted the primary texts myself with pdftotext.

**Definition.** Ollis, *Terraces for small groups*, arXiv v1 §1, pp.1–2, defines it as follows:
- For an arrangement (a₁,…,aₙ) of G, put bᵢ = aᵢ⁻¹aᵢ₊₁.
- The arrangement is a terrace "if each involution occurs exactly once in b and if for each x ∈ G with x² ≠ e the sequence b contains x and x⁻¹ twice in total".

The survey DS10v3 (2025) §2.3, p.13, gives the same thing in 2-sequencing form, and §3.4 says that terraces and 2-sequencings are equivalent. Ollis attributes the notion and the terminology to Bailey [J. R. Stat. Soc. B 46 (1984)]. I did not obtain Bailey's 1984 paper. Two independent restatements agree (Ollis 2016, and survey §§2.3/3.4).

**Lean statement.** `HasTerrace` is `∃ a : Fin 2520 ≃ G, a 0 = 1 ∧ ∀ g ≠ 1, card {i : Fin 2519 // d i = g ∨ d i = g⁻¹} = if g = g⁻¹ then 1 else 2`, where `d i = (a i.castSucc)⁻¹ * a i.succ`. Checked against the source:
- **Every element exactly once.** The `Equiv` forces this.
- **Quotient convention.** The 2519 consecutive left quotients use the same convention as Ollis.
- **Counting rule.** For an involution, {g, g⁻¹} = {g}, so the count is "exactly once". For any other g, the count is "g and g⁻¹ twice in total". Both directions may be the same.
- **The identity is excluded.** It cannot occur anyway, because a is injective.
- **`a 0 = 1` makes the statement stronger, not weaker.** It asks for a basic terrace. Ollis notes that left-multiplying by a₁⁻¹ preserves the quotients.
- **No extra hypotheses.**

**Choice of convention.** In Python I confirmed that this witness is not a terrace under the right-quotient convention aᵢ₊₁aᵢ⁻¹. That does not matter: the conventions are interchanged by g ↦ g⁻¹, so existence is the same. Lean follows Ollis's convention, and Mathlib's composition order is irrelevant for the same reason.

**The group is really A₇.** My Audit compiles the following with fully qualified names:
- `TaskR.A7.Challenge.G = alternatingGroup (Fin 7)` by `rfl`.
- `Fintype.card (alternatingGroup (Fin 7)) = 2520`.
- The fully unfolded statement, written with Mathlib names only and closed by `TaskR.A7.check_HasTerrace`.

**Non-trivial and satisfiable.**
- The Klein four-group has no terrace. Ollis also says that non-cyclic elementary abelian 2-groups are not terraced.
- A₇ has 105 involutions and 1207 other inverse pairs, and 105 + 2·1207 = 2519, the number of quotients.

**What A₇ contributes.** I checked this against the survey and Ollis's paper. The task brief mixes up two conjectures, so I separate them here.

(a) **Bailey's conjecture** (survey Conjecture 33) says every group except the elementary abelian 2-groups of order ≥ 4 is terraced. Survey Theorem 32 lists the non-abelian groups known to be terraced:
- (i) sequenceable groups;
- (ii) groups of odd order;
- (iii) groups with an odd-order normal subgroup and a terraced quotient, or a terraced normal subgroup of odd index;
- (iv) and (v) special 2-group-type families;
- (vi) groups of order ≤ 511, except possibly 256 and 384. Hanyu Yang closed 256 and 384 on 2026-09-16.

A₇ is outside all of these:
- It is simple, so (iii) does not apply.
- Its order 2520 is greater than 511.
- It is not known to be sequenceable. The known sequenceable groups are those of order ≤ 255, plus A₅, S₅, A₆, S₆, PSL(2,q₁) with q₁ ≤ 11 and PGL(2,q₂) with q₂ ≤ 8 (survey §2.5–2.6; Ollis Theorem 2.1).
- Müyesser–Pokrovskiy (arXiv Theorem 6.12; survey Theorem 14) make every sufficiently large non-abelian group sequenceable, hence terraced. They give no explicit threshold. The survey quotes Müyesser's estimate of roughly 10^50.

So A₇ being terraced is a new verified instance of Bailey's conjecture, as far as all searches show. The conjecture itself stays open.

(b) **Anderson's symmetric-sequencing conjecture** (survey Conjecture 16: Q₈ is the only binary group without a symmetric sequencing). This is where the 1993 reduction belongs. The reduction is by Anderson & Ihrig (not "Ierland"): *Symmetric sequencings of non-solvable groups*, Congr. Numer. 93 (1993) 73–82, cited as [12] in Ollis 2016 and [19] in the survey.
- It shows that it suffices to find 2-sequencings (terraces) of A₇, PSL(2,q) and PGL(2,q) for odd q > 3. Each one covers an infinite, disjoint family of insoluble binary groups (Ollis §3, p.6; survey p.15).
- Before this work, A₅ was done, and Ollis Corollary 3.1 did PSL(2,7), PSL(2,9), PSL(2,11), PGL(2,5) and PGL(2,7). A₇ was not done.
- Survey Theorem 9 (Anderson–Ihrig [18]) then gives the following: every binary G with G/(O(G)Λ(G)) ≅ A₇ has a symmetric sequencing. MATHEMATICS.md states this branch correctly. It also correctly says that the conjecture as a whole, and the general PSL/PGL cases, remain open.

(c) **Keedwell's conjecture.** The witness is **not** a directed terrace (some quotients occur twice; I checked in Python). So it says nothing about whether A₇ is sequenceable.

**Prior work.** I found no earlier terrace, directed terrace or sequencing of A₇, and no non-asymptotic theorem that covers it. What I checked:
- The DS10v3 lists, as of February 2025.
- Javaheri arXiv:2208.14334v5. A web-search summary claimed this paper states that "every group … is terraced". The paper actually only restates Bailey's conjecture (line "Bailey conjectured that …").
- The Müyesser–Pokrovskiy theorem.
- Hanyu Yang's site, deposit and repository list (orders 256/384 only; nothing on A₇).
- arXiv API searches, GitHub repository and code searches, and web searches on terrace / sequenceable / A₇ / 2520.

These results agree with G2, G2-NEIGHBORS and crosscheck-a7.md. Gaps, shared with G2: Ollis's old GAP site is unreachable; the Zenodo API refused my query (non-JSON response); the full text of Anderson–Ihrig 1993b was not obtained.

## 2. Is the proof chain clean?

**CheckA7.lean.** It contains exactly `theorem check_HasTerrace : Challenge.HasTerrace := Proof.HasTerrace` and two `#print axioms`.
- Only Challenge.lean opens `TaskR.A7.Challenge`. The other modules use `TaskR.A7`, `.Data`, `.Kernel`, `.Interpret`, `.Cert` and `.Proof`, so nothing shadows a frozen name.
- My Audit.lean reconfirms the result with fully qualified `example`s and `#print`s the three frozen definitions. They print exactly as in the source above.

**Forbidden constructs.** I grepped all 8 files for `sorry`, `admit`, `native_decide`, `bv_decide`, `axiom` (as a declaration), `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `notation`, `initialize`, `run_cmd`, `ofReduceBool`, `@[`, `attribute`, `instance` and `#eval`. None appear. The `set_option`s are harmless:
- `maxRecDepth 65536` and `maxHeartbeats 0` in Cert;
- `maxHeartbeats 900000` in Interpret.

There are 79 uses of `decide +kernel`, one per 32-row block, plus small `decide`s for `Nat.mod_lt` bounds and the card arithmetic. `development/BlockStart.lean` is not imported by anything.

**How the 2520-element certificate is checked.** The checker is proved correct in Lean.
- **Data.** Data.lean holds plain `Nat` lookup tables generated by generate.py. Their contents are untrusted.
- **Per-row check.** Kernel.lean defines a Boolean `valid i`. It checks two things:
  - The vertex decoded from at most 4 pairs of star transpositions acts on all 7 points like the stored image row. Each pair is a genuine element of A₇, built with `mul_mem_alternatingGroup_of_isSwap`.
  - A hash-based `rank` function sends the packed row back to i.
- **Per-edge check** (for i < 2519). The tables give a partner index e = edge(i) with `edgeBack e = i`. Then pointwise, `raw i ∘ raw (e+1) = raw (i+1)` (or the reverse for the other direction bit).
- **Kernel evaluation.** Cert.lean has the kernel evaluate `interval valid s 32` for each block. `interval_sound` and `merge` (both proved by induction) combine the blocks into `Good valid 0 2520`.
- **Interpretation.** Interpret.lean turns this into three facts:
  - an injective, hence bijective (card 2520 from `card_alternatingGroup`), map `Fin 2520 ≃ G` with `a 0 = 1` (checked pointwise);
  - an injective, hence bijective, matching σ on Fin 2519;
  - `d i ∈ {a(σ i + 1), a(σ i + 1)⁻¹}`.
- **Counting.** Counting.lean (`fromMatching`) proves abstractly that {i : d i ∈ {g, g⁻¹}} is in bijection with {g, g⁻¹}. The reason is that i ↦ a(σ i + 1) is a bijection onto G \ {1}. So the count is 1 or 2.

I read every step. The argument is sound, and a wrong or colliding table entry would make some block's `decide` fail.

**Axioms.** `Proof.HasTerrace`, `check_HasTerrace`, `Cert.allRows` and `fromMatching` all depend only on `[propext, Classical.choice, Quot.sound]`. This holds in Codex's logs and in my rebuild.

## 3. Independent rebuild on this Mac

**Setup.**
- New empty scratch directory. I copied the 8 `.lean` files into `src/` and added Audit.lean.
- I used no lake and no Codex build output.
- I compiled each module with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o out1/<M>.olean` in dependency order: Challenge, Data, Counting, Kernel, Cert, Interpret, Proof, CheckA7, Audit.
- `LEAN_PATH` was my `out1/`, plus the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`, plus the toolchain library.

**Toolchain.**
- Lean 4.34.1, commit 5045d005.
- The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…).
- Mathlib `git rev-parse` gives d13f23b723b8a846827a245b89c10fc7d3f11612.

**Lock.**
- I ran `leanlock.sh acquire any claude-final-a7 60`, got slot A at 19:43:22Z, and released it (`released A`) after the compile.
- I re-acquired it briefly (slot A, 10 min) for one leanchecker rerun on Audit, then released it again. The first Audit checker run had failed only because `lean` was not on PATH.
- Final status: A free, B free. Only one Lean process ran at a time.

**Results.**
- All 9 modules compiled with exit 0. The only output was the `#print` and `#print axioms` info, with no warnings or errors.
- My first Audit draft had a wrong `rw` in my own card lemma. I fixed it, and the second compile exited 0.
- `leanchecker` ran on all 9 modules (8 local + Audit). Each exited 0 with empty output.
- Timings: Cert 15.9 s, everything else ≤ 6 s.
- Peak child RSS was 3.22 GB. Disk had 512 GB free.
- My olean hashes differ from the receipt's because the build method differs (plain `lean -R` instead of lake). That is expected and does not matter.

**Python certificate check** (verify.py, standard library only, run with `-I`). It parses the `images` and `words` tables from Data.lean and decodes them with exactly the Lean bit layout. Results:
- All 2520 rows are permutations, and the decoded star-transposition words equal the rows.
- The set of rows equals the 2520 even permutations of {0..6}, enumerated independently, with no duplicates.
- Row 0 is the identity.
- Among the 2519 left quotients, the identity never occurs. Each of the 105 involutions occurs exactly once, and each of the 1207 other inverse pairs occurs exactly twice (0 bad orbits).
- The rows equal (witness row 0)⁻¹ · (witness rows) for the phase-24 witness.txt, whose SHA d281ee1b… matches.

## 4. Mathematical sanity of MATHEMATICS.md

The written proof (encoding, per-row checks, matching σ, the orbit bijection) is correct and matches what Lean proves. Two credits are correctly given to earlier work:
- The terrace definition and the hill-climbing method with reversed segments: Ollis 2016 §2, which builds on Anderson.
- The lifting theorems: Anderson; Anderson–Ihrig.

The text never claims Bailey's or Anderson's conjecture, and it never says "first" (I grepped for 首次 / 首个 / 首发 / first / novel). The remaining points are presentation and priority hygiene.

## MINOR

1. **MATHEMATICS.md, 历史范围: add the Bailey-conjecture contribution.** The text frames A₇ only through the Anderson–Ihrig symmetric-sequencing reduction. Add one sentence: A₇ is simple, has order 2520 > 511, is not known to be sequenceable, and lies below the unspecified Müyesser–Pokrovskiy threshold, so it is outside every family in survey Theorem 32. The certificate therefore adds one verified group to Bailey's conjecture "据截至 2026-11-20 的检索". Also say that the 1993 reduction belongs to Anderson's conjecture, not Bailey's.
2. **MATHEMATICS.md: replace the vague sentence.** The sentence is "这个具体见证消除了 A₇ 有限实例的阶数门槛". Write instead: Müyesser–Pokrovskiy together with Theorem 8 covers binary groups in the A₇ branch only when they are sufficiently large (no explicit bound; the survey quotes about 10^50). With the witness, Theorem 9 covers every G with G/(O(G)Λ(G)) ≅ A₇. The "associated group via a subnormal series" version uses Anderson–Ihrig 1993b, which was read only through Ollis's paraphrase. Say this in MATHEMATICS.md too; at present only SOURCE-CHECK says it.
3. **MATHEMATICS.md: state that the witness is not a directed terrace.** Some quotients repeat, so A₇'s sequenceability (Keedwell) remains open. This prevents a misreading of "terrace" as "sequencing".
4. **MATHEMATICS.md: check the Müyesser–Pokrovskiy theorem number.** "定理 6.12" is the arXiv numbering (I verified it there), but the link goes to the Inventiones version. Either check the journal numbering or cite arXiv:2204.09666.
5. **Pre-release G3: priority risk.** The niche has an active independent depositor: Hanyu Yang (SeverinVisionary), who deposited Bailey terraces for orders 256/384 with a DOI on 2026-09-16 and has updated their site since. Recheck their site, repository list and Zenodo right before publishing; my Zenodo API query was refused. Also try once more to reach Ollis's old GAP site and the full text of Anderson–Ihrig 1993b.
6. **Optional: Bailey 1984.** Neither SOURCE-CHECK nor I read Bailey 1984 directly; the definition rests on two Ollis texts. Say so, or cite Ollis for the definition.
