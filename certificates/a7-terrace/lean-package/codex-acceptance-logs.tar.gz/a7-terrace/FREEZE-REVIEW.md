# A₇ 陈述独立冻结审查

2026-11-20T19:30:35Z。审查者是本次 SOURCE-CHECK 的非作者 Codex 子代理。审查对象为同目录 Challenge.lean，SHA-256 `27895ac5df9b39265c66e5cf8cd4107e064fa590fae1048bbcdaa2d3b1e537bb`。判定 **APPROVE_FREEZE**。

- `G` 是 Mathlib 的 `alternatingGroup (Fin 7)`。`Fin 2520 ≃ G` 同时强制顶点穷尽及各只出现一次。
- `Fin 2519` 的两个嵌入是原索引和原索引加一，恰好遍历线性排列的相邻边。其群运算算出 aᵢ⁻¹aᵢ₊₁。
- `g ≠ 1` 去除单位元。带析取的 subtype 按位置计数：自逆时不会重复计入同一次出现，非自逆时则合并两个方向。原文的 1 与 2 两个重数准确。
- 首项为单位元的附加条件等价于原文存在性，见 SOURCE-CHECK 的左平移说明。命题未向证明者提供任何先验计算结论、假设或见证。
- 此 SHA 冻结后不可改。审查只核对数学语义，后续逐模块编译和 leanchecker 仍由验收执行。
