"""Encode the fixed witness. Correctness of all exported data is checked in Lean."""
from collections import defaultdict, deque
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUT = HERE.parents[2] / "phase24/scout-q/attempts/a7-terrace/witness.txt"
raw = [tuple(map(int, line)) for line in INPUT.read_text().splitlines()]

def inv(p):
    return tuple(p.index(k) for k in range(7))

def mul(p, q):
    return tuple(p[j] for j in q)

identity = tuple(range(7))
rows = [mul(inv(raw[0]), r) for r in raw]
paths = {identity: ()}
todo = deque([identity])
while todo:
    p = todo.popleft()
    for j in range(1, 7):
        q = list(p)
        q[0], q[j] = q[j], q[0]
        q = tuple(q)
        if q not in paths:
            paths[q] = paths[p] + (j - 1,)
            todo.append(q)

def pack(values, base):
    return sum(v * base**i for i, v in enumerate(values))

words = [pack(paths[p], 6) for p in rows]
assert max(len(paths[p]) for p in rows) <= 10
assert all(len(paths[p]) % 2 == 0 for p in rows)
images = [pack(p, 8) for p in rows]

# A small static perfect hash of the two thousand five hundred twenty packed rows.
buckets = defaultdict(list)
for i, x in enumerate(images):
    buckets[x % 257].append((i, x))
for modulus in (4093, 4241, 5003, 5521, 6911, 8191):
    disp, back = [0]*257, [-1]*modulus
    for k in sorted(buckets, key=lambda b: -len(buckets[b])):
        items = buckets[k]
        if len({x % modulus for _, x in items}) != len(items):
            break
        for shift in range(modulus):
            slots = [(x + shift) % modulus for _, x in items]
            if all(back[h] < 0 for h in slots):
                for (i, _), h in zip(items, slots):
                    back[h] = i
                disp[k] = shift
                break
        else:
            break
    else:
        break
else:
    raise ValueError("No static hash found")

pool = defaultdict(list)
for i, p in enumerate(rows[1:]):
    pool[min(p, inv(p))].append(i)
edge, edge_back = [], [None]*2519
for i, (p,q) in enumerate(zip(rows, rows[1:])):
    d = mul(inv(p), q)
    j = pool[min(d,inv(d))].pop()
    r = rows[j+1]
    assert d==r or d==inv(r)
    edge.append(2*j + (d != r))
    edge_back[j] = i

def table(name, seq, width):
    assert all(0 <= v < 2**width for v in seq)
    st = [f'def {name} (i : Nat) : Nat :=', '  let block := match i / 64 with']
    for b, start in enumerate(range(0, len(seq), 64)):
        data = pack(seq[start:start+64], 2**width)
        st.append(f'    | {b} => 0x{data:x}')
    st += ['    | _ => 0', f'  (block >>> ({width} * (i % 64))) % {2**width}', '']
    return '\n'.join(st)

out = ['import Mathlib.Data.Nat.Basic', '', 'namespace TaskR.A7.Data', '',
       f'def hashMod : Nat := {modulus}', '']
for name, seq, width in [('words', words, 26), ('images', images, 21),
                         ('shifts', disp, 13), ('rankTable', [max(0,i) for i in back], 12),
                         ('edgeTags', edge, 13), ('edgeBack', edge_back, 12)]:
    out.append(table(name, seq, width))
out.append('end TaskR.A7.Data\n')
(HERE / 'Data.lean').write_text('\n'.join(out))
print(len(rows), max(map(lambda p:len(paths[p]),rows)), modulus)

# Every literal interval is independently normalized by the Lean kernel. A
# balanced tree of elementary interval concatenations covers the entire range.
cert = ['import Kernel', '', 'namespace TaskR.A7.Cert', 'open Kernel',
        'set_option maxRecDepth 65536', 'set_option maxHeartbeats 0', '']
segments = []
for start in range(0, 2520, 32):
    size = min(32, 2520-start)
    name = f'b{start}_{size}'
    cert.append(f'private theorem {name} : Good valid {start} {size} := interval_sound (by decide +kernel)')
    segments.append((start,size,name))
while len(segments) > 1:
    next_segments=[]
    for j in range(0,len(segments),2):
        if j+1 == len(segments):
            next_segments.append(segments[j])
            break
        s,n,h=segments[j]
        t,m,k=segments[j+1]
        assert s+n==t
        name = f'b{s}_{n+m}' if n+m < 2520 else 'allRows'
        access = 'private ' if n+m < 2520 else ''
        cert.append(f'{access}theorem {name} : Good valid {s} {n+m} := merge {h} {k}')
        next_segments.append((s,n+m,name))
    segments=next_segments
cert.append('\nend TaskR.A7.Cert\n')
(HERE/'Cert.lean').write_text('\n'.join(cert))
