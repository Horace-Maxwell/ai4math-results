# Cross-family FINAL review 01: prism–cube sandwich illumination trichotomy (Task V)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The frozen target `PrismIllumination.Trichotomy` faithfully states the claimed 6/7/8 classification with the standard Hadwiger–Boltyanski illumination number. It quantifies over all compact convex K with P ⊆ K ⊆ Q, not only polytopes, and it is fully Lean-verified. I checked this with an independent plain-`lean` rebuild, leanchecker on every module, and standard axioms only. I found no published statement of this trichotomy or of a result that implies it. The class is very special and the proof is elementary, so the write-up must position it modestly. The MINOR items concern the write-up only. None affects the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session; wrote none of the reviewed files. Lock owner name `claude-final-illum-01`.
- Review started 2026-11-21T04:51:55Z; report written after 2026-11-21T04:56:42Z (Mac `date -u`).
- My only write in the task directory is this file. All scratch work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/illum/`.
- Inputs not present for this task: there is no FREEZE.json, FREEZE-REVIEW.md, SOURCE-CHECK.md, G2.md, MATHEMATICS.md, Proof.lean, dev-logs/, ../SELECTION.md or ../BRIEF.md in the form named by the common instructions. Their roles are played by `acceptance/FROZEN.sha256`/`FROZEN.utc`, `STATEMENT-MAP.md`, `higher-order/PROOF.md`, `literature-cont/REPORT.md`, the two non-author reviews, and `../../BRIEF.md` / `../../CONTINUE-MARKOV-ILLUMINATION.md` / the card. The task is self-posed, a subclass carved out of the open 3D Hadwiger–Boltyanski problem, so there is no single "source paper" to quote. I checked faithfulness against the standard definition (Bezdek–Khan survey, arXiv 1602.06040: "The smallest cardinality of an illuminating set for K is called the illumination number of K").

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| formal/Illumination/Challenge.lean (= `FROZEN.sha256` entry) | 2fd9927a0e7b532493e5de4038665d92490e479fb712298ad2b7321b863bbe6d |
| formal/Illumination/Check.lean | 34e0b19aa01520859e77aac48d8f082d67f3b8c110c236a3555b62400a144347 |
| formal/Illumination/Result.lean | ff2bfbe83b47fad9184bf92a98866171efeb75c5a2928a574d7d57a47ae25a92 |
| formal/Illumination/Planar.lean | a779c88882706ff41d8b415665dfd6f0563f17f78d1d0c0fd7dd2f972da8abfc |
| formal/Illumination/Gaps.lean | a21497952131532b491b30c5e73bcc2124fe202707c38aaeb9b4d07c4bf0d1b5 |
| formal/Illumination/Upper.lean | 63d3eb03ee201eb8acdc7969cdeea2ce3841e149e97e325bd803ffa9ad15aa0f |
| formal/Illumination/Lower.lean | efe6d6ea94de4645a6db6eafbc79ce2cc86a7144ee185b3f3b7b6d8737b06f14 |
| formal/lakefile.toml | ced1e29459c4ced0a4b515370bf6c5e29f93739d13d46b7bfad3996f73436c08 |
| formal/lake-manifest.json (mathlib d13f23b7…, = v4.34.1) | 67c34c86ccc3f65ab5f8afed6bd5d38f34ed6b361930c1bb2c54dc35287eb005 |
| acceptance/FROZEN.sha256 (FROZEN.utc 2026-11-21T03:53:24Z) | 8884256ba466fc4578397f65431930396e834bdbaf20661fab4885f17136ed26 |
| acceptance/dual-02/receipt.json (machine_status PASS) | bdc4a5d4a22359cb86bf638a2fe423d1f2f9ab1685b71d9c72e8af861330f644 |
| acceptance/controller-dual-02-resume-01/POST-AUDIT.json | fbf59d1c0df084165c1da2035aed63d4ccd12501f5cb0e27b23680954d024e4d |
| acceptance/INDEPENDENT-FORMAL-REVIEW.md | 53e732f087280dd2c6682df6681a34640a1c305a177c2d0e605c9d6c6e2eff1e |
| higher-order/PROOF.md (= `FROZEN.sha256` entry) | dc3072fefce1dcde1199d82165ab90089593f5b46c4d68e6b0368f75b318dfda |
| STATEMENT-MAP.md | c1e6490e08821ae3b2627082d994e8284f1eb1257b2d82ce19b1611fac1790af |
| FINAL-HANDOFF.md | 5c3d91baa3dfa674f145b4dd96b36b3d6c67f0bc9ed299568591616e36503d1e |
| literature-cont/REPORT.md | ad8aab3bc104a6525d03a9b52de1ceb91803a0f31c44f31d7b756f9514a64519 |
| My Audit.lean (scratch) | 60f6ebd3d4862f53c45cc72326f5d585bf5de5923de172619df1c4853b8352ee |
| My Extra.lean (scratch; definition-equivalence lemma) | 14f3785866a884cc25e6e1b334f0fd1d77fd7122cc64f5400d60444aa94f89ec |
| My illum.py (scratch; LP illumination checker) | 64ef9e93d6fceba29cbaf43d54370808a9eee59de00107f1624c3348fc628f46 |

All seven source hashes, the lakefile and the manifest match `receipt.json.source_sha256` and POST-AUDIT. The Challenge and PROOF hashes match `FROZEN.sha256`. `formal/Illumination/` is byte-identical to `acceptance/dual-02/fresh/Illumination/` (`diff -r` empty). The receipt SHA matches the value quoted in DONE/STATUS.

## 1. Is the statement faithful?

**Definitions.** `Space := Fin 3 → ℝ` has the product topology, which is the usual topology of ℝ³. `interior` and `frontier` are therefore the usual ones. `cube`, `prism` (x+y ≤ 1 inside Q) and `edge` (x = y = 1 inside Q, both endpoints included) match the stated sets coordinate by coordinate.

**Illumination.** `Illuminates K u p := ∃ t > 0, p + t•u ∈ interior K`. This is Boltyanski's "the ray from p in direction u meets int K". The Hadwiger-style "p + εu ∈ int K for all sufficiently small ε > 0" is equivalent for convex K and p ∈ cl K. I proved this in Lean myself (`illum_all_small` in Extra.lean, via `Convex.openSegment_closure_interior_subset_interior`; axioms standard). Boundary points satisfy p ∈ frontier K ⊆ closure K, so the "some t" and "all small ε" versions coincide here.

**Counting.** `CanLight K n` fixes a family `Fin n → Space` of nonzero vectors *before* quantifying over `p ∈ frontier K`. That is the correct fixed-directions order of quantifiers. `Exact K n := CanLight K n ∧ ∀ m, CanLight K m → n ≤ m` is a genuine minimum (IsLeast-style). It is not an `sInf` that could default to 0. Repeated directions are allowed, but that cannot lower the minimum. Since the frontier is nonempty, `CanLight K 0` is false. `Exact` is functional: I proved `Exact K a → Exact K b → a = b` in Extra.lean.

**Range of K.** `IsCompact K → Convex ℝ K → prism ⊆ K → K ⊆ cube` covers all compact convex sandwiched sets, curved ones included. Nonempty interior is automatic, since the open prism lies in int K. The three branches are exhaustive. The middle branch carries both `¬Disjoint K edge` and `K ≠ cube`, and `Disjoint` implies `K ≠ cube`, so no case is lost.

**Non-vacuity.** In Extra.lean I instantiated the theorem at K = cube and obtained `Exact cube 8`. Satisfiable examples exist for all three branches: P; Q ∩ {x+y−z ≤ 1}, which meets E only at (1,1,1); and Q.

**Numerical sanity, my own code.** I wrote an LP-based exact-cover checker for polytopes. It treats a vertex v as lit by u iff a_i·u < 0 for every facet active at v, which is the open tangent cone. Lighting all vertices suffices, because the active set of a relative-interior point of a face is contained in that of any vertex of the face. The checker then finds the minimum partition of the vertices into groups whose cones have a common point.

| K | vertices | computed I(K) | predicted |
|---|---:|---:|---:|
| P | 6 | 6 | 6 |
| cube | 8 | 8 | 8 |
| conv(P ∪ {(1,1,1/2)}) | 7 | 7 | 7 |
| conv(P ∪ {(1,1,0)}) | 7 | 7 | 7 |
| conv(P ∪ {(1,1,1)}) | 7 | 7 | 7 |
| conv(P ∪ box [0.9,1]²×[0.4,0.6]), a neighbourhood of a point of E | 8 | 7 | 7 |
| conv(P ∪ {(0.9,0.9,0.5)}), misses E | 7 | 6 | 6 |
| Q with corner (1,1,1) cut off | 10 | 7 | 7 |
| Q minus a thin slab along E | 10 | 6 | 6 |
| 300 random conv(P ∪ 1–5 points of Q), 123/159/18 per branch | — | 0 mismatches | — |

The checker uses floating-point LP, so it is a sanity check, not a certificate. It agrees everywhere.

## 2. Proof chain

- `Check.lean` is exactly `theorem check_trichotomy : Trichotomy := prism_trichotomy`. `Result.lean` assembles `gapSix/gapSeven` (compactness gaps), `upperSix/upperSeven/cubeEight` and `lowerSix/lowerSeven/lowerEight`.
- No local declaration shadows a frozen name. The local defs are `dx, dy, Step, core, beam, level, orient, lamps, address, corner, valid, distinguish, depth`.
- I grepped all seven modules for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, set_option, initialize, run_cmd, ofReduceBool and `@[`. There are no hits.
- There are two `private instance … : Decidable …` declarations in Lower.lean. They are ordinary instances, built by `unfold; infer_instance`.
- **`decide` uses.**
  - Lower.lean:110, 132, 141 are kernel `decide` on the finite "corner addresses pairwise distinguished" predicate over Fin 6, Fin 7 (masked) and Fin 8 × Fin 3 via `Nat.testBit`. These are small, and leanchecker accepted them.
  - Planar.lean:38, 40, 45, 50, 71 and Upper.lean:96, 119, 141 are trivial `j < 3`, `j < 4` and `3 ≤ 6` style facts.
- The lakefile sets `warningAsError = true` and `autoImplicit = false`. It has no other options.
- **Mathematical content of the Lean proof.** I read it in full.
  - The lower bounds come from interior points of K ⊆ Q having strictly interior coordinates. Each cube corner then forces a strict sign on every coordinate of the direction, and the pigeonhole step is an injective map from points to direction indices.
  - The upper bounds send every frontier point with a step 0 < t < 1 into the open prism `core`. `core` is open and contained in P ⊆ K, hence in int K, so no regularity of ∂K is needed.
  - The horizontal directions are (1,1), (−1,e), (e,−1) and, only when needed, (−1,−1). The vertical component is ±1/4 in the 6-direction and 8-direction cases and ±e in the 7-direction case. A Boolean flips z ↦ 1−z according to which endpoint of E is missing.

## 3. Independent rebuild on this Mac

- **Lock.** `leanlock.sh acquire any claude-final-illum-01 60` gave slot A at 04:52:40Z. I released it at 04:54:13Z ("released A"). There was only one Lean process at a time.
- **Compile.** I copied the seven sources into an empty scratch `src/`. I compiled each with plain `lean -j1 -DautoImplicit=false -DwarningAsError=true -R src -o out/…olean`, using Lean 4.34.1 (`work/toolchains/lean-4.34.1-darwin_aarch64/bin`). LEAN_PATH pointed to the prebuilt Mathlib d13f23b7 oleans in `work/research-lean-v434/.lake/packages`. The build order was Challenge, Planar, Gaps, Upper, Lower, Result, Check, Audit, Extra.
- **Results.** All modules compiled with rc 0 and no output, in 4–6 s each. `leanchecker Illumination.<M>` returned rc 0 with empty output for all eight modules (the seven plus Audit).
- **Audit.lean.** It contains fully qualified `example`s for `check_trichotomy` and `prism_trichotomy`, the fully unfolded frozen statement, and `Iff.rfl` unfoldings of `Illuminates` and `Exact`. `#print axioms` for check_trichotomy, prism_trichotomy, upperSix, upperSeven, cubeEight, lowerSix, lowerSeven, lowerEight, gapSix and gapSeven is in every case `[propext, Classical.choice, Quot.sound]`. The same holds for my `illum_all_small`.
- **Comparison with the receipt.** My plain-lean olean hashes differ from the receipt's lake-built oleans, as expected given different invocation and paths. The receipt's own two roots, normal and fresh, have byte-identical oleans, and both report the same three axioms for all 23 audited names.
- **Interrupted root.** The resumed first root is documented: the original controller exit was "unobserved" and the Upper checker log was kept separately. My independent rebuild makes that interruption immaterial.

## 4. Mathematics, attribution and novelty

**Correctness.** `higher-order/PROOF.md` is correct. I checked:
- the planar lemma, including the origin, the axes and the (−1,−1) case;
- the compactness gap η, and the reflection reducing to (1,1,0) ∉ K;
- the choice δ = min(ρ/2, 1/4) with ε < min(δ, 1−δ);
- the lower bounds, including contact only at an endpoint of E.

`STATEMENT-MAP.md`'s middle-branch example Q ∩ {x+y−z ≤ 1} contains P and meets E only at (1,1,1), as stated. No "first" claims appear. The handoff states that the general 3D conjecture remains open and keeps the finite hull computations and the quartet outside the contract.

**Prior work, my own search.** I checked against the general 3D bounds:
- Papadoperakis (16) and Prymak (SIAM J. Discrete Math. 2023; 14);
- Lassak 1984 (centrally symmetric) and Dekster (plane-symmetric);
- Bezdek (polytopes with affine symmetry), Boltyanski 2001 (md(K) = 2 ⇒ ≤ 6) and Martini–Soltan 1999;
- Livshyts–Tikhomirov (arXiv 1710.05070, DCG 2020: non-parallelotopes sufficiently close to the cube need ≤ 2ⁿ−1);
- Wu–Zhou (CDM 14 (2019) 190–202: convex hulls of two compact convex sets in parallel planes of ℝ³ are "completely solved"; ≤ 8, with 8 only for parallelepipeds) and Wu–Zhang–He 2021;
- Sun–Vritsiou (1-unconditional bodies in ℝ³ and ℝ⁴), Arman–Kaire–Prymak (3D cap bodies, I = 6), and the Bezdek–Khan survey.

None states this trichotomy, and none implies it for all sandwiched K:
- The lower bounds (6, 7, 8) are classical. They are the pairwise antipodality of cube vertices and of a point of E against the six prism corners.
- The cube value 8 is classical.
- Wu–Zhou plus the lower bound gives exactly 7 only for *two-layer* K in the middle branch, and only ≤ 7 rather than 6 in the disjoint branch. REPORT.md's curved example, Q ∩ a ball, avoids E and has extreme points off any two planes, so it is not two-layer.
- Livshyts–Tikhomirov gives ≤ 7 only for K within an unspecified small Banach–Mazur distance of the cube.
- Boltyanski's md(K) = 2 criterion does not apply in general. REPORT.md gives a branch-6 example with md = 3.

**Verdict on novelty.** No MAJOR novelty item. The assessment is subject to the usual blind spots: books, non-digitised work, and the G3 release-day recheck, which is still pending.

**Honest positioning.** The class is very special. It is an ad hoc coordinate family, not a natural class studied in the literature. The theorem is essentially an exercise. The lower bounds are textbook, and the upper bounds come from one short trick: steer every boundary point into the interior of the inscribed prism. This is a correct, fully verified, small result. It is not progress on the Hadwiger–Boltyanski conjecture, and the write-up should say so plainly.

## MINOR fixes (write-up only)

1. `acceptance/INDEPENDENT-FORMAL-REVIEW.md` still ends with the placeholder "两个新根的机器证据 / 本节待正式收据封口后填写". Fill it in, or mark it superseded by `dual-02/receipt.json` and POST-AUDIT.
2. `higher-order/PROOF.md` cites no literature. Add attributions:
   - the six-corner and cube-vertex lower bounds and I(cube) = 8 are classical (Boltyanski / Hadwiger; see the Bezdek–Khan survey);
   - I(T×I) = 6 is classical;
   - the exact value 7 of the example conv(P ∪ {(1,1,1/2)}) already follows from Wu–Zhou (2019) together with the lower bound;
   - Livshyts–Tikhomirov's ≤ 7 covers the near-cube part of the middle branch.
   REPORT.md has all of this, but the proof text that will be published does not.
3. State explicitly in the release text that the new content is only the matching *upper* bounds (6 and 7) for *all* sandwiched compact convex K. Also state that the class is a special coordinate family and that the argument is elementary. Do not present it as a step towards the 3D conjecture.
4. Optionally add a sentence to PROOF.md or STATEMENT-MAP.md noting that Lean uses an equivalent but differently parameterised direction set. Lean uses (−1,e), (e,−1) with e < r, which is (1/M)·c and (1/M)·b with e = 1/M. It uses t = 3/4 for the (−1,−1) case, and ±e with threshold 2e (e < r/3) instead of ±ε with threshold δ. This lets a reader match the paper proof to the Lean proof.
5. Optionally record in STATEMENT-MAP.md that the "some t > 0" definition is equivalent to the "all small ε > 0" definition for convex K. This is a one-line convexity argument, and I checked it in Lean in my scratch Extra.lean. Readers familiar with the Hadwiger form will look for it.
6. FINAL-HANDOFF.md mixes the trichotomy with out-of-contract counterexample-route computations (the 43 hulls and the quartet). They are correctly marked as outside the contract. Keep them out of the published result page, or put them under a clearly separate heading, so they are not mistaken for verified claims.

Lock: slot A acquired as `claude-final-illum-01` at 2026-11-21T04:52:40Z and released at 2026-11-21T04:54:13Z.
