#!/bin/zsh
set -eu
base=${0:A:h}
repo=${base:h:h:h:h:h:h}
lock="$repo/work/tools/leanlock.sh"
owner="taskV-illumination-prism-preflight"
cd "$base"
out="$base/acceptance/preflight-01"
mkdir "$out"
date -u '+%FT%TZ' > "$out/start"
for attempt in {1..180}; do
  if slot=$("$lock" acquire any "$owner" 5 2>>"$out/wait.log"); then
    print -r -- "$slot" > "$out/slot"
    trap '"$lock" release "$slot" "$owner" >> "$out/release.log"' EXIT
    date -u '+%FT%TZ' > "$out/acquired"
    ./lean-local.sh Challenge "$out" >"$out/compiler.log" 2>&1
    test ! -s "$out/compiler.log"
    shasum -a 256 formal/Illumination/Challenge.lean higher-order/PROOF.md positive-route/INDEPENDENT-SANDWICH-STATEMENT.md literature-cont/REVIEW-MATH-AND-CHALLENGE.md > "$out/sha256"
    date -u '+%FT%TZ' > "$out/pass"
    exit 0
  fi
  sleep 15
done
exit 75
