#!/bin/zsh
set -eu
base=${0:A:h}
repo=${base:h:h:h:h:h:h}
lock="$repo/work/tools/leanlock.sh"
label=$1
owner="taskV-illumination-$label"
d="$base/acceptance/controller-$label"
mkdir "$d"
date -u '+%FT%TZ' > "$d/start"
for attempt in {1..600}; do
  if slot=$("$lock" acquire any "$owner" 45 2>>"$d/wait.log"); then
    print -r -- "$slot $owner" > "$d/acquired"
    trap '"$lock" release "$slot" "$owner" > "$d/release.log"' EXIT
    date -u '+%FT%TZ' > "$d/acquired.utc"
    if python3 "$base/verify.py" "$label" >"$d/output.log" 2>&1; then code=0; else code=$?; fi
    date -u '+%FT%TZ' > "$d/end"
    print "$code" > "$d/exit"
    cat "$d/output.log"
    exit "$code"
  fi
  sleep 3
done
exit 75
