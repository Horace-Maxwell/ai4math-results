import Illumination.Check

example : PrismIllumination.Trichotomy := PrismIllumination.check_trichotomy
example : PrismIllumination.Trichotomy := PrismIllumination.prism_trichotomy
example : ∀ K : Set (Fin 3 → ℝ), IsCompact K → Convex ℝ K → PrismIllumination.prism ⊆ K →
    K ⊆ PrismIllumination.cube →
    (Disjoint K PrismIllumination.edge → PrismIllumination.Exact K 6) ∧
    (¬ Disjoint K PrismIllumination.edge → K ≠ PrismIllumination.cube → PrismIllumination.Exact K 7) ∧
    (K = PrismIllumination.cube → PrismIllumination.Exact K 8) := PrismIllumination.check_trichotomy
-- definitional unfolding check of the frozen notions
example (K : Set (Fin 3 → ℝ)) (u p : Fin 3 → ℝ) :
    PrismIllumination.Illuminates K u p ↔ ∃ t : ℝ, 0 < t ∧ p + t • u ∈ interior K := Iff.rfl
example (K : Set (Fin 3 → ℝ)) (n : ℕ) : PrismIllumination.Exact K n ↔
    PrismIllumination.CanLight K n ∧ ∀ m, PrismIllumination.CanLight K m → n ≤ m := Iff.rfl
#print axioms PrismIllumination.check_trichotomy
#print axioms PrismIllumination.prism_trichotomy
#print axioms PrismIllumination.upperSix
#print axioms PrismIllumination.upperSeven
#print axioms PrismIllumination.cubeEight
#print axioms PrismIllumination.lowerSix
#print axioms PrismIllumination.lowerSeven
#print axioms PrismIllumination.lowerEight
#print axioms PrismIllumination.gapSix
#print axioms PrismIllumination.gapSeven
