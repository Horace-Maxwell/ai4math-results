import Illumination.Check
import Mathlib.Analysis.Convex.Topology
import Mathlib.Analysis.Normed.Module.Convex

open PrismIllumination

/-- The "some t" definition is equivalent to the "all small ε" (standard Hadwiger) one
for convex K and boundary points. -/
theorem illum_all_small (K : Set Space) (hv : Convex ℝ K) {u p : Space}
    (hp : p ∈ closure K) (h : Illuminates K u p) :
    ∃ t0 : ℝ, 0 < t0 ∧ ∀ s, 0 < s → s ≤ t0 → p + s • u ∈ interior K := by
  obtain ⟨t, ht, hi⟩ := h
  refine ⟨t, ht, fun s hs hst => ?_⟩
  rcases eq_or_lt_of_le hst with rfl | hlt
  · exact hi
  have := hv.openSegment_closure_interior_subset_interior hp hi
  apply this
  have hlt1 : s / t < 1 := (div_lt_one ht).2 hlt
  refine ⟨1 - s / t, s / t, by linarith, by positivity, by ring, ?_⟩
  rw [smul_add, smul_smul, ← add_assoc, ← add_smul, div_mul_cancel₀ s ht.ne']
  simp

/-- Non-vacuity: the prism and the cube satisfy the hypotheses. -/
example : prism ⊆ cube := fun _ h => h.1
example : Exact cube 8 := (check_trichotomy cube
  (by
    have : cube = Set.univ.pi (fun _ : Fin 3 => Set.Icc (0:ℝ) 1) := by
      ext x; exact ⟨fun h j _ => h j, fun h j => h j (Set.mem_univ j)⟩
    rw [this]; exact isCompact_univ_pi fun _ => isCompact_Icc)
  (by
    have : cube = Set.univ.pi (fun _ : Fin 3 => Set.Icc (0:ℝ) 1) := by
      ext x; exact ⟨fun h j _ => h j, fun h j => h j (Set.mem_univ j)⟩
    rw [this]; exact convex_pi fun _ _ => convex_Icc 0 1)
  (fun _ h => h.1) le_rfl).2.2 rfl
/-- Exact is functional: no two different values. -/
example (K : Set Space) (a b : ℕ) (ha : Exact K a) (hb : Exact K b) : a = b :=
  le_antisymm (ha.2 b hb.1) (hb.2 a ha.1)
#print axioms illum_all_small
