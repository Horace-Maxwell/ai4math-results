import numpy as np, itertools, random
from scipy.spatial import ConvexHull
from scipy.optimize import linprog
P=[(x,y,z) for x in (0,1) for y in (0,1) for z in (0,1) if x+y<=1]
def facets(pts):
    h=ConvexHull(np.array(pts,float)); eqs=[]
    for e in h.equations:
        n=e[:3]; b=-e[3]; s=np.linalg.norm(n); n,b=n/s,b/s
        if not any(np.allclose(n,m,atol=1e-9) and abs(b-c)<1e-9 for m,c in eqs): eqs.append((n,b))
    verts=[tuple(h.points[i]) for i in h.vertices]
    return eqs,verts
def cone_feasible(normals):
    # exists u with n.u <= -1 for all outward normals n
    if not normals: return True
    A=np.array(normals); r=linprog(np.zeros(3),A_ub=A,b_ub=-np.ones(len(A)),bounds=[(None,None)]*3,method='highs')
    return r.status==0
def illum_number(pts):
    eqs,verts=facets(pts)
    act=[[n for n,b in eqs if abs(n@np.array(v)-b)<1e-9] for v in verts]
    m=len(verts); best=[m]
    memo={}
    def ok(group):
        k=frozenset(group)
        if k not in memo: memo[k]=cone_feasible([n for i in group for n in act[i]])
        return memo[k]
    # exact min clique cover-like partition by DFS
    def dfs(i,groups):
        if len(groups)>=best[0]: return
        if i==m: best[0]=len(groups); return
        for g in groups:
            if ok(g+[i]):
                g.append(i); dfs(i+1,groups); g.pop()
        groups.append([i]); dfs(i+1,groups); groups.pop()
    dfs(0,[]); return best[0], len(verts)
def classify(pts):
    eqs,verts=facets(pts)
    onE=any(abs(v[0]-1)<1e-12 and abs(v[1]-1)<1e-12 for v in verts)
    # K meets E iff some point of K has x=y=1; K polytope inside Q: check LP max of x+y over K == 2
    cube=all(any(np.allclose(v,c) for v in verts) for c in itertools.product((0,1),repeat=3))
    mx=max(v[0]+v[1] for v in verts)
    if cube: return 8
    return 7 if mx>2-1e-12 else 6
tests={
 'P':P,
 'cube':[c for c in itertools.product((0,1),repeat=3)],
 'P+(1,1,1/2)':P+[(1,1,.5)],
 'P+(1,1,0)':P+[(1,1,0)],
 'P+box near E':P+[(x,y,z) for x in (.9,1) for y in (.9,1) for z in (.4,.6)],
 'P+(0.9,0.9,0.5)':P+[(.9,.9,.5)],
 'Q minus corner cut at (1,1,1)':[c for c in itertools.product((0,1),repeat=3) if c!=(1,1,1)]+[(1,1,.9),(.9,1,1),(1,.9,1)],
 'Q minus thin slab near E':[c for c in itertools.product((0,1),repeat=3) if c[0]+c[1]<2]+[(1,.99,0),(1,.99,1),(.99,1,0),(.99,1,1)],
 'P+(1,1,1) only':P+[(1,1,1)],
 'P+(1,1,0),(1,1,1)-ish both corners minus tiny':P+[(1,1,0),(1,1,.999),(.999,1,1),(1,.999,1)],
}
for k,v in tests.items():
    n,nv=illum_number(v); print(f'{k:45s} verts={nv:3d} illum={n} predicted={classify(v)}')
random.seed(1); bad=0; cnt={6:0,7:0,8:0}
for trial in range(300):
    extra=[]
    for _ in range(random.randint(1,5)):
        r=random.random()
        if r<0.3: extra.append((1,1,random.choice([0,1,round(random.random(),3)])))
        else:
            x=random.random(); y=random.random()
            if x+y<=1: x,y=1-x,1-y
            extra.append((round(x,3),round(y,3),random.choice([0,1,round(random.random(),3)])))
    pts=P+extra; n,_=illum_number(pts); c=classify(pts); cnt[c]+=1
    if n!=c: bad+=1; print('MISMATCH',extra,n,c)
print('random trials mismatches',bad,cnt)
