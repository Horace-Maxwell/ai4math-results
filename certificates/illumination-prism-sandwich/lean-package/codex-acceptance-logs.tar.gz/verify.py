"""Replay the frozen prism trichotomy in two initially empty, independent roots."""
from pathlib import Path
import hashlib
import json
import os
import re
import resource
import shutil
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
repo = base.parents[5]
project = repo / "work/research-lean-v434"
toolbin = repo / "work/toolchains/lean-4.34.1-darwin_aarch64/bin"
pkg = project / ".lake/packages"
src = base / "formal"
modules = ["Challenge", "Planar", "Gaps", "Lower", "Upper", "Result", "Check"]

def utc():
    return subprocess.check_output(["date", "-u", "+%FT%TZ"], text=True).strip()

def digest(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()

def persist(p, data):
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def run(cmd, log, cwd, env):
    start = utc()
    before = time.monotonic()
    with log.open("xb") as out:
        proc = subprocess.run(cmd, cwd=cwd, env=env, stdout=out, stderr=subprocess.STDOUT, timeout=900)
    info = dict(argv=list(map(str, cmd)), cwd=str(cwd), start=start, end=utc(), exit=proc.returncode,
                wall_seconds=time.monotonic()-before, log_sha256=digest(log),
                child_peak_rss_bytes_so_far=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    persist(log.with_suffix(".json"), info)
    if proc.returncode:
        raise RuntimeError(f"exit {proc.returncode} in {log}")
    return log.read_text()

def verify():
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("label")
    args=parser.parse_args()
    batch = base / "acceptance" / args.label
    batch.mkdir(exist_ok=False)
    env = dict(os.environ, PATH=str(toolbin)+":"+os.environ["PATH"], LEAN_NUM_THREADS="1",
               LAKE_NO_CACHE="true", GIT_ALLOW_PROTOCOL="file", ELAN_TOOLCHAIN="leanprover/lean4:v4.34.1")
    env.pop("LEAN_PATH", None)
    srcs = sorted(p.relative_to(src) for p in src.rglob("*") if p.is_file())
    frozen = (base/"acceptance/FROZEN.sha256").read_text().split()[0]
    assert digest(src/"Illumination/Challenge.lean")==frozen
    source_hash = {str(p):digest(src/p) for p in srcs}
    pins = {}
    for p in json.loads((src/"lake-manifest.json").read_text())["packages"]:
        sha=subprocess.check_output(["git","-C",str(pkg/p["name"]),"rev-parse","HEAD"],text=True).strip()
        assert sha==p["rev"]
        pins[p["name"]]=sha
    trusted = sorted(p for p in pkg.glob("*/.lake/build/lib/lean") if p.is_dir())
    names = []
    unsafe_pattern = re.compile(r"\b(sorry|admit|axiom|native_decide|bv_decide|implemented_by|extern|unsafe|partial|opaque)\b|debug\.skipKernelTC|decide\s*\+native|#eval")
    for mod in modules:
        code=(src/"Illumination"/(mod+".lean")).read_text()
        assert not unsafe_pattern.search(code), mod
        names += ["PrismIllumination."+n for n in re.findall(r"^(?:def|abbrev|theorem)\s+(\w+)",code,re.M)]
    receipt=dict(start=utc(),frozen=frozen,source_sha256=source_hash,packages=pins,
                 packages_with_prebuilt_cache=[str(p.relative_to(pkg)) for p in trusted],
                 bin_sha256={n:digest(toolbin/n) for n in ["lean","leanchecker","lake"]},
                 verifier_sha256=digest(Path(__file__)),lemmas_audited=names,
                 versions={n:subprocess.check_output([str(toolbin/n),"--version"],text=True,env=env).strip()
                           for n in ["lean","lake"]},
                 roots=[])
    persist(batch/"receipt.json",receipt)
    (batch/"inputs.sha256").write_text("".join(f"{v}  {k}\n" for k,v in source_hash.items()))
    roots = []
    for label in ("normal","fresh"):
        root = batch / label
        root.mkdir()
        assert not list(root.iterdir())
        for p in srcs:
            dest=root/p
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src/p,dest)
        (root/".lake").mkdir()
        (root/".lake/packages").symlink_to(pkg)
        logs=root/"logs"
        logs.mkdir()
        lake=str(toolbin/"lake")
        rows=dict(label=label,start=utc(),modules={},axioms={})
        receipt["roots"].append(rows)
        persist(batch/"receipt.json",receipt)
        imports=sorted({match for f in (root/"Illumination").glob("*.lean")
                        for match in re.findall(r"^import (Mathlib\.\S+)",f.read_text(),re.M)})
        run([lake,"--no-build","--no-cache","--wfail","build"]+["+"+name+":olean" for name in imports],
            logs/"cached-imports.log",root,env)
        for mod in modules:
            module="Illumination."+mod
            log=logs/(mod+"-lake.log")
            result=run([lake,"-v","--no-cache","--wfail","build","+"+module+":olean"],log,root,env)
            local_argv=[line for line in result.splitlines()
                        if "/bin/lean " in line and str(root/"Illumination"/(mod+".lean")) in line]
            assert len(local_argv)==1 and re.search(r"(?:^| )-j1(?: |$)",local_argv[0]), (mod,local_argv)
            if re.search(r"(?im)(?:\bwarning:|\berror:|declaration uses )",result):
                raise RuntimeError(f"diagnostic in {log}")
            out=root/".lake/build/lib/lean/Illumination"/(mod+".olean")
            assert out.is_file() and not out.is_symlink()
            check=logs/(mod+"-checker.log")
            assert run([lake,"env",str(toolbin/"leanchecker"),module],check,root,env)==""
            rows["modules"][mod]=dict(olean_sha256=digest(out),source_sha256=digest(root/"Illumination"/(mod+".lean")))
        run([lake,"--no-cache","--wfail","build"],logs/"default.log",root,env)
        audit=root/"Axioms.lean"
        audit.write_text("import Illumination.Check\n"+"".join(f"#print axioms {n}\n" for n in names))
        content=run([lake,"env",str(toolbin/"lean"),"-j1","-DwarningAsError=true",audit.name],logs/"axioms.log",root,env)
        allowed={"propext","Classical.choice","Quot.sound"}
        for line in content.splitlines():
            match=re.fullmatch(r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)",line)
            if not match: raise ValueError(line)
            n=match.group(1)
            deps=[s.strip() for s in (match.group(2) or "").split(",") if s.strip()]
            assert set(deps)<=allowed and n not in rows["axioms"]
            rows["axioms"][n]=deps
        assert list(rows["axioms"])==names
        for mod in modules:
            assert rows["modules"][mod]["source_sha256"]==source_hash[f"Illumination/{mod}.lean"]
        rows["end"]=utc()
        roots.append(rows)
        persist(batch/"receipt.json",receipt)
    assert roots[0]["modules"]==roots[1]["modules"]
    assert roots[0]["axioms"]==roots[1]["axioms"]
    assert source_hash=={str(p):digest(src/p) for p in srcs}
    receipt["end"]=utc()
    receipt["machine_status"]="PASS"
    persist(batch/"receipt.json",receipt)
    print(batch/"receipt.json")

if __name__=="__main__":
    verify()
