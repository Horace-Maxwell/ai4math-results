# 三维凸体照明：三棱柱夹层精确分类的终审交接

正式双根机器验收已通过。请 Claude 安排未参与研究的跨模型族终审，审阅对象为冻结的 `PrismIllumination.Trichotomy`。本次交付处理三维凸体的一个子类。一般八方向猜想仍开放。

## 定理

设 Q=[0,1]³，P={p∈Q | x+y≤1} 为 Q 的一半，E={(1,1,z) | 0≤z≤1} 是对面的闭竖棱。对所有满足 P⊆K⊆Q 的实三维紧凸体 K，照亮全部边界所需的最少固定非零方向数如下。

| 几何情形 | 最少方向数 |
|---|---:|
| K 与 E 不相交 | 6 |
| K 与 E 相交且 K≠Q | 7 |
| K=Q | 8 |

三棱柱的六个角两两需要不同方向。碰棱的点要求两个水平分量同时为负，因此至少还要一个方向。相应上界由把光线送入开三棱柱的显式方向组给出，兼顾上下两个底面。证明覆盖含弯曲边界的紧凸体。[书面证明](higher-order/PROOF.md) · [陈述对照](STATEMENT-MAP.md)

## 机器与审查记录

- 陈述于 2026-11-21T03:53:24Z 冻结，SHA-256 为 `2fd9927a0e7b532493e5de4038665d92490e479fb712298ad2b7321b863bbe6d`。最终检查将 `prism_trichotomy` 直接赋给冻结命题。[挑战文件](formal/Illumination/Challenge.lean) · [最终检查](formal/Illumination/Check.lean) · [冻结清单](acceptance/FROZEN.sha256)
- Lean 与 Mathlib 均为 v4.34.1。两根各自从空目录建立，只复用已固定提交的第三方缓存。每根逐一构建七个自有模块并运行七次 `lake env leanchecker`，再作默认构建和 23 项公理审计。14 份 checker 日志均为空且有零退出收据，全程采用单线程编译。全部七对自产 .olean 逐字节相同，两根公理逐项一致。`check_trichotomy` 仅依赖 `propext`、`Classical.choice`、`Quot.sound`。自有模块全部重放；Mathlib 与标准库作为受信依赖。[正式双根收据](acceptance/dual-02/receipt.json) · [逐命令和产物核查](acceptance/controller-dual-02-resume-01/POST-AUDIT.json)
- 正式第一根曾因额度中断。本轮核实并沿用五次成功编译、四次成功内核复验，从 Upper 的内核复验继续；原空日志、旧控制器退出未知的记录和首批线程参数修正均保留。第二根独立完成。恢复控制器退出 0，A 槽已由当前 owner 释放。[前缀收据](acceptance/serial-recovery-01/prefix.json) · [恢复日志](acceptance/controller-dual-02-resume-01/) · [首批资源参数更正](acceptance/dual-01/RESOURCE-CORRECTION.md)
- 数学和陈述有两名同族非作者核读。另一名同族审阅者读了七个 Lean 源及非空性实例。终态日志由当前串行会话执行机器核对，未新增独立审阅者签字。跨族 FINAL 仍待安排。[数学核读](positive-route/INDEPENDENT-SANDWICH-MATH.md) · [合同核读](literature-cont/REVIEW-MATH-AND-CHALLENGE.md) · [七源静态核读](acceptance/INDEPENDENT-FORMAL-REVIEW.md)

## 文献与反例方向

专项查重已对照既有双层凸包、对称体、近立方体及对踵点结果；在已核来源中未找到同范围的完整三分式。文献有检索盲区，发布日 G3 尚待执行。一般三维上界已有同行评议的 14 和公开的 13 声称，后者的证书另待独立核验。[文献检索与先前工作对照](literature-cont/REPORT.md)

在反例方向，43 个非中心对称有理壳中，42 个恰需四束，一个恰需五束。一个整数壳上的四个指定尖点任取三个均能同照，全四个无法同照；整个壳恰需四束。有限计算和独立坐标核验单列；它们不在冻结合同内。投影推广保留在书面候选阶段。[高阶约束与计算](higher-order/OBSTRUCTIONS.md) · [非作者坐标复核](positive-route/INDEPENDENT-QUARTET.md) · [投影候选](positive-route/CUBICAL-PROJECTION.md)
