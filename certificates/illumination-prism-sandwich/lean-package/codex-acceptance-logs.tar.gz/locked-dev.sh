#!/bin/zsh
set -eu
base=${0:A:h}
repo=${base:h:h:h:h:h:h}
lock="$repo/work/tools/leanlock.sh"
key="taskV-illumination-dev-$1-$$"
d="$base/acceptance/dev-runs/$(date -u '+%Y%m%dT%H%M%SZ')-$1-$$"
mkdir -p "$d"
date -u '+%FT%TZ' >"$d/start"
for attempt in {1..180}; do
  if slot=$("$lock" acquire any "$key" 8 2>> "$d/wait.log"); then
    print -r -- "$slot" >"$d/slot"
    trap '"$lock" release "$slot" "$key" >> "$d/release.log"' EXIT
    if "$base/lean-local.sh" "$1" > "$d/compiler.log" 2>&1; then code=0; else code=$?; fi
    print "$code" > "$d/exit"
    date -u '+%FT%TZ' > "$d/end"
    cat "$d/compiler.log"
    exit "$code"
  fi
  sleep 4
done
exit 75
