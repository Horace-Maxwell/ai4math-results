"""Read-only independent audit of the finished finite family, including actual build bytes."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

here=Path(__file__).resolve().parent
task=here.parents[1]
batch=task/'acceptance/dual-02'
controller=here
data=json.loads((batch/'receipt.json').read_text())
src=task/'formal'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def require(condition,context):
    if not condition: raise ValueError(context)
require(data.get('machine_status')=='PASS','machine receipt not final')
mods = ['Challenge','Planar','Gaps','Lower','Upper','Result','Check']
expected = {
 'Space','cube','prism','edge','Illuminates','CanLight','Exact','Trichotomy',
 'dx','dy','Step','planarThree','planarFour','gapSix','gapSeven',
 'lowerSix','lowerSeven','lowerEight','upperSix','upperSeven','cubeEight',
 'prism_trichotomy','check_trichotomy'}
expected={'PrismIllumination.'+e for e in expected}
allow={'Classical.choice','propext','Quot.sound'}
for ln in (task/'acceptance/FROZEN.sha256').read_text().splitlines():
    h,fn=ln.split(maxsplit=1);require(sha(task/fn)==h,fn)
frozen_sha='2fd9927a0e7b532493e5de4038665d92490e479fb712298ad2b7321b863bbe6d'
require(sha(src/'Illumination/Challenge.lean')==data['frozen']==frozen_sha,'frozen contract')
require(set(data['lemmas_audited'])==expected,'declared audit scope')
require('moreLeanArgs = ["-j1"]' in (src/'lakefile.toml').read_text(),'Lean package job constraint')
require((task/'acceptance/preflight-01/compiler.log').read_bytes()==b'', 'preflight warning or error')
require((task/'acceptance/preflight-01/pass').read_text().strip() < (task/'acceptance/FROZEN.utc').read_text().strip(),'freeze chronology')
acquired=(controller/'acquired').read_text().strip().split()
require(acquired[0] in ('A','B') and acquired[1]=='taskV-illumination-dual02-serial01','owner')
require((controller/'exit').read_text().strip()=='0' and (controller/'release.log').read_text().strip()=='released '+acquired[0],'lock release')
require(sha(task/'verify.py')==data['verifier_sha256'],'runner drift')
require(sha(task/'resume-dual-02.py')==data['resumption']['runner_sha256'],'resume runner drift')
prefix=task/'acceptance/serial-recovery-01/prefix.json'
require(sha(prefix)==data['resumption']['prefix_sha256'],'prefix drift')
prior=json.loads(prefix.read_text())
require(sha(controller/'original-unfinished-receipt.json')==prior['initial_receipt_sha256'],'original receipt')
require((batch/data['resumption']['interrupted_log']).read_bytes()==b'', 'original interrupted log')
require(prior['unreceipted_stage']=='normal/Upper-checker', 'resume stage')
for mod,rec in prior['completed'].items():
    for kind,suffix in [('build','lake'),('checker','checker')]:
        if kind in rec:
            p=batch/'normal/logs'/(mod+'-'+suffix+'.json')
            require(sha(p)==rec[kind]['metadata_sha256'] and sha(p.with_suffix('.log'))==rec[kind]['log_sha256'],mod+' prefix reuse')
    require(data['roots'][0]['modules'][mod]['olean_sha256']==rec['olean_sha256'],mod+' old olean')
require([v['label'] for v in data['roots']]==['normal','fresh'],'roots')
sources={str(f.relative_to(src)):sha(f) for f in src.rglob('*') if f.is_file()}
require(sources==data['source_sha256'],'source/config hash map mismatch')
toolkit=task.parents[5]/'work/toolchains/lean-4.34.1-darwin_aarch64/bin'
for name,h in data['bin_sha256'].items():require(sha(toolkit/name)==h,name)
m=json.loads((src/'lake-manifest.json').read_text())
pindir=task.parents[5]/'work/research-lean-v434/.lake/packages'
require({p['name']:p['rev'] for p in m['packages']}==data['packages'],'manifest differs')
for name,h in data['packages'].items():
    got=subprocess.check_output(['git','-C',str(pindir/name),'rev-parse','HEAD'],text=True).strip()
    require(got==h,'package '+name)
history={}
full_maps=[]
for r in data['roots']:
    root=batch/r['label']; logs=root/'logs'
    require((root/'.lake/packages').resolve()==pindir.resolve(), 'unexpected cache root')
    require((root/'Illumination').resolve().parent==root,'package source not private')
    require(all(sha(root/p)==h for p,h in sources.items()),'clean root files drifted')
    times={};oleans={};logmap={}
    def step(n,pattern=None):
        side=json.loads((logs/(n+'.json')).read_text())
        log=logs/(n+'.log'); body=log.read_bytes(); require(side['exit']==0 and side['log_sha256']==sha(log) and Path(side['cwd'])==root,'command receipt '+n)
        require(side['start']<=side['end'] and side['wall_seconds']>=0,'timings '+n)
        if pattern:require(pattern(side['argv'],body),n)
        require(not re.search(br'\b(?:warning:|error:)|declaration uses ',body,re.I),'diagnostic '+n)
        logmap[n]=side['log_sha256'];times[n]=[side['start'],side['end']]
        return body.decode()
    step('cached-imports',lambda a,b:a[1:5]==['--no-build','--no-cache','--wfail','build'])
    for mod in mods:
        p=src/'Illumination'/(mod+'.lean')
        require(not re.search(r'\b(sorry|admit|axiom|native_decide|bv_decide|implemented_by|extern|unsafe|partial|run_tac)\b|debug\.skipKernelTC|decide\s+\+native',p.read_text()),'trust bypass '+mod)
        name='Illumination.'+mod
        step(mod+'-lake',lambda a,b:a[1:]==['-v','--no-cache','--wfail','build','+'+name+':olean'] and ('Built '+name+' ').encode() in b)
        step(mod+'-checker',lambda a,b:a==[str(toolkit/'lake'),'env',str(toolkit/'leanchecker'),name] and b==b'')
        obj=root/'.lake/build/lib/lean/Illumination'/(mod+'.olean')
        trace=json.loads(obj.with_suffix('.trace').read_text())
        require(trace['synthetic'] is False and any(str(toolkit/'lean')+' -j1 '+str(root/'Illumination'/(mod+'.lean')) in log.get('message','') for log in trace['log']), 'actual Lean argv '+mod)
        logmap[mod+'-trace']=sha(obj.with_suffix('.trace'))
        st=obj.stat(); require(st.st_size>0 and not obj.is_symlink(),'object '+mod)
        require(sha(obj)==r['modules'][mod]['olean_sha256'],'recorded object')
        require(sha(p)==r['modules'][mod]['source_sha256'],'recorded source')
        oleans[mod]=sha(obj)
    step('default',lambda a,b:a[1:]==['--no-cache','--wfail','build'])
    ls=step('axioms',lambda a,b:a[1:]==['env',str(toolkit/'lean'),'-j1','-DwarningAsError=true','Axioms.lean']).splitlines()
    vals={}
    for ln in ls:
        mt=re.fullmatch(r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)",ln)
        require(mt is not None,'bad axiom line '+ln)
        nm=mt[1];require(nm not in vals,'duplicate '+nm);vals[nm]=[x.strip() for x in (mt[2] or '').split(',') if x.strip()]
        require(set(vals[nm])<=allow,nm)
    require(set(vals)==expected and vals==r['axioms'],'axiom coverage')
    full_maps.append((oleans,vals))
    history[r['label']]={'files':len(sources),'oleans':oleans,'command_logs':logmap,'times':times,
                         'axiom_count':len(vals),'result_axioms':vals['PrismIllumination.check_trichotomy']}
require(full_maps[0]==full_maps[1],'normal/fresh mismatch')
for mod in mods:
    a,b=[batch/r/'.lake/build/lib/lean/Illumination'/(mod+'.olean') for r in ['normal','fresh']]
    require(not a.samefile(b),'shared local olean '+mod)
result={'utc':subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip(),'source_sha256':sources,
        'receipt_sha256':sha(batch/'receipt.json'),'runner_sha256':sha(task/'verify.py'),
        'modules':mods,'audit_script_sha256':sha(Path(__file__)),'release_slot':acquired[0],
        'roots':history,'judgment':'PASS_RECEIPT_CHECK_EXECUTED_BY_RESUMING_SESSION'}
print(json.dumps(result,indent=2,ensure_ascii=False))
