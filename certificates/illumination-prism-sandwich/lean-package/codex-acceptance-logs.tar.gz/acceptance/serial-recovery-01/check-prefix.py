"""Validate the actual uninterrupted command receipts before the quota interruption."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

here = Path(__file__).resolve().parent
task = here.parents[1]
batch = task/'acceptance/dual-02'
root = batch/'normal'
logs = root/'logs'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def utc(): return subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()
r = json.loads((batch/'receipt.json').read_text())
assert 'machine_status' not in r and not (batch/'fresh').exists()
assert sha(task/'verify.py') == r['verifier_sha256']
for name,h in r['source_sha256'].items():
    assert sha(root/name)==sha(task/'formal'/name)==h, name
for row in (task/'acceptance/FROZEN.sha256').read_text().splitlines():
    h,name=row.split(maxsplit=1)
    assert sha(task/name)==h
repo=task.parents[5]
bin_dir=repo/'work/toolchains/lean-4.34.1-darwin_aarch64/bin'
assert all(sha(bin_dir/name)==h for name,h in r['bin_sha256'].items())
assert all(subprocess.check_output(['git','-C',str(root/'.lake/packages'/n),'rev-parse','HEAD'],text=True).strip()==h for n,h in r['packages'].items())
def verified_command(stage,argv):
    j=logs/(stage+'.json')
    doc=json.loads(j.read_text())
    log=logs/(stage+'.log')
    assert doc['exit']==0 and doc['cwd']==str(root)
    assert doc['argv']==argv and doc['log_sha256']==sha(log)
    return {'metadata_sha256':sha(j),'log_sha256':sha(log),'end':doc['end']}
lake=str(bin_dir/'lake')
checked={}
for mod in ['Challenge','Planar','Gaps','Lower','Upper']:
    obj=root/'.lake/build/lib/lean/Illumination'/(mod+'.olean')
    assert obj.is_file() and not obj.is_symlink()
    trace=json.loads(obj.with_suffix('.trace').read_text())
    assert trace['synthetic'] is False
    assert obj.with_suffix('.olean.hash').read_text().strip()+'.olean' in trace['outputs']['o']
    arg=[l for l in (logs/(mod+'-lake.log')).read_text().splitlines() if str(bin_dir/'lean')+' ' in l and str(root/'Illumination'/(mod+'.lean')) in l]
    assert len(arg)==1 and ' -j1 ' in arg[0]
    row={'build':verified_command(mod+'-lake',[lake,'-v','--no-cache','--wfail','build','+Illumination.'+mod+':olean']),
         'olean_sha256':sha(obj),'trace_sha256':sha(obj.with_suffix('.trace'))}
    assert not re.search(r'\b(?:warning:|error:)',(logs/(mod+'-lake.log')).read_text(),re.I)
    if mod!='Upper':
        row['checker']=verified_command(mod+'-checker',[lake,'env',str(bin_dir/'leanchecker'),'Illumination.'+mod])
        assert (logs/(mod+'-checker.log')).read_bytes()==b''
    checked[mod]=row
assert (logs/'Upper-checker.log').read_bytes()==b'' and not (logs/'Upper-checker.json').exists()
pre=logs/'cached-imports.json'
c=json.loads(pre.read_text()); assert c['exit']==0 and c['log_sha256']==sha(logs/'cached-imports.log')
try:
    os.kill(92088,0)
except ProcessLookupError:
    owner_gone=True
else:
    owner_gone=False
assert owner_gone
print(json.dumps({'utc':utc(),'batch':'dual-02','normal_builds':5,'normal_checkers':4,
                  'completed_roots':0,'fresh_created':False,'original_process_exit':'unobserved',
                  'previous_owner_pid':92088,'previous_owner_pid_gone':owner_gone,
                  'frozen_sha256':r['frozen'],'source_sha256':r['source_sha256'],
                  'initial_receipt_sha256':sha(batch/'receipt.json'),'completed':checked,
                  'unreceipted_stage':'normal/Upper-checker','lock_observation':(here/'lock-before.log').read_text(),
                  'resume_acquire_exit':int((here/'acquire.exit').read_text())},indent=2))
