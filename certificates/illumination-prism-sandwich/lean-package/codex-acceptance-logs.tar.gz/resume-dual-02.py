"""Complete dual-02, preserving the verified prefix and the interrupted log."""
from pathlib import Path
import json
import os
import re
import shutil
import subprocess

from verify import base, digest, modules, pkg, run, src, toolbin, utc

batch = base / "acceptance/dual-02"
controller = base / "acceptance/controller-dual-02-resume-01"
receipt_path = batch / "receipt.json"
prefix_path = base / "acceptance/serial-recovery-01/prefix.json"
lake = str(toolbin / "lake")
env = dict(os.environ, PATH=f"{toolbin}:"+os.environ["PATH"], LEAN_NUM_THREADS="1",
           LAKE_NO_CACHE="true", GIT_ALLOW_PROTOCOL="file", ELAN_TOOLCHAIN="leanprover/lean4:v4.34.1")
env.pop("LEAN_PATH", None)

def checkpoint():
    tmp = batch / "receipt.json.tmp"
    tmp.write_text(json.dumps(receipt, indent=2, ensure_ascii=False)+"\n")
    tmp.replace(receipt_path)

def stage(root, name, argv):
    path = root / "logs" / (name+".log")
    side = path.with_suffix(".json")
    if side.exists():
        doc = json.loads(side.read_text())
        assert doc["argv"]==argv and doc["cwd"]==str(root) and doc["exit"]==0, name
        assert doc["log_sha256"]==digest(path), name
        text = path.read_text()
    else:
        text = run(argv,path,root,env)
    assert not re.search(r"\b(?:warning:|error:)|declaration uses ",text,re.I), name
    return text

assert digest(prefix_path)=="0c1540a89146a2f80e55c1bc9745dab0f2ca4ba5e1c5616685631b57b84648e7"
prefix = json.loads(prefix_path.read_text())
assert digest(receipt_path)==prefix["initial_receipt_sha256"]
receipt = json.loads(receipt_path.read_text())
assert digest(base/"verify.py")==receipt["verifier_sha256"]
assert len(receipt["lemmas_audited"])==len(set(receipt["lemmas_audited"]))==23
for h, file in (line.split(maxsplit=1) for line in (base/"acceptance/FROZEN.sha256").read_text().splitlines()):
    assert digest(base/file)==h
for package,pin in receipt["packages"].items():
    assert subprocess.check_output(["git","-C",str(pkg/package),"rev-parse","HEAD"],text=True).strip()==pin
for program,pin in receipt["bin_sha256"].items():
    assert digest(toolbin/program)==pin
copy_before_resume=controller/"original-unfinished-receipt.json"
assert not copy_before_resume.exists()
shutil.copyfile(receipt_path,copy_before_resume)
normal = batch/"normal"
for mod,entry in prefix["completed"].items():
    obj = normal/".lake/build/lib/lean/Illumination"/(mod+".olean")
    assert digest(obj)==entry["olean_sha256"] and digest(obj.with_suffix(".trace"))==entry["trace_sha256"]
    for kind,suffix in [("build","lake"),("checker","checker")]:
        if kind in entry:
            side=normal/"logs"/(mod+"-"+suffix+".json")
            assert digest(side)==entry[kind]["metadata_sha256"]
            assert digest(side.with_suffix(".log"))==entry[kind]["log_sha256"]
lost = normal/"logs/Upper-checker.log"
archive=lost.with_name("Upper-checker.interrupted-0404.log")
assert lost.read_bytes()==b"" and not lost.with_suffix(".json").exists() and not archive.exists()
lost.rename(archive)
receipt["resumption"]={"utc":utc(),"controller":controller.name,"prefix_sha256":digest(prefix_path),
                       "runner_sha256":digest(Path(__file__)),"original_controller_exit":"unobserved",
                       "interrupted_log":str(archive.relative_to(batch))}
checkpoint()
for label in ["normal","fresh"]:
    root = batch/label
    if label=="normal":
        row=receipt["roots"][0]
        assert row["label"]=="normal"
    else:
        root.mkdir()
        assert not any(root.iterdir())
        for rel,h in receipt["source_sha256"].items():
            assert digest(src/rel)==h
            dest=root/rel
            dest.parent.mkdir(exist_ok=True,parents=True)
            shutil.copyfile(src/rel,dest)
        (root/".lake").mkdir()
        (root/".lake/packages").symlink_to(pkg)
        (root/"logs").mkdir()
        row={"label":label,"start":utc(),"modules":{},"axioms":{}}
        receipt["roots"].append(row)
        checkpoint()
    for rel,h in receipt["source_sha256"].items():
        assert digest(src/rel)==digest(root/rel)==h
    assert (root/".lake/packages").resolve()==pkg.resolve()
    imports=sorted({m for p in (root/"Illumination").glob("*.lean")
                    for m in re.findall(r"^import (Mathlib\.\S+)",p.read_text(),re.M)})
    stage(root,"cached-imports",[lake,"--no-build","--no-cache","--wfail","build"]+
          ["+"+m+":olean" for m in imports])
    for mod in modules:
        module="Illumination."+mod
        text=stage(root,mod+"-lake",[lake,"-v","--no-cache","--wfail","build","+"+module+":olean"])
        lean_source=root/"Illumination"/(mod+".lean")
        actual=[line for line in text.splitlines() if str(toolbin/"lean")+" " in line and str(lean_source) in line]
        assert len(actual)==1 and " -j1 " in actual[0]
        obj=root/".lake/build/lib/lean/Illumination"/(mod+".olean")
        assert obj.is_file() and not obj.is_symlink()
        assert stage(root,mod+"-checker",[lake,"env",str(toolbin/"leanchecker"),module])==""
        row["modules"][mod]={"olean_sha256":digest(obj),"source_sha256":digest(lean_source)}
        checkpoint()
    stage(root,"default",[lake,"--no-cache","--wfail","build"])
    audit=root/"Axioms.lean"
    audit.write_text("import Illumination.Check\n"+"".join("#print axioms "+n+"\n" for n in receipt["lemmas_audited"]))
    lines=stage(root,"axioms",[lake,"env",str(toolbin/"lean"),"-j1","-DwarningAsError=true",audit.name]).splitlines()
    for line in lines:
        m=re.fullmatch(r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)",line)
        assert m and m[1] not in row["axioms"], line
        deps=[s.strip() for s in (m[2] or "").split(",") if s.strip()]
        assert set(deps)<={"propext","Classical.choice","Quot.sound"}
        row["axioms"][m[1]]=deps
    assert list(row["axioms"])==receipt["lemmas_audited"]
    row["end"]=utc()
    checkpoint()
a,b=receipt["roots"]
assert a["modules"]==b["modules"] and a["axioms"]==b["axioms"]
for mod in modules:
    rel=Path(".lake/build/lib/lean/Illumination")/(mod+".olean")
    assert not (normal/rel).samefile(batch/"fresh"/rel)
    assert (normal/rel).read_bytes()==(batch/"fresh"/rel).read_bytes()
assert all(digest(src/rel)==h for rel,h in receipt["source_sha256"].items())
receipt["end"]=utc()
receipt["machine_status"]="PASS"
checkpoint()
print(receipt_path)
