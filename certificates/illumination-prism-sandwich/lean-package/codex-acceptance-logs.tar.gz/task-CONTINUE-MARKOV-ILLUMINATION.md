# Task V 续（Claude 代用户下达）：Markov 唯一性与凸体照明继续攻

用户原话："Markov 和照明也让 Codex 继续攻"（看过 Task V 报告之后）。两题各由一个独立 Codex 会话负责，与 Stanley 会话并行，互不等待。

## 共同要求
- 起点：本目录 `REPORT.md`、对应卡片 `lanes/number/card-markov.md` / `lanes/geometry/card-illumination.md`、`attempts/markov/` / `attempts/illumination/`、`prior/REVIEW-*.md`。报告里说已失效的路线（Markov 的纯模数筛和单纯扩大验证上界；照明的简单扰动立方体和两两互斥构造）不要重复。
- 先查清文献的最新进展与竞争者（含已验证范围、近 6 个月 arXiv、AI 团队与公开题库），每 24 小时复查一次；若有人公开解决，立即停手并报告。
- **不设保守止损**：一条路线有障碍就换下一条，直到有结果或用户叫停。每 24 小时在 `attempts/<题>/STATUS.md` 写进度小结（已试路线、最好成绩、下一条路线）。
- 得到完整证明并经非作者核读，或找到反例/见证并独立复核，就按手册第 3.5 节核对原文 → 冻结陈述（零诊断预编译 + 非作者审查）→ Lean（计算证书只用 `decide` 或反射，禁止 `native_decide`/`bv_decide`）→ 两个新空根验收 → `FINAL-HANDOFF.md`，并在 `CODEX-TASKS.md` 顶部报告。

## ① Markov 唯一性（Frobenius 1913）：`attempts/markov/`
- 方向：(a) 你报告里"控制不同模平方根的整数逼近"的统一估计，争取一般证明或可证的新大类（如最大项为素数幂、半素数等的推广）；(b) 结构性反例思路（若存在）。

## ② Hadwiger–Boltyanski 照明（三维 8 个方向）：`attempts/illumination/`
- 方向：(a) 利用三个以上顶点共同约束的非中心对称三维凸体，构造必须 9 个方向的反例，用精确有理算术检查；(b) 正面：扩大已证类（如某类多面体、零宽度对称性等）并给出可 Lean 的证明。

## 机器与限制
- Mac 共 18 核，与 Stanley 会话共用：本会话计算 ≤4 核、单任务 ≤60 分钟分段续跑；Lean 编译走 `work/tools/leanlock.sh`；内存紧张或 RSS 超 40 GB 降并发。Windows 禁用。
- 零对外动作；不碰 `outputs/release/`、`work/release-v*/`、`我的笔记/` 和其他任务目录；不读 `~/.codex/auth.json`；请求里不放邮箱；不下载数据集或软件、不安装东西；时间用 `date -u`。
- 做完或用户叫停时写 `attempts/<题>/DONE`。
