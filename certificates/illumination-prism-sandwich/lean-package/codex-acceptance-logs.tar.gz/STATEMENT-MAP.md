# 三棱柱夹层定理的陈述对照

把单位立方体沿竖直对角平面 x+y=1 切开，取含竖棱 (0,0,z) 的那半个三棱柱。可以在三棱柱与整个立方体之间填入任意材料，只要求成品是紧凸集。定理断言，整个边界的最少平行光方向数完全由成品与对面竖棱 (1,1,z) 的接触情况决定。材料可以有弯曲边界。

| 数学陈述 | 冻结 Lean 含义 |
|---|---|
| 在实三维空间中，Q 是闭单位立方体。 | `Space := Fin 3 → ℝ`，`cube` 把每个坐标限制在闭区间 [0,1]。有限乘积拓扑是通常的三维拓扑。 |
| P 为闭三棱柱，E 为对面的一整条闭竖棱。 | `prism` 为 Q 内满足 x+y≤1 的所有点，`edge` 为 Q 内满足 x=y=1 的所有点，含两端点。 |
| K 是满足 P⊆K⊆Q 的任意紧凸体。 | `IsCompact K`、`Convex ℝ K` 和两个包含关系。P 已含开集，故 K 有三维内点。 |
| 一组非零向量固定下来。对每个边界点 p，至少一支向量 u 能把 p 沿正步长送入 K 的内部。 | `CanLight` 先选 `Fin n → Space`，再量化 `p ∈ frontier K`。`Illuminates` 要求某个严格正的 t 使 p+t·u 落入三维 `interior K`。向量长度由 t 吸收；不同边界点可用不同的 t。 |
| 最少 n 盏的上界和下界同时成立。 | `Exact K n` 同时要求 `CanLight K n` 及对每个可行 m 有 n≤m。编号中允许重复，最小数等同于把方向去重后的数目。 |
| K 不碰 E 时恰好六盏。 | `Disjoint K edge → Exact K 6`。 |
| K 碰 E 但 K≠Q 时恰好七盏。 | `¬ Disjoint K edge → K ≠ cube → Exact K 7`。棱上单点或端点接触均计入。 |
| K 填满 Q 时恰好八盏。 | `K = cube → Exact K 8`。 |

[冻结陈述](formal/Illumination/Challenge.lean) · [原猜想与适用范围出处](literature-cont/REPORT.md) · [完整书面证明](higher-order/PROOF.md) · [精确原型检查](formal/Illumination/Check.lean)

三种情形在几何上都能发生。例如 P 避开 E，Q 碰到整条 E。在 Q 中再加条件 x+y−z≤1，得到包含 P 的紧凸多面体，在 E 上仅保留 (1,1,1)，见证中间分支。这个例子便于人工核对量词。独立研究者的七点标准型、一般九顶点壳的推论、投影路线以及 43 个有理壳的计算各有不同的前提，未列入本合同。
