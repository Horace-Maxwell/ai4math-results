# 夹层定理 Lean 陈述的独立核读

**人工作用域内通过，APPROVE_STATEMENT。** 审者为本会话 positive 子代理，既未起草受审书面证明，也未写这份 Lean 陈述。受审对象是 ../formal/Illumination/Challenge.lean，SHA-256 2fd9927a0e7b532493e5de4038665d92490e479fb712298ad2b7321b863bbe6d。逐项对照 ../higher-order/PROOF.md，SHA-256 dc3072fefce1dcde1199d82165ab90089593f5b46c4d68e6b0368f75b318dfda。

| Lean 定义 / 条件 | 对应语义 | 核读 |
|---|---|---|
| Space = Fin 3 → ℝ；三个导入 | 三个实坐标，乘积拓扑与通常三维欧氏拓扑一致 | 通过 |
| cube、prism、edge | 分别为闭单位立方体、附加 x+y≤1 的闭三棱柱、以及 x=y=1 的整条闭棱 | 通过 |
| Illuminates K u p | 存在严格正实数步长使 p+tu 落入 ambient interior K | 通过 |
| CanLight K n | 同一族的 n 个非零实三维向量，照亮 frontier K 的每一点；先量化所有方向再量化边界点 | 通过 |
| Exact K n | 明示存在 n 盏且任一可行自然数盏数 m 均不小于 n | 通过 |
| IsCompact K、Convex ℝ K、prism⊆K⊆cube | 在所有紧凸夹层凸体上量化；包含棱柱保证真实三维内点，无需另引非空条件 | 通过 |
| Disjoint K edge、¬Disjoint K edge ∧ K≠cube、K=cube | 与空棱、不空棱且非满方、满方的数学条件逐一相同；中项以蕴涵柯里化表示两个前提 | 通过 |
| 6、7、8，三个结果取合取 | 每个 K 按唯一相符分支给精确值，K=cube 时整棱自动非空 | 通过 |

CanLight 允许重复或同正射线的方向，最小值完全不变：任意有限有序族可以删去冗余得到不更多盏，反向把有限集合枚举为有限族。方向不要求单位长度也等价，正实缩放相应缩放严格正步长。合同不含正式定理声明、证明、未证公理或占位。本次只审语义，零诊断预编译收据由执行者单独保存；源码若变需要重新核读。
2026-11-21T03:52:34Z
