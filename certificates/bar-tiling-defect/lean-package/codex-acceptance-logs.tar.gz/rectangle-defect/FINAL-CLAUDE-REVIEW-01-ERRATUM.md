# Erratum to FINAL-CLAUDE-REVIEW-01.md (Claude, 2026-11-20T21:26:04Z)

FINAL-CLAUDE-REVIEW-01.md §1 says the rejected draft `candidate-01` "had no `0 < n` condition, which made the k ≤ 2 clause false at n = 0". That is wrong. Under candidate-01's definition, n = 0 is harmless: the empty multiset tiles the empty grid, so the defect is 0 and the clause holds. It is the revised definition (closed rectangle [0,2]×[0,n]) that needs 0 < n, because the empty multiset does not cover [0,2]×{0}.

The independent review of Paper 24 (work/release-v1250/REVIEW-P24-01.md, MAJOR-1) found this. It does not affect the frozen statement, the Lean proof or the verdict APPROVE_FORMAL. The original report is left unchanged.
