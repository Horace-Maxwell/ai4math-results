# Cross-family FINAL review 01: bar-tile defect of the 2×n rectangle (Task P)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The frozen target `SharpBound` (root `Challenge.lean`, SHA 906da3fa…; `candidate-01/` holds the earlier integer-anchor draft, which was returned for revision and is not frozen) faithfully answers Gajdzica–Visser–Zakarczemny's Remark 5.11 in its natural reading, and it is fully Lean-verified (standard axioms only; independent rebuild and leanchecker pass). The MINOR items below concern `MATHEMATICS.md` only. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session; wrote none of the reviewed files and took no part in Task O/P authoring.
- Review started 2026-11-20T20:52:09Z; report written after 2026-11-20T21:00:08Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-rect/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= frozen/906da3…/Challenge.lean, byte-identical) | 906da3fa8ff5800a0d1dd1a2b7f74be45784858f93eef10acf7aa19d666d29d9 |
| candidate-01/Challenge.lean (superseded, not frozen) | 24ae9104d4c5da4546b363e93db30cff02a6f9f19117e5da36d962fb94cd7ea0 |
| CheckRectangle.lean | 8e8466798b836f2230d2c70e58abc018938d2ed68e8479678f4dcbd81258eae4 |
| Proof.lean | 3d758b0b9c6c7aaab840349489a48d941dcd34be42aa01beaf92505836e7f4cf |
| RowSplit.lean | 04299e7581d40dc421294e93d2f46e9e4efead889c0890655b310701dabc02e6 |
| RectCounts.lean | 6026916f6539e9f54f8de7bdf2c136b7f4dab226339a868f9e069a676baeb487 |
| BoundaryWidths.lean | 504827ad0cbe8b45ce32919445eb1be1ff60d3ce87c4dfb657d05270928fd55b |
| BoundaryRows.lean | 09459e185a81cbe380a8b8ede93c3edb84c209020ef77fd66a8404f45212e1d3 |
| IntervalPacking.lean | 9909d2f6566c4bec83f0cf0125490482af4d1f41da16e62d3cabbf9ba51ab30c |
| StripLayout.lean | 87d3a647c66e1dbb17facdb60fe7b2a726ea40a1391f316c2a67c82f2fadfb9c |
| RowPlacement.lean | 34995b9f49203972eac001dbfd03050044d0377737b6824a157ac6b0378194a0 |
| SmallRows.lean | ff8c9d1130568142915cbd566546354d929363acc639497b6593755bbe594059 |
| BoundedBezout.lean | 570ddb9681f9770c3f679cc924dd43a164cea57edcde3277f527af8b107ff53f |
| BalanceConstruction.lean | fde6a48db87d27584807a5454420f80322571ea92c396fb07d20f392894de532 |
| BalanceCases.lean | 9f19b66608cba356c440606cafaeabe6a1f4e8a047e8e366797968abb93c9abc |
| UpperCount.lean | 2b283dbd1bcb57cc062a103654f3570d0c98a3c3aa8afedb36bffebe34ef5756 |
| UpperSparse.lean | ed11e4053a0a8e948c508dc887ef751c5d6b37815bc12ebab420d0cd996f5d62 |
| LowerFamily.lean | 14763519bde74b1c74cbf6f8fed644cdc4692655a9a280e82778a4ed72875ef8 |
| MatchingLower.lean | 6fa35536a8bf9bc9ddc51aae7762a618e39cbaf6a8374f77a5198788529a2452 |
| FREEZE.json | a28914d51665e5a3597da60cd24508bdb3ec03aa9d057be8b63fec8b8218325e |
| FREEZE-REVIEW.md | c40ea9deb47a50cacd56ec734b2056555bbbc42c316a3478495437fcd33a6fbd |
| SOURCE-CHECK.md | 8a7eaf25e0ad8e830c551dfe157fea0aea5c312490445181e8eea5f4608add53 |
| G2.md | 039429dffde374b648a53de63a0bf2986216c210316e49ee5729cdbcb71af091 |
| MATHEMATICS.md | 9d363f837757696aa174be52707853e7aee4475c4613657f0e935a79e4d9461f |
| FINAL-HANDOFF.md | ec6a8c74a9129b90371a1ce1a77344913e06a006dea542af81ef28c8555d513d |
| acceptance/2026-11-20T183524Z/receipt.json | 5205dcd45d45b70d7d692e6dd8282f93e8cb81800c6c83958c00aa7c9c3abdcc |
| arXiv 2509.20495v2 PDF (downloaded by me) | 36af7e84185300f288039e8ce7f7c8c8a9ff383b5d68c28046b4106accfd000d |
| arXiv 2609.13305v1 PDF, Shaikh (downloaded by me) | b41a9e3fcbe8dadb1b08dbb521d200b879e69d408ae63bd79f4c93b934582971 |
| My Audit.lean (scratch) | fe8e14d8f9bce5a89149729df05f9fb1fb60f6f885b0578e72dc1a782ef724d0 |

All 18 source hashes match `receipt.json.source_sha256`. The 18 `.lean` files in the task root are byte-identical to `acceptance/.../root1` and `root2`. The Challenge hash matches `FREEZE.json.challenge_sha256` and the `frozen/` snapshot. The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`. `receipt.freeze_sha256` is the hash of FREEZE.json. The receipt hash matches FINAL-HANDOFF.

## 1. Is the statement faithful to the source?

The Springer PDF and HTML were blocked by a bot wall. I used arXiv v2, which SOURCE-CHECK says has the same numbering and wording, and Crossref metadata. Crossref confirms DOI 10.1007/s00026-026-00826-w = "Rectangle Partitions Generalizing Integer Partitions", Gajdzica, Visser, Zakarczemny, Annals of Combinatorics, 2026-04-28, CC BY 4.0. I did not see the journal page numbers myself.

- **Tiling (Def. 1.1–1.2).** The source says a partition is a multiset of rectangles with positive integer sides, where "a rectangle of size k × l is indistinguishable with a rectangle of size l × k". The rectangles must "cover exactly the area of the rectangle R and their interiors do not intersect", and two partitions are the same "if they are equal as multisets". Lean's `tiles m n` gives each labelled occurrence `⟨i, j⟩ : Σ i, Fin (m i)` a real anchor and its own orientation bit. The closed tiles must have union exactly `Icc 0 2 ×ˢ Icc 0 n`, and distinct occurrences must have disjoint open interiors. This is the source definition with real coordinates. Rotation is allowed for every bar: a rotated bar of length ≥ 3 cannot fit in height 2, and a rotated 1×1 is the same tile. So in effect only the 1×2 bar can stand vertically, as in the source, where 2×1 is the 1×2 block and not a separate type.
- **Tile set (§5).** "p_{k,l}(2,n) … only the blocks of sizes 1 × i and 2 × j are allowed for any 1 ≤ i ≤ k and 2 ≤ j ≤ l". With l = 1 only the bars 1×1, …, 1×k remain. `Counts k = Fin k → ℕ`, and index i has length i+1. A vector m is exactly one multiset, so each multiset is counted once, independent of arrangement, orientation or anchors.
- **Counts.** `multisets k n = {m | Σ (i+1) m_i = 2n}` corresponds one-to-one with partitions of 2n into parts ≤ k, i.e. p_k(2n). (Counting partitions into at most k parts gives the same number by conjugation.) The tileable vectors are exactly p_{k,1}(2,n). The first conjunct proves finiteness for all k, n, so neither `ncard` can default to 0. The tileable set is a subset, so the natural-number subtraction in `defect` is |p_{k,1}(2,n) − p_k(2n)| exactly.
- **Not degenerate.** `tiles` is satisfiable and can fail. The proven `tiles_iff_rowSplit` (n > 0, area 2n) reduces it to a two-row condition. My `Audit.lean` proves `tiles (k:=2) ![2,0] 1` (two unit squares) and `¬ tiles (k:=3) ![1,0,1] 2` (a 1×3 bar plus a unit square), both through the Lean definitions. The hypothesis 0 < n is needed: at n = 0 the degenerate segment cannot be covered by the empty multiset. The source has n ∈ ℕ = positive integers (v2 p.1), so this is the correct range.
- **The question and the "tight" reading.** Remark 5.11 (v2 p.17) reports, from the conjectured Table 2, O(1) for k ≤ 5, O(n) for k = 6, 7 and O(n²) for k = 8, then says "it seems an interesting problem to compute a tight upper bound for |p_{k,1}(2,n) − p_k(2n)| for all k". `SharpBound` gives:
  - zero for k = 1, 2 and all n > 0;
  - for each k ≥ 3, a k-dependent C > 0 with defect ≤ C(n+1)^e for all n > 0, where e = k/2 − 2 is truncated ℕ-subtraction, i.e. max(0, ⌊k/2⌋ − 2);
  - a k-dependent C > 0 such that for every N some n ≥ N has (n+1)^e ≤ C·defect. So the upper bound is not o(n^e). For e = 0 this says the defect is ≥ 1 infinitely often, so O(1) cannot be improved to "eventually 0";
  - for k ≥ 6, the same bound for every sufficiently large odd n.

  The quantifiers are in the right order (∀k ∃C ∀n), cover the full range, and add no hidden hypotheses. This is the optimal polynomial order, which is the sense in which the source's own examples are stated. It agrees with all three of the source's examples: e = 0, 0, 0, 0, 1, 1, 2 for k = 3…8 (plus 0 for k ≤ 2). The statement does not give a leading constant or a quasi-polynomial description, and the source asks for neither. It correctly claims the matching lower bound only along a subsequence (odd n), and that is necessary: the defect is much smaller on some even widths (see §3).
- **Small cases (my own Python, independent of Codex's scripts).** First, exhaustive backtracking placement of bars on the 2×n cell grid (horizontal bars, vertical 1×2) for all multisets with k ≤ 11 and n ≤ 18. Second, the row-split criterion. The two agree on every multiset (0 mismatches). Lean proves that the real-coordinate `tiles` is equivalent to the row split, so this also checks the Lean definition against grid tilings. Further checks:
  - p_{3,1}(2,n) equals n²/3 + n + A_{3,1}(n) from the source's Proposition 5.5 for n = 1…18.
  - p_{4,1}(2,n) equals the k = 4 row of Table 2 for n = 6…18. Caveat: the PDF text is garbled there; I took the constants (−5/4, −53/36, −121/36 mod 3; 9/4, 1, 1/4, 0 mod 4) from the extraction, and they fit all 13 values exactly.
  - Example defects: k = 3 gives 1 exactly when n ≡ 2 (mod 3), up to n = 60. k = 4 gives 0,2,2,0,2,2,2,2,1,…
- **candidate-01.** The earlier draft used only ℕ anchors and had no 0 < n. Under it, the k ≤ 2 clause would be false at n = 0 (defect 1). The freeze reviewer returned it, and the frozen version fixes both points.

## 2. Is the proof chain clean?

- **CheckRectangle.lean.** It is exactly `theorem check_SharpBound : Challenge.SharpBound := Proof.SharpBound` plus two `#print axioms`. Only Challenge.lean opens `TaskP.RectangleDefect.Challenge`. The other modules use `TaskP.RectangleDefect`, `.Lower` and `.Proof`, so nothing shadows a frozen name. My `Audit.lean` checks `TaskP.RectangleDefect.check_SharpBound` and `Proof.SharpBound` against `Challenge.SharpBound` with fully qualified names. It also restates the whole statement with the definitions inlined (k/2 − 2 written out), and it contains the two sanity examples above.
- **Forbidden constructs.** I grepped all 18 files for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, set_option, initialize, run_cmd, ofReduceBool and `@[`. None appear. There are four kernel `decide` uses: `0 < 2` (MatchingLower l.41), `0 < 1` (MatchingLower l.105), and `Even 4 ∧ 4 ≤ 4` and `Even 6 ∧ 4 ≤ 6` (LowerFamily l.86, 90). All are trivial closed ℕ facts. `mkStrip` uses `Classical.choice` on a proven nonempty Prop, which is harmless.
- **Proof structure.**
  - Necessity, `rowSplit_of_tiles`, works directly on the real-coordinate tiling. Tiles meeting the side x = 0 have disjoint open y-projections, because every tile reaches x = 1/2, and their closed projections cover [0, n]. Lebesgue measure then gives the boundary-length identity. No integrality of anchors is assumed.
  - Sufficiency, `tiles_of_rowSplit`, builds an explicit real tiling: vertical dominoes first, then two rows of packed intervals.
  - k ≤ 2: all dominoes vertical, and the unit squares split evenly.
  - Upper bound: a bounded-Bézout balancing shows that failures have few "heavy" coordinates (`sparse_of_gcd` gives ≤ e+1). An injective code then gives defect ≤ 2^k (T+1)^k (2n+1)^e.
  - Lower bounds: one unit square plus an odd number of 3-bars at n = 3N+2, and, for k ≥ 6, an injective family of all-even-length (≥ 4) multisets at odd n.
- **Axioms.** `Proof.SharpBound` and `check_SharpBound` depend only on `[propext, Classical.choice, Quot.sound]`, both in the receipt and in my rebuild.

## 3. Independent rebuild on this Mac

- **Setup.** A new empty scratch directory. I copied the 18 `.lean` files, added `Audit.lean`, and compiled each module with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -o` in dependency order. `LEAN_PATH` was my own fresh output directory plus the prebuilt package oleans of `research-lean-v434/.lake/packages`. No lake, and no Codex build products.
- **Toolchain and dependencies.** Lean 4.34.1. The `lean` SHA is 1b370cfc… and the `leanchecker` SHA is cfde41cb…, both equal to the receipt. Mathlib is at `d13f23b723b8a846827a245b89c10fc7d3f11612` (`git rev-parse`).
- **Lock.** I acquired `leanlock.sh acquire any claude-final-rect 60` (slot B) and released it afterwards (`release B claude-final-rect` → `released B`; status shows B free). Only one Lean process ran at a time.
- **Result.** All 19 modules (18 + Audit) exited 0 with no warnings and no errors. The only output was the `#print axioms` info. `leanchecker` exited 0 with empty output on all 19 modules. Peak single-command RSS was 5.996 GB (receipt: 6.004 GB).
- **Empirical growth (row-split DP, validated above).** These numbers are consistent with the exponent. They are not evidence for it; Lean is.
  - k = 6 (e = 1): D/(n+1) ≤ 1 for odd n up to 45. The even values dip as low as D(36) = 2.
  - k = 7: D/(n+1) is in [0.35, 2.1] for n ≤ 40.
  - k = 8, 9 (e = 2): D/(n+1)² is in [0.05, 0.37] for n ≤ 34 and n ≤ 30.
  - For k ≥ 10 the ranges I could reach are pre-asymptotic. This is expected, since the Lean lower-bound constant (2D)^e with D = 2k²+4 is tiny.

## 4. Mathematical sanity of MATHEMATICS.md

The written proof is correct and matches the Lean argument section by section:
- §1, the boundary argument and the strip construction;
- §2, the bounded Bézout balancing with T = 2B+4, the parity reservation of one vertical domino when gcd(J) = 2 and 2 ∈ J, and 2h = Σ_{m_j odd} j;
- §3, the failure cases gcd ≥ 3 (≤ ⌊k/3⌋ lengths) or gcd = 2 with 2 ∉ J (≤ ⌊k/2⌋ − 1 lengths), both ≤ e+1, with one coordinate recovered from the area;
- §4, the families. The area identity, the injectivity including the shared length-6 coordinate, M = ⌊n/D⌋ and n+1 ≤ 2DM for n ≥ D all check out.

The text never says "first". Shaikh's Theorem 1 is correctly described as proving the adjacent Conjecture 5.10; I checked the arXiv abstract and §1, which do not address Remark 5.11. The source's Proposition 5.8 is correctly described as a leading-term estimate. The closing paragraph separates the Lean content from the bibliographic statements.

**Prior work (my spot check, 2026-11-20).**
- An arXiv search for "rectangle partitions" returns, after the source: Gajdzica et al. 2608.08762 (asymptotics of p(n,n), p(3,n)); Gajdzica–Zakarczemny 2608.22955 (log p(m,n)); and Shaikh 2609.13305.
- OpenAlex lists one work citing Shaikh, the November cubic-partition approximation (W7226255988). Its abstract treats r(n), multisets of arbitrary integer rectangles tiling 2×n, with an exponential error term.
- None of these treats bars of bounded length k or the difference in Remark 5.11.

My search was a spot check, not a G3.

## MINOR write-up fixes

1. MATHEMATICS.md, opening paragraph: Remark 5.11's O(1)/O(n)/O(n²) observations for k ≤ 8 rest on the authors' *conjectured* Table 2 formulas. Say so, and add as a corollary (Lean-covered) that `SharpBound` proves these observations unconditionally and shows each is sharp.
2. MATHEMATICS.md, "合同、来源与证明范围": name the adjacent 2026 works that G2 and Task O already found but the write-up omits, and say what each covers. These are the November cubic-partition approximation for unrestricted two-row rectangle partitions, and the August 2026 asymptotic papers on p(m,n) (arXiv 2608.08762, 2608.22955). None restricts bar length or treats the Remark 5.11 difference. Scope the statement "as of the 2026-11-20 G2 search" and repeat G3 before publishing.
3. MATHEMATICS.md, 结论: add one sentence that the matching order is claimed only along a subsequence (all large odd n for k ≥ 6, n ≡ 2 mod 3 for 3 ≤ k ≤ 5). Nothing is claimed about lim inf, and on some even widths the defect is much smaller (e.g. D₆(36) = 2). This keeps readers from reading "Θ(n^e) for all n" into "紧".
4. Optional: when citing the source, give both the journal location (Remark 5.11, journal p.24, per SOURCE-CHECK) and arXiv v2 p.17 in MATHEMATICS.md itself. The write-up currently links only the DOI and "第 5 节".
