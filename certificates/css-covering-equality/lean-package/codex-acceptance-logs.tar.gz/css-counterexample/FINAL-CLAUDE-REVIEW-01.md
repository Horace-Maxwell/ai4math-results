# Cross-family FINAL review 01: four-dimensional equality counterexample to CSS Conjecture A (Task R)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The four frozen targets `NonHollow`, `Radius`, `Volume` and `OutsideList` faithfully state that P = conv(e₁,e₂,e₃,e₄,−(2,1,1,1)) is a non-hollow lattice 4-polytope, that its covering radius in the source's sense is exactly 2 = d/2, that its normalized volume is 6, and that it is not in a family that contains every polytope the paper's equality clause allows. All four are fully Lean-verified: standard axioms only, and my independent rebuild and leanchecker run pass. The freeze-timing irregularity does not matter, because the two statement versions differ only by one scope token. The MINOR items below concern the write-up only.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session. I wrote none of the reviewed files and took no part in Task Q or Task R on this problem.
- Review started 2026-11-20T19:42:05Z. Report written after 2026-11-20T19:52:00Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-css/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= `frozen/1dbf…/Challenge.lean`, byte-identical) | 1dbf0ce8747f85337df077147c06a97ba2cd349e201b38a5d647122ca8818161 |
| frozen/7fff…/Challenge.lean (first version) | 7fff04f34fc0b9f3fba5657cc201f2f2e53dfc06c3fcf39178a5e0dd1e5eb013 |
| CheckCSS.lean | 9a46571399c52ba3b53ab63a0d953484d622f69ca1afb3b71bf00f82ec910279 |
| Proof.lean | b9eea1ae6c568d72fe25f8e815b484c00669cf5245be2ed2b276b958fbdecda8 |
| Geometry.lean | 328ebdc2ff864ed0f061e5306d0108dcda74e4f59a06ec08a486a3298173265f |
| Residues.lean | fe8ed30e45bae13cd662ac992f3ac97b92ac0cee202f785087e3cfdc592b5ff4 |
| Radius.lean | f40d45095ec33870cf2b5d1957319ce218a1ae2b5146daf42611f4340d859d41 |
| Volume.lean | 465f95cee80927d0a05db0c8b7747392ec6f7f6e894775cf9943719ff2e8cfdf |
| ExclusionFinite.lean | 6a90c3d98ad747b49a84c05cd42182fc32ba9286bdd5c6be3e66ff5a85ee03fe |
| Exclusion.lean | dfaabc7c772f0aa2d4c2a622f823cddd6025118ab4e54e7b860360bb069192a0 |
| FREEZE.json | 809dbe0e30206eb69a5b0f1f6691d66a5abc89fea181d6547224eedeabe43cc8 |
| FREEZE-REVIEW-02.md | 581a2fe4efeb65c614155a46473e4a6225f45a8a7be7734de1b5e8a2fe509580 |
| SOURCE-CHECK.md | 064e3d3805bd12ef93844ba45dfdb0de66929810ca0d003916d7eb9dca5020a1 |
| G2.md | 88b3c79d80717414e3e1bbef4e259443b7f52cd72cf73b7b5ecd2adeb81a0d2f |
| MATHEMATICS.md | 11ae6a10dbd5bbc21ec5fc19e07d400e67fdb6ae18d36cf5ba941397897c6ade |
| FINAL-HANDOFF.md | 551a0815c66fb1462432cb688a2a791ab6f4337191603b30d7051916cb4280a4 |
| acceptance/2026-11-20T193547Z/receipt.json | fe29128d7d8f67b5d53d39ad581d413553f45eb22a8baa002f4aae52c855eb0b |
| arXiv 1903.02866v2 PDF (downloaded by me) | 4ece078961e7c03677952249ad8d205b40cf470c64ef51ab55f1f8e9d1a0fd6b |
| arXiv 1903.02866v1 PDF (downloaded by me) | df4ffb26285256f72bcd0a49abf0d5a85d1744801c80779a8b3b1763cfc90a07 |
| Journal full text, PMC8709830 HTML (downloaded by me) | 386025da139d5cc1bf551cf588ce1b803ccf7d04bd44be27c609b51039fccda3 |
| My Audit.lean (scratch) | b5927e17872f594930146c7a0e6f7bc303fccc40cfe36efe53ee339c66e1e372 |

All 9 source hashes match `receipt.json`. The 9 `.lean` files in the task root are byte-identical to `acceptance/…/root1` and `root2`. The Challenge, FREEZE-REVIEW-02, SOURCE-CHECK and G2 hashes match `FREEZE.json`. The receipt hash matches FINAL-HANDOFF. The root2 checker logs are all empty (0 bytes in total).

## 1. Are the statements faithful to the source?

**Source.** G. Codenotti, F. Santos, M. Schymura, "The Covering Radius and a Discrete Surface Area for Non-Hollow Simplices", *Discrete Comput. Geom.* 67(1) (2022) 65–111, published online 2021-11-17, DOI 10.1007/s00454-021-00330-3. arXiv:1903.02866 has two versions: v1 (2019-03-07) and v2 (2021-08-27). I extracted the text of v1, v2 and the PMC journal full text myself. Conjecture A has the same wording in all three:

> Conjecture A. Let P ⊆ ℝ^d be a non-hollow lattice d-polytope. Then μ(P) ≤ d/2, with equality if and only if P is obtained by direct sums and/or translations of simplices of the form S(1_l).

Here S(1_{d+1}) = conv(−1_d, e₁, …, e_d). The direct sum is defined in §2.1 as K ⊕ L = {λx + (1−λ)y : x∈K, y∈L, λ∈[0,1]} for K ⊆ V and L ⊆ W in complementary subspaces, both containing the origin, with lattice Λ ⊕ Γ. Example 1.1 and Lemma 3.8 translate factors before taking the sum. The paper does not give its list as a table of volumes. It gives a generative description, and it compares the polytopes up to unimodular equivalence (Lemma 3.8: "nine non-equivalent").

- **Covering radius.** The source (p.1) defines μ(K,Λ) = min{μ ≥ 0 : μK + Λ = ℝ^d}, with Λ = ℤ^d. Lean's `Radius` is `IsLeast {r | 0 ≤ r ∧ Covers P r} 2`, where `Covers K r` means every x is `embed z + r • y` with z ∈ ℤ⁴ and y ∈ K. This is exactly the source's minimum, stated as attained. It is not a finite proxy. My `Audit.lean` restates the target with my own vertex list `![1,0,0,0], …, ![-2,-1,-1,-1]` and an explicit ∃z ∃y, and proves it from `check_Radius`.
- **Non-hollow lattice polytope.** The source requires int(P) ∩ ℤ^d ≠ ∅ and lattice vertices. `NonHollow` is `0 ∈ interior P`, which is stronger and implies full dimension. The vertices are integer by construction.
- **Normalized volume.** The source normalizes Euclidean volume so that a unimodular simplex has volume 1. Lean defines `volume K / volume unitSimplex`, with unitSimplex = conv(0,e₁,…,e₄), computed from the real Lebesgue measure. The ENNReal ratio could be degenerate only if vol(unitSimplex) were 0 or ∞. The proof rules out both. My `audit_volume` proves vol P = 6·vol(Δ), vol Δ ≠ 0 and vol Δ ≠ ⊤ directly.
- **Equality list.** `Generated` is a family that contains everything the paper's list allows:
  - Leaves are any ≥2 distinct lattice points summing to 0. Every positive-dimensional S(1_l), placed in a sublattice of the final ℤ⁴ by any injective lattice-linear map, has this form.
  - `translate` allows any ℤ⁴ translation.
  - `join` takes the hull of a union with no subspace, lattice or origin constraint. When both factors contain 0, the paper's K ⊕ L is exactly conv(K ∪ L).
  - The family is closed under GL₄(ℤ), because linear maps commute with convexHull and keep zero sums. So "up to unimodular equivalence" is covered as well.
  - The point factor S(1_1) is a unit for ⊕ and changes nothing.

  So `¬ Generated P` is at least as strong as "P is not on the paper's list". `Generated` is not trivially empty (for example {e₁, −e₁}), and the exclusion proof is substantive (see §2).
- **Reading of "translations".** `Generated.translate` uses lattice translations only. This matches the paper's own sentence on p.2, "direct sums of simplices of the form S(1_l) or lattice translates thereof", and its examples. It also matches later restatements: Krivokuća, arXiv:2601.15173, p.2, "direct sums of translates of standard terminal simplices", and her master's thesis, Def. 3.2, "direct sum of lattice translates". Under a literal reading that allowed arbitrary real translations, the Lean target would not cover the class. That reading is still excluded by the informal volume-product argument of Task Q (any such polytope has normalized volume in {5,8,9,12,16}, and P has 6), but that argument is not in Lean. See MINOR-2.
- **Volume → not on list.** The Lean exclusion does not use the volume argument. `Volume` is only an informative fourth target. The claim "volume ∉ {5,8,9,12,16} implies not on the list" (Task Q) needs the product formula for direct sums with the origin possibly on the boundary. That formula is plausible, but it is not formalized and the Lean result does not depend on it.

**Independent numerical check** (`py/check2.py`, exact integer and Fraction arithmetic):

- det of the edge matrix = 6.
- The facet normals are (−2,1,1,1), (1,−5,1,1), (1,1,−5,1), (1,1,1,−5), (1,1,1,1), with P = {x : a·x ≤ 1}.
- The lattice points of P are exactly the 5 vertices and 0. The only interior lattice point is 0. No subset of 2 or more of these points has a lattice centroid.
- The exact minimum gauge over lattice translates is 2 at y₀ = (2/3, 2/3, 1/2, 1/6).
- The maximum over all points of (1/6)ℤ⁴, (1/12)ℤ⁴, (1/18)ℤ⁴ and (1/24)ℤ⁴ is exactly 2. The maximum over 20,000 random points with denominator 1009 is 1.962.

This agrees with μ = 2.

**Already in the literature?** The simplex itself is known:
- weight (2,1,1,1,1), Kasprzyk's thesis Prop. 9.7.10 (cited by Task Q);
- T.-J. Lee, arXiv:2610.26186 ("On the hyperplane conjecture", Oct 2026), an algebraic-geometry paper whose abstract does not mention covering radii.

My own extended web search found no statement of its covering radius and no counterexample to the equality clause. The search covered the CSS paper, Codenotti's thesis entry, Krivokuća 2601.15173 (her Conjecture 4.1 restates the CSS list without objection), and the 2606.14442 minimal-covering-bodies paper. CSS Theorem 1.4 gives μ(S(ω)) only for simplices of the form S(ω). G2-NEIGHBORS correctly shows P is not unimodularly an S(ω): all vertices are primitive and 0 is the only interior lattice point, which would force ω = 1 and volume 5. This is not a guarantee of priority. The final G3 check remains the project's job.

## 2. Proof chain

- `CheckCSS.lean` has exactly four lines of the form `theorem check_X : Challenge.X := Proof.X`, inside `namespace TaskR.CSS`. `Proof.OutsideList` is defined in Exclusion.lean under `namespace TaskR.CSS.Proof`. No local declaration shadows a `Challenge.*` or `Proof.*` name. My `Audit.lean` repeats all eight bindings with fully qualified names (`TaskR.CSS.Challenge.X := TaskR.CSS.Proof.X` and `:= TaskR.CSS.check_X`).
- Grep of all 9 local `.lean` files found none of: sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, notation, instance, attribute, `@[`, initialize, run_cmd, ofReduceBool.
- The only `set_option`s are `maxRecDepth 30000` and `maxHeartbeats 4000000`, scoped with `in` to `Residues.box`.
- There are two `decide +kernel` uses:
  - `Residues.box`: 6⁴ = 1296 residue tuples × 6 candidate k;
  - `ExclusionFinite.nonintegral_subsets`: 64 subsets of the 6 lattice points.

  Both are small and kernel-checked. The other `decide` uses are trivial `(6:ℤ) ≠ 0` and `0 < 6` facts.
- Mathematical structure, which I checked line by line:
  - `Geometry`: barycentric coordinates and an open neighbourhood of 0, so 0 ∈ interior.
  - `Residues` and `Radius`: the upper bound by the mod-6 certificate (max over r of min over k of the residue sum is 8, so S(b) < 2), and the lower bound for every r < 2 at the point X_r((p + r/2)/6), p = (1,1,2,4). The residue sums for k mod 6 = 0..5 are 8, 13, 12, 11, 10, 9; I recomputed them by hand.
  - `Volume`: affine image of Δ under I + u1ᵀ (det 6) plus `addHaar_image_linearMap`.
  - `Exclusion`: by induction, every generated set contains a lattice translate of a zero-sum leaf. The lattice points of P are the 6-point set, and none of its subsets of 2 or more points has a lattice centroid.

## 3. Independent rebuild on this Mac

- Lock: slot A acquired as `claude-final-css` at 2026-11-20T19:48:20Z and released at 19:51:39Z (`status` showed A and B free afterwards). Only one Lean process ran at a time.
- Toolchain: Lean 4.34.1 (`work/toolchains/lean-4.34.1-darwin_aarch64/bin`). Mathlib d13f23b7 prebuilt oleans via LEAN_PATH from `work/research-lean-v434/.lake/packages`.
- Procedure: copied the 9 sources plus my `Audit.lean` to a new `src/`, then ran plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o build1/<M>.olean`, followed by `leanchecker <M>`, in dependency order into the new empty `build1/`.
- Result: all 10 modules exit 0, with 0 warnings and 0 errors. All 10 leanchecker runs exit 0 with empty output. Peak child RSS was 6.29 GB.
- `#print axioms` gives `[propext, Classical.choice, Quot.sound]` for:
  - `Proof.NonHollow`, `Proof.Radius`, `Proof.Volume` and `Proof.OutsideList`;
  - all four `check_*`;
  - my `audit_radius`, `audit_nonhollow`, `audit_volume` and `audit_outside`.
- My olean hashes differ from the receipt's, as expected: plain `lean -o` is not the lake build used in acceptance. Source hashes are identical.

## 4. Freeze chronology

- **Diff.** I diffed `frozen/7fff…/Challenge.lean` against the current file. The only difference is line 6: `open scoped BigOperators` became `open scoped BigOperators ENNReal`. Every definition and all four target lines are byte-identical.
- **Effect of the change.** Opening the ENNReal scope only adds the notations `ℝ≥0∞` and `∞`. `∞` does not occur in the file. Without the change, v1 did not elaborate at all (`dev-logs/Challenge-…193149Z…log`: parse error at 26:56 on `ℝ≥0∞`).
- **Timeline.** I checked file birth times (`stat`) and dev-log timestamps:
  - v1 approval: 19:31:21Z;
  - Geometry.lean draft born 19:31:49Z, Residues.lean draft born 19:32:14Z;
  - v2 zero-diagnostic compile: 19:32:45Z;
  - FREEZE-REVIEW-02: 19:33:19Z;
  - FREEZE.json and frozen snapshot: 19:33:34Z;
  - first Lean compile of either draft: 19:33:41Z or later (logs `…193341Z…`).

  This matches FREEZE-CHRONOLOGY.md.
- **Judgement.** The rule "statement frozen before proofs" exists to stop the statement being adjusted to fit the proof. Here the mathematical text that the proofs target was approved before any proof file existed, and it never changed afterwards. The only later edit cannot strengthen, weaken or alter any target. So the irregularity is not material. The only real weakness is in the process: v1 was approved without a successful compile (MINOR-4).

## 5. MATHEMATICS.md

The proofs in MATHEMATICS.md are correct and match the Lean development, and the content not in Lean is labelled. The novelty wording is limited ("据 2026-11-20 本题 G2 检索，在所覆盖的来源中未识别…"). There is no "first" claim. It says that the numerical bound holds here and that only the equality clause is refuted. It also says the simplex, its vertices and its volume are already in the literature, and credits CSS Appendix B for the algorithm.

## BLOCKER

None.

## MAJOR

None.

## MINOR (write-up only; the Lean result is unaffected)

1. **Corollary 4.3 and Conjecture D.** MATHEMATICS.md should add one sentence on the Corollary 4.3 discussion. CSS Cor. 4.3 states "Conjecture C ⇒ Conjecture A", but its proof gives only μ ≤ d/2. Since A's equality clause is false, Cor. 4.3 holds only for the numerical part; otherwise C itself would be refuted. P does not refute C (Task Q's REVIEW-GRAPHS says P attains C's bound). Add also that P has exactly one interior lattice point, so it also contradicts the k = 1 equality clause of Conjecture D. The Lean lemma `Exclusion.lattice_point` comes close to proving this, but D(k=1) is not a Lean target, and this point should be labelled as such.
2. **Translations.** State explicitly that `OutsideList` covers lattice translations, which is the paper's own p.2 wording ("lattice translates thereof"). Arbitrary real translations are excluded only by the informal volume-product argument ({5,8,9,12,16} ∌ 6). Either add that argument as a remark marked "not in Lean", or cite the p.2 wording.
3. **Prior-appearance citations.** The text says the simplex is known but points only to Task Q's NOTE.md. The public text should cite Kasprzyk's thesis (Prop. 9.7.10) and Lee, arXiv:2610.26186 (App. C) by name. It should also mention CSS Theorem 1.4 (the S(ω) formula) and why P is not an S(ω) (G2-NEIGHBORS has the argument).
4. **Process note.** The first freeze review approved a Challenge.lean that did not compile. For future tasks, a zero-diagnostic compile should be required before APPROVE_FREEZE. The current disclosure in FREEZE-CHRONOLOGY is accurate and enough for this item.

Lock status at the end of this review: slot A released by `claude-final-css`; slots A and B free.
