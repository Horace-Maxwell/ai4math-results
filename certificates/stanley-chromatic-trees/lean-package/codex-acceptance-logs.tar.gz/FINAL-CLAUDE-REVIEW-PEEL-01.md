# Final cross-family review: Stanley peeling theorem (`PeelingReconstruction`)

- Reviewer: Claude Opus 5.5 subagent, cross-family, non-author (the authors are OpenAI Codex sessions).
- Review UTC: 2026-11-27T06:01:22Z (`date -u`). Work started 2026-11-27T05:46:43Z.
- Scope: frozen statement, written proof, Lean plumbing and receipts, size of the class, and priority.
- Scratch scripts (outside the repo): `<claude-scratch>/34790acf-0f2c-43bb-913c-85410423b576/scratchpad/stanley-peel/{peel_trees.py, peel_trees.out, examples.py, colored_lemma.py, colored_lemma.out, public_criteria.py, small30.py, ReviewPeel.lean, web/}`.
- Reused from the anchor review (FINAL-CLAUDE-REVIEW-ANCHOR-01.md, PRIOR-CLAUDE-ANCHOR-01.md): `SameCSF` is equivalent to X_G = X_H, neither weaker nor stronger. `ChallengeA.lean` is byte-identical to the file reviewed there (hash below), so I did not repeat that check.

## Hashes recomputed at review time

| Object | SHA-256 | Matches |
|---|---|---|
| `formal/Stanley/ChallengePeel.lean` (frozen) | `dcc0d30ad44625a6d81cb1518ccd9f2ab60e3dcebacaf60fc8606272b4e7c8a3` | FREEZE-Peel, both receipts, PAIR-PASS `challenge_sha256` |
| `formal/Stanley/ChallengeA.lean` (definitions) | `683c4463a7521b2536f7fcb9b92375a7e2e93f80fd4c882f6e27a32ce9876591` | the anchor review and both receipts |
| `formal/FREEZE-Peel.json` | `dd760e4968f41db284573201c4f547eb17ee389278e3c7d4ac0d737f37757aa9` | PAIR-PASS `frozen_record`, `frozen` field of both receipts |
| `acceptance/peel-20261127T051155Z/PAIR-PASS.json` | `ebfb1021b83f85f2dd6536ce7edee66da311d85c672a8c1e02f7b9fa8b864549` | handoff |
| `root1/receipt.json` / `root2/receipt.json` | `0437a6e2…f3ac` / `47e79f16…fb80` | PAIR-PASS |
| `root{1,2}/release.log` | `b82fc226…93e7` | PAIR-PASS |
| `verify.py` / `serial.sh` / `seal.py` | `18680e4b…b07e` / `c5d0538d…acab6` / `3e35ffb4…35b0` | PAIR-PASS `step_files` |
| `formal/Stanley/CheckPeel.lean` / `PeelProof.lean` | `cf1c65ba…0f13` / `e7fe79dd…9734` | the receipts' source maps |
| `PEEL-FINAL-HANDOFF.md` / `formal/PEEL-STATEMENT-MAP.md` | `5d5b3d1b…c726` / `9da64308…035b` | (reviewed copies) |

All 5 bindings in FREEZE-Peel still hold. Each receipt lists 34 source and config hashes. All of them match the current files under `formal/` (the package entry is `package/Stanley.lean`) and the copies in `root1/` and `root2/`. There are 0 mismatches. Every command log also matches its recorded hash.

## A. Frozen statement, line by line

`PeelingReconstruction` reads: `∀ n m G H, G.IsTree → H.IsTree → PeelingWeights G → SameCSF G H → Nonempty (G ≃g H)`. `PeelingWeights G` is the conjunction of four clauses:

1. `2 ≤ (core G).card`: there are at least two non-leaf vertices. With `core` = {deg ≠ 1}, this forces n ≥ 4 in practice.
2. `∀ v ∈ core, 2 ≤ coreWeight v`: every internal vertex has a pendant leaf, so T is proper.
3. `∀ v ∈ core, ∀ P ⊆ core, 2 ≤ |P| → Σ_P w ≠ w(v)`: no core weight equals the sum of the weights of two or more distinct core vertices ("atomic" weights). Repeated weights may still appear separately in P, because P is a set of vertices, not of values. This is exactly condition 2 of LEAF-PEELING.md. A sufficient condition is that all weights lie in [b, 2b).
4. `untaggedCoreLeaf v ∧ untaggedCoreLeaf u → v = u`, where `untaggedCoreLeaf v` means: v is in the core, has exactly one core neighbour, and some other core vertex has the same weight. So at most one leaf of the core has a weight that is repeated anywhere in the core.

These clauses match the statement map and the handoff one for one. One small wording point: the handoff summary says "at most one core leaf shares its weight with another core vertex". That matches clause 4 exactly, because the competitor can be any core vertex, internal ones included.

The conclusion is a Mathlib graph isomorphism of the two whole trees. The hypotheses constrain G only, and H is an arbitrary finite tree.

**Lean replay.** I held lock slot A (`claude-stanley-peel`) for about 3 seconds and released it (`released A`). I ran plain `lean` on root1's oleans, writing nothing in the repo. Results:
- `check_peelingReconstruction : PeelingReconstruction`;
- `#print axioms` gives `[propext, Classical.choice, Quot.sound]`;
- `Iff.rfl` proves that `PeelingReconstruction` is the displayed ∀-statement, and that `PeelingWeights G` is the displayed four-clause conjunction;
- `#print untaggedCoreLeaf`, `SameCSF` and `colorCoefficient` show the frozen definitions unchanged.

**Independent encoding check.** `peel_trees.py` has two encodings:
- `lean_peel` transcribes the Lean predicate literally: degree ≠ 1, brute-force over every subset P;
- `indep_peel` follows the informal statement: non-leaves, a dynamic-programming test for atomicity, and core-leaf multiplicities.

They agree on every tree with at most 20 vertices, about 1.6 million trees with 0 disagreements.

**Non-vacuity and the examples (`examples.py`).**
- *The 178-vertex example.* Core: the complete binary tree of height 3. Weights: 10 on the 7 internal vertices and on one core leaf, 11 to 17 on the other leaves. It has n = 178, it is a tree, its diameter is 8, its core has 15 vertices and 8 leaves, and weight 10 occurs 8 times. The literal predicate holds (all 32,768 core subsets checked). It is not in Zeng's class, not in the anchor class A, and does not have all-distinct weights. It is not a caterpillar and not a spider. Every claim in the handoff about this example is confirmed.
- *Larger heights.* The same construction at h = 4, 5, 6 gives n = 678, 2638 and 10398, in agreement with the formula (2ℓ−1)b + ℓ(ℓ−1)/2, with diameters 10, 12 and 14. The independent encoding accepts all of them.
- *The LEAF-PEELING variant* (all core leaves tagged) gives n = 186 at h = 3, in agreement with its formula. It is accepted.
- *Negative controls.* Two repeated core leaves, or an internal weight 21 = 10 + 11, each make the predicate false, as they should.

**Size of the class.** Counts of members by n (`peel_trees.out`):

| n | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| members | 1 | 1 | 3 | 3 | 8 | 6 | 16 | 18 | 37 | 23 | 76 | 56 | 137 | 142 | 231 | 207 |

This is roughly 3 to 5 times the size of the anchor class at the same n. Up to n = 20, exactly 6 members (all at n = 18) are not caterpillars, not spiders and have diameter at least 6. All 6 are also outside Zeng's class and the anchor class. Example: core = spider with legs (2,2,1), internal weights 3,3,3, core-leaf weights 3,2,4. This tree has 18 vertices, which is well below the 29-vertex computational bound of Heil–Ji.

Structural facts:
- **Peel ∩ Zeng is exactly the class with all core weights distinct** (GOT Cor. 5.15), so it brings nothing new. Proof: if internal weights are unique, a repeated core-leaf weight must be shared with another core leaf, giving two untagged leaves. The counts confirm this ("zeng" = "got_distinct" at every n).
- **Peel and A are incomparable.** Every member of A with at most 20 vertices is also in Peel; the counts equal the anchor review's counts at n = 13 to 18. But a path core with weights 16, 2, 4, 2, 32 (n = 56) is in A and not in Peel, because 4 = 2 + 2. In the other direction, the 178-vertex example is in Peel and not in A.
- **Core leaves: about √n.** This genuinely escapes family A's O(log n) limit. All core leaves but one have distinct weights, each at least 2, so n ≥ Σ w ≳ L²/2. That gives L ≤ √(2n) + O(1) in general, and the binary family reaches L ≍ √n. So the class is polynomially thin, not logarithmically thin. Arbitrary core shapes are allowed, and the internal weights may repeat in any pattern.
- **First members beyond the computational bound.** I found members outside every published or public criterion checked in D at n = 30 (core spider (2,2,1), internal 5,5,5, leaves 5,4,6) and at n = 36 (internal 6,6,6, leaves 6,5,7). Both pass the literal predicate and have no balanced edge, a non-qualifying centroid and no degree-2 vertex (`small30.py`). So new content starts no later than 30 vertices, just above the published bound of 29. I did not compute the exact minimum above 33, the unvetted clawrxiv bound mentioned in the anchor review.

## B. Proof sanity

The argument in `positive-a/LEAF-PEELING.md` is sound. I checked each step.

1. **Properness and W.** X_T determines that T′ is proper and has the same weight multiset W (GOT Thm 4.15 and Cor 4.20). In Stanley's spanning-forest expansion, the 1-free terms are exactly the edge subsets that contain every leaf edge. That part is the weight-sum forest enumerator of the weighted core.
2. **Extraction.** Take a core forest whose monomial has exactly one factor with index outside supp(W).
   - By atomicity, each factor with index in supp(W) comes from a singleton component, and each non-singleton component gives a factor outside supp(W).
   - So the forest has exactly one non-singleton component A, and A is connected in the core.
   - Removing the singleton weights from W leaves the multiset of colours of A.
   - So X gives, for each colour multiset M with |M| ≥ 2, the number of connected core sets with colour multiset exactly M.
   - The same holds for T′, because atomicity depends only on W.

   This is a clean use of the "single non-singleton component" coefficients, in the spirit of APdMOZ Lemma 7.4.
3. **Colored lemma.** A coloured tree with at most one untagged leaf is determined by its connected-set polynomial C among all coloured trees.
   - At least one leaf is tagged.
   - The degree-2 coefficients that contain z_a give the degree of the a-vertex in R′, so it is also a leaf there.
   - The polynomial F of connected sets containing the neighbour is (C − C|_{z_a=0})/z_a − 1. Its linear term gives the neighbour's colour c.
   - Recolour the neighbour with a fresh y: C_new = C₀ − F + z_y·F/z_c. The same identity holds in R′.
   - Leaves stay tagged after the step. The only new leaf is the neighbour, which carries a fresh unique colour. So the hypothesis persists on R's side only, and nothing needs to be assumed about R′.
   - Reattach the leaf and restore the colour.

   This matches the Lean chain: `peel_coloredSets_of_sameCSF` → `peel_step` / `atMostOne_after_deletion` → `colored_tree_reconstruction` → `reattach_tagged_leaf` → `expand_weighted_core_iso`.

Brute-force checks:
- **Colored lemma (`colored_lemma.py`).** I tested all vertex-coloured trees with m ≤ 8 vertices and at most 3 colours (58,596 trees at m = 8). No C-class that contains a tree satisfying the hypothesis contains a second tree. C-collisions do occur at m = 7 and 8, but only among trees with two or more untagged leaves, which shows the hypothesis is doing real work. An earlier run reported false collisions; they came from a bug in my canonical form for bicentral trees, which I fixed and re-ran.
- **Tree collisions (`peel_trees.py`).** For n ≤ 20, no Peel member shares its U-polynomial (equivalent to X) with any other proper tree of the same weight multiset. For n ≤ 14, all trees have pairwise distinct U, a full comparison with no assumption about W. (This is consistent with Heil–Ji.)

## C. Plumbing

- I grepped `formal/Stanley/*.lean` and `Stanley.lean` for `sorry|admit|axiom|native_decide|bv_decide|implemented_by|extern|unsafe|opaque|csimp|run_cmd|#eval|import Lean|debug.|set_option`. Nothing was found. `verify.py` applies a similar regex to each of the 31 modules before building.
- `CheckPeel.lean` is `theorem check_peelingReconstruction : PeelingReconstruction := peelingReconstruction` in `StanleyContinuation`.
  - `PeelingReconstruction` is defined only in `ChallengePeel.lean`.
  - `SameCSF`, `core` and `coreWeight` are defined only in `ChallengeA.lean`.
- The package entry `package/Stanley.lean` is `import Stanley.CheckPeel`. The repo's `formal/Stanley.lean` still imports `CheckAnchor`, as the handoff discloses.
- The import closure has 31 modules. They include the shared `Anchor*` and `Star*` infrastructure, which is part of the closure and was hash-bound.
- Both receipts report:
  - `pass: true`;
  - 65 commands, all with exit 0;
  - all 31 `leanchecker` replays with empty logs;
  - Lean 4.34.1;
  - Mathlib `d13f23b7…`;
  - `no_prior_local_oleans: true`;
  - 92 audited declarations, each with axioms a subset of {propext, Classical.choice, Quot.sound}.
- The raw `axioms.log` shows `check_peelingReconstruction` and `peelingReconstruction` depending on `[propext, Classical.choice, Quot.sound]`.
- The 31 olean hashes are identical in root1 and root2.
- The runs were serial on slot A (05:11:58 to 05:20:33 and 05:20:33 to 05:27:37), and both releases are logged.
- As for the anchor result, both roots symlink the same pinned Mathlib cache. The handoff discloses this and it is acceptable.

## D. Priority

**Sources read for this review:**
- Local full texts: GOT 2404.06002 (Thm 4.15, Cor 4.20, Cor 5.15, Thms 5.20 and 5.27), the FPSAC version 2507.15986, Zeng 2608.18179 (Thm 1.1), Awan 2609.13464v2 (Thms 1 and 2), Orellana–Tomba 2611.18940 (Prop 3.8, Cor 4.12, Thm 5.1), Liu–Tang 2411.18972 (Thms 3.4 to 4.9), APdMOZ 2202.11787 (M- and D-polynomials, Lemma 7.4, Question 1, Cor 7.14), Loebl–Sereni 1405.4132 (Def 2.1, Thms 1 and 2, Obs 3.2), and MMW math/0609339.
- Also scanned: 1509.09210, 1702.06474, 2307.02234.

**Findings:**
- **No published or preprint statement found that contains the Peel class.** The closest criteria all require uniqueness at internal core vertices (Zeng, Awan) or all-distinct weights (GOT Cor 5.15). Peel instead requires uniqueness at the core leaves, allows internal weights to repeat freely, and adds atomicity.
  - Peel ∩ Zeng is only the all-distinct class.
  - Diameter ≤ 5 (GOT, APdMOZ Cor 7.14), caterpillars (Loebl–Sereni Thm 2), spiders and 2-spiders do not contain the 178-vertex, 30-vertex or 36-vertex witnesses.
  - Loebl–Sereni Thm 1 needs weight 1 at leaves and leaf-neighbours, so it does not apply to weighted cores.
  - APdMOZ Question 1 (whether the M-polynomial distinguishes weighted trees) is open there. Peel answers a special case for the weaker W-type data under atomic weights. That is a point worth citing, not a conflict.
  - Orellana–Tomba reduce the full conjecture to uniform-weight proper trees. Those violate clause 4 whenever the core has at least 3 leaves.
- **Public AI drafts:**
  - 1337isnot1337/solved-conjectures: main at #985 / `c2b08e66`, research branch at `192d2d23` (05:54:17Z). Every Stanley file there was read:
    - long subdivisions (#972) and independent hub subdivisions (#985) need degree-2 chains, and the witnesses have no degree-2 vertex;
    - balanced-edge (#977): the witnesses have no balanced edge;
    - leaf-rich centroid (#977), p ≥ b − 1: at n = 178, p = 9 and b = 86; at n = 30, p = 4 and b = 10;
    - repeated and two identical branches at a hub (#972): fails, because every core vertex has a pendant leaf;
    - centroid-branch truncation (research CENTROID.md): not a proper-weight criterion, and it does not cover the class;
    - the research README proper-tree criterion (each edge-type class pairwise incident, with distinct class sizes): at n = 178 the {10,10} class has 7 edges that are not pairwise incident, so it fails.

    #977 does cover the Hub freeze, as already recorded, but not Peel.
  - Aurantium-47 PR #5: last commit 2026-11-22T06:21Z, unchanged since. Its criteria fail on the witnesses:
    - independent repeated vertices: fails;
    - adjacent pairs and same-colour edge: fail;
    - ANCHORED-THREE: the repeated internal vertices have no unique-weight neighbour;
    - MATCHED-THREE: 8 repeated versus 7 unique vertices, so no saturating matching.
- **The mechanism.** These ingredients are known:
  - the W-polynomial or weighted core inside X (APdMOZ Cor 5.11, OT Prop 3.8);
  - the coefficients with one non-singleton component (APdMOZ Lemma 7.4);
  - the uncoloured subtree polynomial (MMW).

  I found no statement of the coloured peeling lemma, the one-untagged-leaf reconstruction from colour-multiset connected-set counts. The nearest work is Dailly–Lehtilä arXiv:2504.00169, which reconstructs labellings of a *known* graph from connected-subgraph label compositions, and Guillemot–Sikora 1002.1880, which counts coloured subtrees algorithmically. Neither is the same problem. The lemma is elementary, and a referee may consider it folklore.

**Query log (UTC 2026-11-27, about 05:50 to 06:00).**

Successes:
1. arXiv API, `abs:"chromatic symmetric" AND abs:tree*` sorted by date (40 results). The newest relevant item is 2611.18940 (2026-11-13); nothing newer is about distinguishing trees.
2. arXiv API: `"tree isomorphism conjecture"`, `"W-polynomial" AND weighted`, `"subtree polynomial"`, `"proper trees" AND chromatic`, `"distinguishes trees"`, `"U-polynomial" AND tree*`. No new relevant item.
3. WebSearch (extended): proper trees, weighted core, repeated weights, leaves unique, 2026. Found only Zeng, Awan, OT and APdMOZ.
4. WebSearch: coloured-tree reconstruction from coloured connected-subtree counts. Found 2504.00169 (abstract read through WebFetch: the graph is known) and 1002.1880.
5. `gh pr list` for 1337isnot1337/solved-conjectures (last 40 PRs, up to #988). Read the trees of main and of the research branch, and fetched all 7 main Stanley docs and 3 research docs.
6. Issue #315: last comment 05:01:12Z, about #985.
7. Aurantium-47 PR #5 metadata and last commit.
8. `gh search repos "chromatic symmetric"` sorted by update: nothing after 2026-09-10.

Failures (none counts as evidence of absence):
- F1. arXiv `abs:"vertex-colored tree*" AND abs:reconstruct*`: 0 entries.
- F2. `gh search issues "Stanley tree isomorphism chromatic"`: [].
- F3. `gh search code "connected subsets" --repo 1337isnot1337/solved-conjectures`: [] (likely not indexed). The direct file reads in item 5 are the evidence used instead.
- F4. Not fetched this session: Heil–Ji full text (I relied on the local `literature/heil-ji-published.txt`, as the anchor review did), Crew–Spirkl, and APCSZ.

## Verdicts

**Review verdict: PASS.**
- The frozen statement faithfully encodes "X_H = X_T ⇒ H ≅ T" for the stated class: X is not weakened, the conclusion is about whole trees, and H is arbitrary.
- The class is non-vacuous and infinite, and it allows arbitrary core shapes.
- The proof is sound, and brute-force checks agree with it.
- The Lean artefacts and receipts are clean and mutually consistent.

Non-blocking wording fixes for any write-up:
- (i) Every member with at most 29 vertices is computationally covered (Heil–Ji). The smallest member outside Zeng and A has 18 vertices. Witnesses outside every checked criterion exist at 30 and 36 vertices.
- (ii) The class has at most about √(2n) core leaves. This is better than A's O(log n), but it is still a thin class.
- (iii) Peel ∩ Zeng is exactly the all-distinct-weights class. Peel and A are incomparable (56-vertex example).
- (iv) The general binary family and its size formula are hand derivations plus Python checks, not Lean. Only the class-level theorem is Lean-verified.
- (v) Cite APdMOZ (Cor 5.11, Lemma 7.4, Question 1), OT Prop 3.8, GOT Thm 4.15 and Cor 4.20, Zeng and Awan. Avoid the word "first".

**Priority verdict: NOT FOUND.**
- No prior statement found of the Peel class or of any superclass: no published paper, no preprint, and nothing in the public AI drafts (solved-conjectures #972, #977 and #985 plus its research branch to `192d2d23`, and Aurantium #5).
- The ingredients are known, and the coloured peeling lemma is elementary. Present the result as a modest new sufficient condition with a full Lean proof of X defined via colourings.
- The search is bounded (see failures F1–F4). Re-check solved-conjectures, which is merging Stanley results hourly, right before any release.
