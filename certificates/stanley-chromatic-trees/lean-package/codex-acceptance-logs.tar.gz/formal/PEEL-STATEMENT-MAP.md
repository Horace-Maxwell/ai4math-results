# 剥离树族 B 的冻结陈述对照

对两棵任意有限无根简单树 G、H，普通染色对称函数相同。如果 G 的非叶核心至少两点，每个核心点都邻接原树的叶，任一单点权均不等于两个以上不同核心点的权重和，且至多一片核心叶的权重在整个核心中重复，那么 G 与 H 同构。点权等于 1 加该点邻接的原树叶数。H 只需是树。定理允许相邻的核心内点同权，也允许同一权重出现任意多次。[冻结声明](Stanley/ChallengePeel.lean) · [书面定理](../positive-a/LEAF-PEELING.md) · [冻结绑定](FREEZE-Peel.json)

| 陈述中的对象或推论 | Lean 对应与核对要点 |
| --- | --- |
| 普通染色对称函数 | [SameCSF](Stanley/ChallengeA.lean) 枚举所有有限色板，对每个有序颜色类大小向量计数合法染色。没有给根、标记或比较树上的权重对应。 |
| 核心、点权、未带唯一色的核心叶 | [PeelingWeights](Stanley/ChallengePeel.lean) 只约束 G。重复性在整个核心上判断。核心度一与存在唯一邻点的等价见 [core_terminal_iff_count](Stanley/AnchorTerminals.lean)。 |
| 从普通 X 取得逐个多重集的计数 | [peel_coloredSets_of_sameCSF](Stanley/PeelInventory.lean) 得到两棵核心中每个给定颜色多重集的连通子集数量相同。同权点的重数保留。 |
| 识别并剥离 | [peel_step](Stanley/PeelRetag.lean) 仅要求第一树指定一片唯一色叶。该色从两棵缩小后的树中消失，故可用它重标各自的邻点。 |
| 归纳条件持续成立 | [atMostOne_after_deletion](Stanley/PeelLeaves.lean) 把缩小后的每个重复色叶映回原来的重复色叶。邻点有唯一色，其他点至多失去重色竞争者。 |
| 在全体比对树中构造同构 | [colored_tree_reconstruction](Stanley/PeelInduction.lean) 对第一棵树的点数强归纳。单点情形由各色出现次数给出保色双射。有至少两点就有两片不同的叶，故至少一片可剥。 |
| 接回两层叶 | [reattach_tagged_leaf](Stanley/PeelReattach.lean) 用移到邻点的标签识别接回位置，恢复邻点旧色和原叶。最后 [expand_weighted_core_iso](Stanley/ExpandCore.lean) 将保权核心同构扩展到原树所有顶点。 |
| 冻结目标 | [peelingReconstruction](Stanley/PeelProof.lean) 直接证明 `PeelingReconstruction`。[CheckPeel](Stanley/CheckPeel.lean) 在独立模块中再次用原类型检查结论。 |

## 恰有一片核心叶使用重复权重的例子

取高度 h≥3 的满二叉核心，令 ℓ=2ʰ、b=ℓ+2。给所有内点和一片指定核心叶权重 b，其余 ℓ−1 片核心叶分别取 b+1,…,b+ℓ−1。每个核心点 v 接入 w(v)−1 片普通叶。由构造恢复的核心正是原满二叉树。所有点权位于 [b,2b)，恰有一片核心叶的权重重复，故满足冻结假设。其阶为 (2ℓ−1)b+ℓ(ℓ−1)/2，核心叶数随原树阶数的平方根增长。原锚点判据 A 要求每片核心叶均有唯一权重，不能处理这个例族。

在 h=3 时，原树有 178 点、177 条边、直径 8。核心有 15 点，权重 10 出现八次，其中仅一个是核心叶，其余叶权分别为 11 至 17。独立小程序从原图邻接表重新计算核心、连接性和直径，并检查全部 32,768 个核心子集。上述一般构造是手工推导，特例检查由 Python 完成。冻结的树族识别结论由 Lean 证明。[特例程序](../positive-a/peeling-witness.py) · [实算结果](../positive-a/peeling-witness.json)
