"""Verify both roots' source, command logs, axiom reports and module digests."""
import hashlib,json,re,subprocess
from pathlib import Path

p=Path(__file__).resolve().parent
formal=p.parents[1]
def digest(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()
def audit(path):
    r=json.loads((path/'receipt.json').read_text())
    mods=r['modules']
    assert r['pass'] and len(mods)==len(set(mods))==27 and len(r['commands'])==57
    assert r['no_prior_local_oleans'] and not any((path/'Stanley').glob('*.olean'))
    assert (path/'release.log').read_text().strip()=='released '+r['slot']
    sequence=['dependency-cache',*('build-'+n for n in mods),'default-build',*('checker-'+n for n in mods),'axioms']
    assert [c['label'] for c in r['commands']]==sequence
    for c in r['commands']:
        f=path/'logs'/(c['label']+'.log')
        assert c['exit']==0 and c['sha256']==digest(f) and c['bytes']==f.stat().st_size
        if c['label'].startswith('checker-'): assert not f.stat().st_size
    for f,h in r['source'].items(): assert digest(path/f)==digest(formal/f)==h
    for n,h in r['oleans'].items(): assert digest(path/'.lake/build/lib/lean'/(n.replace('.','/')+'.olean'))==h
    assert digest(path/'Axioms.lean')==r['audit_source_sha256']
    output=(path/'logs/axioms.log').read_text()
    forms=re.findall(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|(does not depend on any axioms))",output)
    assert [n for n,_,_ in forms]==r['expected_axioms']
    assert {n:sorted(i.strip() for i in ax.split(',') if i.strip()) for n,ax,_ in forms}==r['axioms']
    assert len(r['axioms'])==86 and all(set(v)<={'propext','Classical.choice','Quot.sound'} for v in r['axioms'].values())
    assert 'StanleyContinuation.check_anchorReconstruction' in r['axioms']
    return r
a,b=[audit(p/n) for n in ['root1','root2']]
for k in ['source','oleans','expected_axioms','axioms','audit_source_sha256','modules','frozen','toolchain','mathlib_head','trusted_cache']:assert a[k]==b[k]
assert a['end']<=b['start'] and a['owner']!=b['owner']
frozen=json.loads((formal/'FREEZE-A.json').read_text())
for f,h in frozen['bindings'].items():assert digest(formal.parent/f)==h
res={'utc':subprocess.check_output(['date','-u','+%Y-%m-%dT%H:%M:%SZ'],text=True).strip(),
     'status':'FROZEN_ANCHOR_THEOREM_MACHINE_PASS_PENDING_CROSS_FAMILY_FINAL',
     'theorem_check':'StanleyContinuation.check_anchorReconstruction : StanleyContinuation.AnchorReconstruction',
     'challenge_sha256':a['source']['Stanley/ChallengeA.lean'],'frozen_record':a['frozen'],
     'per_root':{'modules':len(a['modules']),'checker_pass_with_empty_log':27,'commands':len(a['commands']),'public_theorems_audited':len(a['axioms'])},
     'matching_oleans':len(a['oleans']),'axioms_for_final':a['axioms']['StanleyContinuation.check_anchorReconstruction'],
     'root_receipts':{n:digest(p/n/'receipt.json') for n in ['root1','root2']},
     'root_releases':{n:digest(p/n/'release.log') for n in ['root1','root2']},
     'step_files':{n:digest(p/n) for n in ['verify.py','serial.sh','seal.py']}}
(p/'PAIR-PASS.json').write_text(json.dumps(res,indent=2)+'\n')
print(res['utc'],res['status'],res['per_root'],digest(p/'PAIR-PASS.json'))
