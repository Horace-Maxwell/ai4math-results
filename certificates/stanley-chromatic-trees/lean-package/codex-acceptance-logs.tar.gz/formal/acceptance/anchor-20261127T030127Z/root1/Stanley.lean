import Stanley.CheckAnchor
