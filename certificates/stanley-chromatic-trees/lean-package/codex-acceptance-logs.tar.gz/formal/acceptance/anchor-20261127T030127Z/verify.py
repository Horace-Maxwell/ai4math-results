"""Build the frozen anchor theorem in one new root and replay its full local import closure."""
import hashlib, json, os, re, resource, shutil, subprocess, sys
from pathlib import Path

run = Path(__file__).resolve().parent
formal = run.parents[1]
work = next(x for x in formal.parents if (x/'tools/leanlock.sh').exists())
bins = work/'toolchains/lean-4.34.1-darwin_aarch64/bin'
cache = work/'research-lean-v434/.lake/packages'
def utc():
    return subprocess.check_output(['date','-u','+%Y-%m-%dT%H:%M:%SZ'],text=True).strip()
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,data):
    tmp=p.with_suffix('.new')
    tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
    os.replace(tmp,p)
root=run/sys.argv[1]
root.mkdir()
(root/'logs').mkdir()
(root/'.lake').mkdir()
(root/'.lake/packages').symlink_to(cache,target_is_directory=True)
env=dict(os.environ,PATH=str(bins)+':'+os.environ['PATH'],LEAN_NUM_THREADS='1',LAKE_NO_CACHE='true',
         LEAN_ABORT_ON_PANIC='1',GIT_TERMINAL_PROMPT='0')
for key in ('LEAN_PATH','LEAN_SRC_PATH'):
    env.pop(key,None)
rec={'start':utc(),'root':root.name,'slot':sys.argv[2],'owner':sys.argv[3],
     'commands':[],'source':{},'toolchain':subprocess.check_output([str(bins/'lean'),'--version'],text=True).strip(),
     'mathlib_head':subprocess.check_output(['git','-C',str(cache/'mathlib'),'rev-parse','HEAD'],text=True).strip(),
     'trusted_cache':str(cache),'no_prior_local_oleans':True}
assert rec['mathlib_head']=='d13f23b723b8a846827a245b89c10fc7d3f11612'
ordered=[]; foreign=set(); names=[]
def copy(f):
    src=formal/f;dst=root/f;dst.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(src,dst)
    assert digest(src)==digest(dst)
    rec['source'][f]=digest(dst)
def collect(module):
    if module in ordered:return
    name=module.replace('.','/')+'.lean'
    copy(name)
    source=(root/name).read_text()
    assert not re.search(r'\b(sorry|admit|axiom|native_decide|bv_decide|implemented_by|extern|unsafe)\b|debug\.skipKernelTC|decide\s*\+native|partial\s+def',source)
    for dep in re.findall(r'^import (\S+)',source,re.M):
        if dep.split('.')[0]=='Stanley':collect(dep)
        else:foreign.add(dep)
    ordered.append(module)
    names.extend('StanleyContinuation.'+n for n in re.findall(r'^(?:@\[[^\n]+\]\s*)?(?:theorem|lemma)\s+(\w+)',source,re.M))
collect('Stanley')
for f in ['lean-toolchain','lakefile.toml','lake-manifest.json']:copy(f)
freeze=json.loads((formal/'FREEZE-A.json').read_text())
for f,dig in freeze['bindings'].items(): assert digest(formal.parent/f)==dig
assert rec['source']['Stanley/ChallengeA.lean']==freeze['bindings']['formal/Stanley/ChallengeA.lean']
assert len(set(names))==len(names) and 'StanleyContinuation.check_anchorReconstruction' in names
assert len(ordered)==27 and not list(root.glob('.lake/build/**/*.olean'))
rec.update(expected_axioms=names,modules=ordered,frozen=digest(formal/'FREEZE-A.json'))
(root/'Axioms.lean').write_text('import Stanley\n'+''.join('#print axioms '+n+'\n' for n in names))
rec['audit_source_sha256']=digest(root/'Axioms.lean')
def invoke(label,args,mode='build'):
    cmd=[str(bins/'lake'),*args]; logfile=root/'logs'/(label+'.log')
    started=utc()
    with logfile.open('wb') as out:
        proc=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=360)
    text=logfile.read_text()
    rec['commands'].append(dict(label=label,cmd=cmd,start=started,end=utc(),exit=proc.returncode,bytes=logfile.stat().st_size,sha256=digest(logfile)))
    save(root/'receipt.json',rec)
    if proc.returncode or re.search(r'(?im)\b(?:error|warning):|\b(?:sorryAx|failed to build)\b',text) or (mode=='empty' and text):
        raise RuntimeError(label+' '+text[-2000:])
    return text
try:
    invoke('dependency-cache',['--no-cache','--no-build','--wfail','build',*['+'+n for n in sorted(foreign)]])
    for n in ordered:
        invoke('build-'+n,['--no-cache','--wfail','build','+'+n])
    invoke('default-build',['--no-cache','--wfail','build'])
    for n in ordered:invoke('checker-'+n,['env','leanchecker',n],'empty')
    out=invoke('axioms',['env','lean','-j1','Axioms.lean'],'axioms')
    parsed={}
    for name,axioms,none in re.findall(r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|(does not depend on any axioms))",out):
        assert name not in parsed
        parsed[name]=sorted(x.strip() for x in axioms.split(',') if x.strip())
    assert list(parsed)==names and all(set(v)<={'Classical.choice','Quot.sound','propext'} for v in parsed.values())
    rec['axioms']=parsed
    rec['oleans']={n:digest(root/'.lake/build/lib/lean'/(n.replace('.','/')+'.olean')) for n in ordered}
    for f,h in rec['source'].items():assert digest(formal/f)==digest(root/f)==h
    rec['pass']=True
finally:
    rec['children_peak_rss_bytes']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    rec['end']=utc();save(root/'receipt.json',rec)
print(root.name,rec.get('pass'),len(ordered),len(names),rec['end'],flush=True)
