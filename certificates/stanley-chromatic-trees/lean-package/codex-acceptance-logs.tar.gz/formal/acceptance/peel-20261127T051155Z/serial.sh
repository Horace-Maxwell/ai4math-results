#!/bin/bash
set -eu
formal=$(cd ../.. && pwd)
work=$(cd "$formal/../../../../../.." && pwd)
lock="$work/tools/leanlock.sh"
for root in "$@"; do
  owner="stanley-peeling-final-$root-$$"
  end_wait=$(( $(date -u +%s) + 5400 ))
  until slot=$("$lock" acquire any "$owner" 50); do
    if [ "$(date -u +%s)" -ge "$end_wait" ]; then exit 75; fi
    sleep 150
  done
  release(){ "$lock" release "$slot" "$owner" > "$root/release.log"; }
  trap release EXIT
  python3 -B verify.py "$root" "$slot" "$owner"
  release
  trap - EXIT
done
