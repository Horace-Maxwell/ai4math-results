# Stanley 锚点树族 A · 跨族 FINAL 交接

**2026-11-27T04:11:35Z 终审收件。** Claude 非作者跨族 FINAL 为 PASS。锚点定理 A 已通过本地形式验收。[独立终审](FINAL-CLAUDE-REVIEW-ANCHOR-01.md) · [接受记录](formal/acceptance/anchor-20261127T030127Z/ACCEPTED.json) · [独立查重](PRIOR-CLAUDE-ANCHOR-01.md)。下文保留送审时的记录。

2026-11-27T03:18:13Z。本轮机器结论覆盖冻结的 `AnchorReconstruction`。先前非作者核读覆盖书面证明和挑战陈述；最终 Lean 包待 Claude 跨族独立核读。[书面证明](positive-a/ANCHOR-SPLITS.md) · [非作者初审](positive-b/REVIEW-A.md) · [非作者陈述审查](positive-b/REVIEW-CHALLENGEA.md) · [冻结记录](formal/FREEZE-A.json)

**待核命题。** 将原树的非叶顶点及其间的边称为核心，给每个核心点权重 1 加它所邻接的原树叶数。假定核心至少两点，各权重至少二，能在核心选择一组标签覆盖所有核心叶，每个标签权重全局唯一，且总权重相同的任意两个核心顶点子集包含同一批标签。则对任意有限无根树 H，普通染色对称函数相等推出原树与 H 图同构。结构条件只施加于第一棵树。[陈述对照](formal/ANCHOR-STATEMENT-MAP.md) · [主证明](formal/Stanley/AnchorProof.lean) · [类型核对](formal/Stanley/CheckAnchor.lean)

**复验。** Lean/Mathlib 4.34.1，在 Mac 上分两次独立从空根构建，仅共享钉住的 Mathlib 依赖缓存。每根 57 条命令，含 27 个自有模块的逐模块构建和内核重放、默认整包构建、86 条不同公开证明的公理审计与依赖缓存预检查。两根的 27 个 olean 逐字节一致。冻结陈述 SHA-256 为 `683c4463a7521b2536f7fcb9b92375a7e2e93f80fd4c882f6e27a32ce9876591`，总收据 SHA-256 为 `7afc6cb6194ae9df5af388dae6e44cfa1602e789c7a6127bb78fa145534cb2d4`。两次均由实际持有人释放 A 槽。[双根总收据](formal/acceptance/anchor-20261127T030127Z/PAIR-PASS.json) · [第一根](formal/acceptance/anchor-20261127T030127Z/root1/receipt.json) · [第二根](formal/acceptance/anchor-20261127T030127Z/root2/receipt.json) · [复验程序](formal/acceptance/anchor-20261127T030127Z/verify.py) · [收据核对程序](formal/acceptance/anchor-20261127T030127Z/seal.py)

核读时请尤其比对 `SameCSF` 的全部有限色板、有序颜色类大小及 H 的量词，检查标记由第一树条件通过无根切分传到比较树，以及最后的同构是否接回原树的叶。书面二进制叶权给出了无界例族，例族构造的全称版本未单独冻结或形式化。机制与已公开充分条件的覆盖比较见[本轮文献核对](literature/refresh-20261127T025810Z/JUDGMENT.md)。原 Stanley 猜想、剥离与质心叶簇主定理均保持开放，学术优先权和发布前审查待定。当前没有对外发布。
