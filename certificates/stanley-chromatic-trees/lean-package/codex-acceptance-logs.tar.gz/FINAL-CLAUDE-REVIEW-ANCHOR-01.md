# Final cross-family review: Stanley anchor theorem (`AnchorReconstruction`)

- Reviewer: Claude Opus 5.5 subagent, cross-family, non-author (the authors are OpenAI Codex sessions).
- Review UTC: 2026-11-27T04:07:51Z (`date -u`).
- Scope: frozen statement, the written proof, Lean plumbing and receipts, and significance. The full literature search is a separate task and is not done here.
- Scratch scripts (outside the repo): `<claude-scratch>/34790acf-0f2c-43bb-913c-85410423b576/scratchpad/stanley-final/{csf_encoding.py, anchor_trees.py, min_new.py, min_new_exact.py, ReviewCheck.lean}`.

## Hashes recomputed at review time

| Object | SHA-256 | Matches |
|---|---|---|
| `formal/Stanley/ChallengeA.lean` (frozen statement) | `683c4463a7521b2536f7fcb9b92375a7e2e93f80fd4c882f6e27a32ce9876591` | FREEZE-A, both receipts, PAIR-PASS |
| `formal/FREEZE-A.json` | `e32627640ccbb0097133aab53c9e078895a381e8801740f9694b5193d63a2c8b` | `frozen` field in both receipts and in PAIR-PASS |
| `acceptance/anchor-20261127T030127Z/PAIR-PASS.json` | `7afc6cb6194ae9df5af388dae6e44cfa1602e789c7a6127bb78fa145534cb2d4` | handoff |
| `root1/receipt.json` | `4a0d42553e229854726cf5957822dfe87a35b283d5fb83f0e4fa98670cd0b013` | PAIR-PASS |
| `root2/receipt.json` | `fefee791aba59028f007898b3329feb896dde97b4167babf6160dbe68102d141` | PAIR-PASS |
| `root{1,2}/release.log` | `b82fc226b5881d9420c23d192f6d05a5b4ad3b21e4ba507b27a2bc61742493e7` | PAIR-PASS |
| `verify.py` / `serial.sh` / `seal.py` | `4bd1a2d3…fce0` / `63db2774…f6ec` / `73f905d2…6da` | PAIR-PASS `step_files` |

All 5 bindings in FREEZE-A still hold. All 30 source and config hashes listed in each receipt match the current files under `formal/` and also the copies inside `root1/` and `root2/`. There are 0 mismatches.

## A. Frozen statement, line by line

**`colorCoefficient G k mult`** is the number of maps `f : Fin n → Fin k` that are proper colourings (adjacent vertices get different colours) and have exactly `mult c` vertices of colour `c` for every `c`. By definition X_G is the sum of x^κ over all proper κ : V → ℙ, so the coefficient of the monomial x_1^{α_1}⋯x_k^{α_k} counts the proper κ with |κ⁻¹(i)| = α_i. Such a κ automatically takes values in {1,…,k}. That count is exactly `colorCoefficient G k α`.

**`SameCSF`** quantifies over every `k` and every ordered vector, zeros included.
- It is not weaker than X_G = X_H. Every monomial of X has finite support, and by symmetry its coefficient equals the coefficient of the monomial whose exponents are moved onto x_1,…,x_k. So `SameCSF` fixes every coefficient.
- It is not stronger. It compares nothing except monomial coefficients.
- Different orders are excluded. If n ≠ m, take k = n with all multiplicities 1: G gives n! and H gives 0. The project proves this as `sameOrder_of_sameCSF`, and it matches the degree of X.

I checked this numerically (`csf_encoding.py`). On every graph with at most 5 vertices (52 graphs), the `SameCSF` tables (all k ≤ n, all compositions) split the graphs into exactly the same classes as X computed from Stanley's power-sum expansion. They agree on every pair. In particular Stanley's 5-vertex non-isomorphic pair with equal X is correctly `SameCSF`. So the encoding is equivalent to X_G = X_H, neither weaker nor stronger.

**Tree data.** `neighbors` is the set of adjacent vertices. `core` is the set of vertices whose degree is not 1. This equals the set of non-leaves once n ≥ 3; for n ≤ 2 the definition only makes the hypothesis harder to meet. `coreWeight v` is 1 plus the number of non-core neighbours, which is 1 plus the number of adjacent leaves. This matches the informal statement.

**`DecodableLeafAnchors G`** has these parts:
- at least 2 core vertices, and every core weight is at least 2;
- there is an `A ⊆ core` whose members have weights unique within the core;
- `A` contains every vertex whose core-degree is 1, i.e. every leaf of the core tree;
- for all `P, Q ⊆ core` with equal weight sums, `a ∈ P ↔ a ∈ Q` for every `a ∈ A`.

Every clause on `A` is universal over `a ∈ A`, so the predicate holds if and only if it holds with `A` equal to the set of core leaves. I confirmed this equivalence numerically: an exhaustive search over all `A` for n ≤ 10 gives the same answer. The predicate is placed on G only. H is any tree.

**Conclusion.** `Nonempty (G ≃g H)` is a Mathlib graph isomorphism of the two whole trees, leaves included. It is not a statement about the cores.

**Quantifiers.** The statement is `∀ n m G H, G.IsTree → H.IsTree → DecodableLeafAnchors G → SameCSF G H → …`. Mathlib's `IsTree` means connected (hence nonempty) and acyclic. Nothing extra is assumed about H.

**Independent replay.** I took Lean lock slot A (`claude-stanley-final`) for about one minute and released it afterwards. I ran plain `lean`, not `lake`, on a scratch file against root1's built oleans, without writing to the repo. Results:
- `check_anchorReconstruction : AnchorReconstruction`;
- `#print axioms` gives `[propext, Classical.choice, Quot.sound]`;
- `Iff.rfl` proves `AnchorReconstruction ↔ ∀ n m G H, G.IsTree → H.IsTree → DecodableLeafAnchors G → SameCSF G H → Nonempty (G ≃g H)`, so the type is exactly the frozen one;
- `#print` shows the definitions unchanged.

**Vacuity check.** The hypothesis is satisfiable, and by infinitely many trees.
- Core K2 with weights a ≠ b (any a, b ≥ 2) gives double stars with n = a + b, already an infinite family.
- The written binary construction also works. I checked one instance against the literal Lean predicate in Python: a complete binary core of height 3, internal weights 2, leaf weights 17·2^i, n = 3839. It satisfies the predicate.
- Counts of class members by n: n=5:1, 6:1, 7:2, 8:2, 9:6, 10:3, 11:10, 12:10, 13:19, 14:14, 15:32, 16:26, 17:63, 18:39.

**How restrictive the class is.**
- Every internal vertex must carry a pendant leaf. These are "proper" trees, in the authors' term.
- The anchor weights must form a set with distinct subset sums. By Erdős–Moser this forces max weight ≳ 2^L/√L for L core leaves. So the core has only O(log n) leaves.
- If the core is a path, T is a proper caterpillar, which is already known (Aliste-Prieto–Zamora; all caterpillars by Loebl–Sereni). If the core is a star or K2, T is a spider or double star, also known.
- Members of T's diameter ≤ 5 are those whose core has diameter ≤ 3.
- I searched exhaustively over cores with up to 8 vertices (`min_new_exact.py`). The smallest member that is not a caterpillar, not a spider and has diameter ≥ 6 has **33 vertices**. Its core is a 6-vertex spider with legs (2,2,1); internal weights are 2, 2, 2 and terminal weights are 3, 8, 16. It passes the literal predicate.
- Consequence: every member with at most 29 vertices is already covered by the Heil–Ji computation. New content starts above 29 vertices, at 33 or more in the non-caterpillar, non-spider, diameter ≥ 6 sense. The project's literature folder records an unvetted clawrxiv claim of verification up to 33 vertices. If that claim is accepted, the first such member sits exactly at that bound.
- In every n ≤ 18 none of the class members falls outside caterpillar, spider or diameter ≤ 5.

The class is therefore genuinely nontrivial and infinite. Its small members are all old news.

## B. Mathematics (`positive-a/ANCHOR-SPLITS.md`)

I checked the argument step by step and found no gap.
1. U(T) is equivalent to X. This is Stanley's Theorem 2.5; for a forest, n − ℓ(λ) is the number of retained edges.
2. [x₁x_{n−1}]U counts the leaves, so k is the core order and X determines it.
3. In a singleton-free forest, every leaf edge is retained, so every component contains a core vertex. Hence there are at most k components, with equality exactly when no core edge is retained. Such a forest exists iff every weight is ≥ 2, and then it is unique and its monomial is ∏x_{w(v)}.
4. So any T′ with the same X is also proper and has the same weight multiset W, without assuming this.
5. The two-component monomials without x₁ are exactly the single core-edge cuts, recorded by their side masses. A side's mass is its vertex count, which is the sum of the weights on that side.
6. Every side of a core edge contains a core leaf, hence a mark. The marks on a side are decoded from its mass. In T′ this decoding is correct because the anchor weights occur uniquely in W and the actual side is one submultiset with that sum.
7. Orient the edges away from a fixed anchor r. The rooted descendant subtrees form a laminar family. Strict containment holds exactly when the mark sets are in strict containment, or the mark sets are equal and the mass is smaller (positivity of the weights).
8. This recovers the parent map, and each vertex weight is its record mass minus the masses of its children. Reattaching w − 1 leaves at each vertex gives the isomorphism.

In essence this is reconstructing a labelled tree from its split system (Buneman-type), with masses breaking ties along chains.

Lean follows the same route: `anchorCutProfiles_of_sameCSF` → `matching_record_order` → `reconstruct_core_adj` → `weights_of_record_sums` → `expand_weighted_core_iso`.

**Brute-force check (`anchor_trees.py`).** For every n from 4 to 18 (123,867 trees at n = 18), I enumerated all trees, evaluated the literal Lean predicate and computed U by tree DP. No class member shares U, and hence X, with another tree. As expected, all trees of these orders have distinct U.

**Minor written-text remarks (not blocking).**
- The text says the binary family has "unbounded … diameter". That is true, but non-caterpillar members must grow exponentially in the number of core leaves. It would be honest to say so.
- The statement that the minimal new member has 33 vertices should be added next to the 29-vertex bound.

## C. Plumbing

- Grep over all of `formal/Stanley/` and `Stanley.lean` for `sorry|axiom|native_decide|bv_decide|admit|implemented_by|extern|unsafe|opaque|csimp|run_cmd|#eval|import Lean|debug.` finds nothing. `verify.py` performs the same regex per module before building.
- `CheckAnchor.lean` is `theorem check_anchorReconstruction : AnchorReconstruction := anchorReconstruction`, inside `namespace StanleyContinuation`. The only definition named `AnchorReconstruction` is the one in ChallengeA. The import chain is `Stanley → CheckAnchor → AnchorProof → … → ProfileDefs → ChallengeA`.
- The Hub/Peel files in the same folder belong to other freezes. They are not in the anchor import closure, which has 27 modules, and are not in the receipts.
- Both receipts report: `pass: true`, all 57 command exits 0, toolchain 4.34.1, Mathlib `d13f23b7…`, `no_prior_local_oleans: true`, and 86 audited theorems, every one with axioms a subset of {propext, Classical.choice, Quot.sound}.
- The raw `axioms.log` line for `check_anchorReconstruction` is `[propext, Classical.choice, Quot.sound]`.
- The 27 olean hashes are identical in root1 and root2.
- One caveat: both roots symlink the same pinned Mathlib package cache, so they are not independent of that cache. This is disclosed in the handoff and is acceptable.

## D. Significance

The result is a clean, fully Lean-verified sufficient condition. It is not a breakthrough. The class is natural in the "proper tree" tradition: every internal vertex carries a pendant leaf, and the weighted core is visible in X after setting x₁ = 0, the standard Aliste-Prieto–Zamora / Loebl–Sereni reduction.

It strictly contains, in the proper setting, the core-path case (proper caterpillars) and the double-star and spider-type cores. It also reaches arbitrary core shapes, including cores of large diameter and many repeated adjacent internal weights, which per the project's notes fall outside the Zeng/Awan unique-internal-weight criteria.

The price is the very strong decodability hypothesis. The core leaves must carry distinct-subset-sum weights, so the core has O(log n) leaves, and the first new-shape members have 33 or more vertices. Compared with spiders (Martin–Morin–Wagner), all caterpillars (Loebl–Sereni), or diameter-bounded classes, this is a thin but unbounded family.

The mathematical mechanism (labelled split-system reconstruction from edge-cut masses) is standard, and the novelty claim should rest on the exact combination plus the formal proof. Whether an identical statement exists is for the literature agent to settle.

## Verdict

**PASS.** The frozen statement faithfully encodes "X_H = X_T ⇒ H ≅ T" for the stated class: no weakening of X, the whole tree with its leaves, and H arbitrary. The hypothesis is satisfiable by infinitely many trees. The proof is sound. The Lean artefacts are clean and consistent with the receipts.

Recommended, non-blocking wording fixes for any write-up:
- note that every member with at most 29 vertices is already computationally covered, and that the smallest non-caterpillar, non-spider, diameter ≥ 6 member has 33 vertices;
- note the O(log n) bound on the number of core leaves;
- do not present the binary-family claim as Lean-verified; it was never frozen or formalized, only checked by hand.
