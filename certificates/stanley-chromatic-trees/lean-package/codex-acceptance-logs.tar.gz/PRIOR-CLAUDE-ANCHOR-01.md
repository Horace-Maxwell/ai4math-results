# Prior-art check: anchor criterion for Stanley's tree isomorphism conjecture (Claude, independent pass 01)

UTC (from `date -u`): started 2026-11-27T03:56:14Z, written 2026-11-27T04:05:04Z.
Scope: literature and priority only. I did not re-check the Lean proof. Nothing else was modified, and nothing was posted or sent.

## Statement under review

T is a finite tree. Its core K is the set of non-leaf vertices. Each core vertex v gets weight w(v) = 1 + (number of leaves adjacent to v).

The hypotheses are:
- (H1) |K| >= 2.
- (H2) Every w(v) >= 2, so T is "proper": every internal vertex is adjacent to a leaf.
- (H3) There is a set A of "anchor" core vertices such that A contains every leaf of K, and each anchor's weight occurs only once among the core weights.
- (H4) Any two subsets of K with equal total weight contain the same anchors.

Conclusion: for every finite tree H, X_H = X_T implies H ≅ T.

Intermediate results:
- (I1) X determines the number of leaves.
- (I2) If T is proper, X_H = X_T gives a weight-preserving bijection between the cores.

## Verdicts per claim

| Claim | Verdict | Evidence |
|---|---|---|
| (I1) X determines #leaves | **KNOWN** | Martin–Morin–Wagner, JCTA 115 (2008) 237–253, **Proposition 2(v)**: c_{n-1}(T) = number of leaves. See also **Corollary 5** (X gives the degree sequence) and Loebl–Sereni (AIHPD 6 (2019)), §1 (the coefficient for the partition {n-1,1}). |
| (I2) T proper ⇒ H proper and the core weight multisets agree (so a weight-preserving bijection exists) | **KNOWN** | Gonzalez–Orellana–Tomba, "The chromatic symmetric function in the star-basis", Discrete Math. 349 (2026) 114691, arXiv:2404.06002: **Theorem 4.15** (leading star partition = leaf-component partition = multiset of core weights) and **Corollary 4.20** (no part 1 ⇔ proper). Restated in Orellana–Tomba arXiv:2611.18940, **Remark 3.11 and Corollary 3.13**, and in Zeng arXiv:2608.18179, **Lemma 2.2(1)**. An independent route goes through the leaf adjacency sequence: Liu–Tang arXiv:2411.18972, **Theorem 4.9**, together with Aliste-Prieto–Martin–Wagner–Zamora, Bull. LMS 56 (2024) 3452–3476 (X determines the generalized degree polynomial). The "singleton-free partitions = edge sets containing all leaf edges" idea goes back to MMW 2008, **proof of Theorem 11**. |
| Reduction "proper tree ↔ vertex-weighted core" (relevant to your sub-question) | **KNOWN** | Aliste-Prieto–de Mier–Orellana–Zamora, SIAM J. Discrete Math. 37 (2023) 1881–1919, arXiv:2202.11787: **Theorem 5.10, Corollary 5.11** (X_G is computed from the weighted core via the D-polynomial), and **§7**, which states that distinguishing trees by X is equivalent to distinguishing weighted trees without absorbable vertices by D. Orellana–Tomba 2611.18940, **Proposition 3.8**: for proper T the expansion has no cancellation, and its 1-free part counts core edge subsets by component-weight multisets, i.e. it is the Noble–Welsh W / Crew–Spirkl weighted X of the core. Aliste-Prieto–Zamora, Discrete Math. 315 (2014) 158–164, use the same reduction for proper caterpillars. |
| Main theorem (anchor class) | **NOT FOUND** as a statement or as a special case of a published or preprint theorem (details below). | — |
| Main theorem, as a consequence of known ingredients | **IMPLIED BY known ingredients plus a short standard argument, not by any single cited theorem** | (a) GOT Thm 4.15 and Cor 4.20 give properness and the core weight multiset for H. (b) Stanley's power-sum expansion (Adv. Math. 111 (1995), **Thm 2.5**): the coefficient of p_(a,b) counts the edges e with T−e having component orders {a,b}. For a core edge these orders are the total weights of the two sides. This is the "D(T)" data of Loebl–Sereni §1. (c) Under (H4), each side weight decodes to the set of anchors on that side. The hypotheses transfer to H because they depend only on the weight multiset. Every side of every core edge of T contains an anchor, so the same holds for H, which forces H's core leaves to be anchors. (d) A tree with labelled leaves is determined by its leaf-split system (Buneman 1971; Semple–Steel, *Phylogenetics* (2003), Splits-Equivalence Theorem 3.1.4). This citation is **from memory and was not fetched this session**. Degree-2 chains in the core are ordered by their side weights. An expert would probably see this as a short corollary rather than a hard theorem. |

## Comparison with known and claimed classes

The criteria closest in spirit all ask for uniqueness at *internal* core vertices. The anchor criterion asks for uniqueness at core *leaves* and lets internal weights repeat.

- **Zeng, arXiv:2608.18179 (2026-08-18), Theorem 1.1 / Definition 2.1** ("multiplicity-isolated"): every core vertex of core-degree >= 2 has a unique weight, and core leaves may repeat. This is complementary to the anchor class. Neither contains the other. If the internal weights are all distinct, Zeng already covers the tree, so the anchor class is new **only when some internal core weight repeats**.
- **Awan, arXiv:2609.13464v2 (2026-10-29), Theorem 1**: the same multiplicity-isolated hypothesis, using Φ = ∂X/∂p1 at p1 = 0, among proper trees. Theorem 2 gives a uniform-leaf-extension equivalence. It does not cover the anchor class. Awan also has a Lean development (github.com/sawan201/First-Derivative-CSF-Reconstruction-for-Proper-Trees). It defines X through Stanley's power-sum expansion, not through colorings.
- **GOT 2404.06002, Corollary 5.15**: proper trees whose core weights are all distinct. **Theorems 5.20 and 5.27** with the FPSAC version (arXiv:2507.15986, Thm 5.9): all trees of diameter <= 5. APdMOZ **Corollary 7.14**: proper trees of diameter <= 5.
- **MMW 2008, Theorem 11** (proper caterpillars with distinct leaf numbers); **APZ 2014** (all proper caterpillars); **Loebl–Sereni 2019, Theorem 2** (all caterpillars). LS **Theorem 1** covers "good" weighted families, but **Definition 2.1(2)** requires weight 1 at leaves and leaf-neighbours. Weighted cores have all weights >= 2, so LS Theorem 1 never applies to a weighted core with >= 2 vertices.
- Other covered classes: spiders (MMW Thm 8/9); 2-spiders (Huryn, Involve 13 (2020) 109–116); trees with exactly two vertices of degree >= 3 (Wang–Yu–Zhang, Discrete Math. 347 (2024) 114096); proper q-caterpillars (Arunkumar–Narayanan–Rao–Sawant, Discrete Math. 347 (2024) 114162); Crew, Discrete Math. 345 (2022) 112682 (the T° size and the incident path lengths); Gerling arXiv:1702.06474 (leaf-decomposition inequalities); Aliste-Prieto–de Mier–Zamora arXiv:1509.09210 (a PTE-related class). None of these contains the anchor class, and their hypotheses are of a different kind.
- **Orellana–Tomba, arXiv:2611.18940 (2026-11-13)**: X distinguishes all trees if and only if it distinguishes k-weighted proper trees (all core weights equal), for any fixed k >= 2. Uniform weights violate (H3), so the anchor class is disjoint from that reduction class. Consequence: proper trees are not an "easier" subproblem in general, and a positive result has value roughly in proportion to how much it allows *repeated* weights. The anchor class allows repeated internal weights only.
- **Heil–Ji, Australas. J. Combin. 75(2) (2019) 210–222, Theorem 4.5**: all trees with <= 29 vertices. Members of the anchor class with repeated internal weights that lie outside the earlier classes need a core of diameter >= 4 and large anchor weights, so they mostly have far more than 29 vertices.

**AI-generated working notes (priority-relevant, not peer-reviewed).** Aurantium-47 has a GitHub PR, pinned in `literature/refresh-20261127T025810Z/pinned-working-notes/Aurantium-47/`. Its criteria:
- ADDENDUM-VI: repeated-weight vertices form an independent set.
- ADJACENT-PAIRS: repeated-repeated edges only between the two copies of a multiplicity-2 weight.
- SAME-COLOR-EDGE: each repeated weight pair on <= 1 edge.
- ANCHORED-THREE: each repeated-weight vertex has an a-private unique neighbour, plus a subset-sum isolation condition.
- MATCHED-THREE: a saturating matching from each repeated class into the unique vertices, plus distinct sums for submultisets of size <= 4.
- README / ADDENDUM-III: exactly one repeated pair.

ANCHORED-THREE and MATCHED-THREE use a similar arithmetic "distinct subset sums" device, so the *style* of the anchor hypothesis has close informal precedent. None of these criteria covers the test family below.

AnctyEnly453/tree-csf-research (2026-09-10) and the vibemathing repo contain conditional cut and branch results. I saw no anchor or leaf-split criterion in the README or RESEARCH_INDEX, but code search on that repo returned nothing (probably not indexed), so this is not conclusive.

**Test family showing strict extension.** Take as core a spider: a centre c with three arms c–x_i–a_i. Weights: w(c) = w(x_i) = 2, and anchor weights 9, 18, 36. The internal sum is 8 < 9, and the anchor weights are powers of 2 times 9, so (H4) holds. Then:
- T has 71 vertices and diameter 6.
- Repeated weight 2 appears on 4 internal, mutually adjacent vertices, and c has no unique-weight neighbour.

It is therefore outside Zeng, Awan, GOT Cor 5.15, diameter <= 5, caterpillars, 2-spiders, WYZ, q-caterpillars, and all of the Aurantium criteria listed above. The full binary core with internal weights all 2 (from the earlier JUDGMENT) is another example.

## How natural and how large is the class

- **Breadth in shape.** Every finite tree C with >= 2 vertices is the core of some member, and the internal weights can be arbitrary. For example, with s = sum of internal weights, take anchor weights (s+1)·2^(i−1). In this respect it is as broad as Zeng's or GOT's distinct-weights class.
- **Thinness in size.** (H3)+(H4) force the anchors to have distinct, well-separated subset sums. So n >= about 2^(#core leaves), which means at most about log2 n core leaves. Proper trees are already an exponentially small fraction of all trees, and this is a sparse subfamily of them.
- **Naturalness.** (H4) is an arithmetic encoding device: weights act as labels that can be read off subset sums. Combinatorialists will see it as a technical condition, not a structural class. The proof uses only properness, the core weight multiset, and single-edge cut sizes. That is weak data, so the theorem says little about the hard cases (repeated weights at leaves of the core, or uniform weights, which Orellana–Tomba show are as hard as the full conjecture).
- **Overall.** The statement appears to be new: no prior statement found, and it strictly extends known classes in the repeated-internal-weight direction. But it is modest, and a referee may call it an easy corollary of GOT + Stanley's expansion + the splits-equivalence theorem. Any write-up should cite all three explicitly, avoid the word "first", and present the Lean verification (of X defined by colorings) as the main contribution beyond the mathematics.

## Query log (UTC 2026-11-27, ~03:56–04:05)

Successes:
1. Read the local notes: `literature/refresh-20261127T025810Z/JUDGMENT.md`, `final-search.json`, `queries.json`, `ANCHOR-FINAL-HANDOFF.md`, `STATUS.md` (head), `literature/heil-ji-published.txt` (Thm 4.5 context), and the pinned Aurantium-47 notes (grep of all theorem statements).
2. arXiv PDFs fetched and read (pdftotext): 2507.15986, 2608.18179, 2609.13464v2, 2611.18940, 2404.06002v2, 2202.11787, 1405.4132 (Loebl–Sereni), math/0609339v3 (MMW), 1702.06474, 2411.18972, 1509.09210, 2307.02234.
3. arXiv API search `abs:chromatic AND abs:symmetric AND abs:trees`, sorted by date, 80 results. Newest relevant item: 2611.18940. Nothing after 2026-11-13 on tree distinguishing.
4. arXiv API `id_list` metadata for 13 related papers (second try).
5. WebSearch: Loebl–Sereni abstract; MMW results; "chromatic symmetric function trees arXiv 2026 proper tree weighted core reconstruction" (extended). Found only Zeng, Awan, Orellana–Tomba, APdMOZ, GOT.
6. Semantic Scholar citations of 2608.18179 (only Awan cites it), 2609.13464 (only Orellana–Tomba), 2404.06002 and 2202.11787. No further reconstruction papers.
7. scite `search_literature`, "chromatic symmetric function trees distinguish proper weighted core" (2019+, 20 hits). Nothing new.
8. GitHub `gh search repos "chromatic symmetric"` / `"chromatic-symmetric"` found VietaFan/CSFTreeConjecture, vibemathing problem-um-opg-36880, AnctyEnly453/tree-csf-research and others. File trees listed for those two and for sawan201 (Awan's Lean).
9. google-deepmind/formal-conjectures: listed the full tree (2,288 files). No chromatic-symmetric or Stanley-tree file. facebookresearch/atlas-lean has `ChromaticSymmetric.lean` with basic `SameChromaticSymmetricFunction` lemmas only, nothing on tree isomorphism. math-proof/lemma is similar.
10. Open Problem Garden: the category page led to `/op/does_the_symmetric_chromatic_function_distinguish_trees`. Status: open. It lists MMW only and was posted 2009-02-25.

Failures (logged as failures; none counts as evidence of absence):
- F1. arXiv API over `http://` returned an empty body. Retried with https and it worked.
- F2. arXiv `id_list` with a bare `0609339` gave an id-format error. Retried as `math/0609339`.
- F3. The first `gh api repos/.../git/trees/HEAD?recursive=1` attempts failed with a zsh glob error ("no matches found"). Retried quoted.
- F4. `gh search repos` returned zero results for "chromatic symmetric function lean", "Stanley tree isomorphism", "chromatic symmetric tree", "Stanley chromatic" and "proper trees chromatic".
- F5. `gh search code` in AnctyEnly453/tree-csf-research for "subset sum", "子集和", "二进制", "proper tree", "叶标签" and "锚" returned [] each time. The repo is probably not indexed, so this is not evidence.
- F6. `gh search code "chromatic symmetric" --repo google-deepmind/formal-conjectures` returned []. The file-tree listing (item 9) is the evidence used.
- F7. Open Problem Garden URLs `/op/do_any_two_non_isomorphic_trees_have_different_chromatic_symmetric_functions` and `/op/does_the_chromatic_symmetric_function_distinguish_between_trees` returned HTTP 404.
- F8. Semantic Scholar citations of 2611.18940 returned an empty list (too recent).
- F9. Not fetched: Crew–Spirkl EJC 89 (2020) and Aliste-Prieto–Crew–Spirkl–Zamora EJC 28(2) (2021) full texts (scite access restricted). They are background on vertex-weighted X and graph pairs with equal X, judged from abstracts and from how APdMOZ and OT cite them. The Semple–Steel / Buneman theorem number is quoted from memory.
