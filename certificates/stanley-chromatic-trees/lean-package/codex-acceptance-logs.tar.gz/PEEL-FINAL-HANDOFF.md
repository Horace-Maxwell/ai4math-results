# Stanley 剥离树族 B　跨模型最终核读交接

**核读目标**是 11 月 21 日冻结的 `PeelingReconstruction`。两棵树均无根，只有第一棵树需要满足核心的三个条件。若比较树的所有普通染色系数相同，结论为原树的图同构。[冻结声明](formal/Stanley/ChallengePeel.lean) · [冻结哈希与五份绑定](formal/FREEZE-Peel.json) · [书面非作者核读](positive-b/REVIEW-PEEL.md) · [陈述非作者核读](positive-b/REVIEW-CHALLENGEPEEL.md)

核读时可沿以下三处检查量词和构造。

1. 从所有有限色板的合法染色计数取得逐颜色多重集的连通子集系数。重复权重允许出现多次，比较核心的分块标签排列数已消去。[序列起点](formal/Stanley/ChallengeA.lean) · [计数等式](formal/Stanley/PeelInventory.lean)
2. 至多一片核心叶与其他核心点同色，因而当核心至少两点时至少一片叶可凭颜色识别。删除它之后，邻点有新的唯一色。任一仍重复的叶在删除前已是重复色叶，所以归纳亦适用于有一个例外的边界情形。比较树一侧的叶、邻点和原色均由相等的计数推出。[整步](formal/Stanley/PeelRetag.lean) · [归纳条件](formal/Stanley/PeelLeaves.lean)
3. 还原邻点原色，接回两侧被删的核心叶，得到保权核心同构。把每个核心点的普通叶按权重减一配对，最后得到原树的同构。[保色归纳](formal/Stanley/PeelInduction.lean) · [主证明](formal/Stanley/PeelProof.lean) · [类型核对](formal/Stanley/CheckPeel.lean)

**范围与查重。** 例族允许大块相邻内点同权，并允许一片末端取内点权。178 点的例子有八个权重为 10 的核心点，其中一片是核心叶。其结构假设已在独立邻接表脚本中复算，一般例族的构造仍属书面推导。请单独判断剥离准则和逐色连通子集的归纳机制在树重构、加权树与带色子树文献中的优先权。GOT 的叶分量权重和已有 proper 树还原结果均有明确先例。质心路线另有更强的公开结果。[陈述对照与构造](formal/PEEL-STATEMENT-MAP.md) · [本轮公开稿核查](literature/refresh-20261127T050936Z/JUDGMENT.md)

**机器验证于 2026-11-27T05:27:37Z 完成。** 两个独立的空目录仅共享固定的 Mathlib 缓存，各完成 31 模块构建、默认整包构建、31 次零输出内核重放，以及 92 条公开声明的公理审计。31 个 olean 文件、声明清单与公理逐条一致。核对目标只使用 `propext`、`Classical.choice`、`Quot.sound`。两次均由持有者释放 A 槽。B 的独立包入口导入 `Stanley.CheckPeel`，保留了此前 A 的原始验收入口。总收据 SHA-256 为 `ebfb1021b83f85f2dd6536ce7edee66da311d85c672a8c1e02f7b9fa8b864549`。[汇总](formal/acceptance/peel-20261127T051155Z/PAIR-PASS.json) · [第一根](formal/acceptance/peel-20261127T051155Z/root1/receipt.json) · [第二根](formal/acceptance/peel-20261127T051155Z/root2/receipt.json) · [构建与内核重放程序](formal/acceptance/peel-20261127T051155Z/verify.py) · [收据核对程序](formal/acceptance/peel-20261127T051155Z/seal.py)

本交接供另一模型核对冻结条件、证明覆盖和验收记录。此前的书面非作者审查与冻结陈述审查已有记录，本轮尚无新的跨模型 FINAL 或优先权结论。
