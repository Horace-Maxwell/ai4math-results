"""Check paper's A and B inversions on independent weighted-cut / connected-set enumerations."""
from collections import Counter
from itertools import combinations
import json,random,subprocess
def components(n, edges):
    nbr=[[] for _ in range(n)]
    for u,v in edges:nbr[u].append(v);nbr[v].append(u)
    done=set();result=[]
    for i in range(n):
        if i in done:continue
        stack=[i];done.add(i);c=[]
        while stack:
            v=stack.pop();c.append(v)
            for u in nbr[v]:
                if u not in done:stack.append(u);done.add(u)
        result.append(c)
    return result

def weighted_profiles(w,edges):
    n=len(w);out=Counter()
    for mask in range(1<<len(edges)):
        c=components(n,[e for j,e in enumerate(edges) if mask>>j&1]);out[tuple(sorted(sum(w[i] for i in s) for s in c))]+=1
    return out

def canon(w,edges):
    def root(v,parent):
        sub=sorted(root(u,v) for a,b in edges for u in ([b] if a==v else ([a] if b==v else [])) if u!=parent)
        return (w[v],tuple(sub))
    return min(root(i,-1) for i in range(len(w)))

def reconstruct_split(w,L,parts):
    n=len(w);root=min(L); decode={}
    for mask in range(1<<n):
        weights=[w[i] for i in range(n) if mask>>i&1];s=sum(weights);a=frozenset(L.intersection(weights))
        assert decode.setdefault(s,a)==a
    records=[(frozenset(L),sum(w))]
    for pair,c in parts.items():
        if len(pair)!=2:continue
        for mass in pair:
            if root not in decode[mass]:
                assert decode[mass] and c==1;records.append((decode[mass],mass))
    assert len(records)==n
    def below(i,j):
        a,m=records[i];b,q=records[j]
        return a<b or (a==b and m<q)
    edges=[];weights=[mass for _,mass in records]
    for i in range(1,n):
        up=[j for j in range(n) if below(i,j)];parent=min(up,key=lambda j:records[j][1]);edges.append((parent,i));weights[parent]-=records[i][1]
    return weights,edges

def connected_polynomial(w,edges):
    n=len(w);out=Counter()
    for mask in range(1,1<<n):
        vertices=[v for v in range(n) if mask>>v&1]
        if sum(1 for i,j in edges if mask>>i&1 and mask>>j&1)==len(vertices)-1:
            out[tuple(sorted(w[i] for i in vertices))]+=1
    return out

def extract(w,parts):
    out=Counter((v,) for v in w);counts=Counter(w)
    for mon,c in parts.items():
        single=Counter(v for v in mon if v in counts)
        if len(mon)-single.total()==1:
            rem=counts-single;assert rem.total()>=2;out[tuple(sorted(rem.elements()))]+=c
    return out

def peel(poly):
    atoms=Counter({m[0]:v for m,v in poly.items() if len(m)==1})
    if atoms.total()==1:return list(atoms),[]
    a=next(c for c,t in atoms.items() if t==1 and sum(k for m,k in poly.items() if c in m and len(m)==2)==1)
    c0=Counter();fiber=Counter()
    for m,count in poly.items():
        if a not in m:c0[m]+=count;continue
        if len(m)==1:continue
        s=list(m);s.remove(a);fiber[tuple(s)]+=count
    c=next(m[0] for m in fiber if len(m)==1)
    fresh=max(atoms)+1;new=c0.copy()
    for m,t in fiber.items():
        new[m]-=t; z=list(m);z.remove(c);z.append(fresh);new[tuple(sorted(z))]+=t
    assert min(new.values())>=0
    ww,ee=peel(+new);idx=ww.index(fresh);ww[idx]=c;ee.append((idx,len(ww)));ww.append(a);return ww,ee

def main():
    rng=random.Random(756241)
    cases_a=cases_b=0;size_a=[];size_b=[]
    for n in range(5,12):
        for _ in range(12):
            edges=[(v,rng.randrange(v)) for v in range(1,n)]
            degrees=Counter(i for e in edges for i in e);leaves=[v for v in range(n) if degrees[v]==1]
            wa=[rng.randint(2,5) for v in range(n)]
            B=2+sum(wa);marks=set()
            for j,v in enumerate(leaves):wa[v]=B<<j;marks.add(wa[v])
            assert canon(*reconstruct_split(wa,marks,weighted_profiles(wa,edges)))==canon(wa,edges)
            cases_a+=1;size_a.append(sum(wa))
            low=n+3; wb=[low+rng.randrange(2) for v in range(n)]
            for j,v in enumerate(leaves[1:]):wb[v]=low+2+j
            rec=extract(wb,weighted_profiles(wb,edges))
            assert rec==connected_polynomial(wb,edges)
            assert canon(*peel(rec))==canon(wb,edges)
            cases_b+=1;size_b.append(sum(wb))
    print(json.dumps({'A_cases':cases_a,'A_ordinary_orders':[min(size_a),max(size_a)],'B_cases':cases_b,'B_ordinary_orders':[min(size_b),max(size_b)],'finite_scope':'implementation controls, no exhaustive original-order search','utc':subprocess.check_output(['date','-u','+%Y-%m-%dT%H:%M:%SZ'],text=True).strip()},indent=2))
if __name__=='__main__':main()
