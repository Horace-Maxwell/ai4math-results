"""Evaluate the frozen hypotheses directly on a tree with one repeated-color core leaf."""
from collections import Counter, deque
import json


def example():
    # Complete binary core of height three, with weights 10 at each internal
    # vertex and weights 10,...,17 on its eight leaves, in heap order.
    neighbors = [set() for _ in range(15)]

    def join(i, j):
        neighbors[i].add(j)
        neighbors[j].add(i)

    for child in range(1, 15):
        join((child - 1) // 2, child)
    for vertex, weight in enumerate([10] * 7 + list(range(10, 18))):
        for _ in range(weight - 1):
            neighbors.append(set())
            join(vertex, len(neighbors) - 1)
    return neighbors


def distances(graph, start):
    distance = {start: 0}
    todo = deque([start])
    while todo:
        v = todo.popleft()
        for u in graph[v]:
            if u not in distance:
                distance[u] = distance[v] + 1
                todo.append(u)
    return distance


def audit(graph):
    n = len(graph)
    edges = sum(map(len, graph)) // 2
    assert len(distances(graph, 0)) == n and edges == n - 1
    core = {v for v in range(n) if len(graph[v]) != 1}
    core_leaves = {v for v in core if len(graph[v] & core) == 1}
    weights = {v: 1 + len(graph[v] - core) for v in core}
    counts = Counter(weights.values())
    repeated = sorted(v for v in core_leaves if counts[weights[v]] > 1)
    assert len(core) >= 2 and min(weights.values()) >= 2

    # Check the full subset-sum condition on this particular core.
    totals = [0]
    for v in sorted(core):
        totals += [t + weights[v] for t in totals]
    assert not any(total in counts for mask, total in enumerate(totals) if mask.bit_count() >= 2)
    from_first = distances(graph, 0)
    far = max(from_first, key=from_first.get)
    diameter = max(distances(graph, far).values())
    assert n == 178 and diameter == 8 and len(repeated) == 1
    assert all(len(graph[v]) != 2 for v in range(n))
    return dict(order=n, edges=edges, diameter=diameter, core_order=len(core),
                core_leaves=len(core_leaves), weight_multiplicities=dict(sorted(counts.items())),
                repeated_color_core_leaves=repeated, checked_subsets=len(totals))


if __name__ == '__main__':
    print(json.dumps(audit(example()), indent=2))
