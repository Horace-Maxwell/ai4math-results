# Recovering a proper tree by transferring uniquely occurring colors one leaf at a time

## The theorem

Let T be a finite simple unrooted tree whose nonleaf core S has k≥2 vertices. At each core vertex v put the integer w(v)=1 plus its number of neighbors that are leaves of T. Assume:

1. T is proper: each w(v)≥2.
2. No value w(v) equals the sum of weights of any set of two or more distinct core vertices.
3. Of all leaves of S, at most one carries a weight occurring at least twice in S.

**Theorem B.** For every finite simple tree T′, X(T′)=X(T) implies T′≅T. Repetitions of weights inside S are unrestricted. T′ need not be assumed to satisfy any of these three conditions.

The test in condition 2 may simply be replaced by b≤w(v)<2b for an integer b≥2. Distinct weights on the leaves need not have distinct pair sums. No condition is imposed on subset sums of weights unless the sum equals a single weight. Mixed multiplicities of internal weights are allowed.

## Extracting a colored connected-set polynomial

By the inclusion–exclusion, leaf-count and no-singleton forest arguments in the first two sections of [the companion proof](ANCHOR-SPLITS.md), the ordinary X(T) determines the properness of T′, the common multiset W of weights, and the full weighted forest enumerator of each core. In detail the number of original leaves is the coefficient of the two-part type (n−1,1) in the unsigned enumerator, so the two core orders agree. In a forest without isolates one cannot cut a leaf edge. The term of largest possible length k thus exists precisely when each leaf component has size at least two, and if it exists records W. One then retains arbitrary sets of core edges.

In a weighted forest monomial, any factor with index in the support of W comes from a core singleton, and every core singleton yields such a factor. This equivalence uses condition 2, which is shared by the two cores because their weight multiset is the same. Hence we recognize the spanning forests that have exactly one nonsingleton component. Such forests are in bijection with connected vertex sets A in S of size at least two. Given A, retain precisely the edges induced by A. Conversely the component on A must contain every edge induced by A, since S is a tree and has a unique path between any two vertices. All other vertices are core singletons. In each monomial with exactly one non-atomic factor, remove from W precisely the multiset of singleton weights occurring in that monomial. The remainder is the complete multiset of colors w(v) with v in A. Thus, after adding the k singleton sets from W, we know the colored polynomial

$$C(S)=\sum_{\varnothing\ne A\subseteq V(S),\ S[A]\text{ connected}}\ \prod_{v\in A} z_{w(v)}.$$

The variables here are formal colors, indexed by single-vertex weight values. Coefficients include multiplicities. No labels for vertices with repeated weight were needed. The two cores, viewed as trees with these formal colors, have equal C.

## A reconstruction lemma with no numerical weights

A colored tree is a finite tree with a map of its vertices to an arbitrary alphabet. Isomorphisms preserve colors. Say a leaf is tagged when its color appears just once in the *whole tree*. Suppose at most one leaf of a colored tree R is untagged. Then C(R) determines R up to colored isomorphism among all colored trees.

Proof by induction on the number m of vertices. The degree-one part of C lists all color multiplicities, hence also m. For m=1 it gives the unique vertex's color. For m≥2 there are at least two leaves, so choose a tagged leaf, with color a. A competing R′ with the same polynomial has exactly one a vertex. The sum of coefficients of degree-two monomials containing z_a equals its degree: the connected two-sets are precisely the edges, and the unique a vertex cannot have an a-colored neighbor. Thus a is a leaf in R′ too.

Write R₀ for deletion of that leaf in R; this leaves a nonempty tree. Put C₀=C(R)|_(z_a=0). This equals C(R₀). Every connected subset containing a alone contributes z_a, and every larger connected set containing it consists of that leaf and a connected set of R₀ containing its sole neighbor v. Commutatively in the polynomial ring, set

$$F=(C(R)-C_0)/z_a-1.$$

This gives the full generating polynomial of connected sets of R₀ that contain v. Its degree-one term is z_c for the original color c of v, so c is also the color of the neighbor of a in R′. Take a new color y absent from both color sets, which coincide by the degree-one terms. Replace just v's color c by y in R₀. The connected-set polynomial after this change is

$$C_{\rm new}= C_0-F + z_y(F/z_c).$$

Every monomial of F contains z_c. If several vertices of that color occur, dividing by z_c removes one factor for v, as required. Hence both operations use exact polynomial division by a variable. The same expression is obtained from R′, so both recolored, pruned trees have equal polynomials.

In the pruned, recolored tree from R the property in the lemma persists. For m>2, a new leaf, if any, is the neighbor v, which now has a fresh unique color. Any surviving leaf other than v keeps its color. A color formerly unique at such a leaf cannot lose uniqueness when a is deleted and v is given a previously unused color. For m=2 the result has one vertex and the base case applies. Therefore the induction hypothesis gives a color-preserving isomorphism between the pruned, recolored trees, and it matches v to its counterpart by the new color y. Recolor that vertex back to c and reattach the a-colored leaf. This constructs the required original colored isomorphism. No condition concerning untagged leaves was assumed for R′.

Apply this lemma to the two weighted cores with weights treated as colors. The resulting isomorphism preserves weights, so attaching w(v)−1 ordinary leaves at every core vertex yields T′≅T. This proves Theorem B.

## Explicit size and distinction from known criteria

Take *any* core S with k≥2 vertices and ℓ leaves. Set b=ℓ+2. Assign each nonleaf weight b; assign distinct b+i, 1≤i≤ℓ, to the ℓ core leaves. All weights are in [b,2b); all leaves are tagged. Replacing each weight w by its vertex and w−1 ordinary pendant neighbors makes a tree of order k(ℓ+2)+ℓ(ℓ+1)/2. Thus arbitrary core topology occurs with polynomial-sized expansions. If all core vertices are leaves, the same construction works with no internal occurrences of b. An internal block may instead use any number of different repeated weights if they do not use the leaf tags and condition 2 is retained.

Full binary cores of height h≥3 have unboundedly many connected, identically weighted internal vertices. They violate the nonleaf uniqueness condition of Zeng/Awan, the independent repeated-weight condition in Aurantium's Addendum VI, and the matching of repeated vertex pairs in the adjacent-pair supplement. The general diagonal-extraction formulas for short connected configurations do not on their own state this recursive connected-subset theorem. Shape/reconstruction and multivariate-subtree literature still require a priority check; the argument above is complete as mathematics, with no claim of complete precedence clearance.

[Zeng](https://arxiv.org/abs/2608.18179) · [Awan](https://arxiv.org/abs/2609.13464) · [2026 proper-tree reduction](https://arxiv.org/abs/2611.18940) · [Aurantium evidence and updates](https://github.com/Aurantium-47/aurantium-mathematics/pull/5) · [Martin–Morin–Wagner, uncolored subtree polynomial](https://doi.org/10.1016/j.jcta.2007.05.008)
