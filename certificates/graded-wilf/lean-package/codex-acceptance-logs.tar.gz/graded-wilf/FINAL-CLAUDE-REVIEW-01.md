# Cross-family FINAL review 01: generalized Wilf conjecture for two-generated T-graded GNSs (Task P)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The frozen target `Wilf` states the source's generalized Wilf inequality e(S)·n(S) ≥ d·c(S), computed from the actual sets, for every d ≥ 1 and every coprime 2 ≤ a < b. It is fully Lean-verified: standard axioms only, and my independent rebuild and leanchecker runs pass. The MINOR items below concern attribution and scope in `MATHEMATICS.md` only. Fix them before publication. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), a subagent of the user's Claude session. I wrote none of the reviewed files.
- Review started 2026-11-20T18:28:35Z. Report written after 2026-11-20T18:34:37Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-wilf/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (byte-identical to the frozen snapshot) | b7db38db3648c24f3bbde4ddd5a453240d02ac3a7dcb77fe09870959c7ef83e6 |
| CheckWilf.lean | 622f6e202bf6a76313d602a72f1627a2bdc304c918838e99fa08c1210bdf66dd |
| Proof.lean | 0083311c5fac8eb31c53b0fbb4705f737068b249c77dd7a45675410d1830ade7 |
| WilfScalar.lean | 67841e60cfaa7e2da326f0d949db10a26c880aa85d76178363f5323357386268 |
| WilfBasis.lean | c3277cf5c0ef25d04471dbfc0826deec38f2794e47b5c8b6957582bd2f9518d1 |
| WilfLayers.lean | 55ba7c1e5018f59de8c3cb59cf62f36a2cf82904a1016a879fb928a2de73aa56 |
| WilfHigh.lean | d68876d853434b57e83082d81afc52c1b12b0b2024eb475cacd33c562af7f9b6 |
| WilfAtoms.lean | e88c99ed91e6d99eaad6640c091ec7b4adf13b8d47f8af250462c2db00c595bd |
| WilfLow.lean | b55b756a5131c23818c78e349ff8e7cb155a9941b0d118c37543399a453787dc |
| FREEZE.json | de968274070608dbf6d571fb2af67d12e56c6269a6fc99e1787a4aa67d6e0a37 |
| FREEZE-REVIEW.md | 1a6bfbb69dedc014802d3e74315eff44e3d8d1aaa809c88b9707c564a07eb6ad |
| SOURCE-CHECK.md | 9b1739f6c90418376782899722e185b4f03dd7a3d8e6cb95a52015ecc609465b |
| G2.md | 61d13e4019472424d03fa9e957b2409260d9e3e273c20aff92abcc29557cc471 |
| MATHEMATICS.md | ac6c6a2db253080e49b6c939d76e211441137f62ec192fe1d1139d4c19cd2473 |
| FINAL-HANDOFF.md | c6176b4f28a7747de3d4b2d2adb1df7fd0bd835250653fe4263116b91bbd214a |
| acceptance/2026-11-20T182129Z/receipt.json | 0c7a8ab427c236dc792ec31d3ce3f00ecfc873f57c6708f51bc4adb65637a7e9 |
| Journal PDF, An. Şt. Univ. Ovidius Constanţa 33(1) 153–175 (I downloaded it from anstuocmath.ro) | e1b5a29732bc1a9a2e7bc05c96bade160dc1521d217fc3d726ddeda6f7d55ba6 |
| arXiv 2611.20086v1 PDF (downloaded by me) | cbaec45c4bbfe3e0f34d2407bb0ec278669b981a3fc5e1621418943de6e33d0b |
| arXiv 1909.13120v1 PDF (Cisto–DiPasquale–Failla–Flores–Peterson–Utano; downloaded by me) | ba9c351633d64bd7766a42c94ff25b1ea32a3afa776aa2c08d638877a9a1fd91 |
| My Audit.lean (scratch) | 4ffdf8f5a85cbf087a04bd3d7482d45f183e23a825fc32bac4fe531030b97bd6 |

These hashes all agree with the records:
- All 9 source hashes match `receipt.json`.
- The 9 `.lean` files in the task root are byte-identical to `acceptance/.../root1` and `root2`.
- The Challenge hash matches `FREEZE.json.challenge_sha256` and the `frozen/` snapshot.
- The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`.
- The receipt hash matches FINAL-HANDOFF.

## 1. Is the statement faithful to the source?

**Source identity.** Crossref for DOI 10.2478/auom-2025-0008 gives:
- Carmelo Cisto, Francesco Navarra, "On some classes of generalized numerical semigroups";
- An. Ştiinţ. Univ. "Ovidius" Constanţa, Ser. Mat., 33(1), 2025.

The PDF header reads pp. 153–175. Crossref gives 153–176, which does not matter.

The conjecture comes from Cisto, DiPasquale, Failla, Flores, Peterson, Utano, "A generalization of Wilf's conjecture for generalized numerical semigroups", Semigroup Forum 101 (2020) 303–325, arXiv:1909.13120. Its intro states: "If S ⊂ N^d is a GNS then e(S)n(S) ≥ dc(S)". It uses the same n and c as below.

I extracted the text of all three PDFs myself and checked each piece of the statement:

- **Invariants (journal §2, p.156; same in 1909.13120 and in 2611.20086 Conj. 5.1).**
  - N(S) = {s ∈ S | s ≤ h for some h ∈ H(S)}, and c(S) = |{n ∈ N^d | n ≤ h for some h ∈ H(S)}|.
  - ≤ is the natural partial order on N^d: y − x ∈ N^d.
  - e(S) = |G(S)|, where G(S) is the unique minimal system of generators.
  - Conjecture 2.1 reads e(S) n(S) ≥ d c(S), "or equivalently" (e(S) − d) n(S) ≥ d g(S). The two forms agree because c = n + g.
- **Point and order.** Lean has `Point d = Fin d → ℕ`, so ℕ includes 0. The relation `x ≤ h` is Mathlib's Pi order, which is coordinatewise. My Audit checks by `Iff.rfl` that the target unfolds with `∀ i, x i ≤ h i`.
- **The semigroup S.** Lean's `graded a b d` is {x | Σ x_i ∈ AddSubmonoid.closure {a,b}}. This is Definition 4.1 (p.164) with T = ⟨a,b⟩.
- **C and N.** `belowGaps S` = {x | ∃ h ∉ S, x ≤ h} is exactly the set counted by c(S), with gaps taken as the true complement in N^d. `C ∩ S` is exactly N(S).
- **Embedding dimension.** `atoms S` is the set of nonzero x ∈ S such that every decomposition x = y + z with y, z ∈ S has y = 0 or z = 0. The target proves both that `closure A = S` and that every generating set G of S contains A. So A is the unique minimal generating system, and `A.ncard` = e(S), with no assumed formula.
- **Inequality.** The conclusion `d * C.ncard ≤ A.ncard * (C ∩ S).ncard` is the source's d·c(S) ≤ e(S)·n(S), in the same direction.
- **No `ncard` degeneracy.** `C.Finite` and `A.Finite` are conjuncts of the target, and C ∩ S ⊆ C. So all three `ncard`s are genuine cardinalities. A default value of 0 cannot make the inequality trivial.
  - Since H ⊆ C, finiteness of C also gives finiteness of H, i.e. that S is a GNS.
  - As a non-vacuity check, my Audit proves in Lean that for (a,b,d) = (3,4,3) the three cardinalities are 56, 25 and 26, all nonzero.
- **Quantifiers.** The target ranges over all a, b, d with 2 ≤ a < b, gcd(a,b) = 1 and d > 0. Every two-generated numerical semigroup ⟨a,b⟩ with a,b ≥ 2 arises this way, after ordering a < b (a = b is impossible when a,b are coprime and ≥ 2). There are no extra hypotheses.
- **What the source asks.** Journal §6 (p.172) says "In general it seems very difficult to prove the conjecture for T = ⟨m,n⟩ with m > 2 and n > m", and that the conjecture "for such a class remains open". The target covers this whole family, plus a = 2.
- **Strength.** The target is stronger than the bare inequality, because it also asserts generation and minimality. It is not weaker in any respect that I could find.
- **Independent Python check** (`py/enum.py`, written without Lean). I brute-forced S, H, C, N and the irreducibles in a box containing all gaps, for (a,b) ∈ {(2,3),(2,5),(3,4),(3,5),(4,5),(3,7),(5,6),(4,7)} and d = 1..4 (1..3 for the larger pairs).
  - Each case gives e = C(a+d−1,d−1) + C(b+d−1,d−1), c = C(F+d,d), and g + n = c.
  - The inequality holds in every case. It is an equality at d = 1, e.g. (3,4,1): 2·3 = 6.
  - (3,4,3) gives e = 25, n = 26, c = 56, matching SOURCE-CHECK.
- **Formula-level sweep** (`py/formula.py`). Over 2 ≤ a < 30, a < b < 60, coprime, and d ≤ 24, there are 18,096 cases with no violation. The minimum ratio is exactly 1 (at d = 1).
  - 1,561 of these cases are covered neither by 2611.20086 Thm 5.5/5.6 nor by the journal's a = 2 results. This confirms that the target extends the literature.

## 2. Is the proof chain clean?

- **CheckWilf.lean.** It contains exactly `theorem check_Wilf : Challenge.Wilf := Proof.Wilf` plus two `#print axioms`.
  - Only Challenge.lean opens `namespace TaskP.GradedWilf.Challenge`. All other modules use `TaskP.GradedWilf` or `TaskP.GradedWilf.Proof`, so nothing shadows a frozen name.
  - My `Audit.lean` compiles `example : TaskP.GradedWilf.Challenge.Wilf := TaskP.GradedWilf.check_Wilf`, and the same with `Proof.Wilf`, using fully qualified names.
  - It also checks by `Iff.rfl` that `Wilf` unfolds to the fully explicit statement in terms of `Fin d → ℕ`, `∑`, `AddSubmonoid.closure {a,b}` and coordinatewise `≤`, and it `#print`s every frozen definition.
- **Forbidden constructs.** I grepped all 9 files for `sorry`, `admit`, `native_decide`, `bv_decide`, `axiom` (as a declaration), `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `notation`, `set_option`, `initialize`, `run_cmd`, `ofReduceBool`, `instance`, `attribute` and `decide`.
  - None of them appears, except `axiom` inside the two `#print axioms` lines.
  - The only attributes are three `@[simp]` membership lemmas: `mem_layer`, `mem_ball`, `mem_good`. Four `private` helper theorems in WilfHigh are ordinary.
- **Proof structure in Lean.**
  - `frob_spec` uses Mathlib's `frobeniusNumber_pair` (Sylvester).
  - `reflect_mem`: for t ≤ F, t ∈ T iff F − t ∉ T.
  - `below_eq_ball`: C is the ball of total degree ≤ F, built from the real definition by padding coordinate 0.
  - `atoms_eq`: the atoms are exactly the layers of degree a and b, built from the real definition.
  - `atoms_generate` and `atoms_minimal` prove generation and minimality.
  - `good_count`: n is the sum of the layers of available degrees.
  - Then `high_wilf` (d ≥ 3, single layer F−1) and `low_wilf` (d = 1, 2) finish the proof.
- **Axioms.** `Proof.Wilf` and `check_Wilf` depend only on `[propext, Classical.choice, Quot.sound]`. This holds in Codex's logs and in my rebuild, and Audit shows the same.

## 3. Independent rebuild on this Mac

- **Setup.** New empty directory `.../scratchpad/final-wilf/`. I copied the 9 `.lean` files to `src/` and added `Audit.lean`. I did not use lake or any Codex build product.
  - I compiled each module with `lean -o` in the receipt's order, using `-DautoImplicit=false -DrelaxedAutoImplicit=false -DwarningAsError=true`, as in the acceptance lakefile.
  - `LEAN_PATH` pointed at my own `out/` plus the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`. I did not rebuild Mathlib.
- **Toolchain and dependencies.** Lean 4.34.1. The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…). All 9 package HEADs equal `receipt.dependency_commits`, including mathlib `d13f23b723b8a846827a245b89c10fc7d3f11612`.
- **Lock.** The lock was busy at first, so I waited with an until-loop. I acquired `leanlock.sh acquire any claude-final-wilf 60` (slot A) at 18:31:45Z and released it (`released A`) at 18:34:37Z, after the last checker run. Only one Lean process ran at a time.
- **Result.** All 10 modules compiled with exit 0, with no warnings or errors. The only output was the `#print` and `#print axioms` info.
  - My first Audit draft had three errors in my own numeric `rfl` examples. I fixed them and recompiled Audit alone. No reviewed file was changed.
  - `leanchecker` ran on each of the 10 modules (9 local plus Audit). Every run exited 0 with empty output.
  - Peak RSS for a single command was 6.00 GB. Memory pressure stayed normal (70% free).

## 4. Mathematical sanity of MATHEMATICS.md

The written proof is correct and matches what Lean proves. I checked each step by hand:
- the reflection t ↔ F − t;
- C = ball(F), so |C| = C(F+d,d);
- e = B(d,a) + B(d,b);
- at d = 3, e − F = (a−b)²/2 + 5(a+b)/2 + 2 ≥ 11;
- each step from d to d+1 adds ≥ d+1 per layer, so e ≥ F + d² + d − 1;
- F·d·|C| = (F+d)(F+d−1)·B(d,F−1);
- (F+d)(F+d−1) ≤ F(F+d²+d−1), which is equivalent to d(d−1) ≤ d(d−1)F;
- the d = 1 equality, and the d = 2 bound 4g(g+1) ≥ (F+1)(F+2) with the (2,3) exception.

The write-up never says "first", and it does not claim the general conjecture: the last paragraph limits the result to this family. It credits the generator and layer formulas to Cisto–Navarra §4 and the partial results to Bhardwaj–Cisto–Deshpande. The points below are attribution and scope fixes.

## MINOR write-up fixes

1. **Credit the known a = 2 cases.** In the opening paragraph, state that the a = 2 cases were already known in all dimensions: journal Prop. 4.8 covers T = ⟨2,n⟩ with n ≥ 5 odd, and ⟨2,3⟩ (T = ℕ∖{1}) is the T-stripe case settled in journal §3, since the text notes that T-graded and T-stripe coincide there. At present only "§6 点名了 a>2 的整类" is said, so a reader could think a = 2 is new.
2. **Credit the method of Thm 5.6.** In the d ≥ 3 paragraph, add that 2611.20086 Thm 5.6 already bounds n(S) from below by a single full layer of N(S): the layer s, the largest multiple of a that is ≤ F. Then explain that the new step is the choice of layer F−1 together with comparing directly against c = C(F+d,d) using the exact e, rather than against their bound on g(S). This removes their threshold on b. As written, "最后一个可用层的统一估计消除了对 b 的阈值条件" reads as if the single-layer idea itself were new.
3. **Mark d = 1, 2 as re-proofs.** d = 2 for all coprime a < b is 2611.20086 Thm 5.5. For d = 1, n = c/2 because two-generated T is symmetric, so e·n = c is classical. Say that the d = 1, 2 section is a formal re-proof and not a new result. Then scope the novelty sentence "本文的估计覆盖高维的全部参数" to d ≥ 3, with a ≥ 3 outside the Thm 5.6 condition.
4. **Scope the novelty sentence to the G2 search.** G2 approves only continuation and itself says a G3 check is required before release. Add "据截至 2026-11-20 的 G2 检索", or repeat the pre-release check before publishing.
5. **Optional: say why A is e(S).** In the final paragraph, add one sentence: generation plus "contained in every generating set" makes the atom set the unique minimal generating system of the source, so `A.ncard` is e(S). Also add that finiteness of C makes every `ncard` a genuine cardinality. This makes the Lean-to-source correspondence explicit for readers.
