"""Compile one Task J development module using only local Mathlib caches."""
from pathlib import Path
from contextlib import contextmanager
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
BIN = WORK / 'toolchains/lean-4.34.1-darwin_aarch64/bin'
LOCK = WORK / 'tools/leanlock.sh'
PACKAGES = WORK / 'research-lean-v434/.lake/packages'


def utc():
    return subprocess.check_output(['date', '-u', '+%Y-%m-%dT%H:%M:%SZ'], text=True).strip()


def pressure():
    return int(subprocess.check_output(['/usr/sbin/sysctl', '-n', 'kern.memorystatus_vm_pressure_level'], text=True))


def lean_rss_kib():
    snapshot = subprocess.check_output(['/bin/ps', '-axo', 'rss=,comm='], text=True)
    return sum(int(rss) for line in snapshot.splitlines() if len(parts := line.split(maxsplit=1)) == 2
               for rss, executable in [parts] if Path(executable).name in ('lean', 'leanchecker'))


def environment(build):
    caches = [p for p in sorted(PACKAGES.glob('*/.lake/build/lib/lean')) if p.is_dir()]
    if not any((p / 'Mathlib.olean').is_file() for p in caches):
        raise RuntimeError('Local Mathlib cache missing')
    return {**os.environ, 'PATH': str(BIN) + ':/usr/bin:/bin:/usr/sbin:/sbin',
            'LEAN_PATH': os.pathsep.join(map(str, [build, *caches]))}


@contextmanager
def local_slot(owner):
    start = time.monotonic()
    while True:
        pressure_level = pressure()
        rss = lean_rss_kib()
        if pressure_level == 4 or rss >= 40 * 1024**2:
            if time.monotonic()-start > 1200:
                raise RuntimeError('Memory pressure or aggregate Lean RSS has not cleared')
            time.sleep(3)
            continue
        reserve_both = pressure_level == 2 or rss >= 32 * 1024**2
        lock_cmd = [str(LOCK), 'acquire-both', owner, '30'] if reserve_both else [str(LOCK), 'acquire', 'any', owner, '30']
        claim = subprocess.run(lock_cmd, text=True, capture_output=True)
        if claim.returncode == 0:
            slots = claim.stdout.strip()
            break
        if time.monotonic()-start > 1200:
            raise RuntimeError('Local Lean slots busy')
        time.sleep(2)
    try:
        yield slots
    finally:
        for slot in slots:
            subprocess.run([str(LOCK), 'release', slot, owner], check=True)


def build_one(lane, module):
    if not all(part.isidentifier() for part in module.split('.')):
        raise ValueError(module)
    folder = HERE / lane
    rel = Path(*module.split('.'))
    source = folder / rel.with_suffix('.lean')
    if not source.is_file():
        raise FileNotFoundError(source)
    build = folder / '.dev'
    dest = build / rel.with_suffix('.olean')
    dest.parent.mkdir(parents=True, exist_ok=True)
    logs = folder / 'dev-logs'
    logs.mkdir(exist_ok=True)
    stamp = utc().replace(':', '') + '-' + uuid.uuid4().hex[:8]
    owner = 'taskJ-' + lane + '-' + stamp
    log = logs / (module + '-' + stamp + '.log')
    env = environment(build)
    start = time.monotonic()
    source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    with local_slot(owner) as slots:
        with tempfile.TemporaryDirectory(dir=build) as temp:
            out = Path(temp) / (rel.name+'.olean')
            cmd = [str(BIN/'lean'), '-j2', '-DautoImplicit=false', '-DrelaxedAutoImplicit=false',
                   '-DwarningAsError=true', '-R', str(folder), '-o', str(out), str(source)]
            with log.open('w') as fp:
                proc = subprocess.run(cmd, cwd=folder, env=env, stdout=fp, stderr=subprocess.STDOUT, timeout=1800)
            print(log.read_text(), end='')
            record = {'utc': utc(), 'source': str(source), 'log': str(log), 'returncode': proc.returncode, 'source_sha256': source_sha,
                      'elapsed_seconds_including_slot_wait': time.monotonic()-start, 'command': cmd, 'slot': slots}
            log.with_suffix('.json').write_text(json.dumps(record, indent=2)+'\n')
            if hashlib.sha256(source.read_bytes()).hexdigest() != source_sha:
                raise RuntimeError(f'Edited during compilation: {source}')
            if proc.returncode == 0:
                for produced in Path(temp).iterdir():
                    if produced.is_file():
                        os.replace(produced, dest.parent / produced.name)
            print(f'{module}: {proc.returncode} ({log})', flush=True)
            return proc.returncode


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lane', choices=['rank', 'grid'])
    parser.add_argument('module')
    args = parser.parse_args()
    sys.exit(build_one(args.lane, args.module))
