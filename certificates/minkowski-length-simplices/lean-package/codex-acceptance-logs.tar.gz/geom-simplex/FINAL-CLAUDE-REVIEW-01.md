# Cross-family FINAL review 01: Minkowski length of lattice simplices (Task P, geom-simplex)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. All four frozen targets (`TetrahedronDiameter`, `TetrahedronDilations`, `EveryDimensionDiameter`, `EveryDimensionDilations`) match Soprunov–Soprunova's Problems 3 and 2 as the source states them. They are fully Lean-verified: only standard axioms, and the independent rebuild and leanchecker both pass. The MINOR items concern the write-ups (MATHEMATICS.md, G2.md) only. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), a subagent of the user's Claude session. I wrote none of the reviewed files and took no part in this task's proof, statement, freeze or source check.
- Review started 2026-11-20T20:52:08Z. Report written after 2026-11-20T21:01:51Z (Mac `date -u`).
- This file is my only write in the task directory. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-simplex/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= frozen snapshot, byte-identical) | 98fdde3850a978f245d5cd8cd499e49f9ffb4d5586704a0c3c0a1798675e80a4 |
| CheckSimplex.lean | e862841b1c433d4ae382282c153a1933f0144d99c5302759b493d6721cbcdccc |
| Proof.lean | 4d7413cdc5c6ca6e7e17d858da4c45725c55e9299bcfd58e19d4538aeea2e36d |
| Packing.lean | 1c0e89097f56828b682f0e48b62721aed4e9644a095c828945876b6b1348bb9f |
| TCoordinates.lean | a69de0c83b27d08f2aec5d5935f81c73f93f4da835f87ef70e6ff408b43fd6ea |
| TDiameter.lean | b533f99d6f36411a808a062728e27e4e1ba37b8e973b904038b5548c41aced81 |
| TLength.lean | 9bd4711e8455ae2106552074bc6587a60f183a82bcfc2993ed0da013f5846ddf |
| TTetrahedron.lean | 4bcf8476b255499af92631a1a702c52aeadbf970c65c814fa4ec16f6cd5b6ef9 |
| UCoordinates.lean | 8231dadc259358252c67372ab6da58f5d8bb2c40200b4a210c11aeb14a90f221 |
| ULower.lean | bc8aab784caf3a0104081f38d7be42657c4d37eaa7b2436e1f68929604181e1c |
| UUpper.lean | 2f9acaf67f4a12cb3a6032875ce6d2fd84fc8f7422ad03c8e90ea31093d13da9 |
| UTetrahedron.lean | 4d29f617721091ab8ed604e846bba99024640a37b4eb0ec60a906c7588afb401 |
| PyramidGeometry.lean | 10dd200539d525902dc09ac8e3736eb0e256338abd8d07ccaec0ec10e0e590a2 |
| PyramidCorners.lean | 7ce1f7584c6059c2d271b64e93d7f878c74675999266ea92f2fb65830a603e4f |
| PyramidTransport.lean | 2c432f2d764f8cd044605abb200aefee7541be1ae29b2d2ad589db8ed4e9e8c1 |
| PyramidDiameter.lean | d77c31102daafeb674f79ef70edf364839cbef7a3b8430768b398ab41515b4a8 |
| FREEZE.json | 3abc2e312b63b991eabfab20436d0ded0a35794934818158bba7461128914d1d |
| FREEZE-REVIEW.md | 44a300d855b00f6bccecd842b295fe8616ff1483e6ba1fca961d891d0b99b308 |
| SOURCE-CHECK.md | 28814fa4966bcc8ff85e33582ee7fdffad2ac603c807b4dba42c5d73089a9a7b |
| G2.md | d22dffb1033b4ad9f399ee08acf065ce6444bd67ca298a2d7e4262390064c51b |
| MATHEMATICS.md | c359e7c740b918348bdc5b6fac92111e3170faad8e1bd9713eb4dcd19a697245 |
| FINAL-HANDOFF.md | 6f1ed133f2e720328691585cfa4b2a9dd92e30c4f0166262ab78f2e8dcd24bac |
| acceptance/2026-11-20T182501Z/receipt.json | dbc830267f513683c4d6727a82345dace12ebd3e8046f402cbb03139c6e413d3 |
| arXiv 1412.4404v2 PDF (downloaded by me) | 147e72265f71d63dacba8ca37ff907e16568626df331c31e5b76c3be2378cd9f |
| arXiv 1412.4404v1 PDF (downloaded by me) | c067139fc8717274beb4543a8bb32201f86572598557fae8a75885df3eec8d5b |
| My Audit.lean (scratch) | 7d3993c47b6b4d99df959b1168bdcdb8cdf4d587d47788319129ab78e6f60ab2 |

Hash checks:
- All 16 source hashes match `receipt.json.source_sha256`.
- The 16 `.lean` files in the task root are byte-identical to `acceptance/.../root1` and `root2`.
- The Challenge hash matches `FREEZE.json.challenge_sha256` and the `frozen/` snapshot.
- The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`.
- `receipt.json.freeze_sha256` equals the FREEZE.json hash, and the receipt hash matches FINAL-HANDOFF.

## 1. Are the statements faithful to the source?

**Source.** Crossref confirms DOI 10.1016/j.ejc.2016.05.009: Ivan Soprunov, Jenya Soprunova, "Eventual quasi-linearity of the Minkowski length", European J. Combin. 58 (2016) 107–117. The arXiv version is 1412.4404. I extracted the text of v2 (23 May 2016, the accepted manuscript) and of v1 myself. Problems 1–3 have the same numbers and wording in both versions (v2 p.12, §4). I could not open the ScienceDirect text (paywall), so the journal wording rests on v2.

- **Minkowski length.** Definition 1.1 (p.2) says L(P) is "the largest number of lattice polytopes Q1,…,QL of positive dimension whose Minkowski sum is contained in P".
  - The source uses literal containment. Lattice translations appear only in the partial order on decompositions. Because each Qi may be any lattice polytope, a lattice translation can be absorbed into one factor.
  - Lean's `packs P k` asks for k finite lattice sets `V i` with `1 < card`, and requires every choice of real points `x i ∈ conv(V i)` to sum into P. This is exactly "Q1+…+Qk ⊆ P", with Qi = conv(V i).
  - Every lattice polytope is the hull of its finite vertex set, and positive dimension means at least two distinct points. Real translations are not allowed, as in the source.
  - `lengthIs P n` = attained ∧ every packing has k ≤ n. This is a true maximum, not a proxy. `packs P 0` (meaning 0 ∈ P) plays no role because all claimed values are ≥ 1.
- **Lattice diameter.** The source (Introduction; p.5 after Def. 2.5) defines ℓ(P) as "one less than the largest number of collinear lattice points in P". `diameterOne` requires two distinct lattice points in P, and that every three lattice points in P that are collinear in ℝ^d contain a repeat. That is exactly ℓ(P) = 1.
- **Dilates and simplices.**
  - `dilate t P` is the image under x ↦ t·x. This is the source's tP = {tx | x ∈ P} (p.1).
  - `simplex v` is the real convex hull of the d+1 integer vertices.
  - `fullSimplex` (affine independence over ℝ) makes every witness a genuine d-simplex in ℝ^d. It is not a lower-dimensional one padded with zeros.
- **Problem 3** (v2 p.12): "Prove or disprove that for any simplex in R^d its Minkowski length coincides with its lattice diameter." In context the simplex is a lattice simplex: L is defined only for lattice polytopes, and the motivation is t∆ and lattice triangles.
  - `TetrahedronDiameter` gives a full lattice 3-simplex with L = 2 and ℓ = 1. That disproves the statement in ℝ³.
  - `EveryDimensionDiameter` does the same with a full simplex in every d ≥ 3.
  - Together with the source's Corollary 3.2 (d = 2) and the trivial case d = 1, this settles Problem 3 completely, dimension by dimension.
- **Problem 2** (v2 p.12): "Prove that L(tP) is quasi-linear or give an example of a lattice polytope P for which L(tP) is not quasi-linear."
  - The source separates "quasi-linear" from "eventually quasi-linear" (Def. 1.3, p.3). On p.12 it also says that L(P) = ⌊λ(P)⌋ "would imply that L(tP) is not just eventually quasi-linear, but quasi-linear". So the reading "quasi-linear for all t ∈ ℕ, from the first term on" is the source's own reading.
  - Def. 1.3 uses f : ℕ → ℚ, a period k, and constituents p_r ∈ ℚ[t] chosen by t mod k. "Quasi-linear" means every constituent is linear.
  - `quasiLinearLengths` matches this: a period k > 0 and arbitrary rational slope(r), intercept(r) for t ≡ r, quantified over every t ≥ 1.
  - The source's tP uses positive integers t. If ℕ also included 0, the Lean negation would still be the stronger statement, since a quasi-linear function on ℕ₀ restricts to one on ℕ≥1.
  - Real constituents would make no difference either: two integer values on a residue class already force rational coefficients.
- **Non-vacuity.** `problemTwoWitness` fixes L(U) = 1 and L(tU) = 3t for every t ≥ 2 as separate conjuncts. So `¬ quasiLinearLengths` cannot hold just because some maximum fails to exist. It follows from genuine values: the class 1 mod k forces slope 3 and intercept 0, which gives 3 ≠ 1 at t = 1. `lengthIs` values are unique (`length_unique`).
- **Python cross-check** (independent of Lean, exact rationals; `py/check.py` in scratch):
  - T: determinant −24. It has exactly 8 lattice points, listed as in MATHEMATICS.md, all in distinct classes mod 2, with no three collinear. Brute force over base points and difference vectors gives L(T) ≥ 2 (unit square at z = 2) and no 3-segment packing. The 24×barycentric formulas `tcoords` agree with Gaussian elimination. The lattice width is 2.
  - U: determinant −18. Its only lattice points are its 4 vertices (width 1, empty). There is no 2-segment packing. The `uform` facet description agrees with the barycentric coordinates.
  - The 2U and 3U segment endpoints lie in 2U and 3U. The minimum "cost" of a nonzero lattice direction is 6 over the box [−30,30]³, which matches `edge_cost`.

## 2. Is the proof chain clean?

- **CheckSimplex.lean** contains exactly four lines `theorem check_X : Challenge.X := Proof.X`, plus 8 `#print axioms`.
  - Only Challenge.lean opens `TaskP.GeomSimplex.Challenge`. Every other module uses `TaskP.GeomSimplex.Proof`, so no frozen name is shadowed.
  - My `Audit.lean` checks all four targets with fully qualified `example`s, against both `check_*` and `Proof.*`.
  - It checks by `Iff.rfl` that `TetrahedronDiameter`, `TetrahedronDilations` and `packs` unfold to the explicit statements I expected (convex hulls, the concrete vertex lists, the quasi-linear clause).
  - It checks `verticesT` and `verticesU` by `rfl`, and `#print`s every frozen definition.
- **Forbidden constructs.** I grepped all 16 files for the listed patterns. Nothing appears except:
  - `set_option maxHeartbeats 1600000` (TDiameter, `diameter_table`);
  - `set_option maxHeartbeats 3000000` and `maxRecDepth 10000` (TLength, `noCubeTable`);
  - one `private instance` (TDiameter), a `Decidable` instance for the integer equation `minor` via `inferInstanceAs`. It is harmless.
  - There is no `@[`, `attribute`, `native_decide`, `sorry`, `axiom` or `opaque`.
- **`decide` uses** (all kernel-checked; no `native_decide`):
  - TDiameter: the 8³ collinearity-minor table, and `verticesT 0 ≠ verticesT 1`.
  - TLength: the 8⁴ hash table `noCubeTable`, `key_point`/`valid_point` per point, and the `lowerT` corner checks.
  - UTetrahedron: the 4⁴ parallelogram table, and vertex inequality.
  - ULower: the six/nine witness inequalities, `v ≠ 0`, and `zeroform`.
  - Packing/Proof/PyramidCorners/UUpper: trivial numerals.
- **Proof structure.**
  - T: Lean proves the facet description, the 8-point enumeration (`interval_cases` + `omega`), the minor table for ℓ = 1, and the unit square for L ≥ 2.
  - L(T) ≤ 2: take the first three segments of any packing and apply the hash certificate. The certificate does not assume the hash is injective on ℤ³. It only uses linearity and the table of the 8 actual points, and it allows coincident directions.
  - U, upper bound: the budget argument via `uform` (k·6 ≤ 18t).
  - U, lower bound: collinear witnesses (6 in 2U, 9 in 3U), combined additively, for all t ≥ 2. L(U) = 1 by the parallelogram table.
  - Pyramids: the barycentric "mass" slice description, lifting packings, replacing rising segments by base segments (`replace_rising`), and the diameter argument through the apex.
  - `Proof.lean` iterates the pyramid by `Nat.le_induction` from d = 3. It uses `pyramid_length` with t = 1 and with every t ≥ 2, then re-derives ¬quasi-linearity.
- **Axioms.** In Codex's logs and in my rebuild, all 8 printed declarations in CheckSimplex and the 4 in Audit depend only on `[propext, Classical.choice, Quot.sound]`.

## 3. Independent rebuild on this Mac

- **Setup.** New empty directory `.../scratchpad/final-simplex/`. I copied the 16 `.lean` files to `src/` and added `Audit.lean`.
  - I did not use lake or any Codex build product.
  - Each module was compiled with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -DwarningAsError=true -R src -o out/M.olean`, in the receipt's order.
  - `LEAN_PATH` = my `out/` + the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean` + the toolchain lib.
- **Toolchain.** Lean 4.34.1, commit 5045d005. The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…). Mathlib is at `d13f23b723b8a846827a245b89c10fc7d3f11612` (`git rev-parse`), as in `receipt.dependency_commits`.
- **Lock.** I acquired `leanlock.sh acquire any claude-final-simplex 60` (slot A) at 20:57:34Z and released it (`released A`) at 21:00:28Z, after the last checker run. Only one Lean process ran at a time. Memory free was 66% at the start. Peak single-command RSS was 6.30 GB.
- **Result.** All 17 modules (16 local + Audit) compiled with exit 0 and no warnings or errors. The only output was the `#print` / `#print axioms` info. `leanchecker` exited 0 with empty output on all 17 modules.

## 4. Mathematical sanity of MATHEMATICS.md

The written proofs are correct and match the Lean argument. I checked each part:
- the mod-2 argument for ℓ(T) = 1;
- the mod-2 / central-symmetry argument for L(T) ≤ 2;
- the hash values 1025, …, 2114;
- the facet forms of U and the cost lower bound 6 (residues 5, 8, 3, 2, 7 of 13y mod 18);
- the 2U and 3U segments, the residue-class contradiction, and the pyramid transport (H ≥ m, (t−H)P + HP = tP).

The paragraph on the source's identity L₁(P) = ⌊λ₁(P)⌋ (v2 p.6) is also correct. U has L₁(U) = 1, but 2U contains 7 collinear lattice points along the primitive direction (2,3,0), so λ₁(U) ≥ 3. The cause is that s(P) allows rational translations while ℓ(P) does not. This paragraph is clearly marked as not formalized. The text never says "first", and it credits the definitions, Theorem 2.20 and Corollary 3.2 to the authors.

**Prior work (my own search, 2026-11-20).**
- I read in full the questions sections of:
  - the authors' 2016 Berlin workshop slides (Problem 3 still listed as open);
  - Beckwith–Grimm–Soprunova–Weaver (DCG 2012);
  - Blanco–Santos (arXiv 1601.02577; §5.6 treats only dps = L = 1 polytopes);
  - Meyer–Soprunov–Soprunova (arXiv 2105.10071, the paper behind the GitHub repo `isoprou/minkowski-length`);
  - Gibbs–Hogan–Jabbusch–Plute–Toloczko (arXiv 2509.21178v2, planar only);
  - "Primitive zonotopes" and "Elementary moves" (citation only).
- The Semantic Scholar citations of 1412.4404 add nothing beyond these. OpenAlex was rate-limited for me.
- None of these answers Problem 2 or 3, or exhibits T or U for this purpose.
- T has width 2 and 8 lattice points, so it is in the Blanco–Santos database. It is not dps (it contains the unit square), so it is not among their tabulated L = 1 polytopes.

The closest work is Meyer–Soprunov–Soprunova 2021, by two of the posers. It studies empty tetrahedra in White's normal form, and its Theorem 3.4 already implies L(P+P) ≥ 3 for every empty tetrahedron of volume > 2. That is consistent with U, and it says nothing about the whole sequence L(tU) or about quasi-linearity. MATHEMATICS.md should still cite it (MINOR 1).

## MINOR write-up fixes

1. **MATHEMATICS.md, attribution paragraph.**
   - Credit U's description as an empty tetrahedron to White's classification (G. K. White, Canad. J. Math. 16 (1964)). U = conv{0, e₁, e₃, (13,18,1)} is in White's normal form with volume 18.
   - Cite Meyer–Soprunov–Soprunova, arXiv 2105.10071, as the nearest later work by the posers. They treat L(P+Q) for empty tetrahedra (Lemma 3.2, Theorem 3.4), which already gives L(2P) ≥ 3 for empty tetrahedra of volume > 2. Say that the full sequence L(tU) = 3t and the failure of quasi-linearity are not in it.
2. **G2.md.** It describes `isoprou/minkowski-length` as containing "计算算法、Blanco–Santos 收录小格多面体". The repo's README says it is MAGMA code for the computer search in Meyer–Soprunov–Soprunova (classification of maximal decompositions in 3D polytopes with L ≤ 3). Correct the description, and list that paper among the checked sources at G3.
3. **MATHEMATICS.md, Problem 3 section (optional).** State the complete answer in one sentence: equality holds for lattice simplices in dimension ≤ 2 (source Corollary 3.2; d = 1 trivial) and fails in every dimension d ≥ 3 (formalized). This makes the scope explicit.
4. **MATHEMATICS.md, floor-relation paragraph (optional).**
   - Name the cause in one clause: s(P) allows rational translation, ℓ(P) only lattice translation.
   - Note that Remark 2.21's conclusion "L₁(tP) is in fact quasi-linear" is therefore unsupported in general. Do not claim it is refuted: the given data fix L₁(tU) = 3t only for t divisible by 2 or 3.
5. **Citations.** Give the journal reference (EJC 58 (2016) 107–117, §4) together with the arXiv v2 page. Note that the problem wording was checked on v1 and v2. I did not see the publisher text myself.
