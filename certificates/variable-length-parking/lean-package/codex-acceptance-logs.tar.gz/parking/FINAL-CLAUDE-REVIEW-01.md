# Cross-family FINAL review 01: parking with cars of variable length (Task N)

**Verdict: APPROVE_FORMAL.** There are no BLOCKER or MAJOR items. The MINOR items below concern only the write-up and the public framing. Fix them before publication. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session. I wrote none of the reviewed files.
- Review started 2026-11-20T17:16:37Z. The report was written after 2026-11-20T17:26:40Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-parking/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (byte-identical to the frozen snapshot) | 7f0d8043e63b4f4f467617b1ade9d619e131350cacff9199a664c65972bce46e |
| CheckParking.lean | ac4a4c0b65dd735284ee01533346d58b135480b03e95f712dd8e8e63a7d99986 |
| Proof.lean | e00326e3bbd575cb2c4921cbd7e457d594ec0ee459b6ad04031135ff3c0d1253 |
| ParkGaps.lean | 240c533fe8cc7c8855548f69fbce5de18f6c04c8cb54e6e07b91d9a9b186f35d |
| ParkSums.lean | 44afa5d8827f3802073f4482bb7bafe99c6343712282c37e05ca1b29e9bf00da |
| ParkClassification.lean | a7997b7da84120909d952596f210c6188d24f3f1585ab29293810e4c64802850 |
| SpacingWord.lean | e5332f11a7dc0ada52e3c3e1b29ac2d097eccb2d252378e2849839b7c8808477 |
| SpacingPalCount.lean | bce6f213f1b341f5c4efa47a7ae9dd49a2cc42fa9d7cc0040984cc8ac8dbb8b4 |
| ParkWalk.lean | 346305629a10abe3c10fe5ddc16c2a987588264acf6a4ba5e86e8912f2f51548 |
| ParkPrefix.lean | 72d2ce42c8827835db0cce47c02bfc681e76a411c7238676d37e5a3605e35c60 |
| ParkBand.lean | 9acd25c948bf64a8313f3f0869930a018b3245578bbde89aad6b6a7e77d1343c |
| SpacingCount.lean | 8f93fd96acec89a13e2e3769bc7ad015584ad46576ec7b26dd7eadf38e31aac4 |
| FREEZE.json | 5df7a90fa60a8986d9d85ac891f35fdcd017e9a1be54940b87bb8bc0f0bdc842 |
| FREEZE-REVIEW.md | 02f3fdef8022e62814878c188f9eb596709882025233d32f2fc6ad03dbeb08cc |
| SOURCE-CHECK.md | 91e3ae287f637ec411e75ac7c0bbbf7cc0c7a4e913012523838a33dcc3c35308 |
| G2.md | b905f95d9e326d0b9d25b3741287f7efab462ac42f29b9cc9885a2e628e84baf |
| MATHEMATICS.md | 955b85ffae6f0e1a74b1550e04d358d47be5293eb287d4489bca669c086626a7 |
| FINAL-HANDOFF.md | 53d288769c3e7191e0e2ec797f5439d482f5dedfac403a9ef33ba95f2938c0ed |
| ../FINAL-HANDOFF.md | 0d1efd9195036bb0c92b90c2abeec2e9d69b00db06f57229c11efe075185a6dc |
| acceptance/2026-11-20T143513Z/receipt.json | b6621374e76f7c69d4cb83ff2236c82178268b5e7002b2d695b8a182eefe573f |

Cross-checks:
- All 12 source hashes equal `receipt.json` `source_sha256`.
- The Challenge, FREEZE-REVIEW, SOURCE-CHECK and G2 hashes equal the values recorded in FREEZE.json.
- The 12 `.lean` files in the task root are byte-identical to the copies in `acceptance/.../root1` and `root2`.

## 1. Are the statements faithful to the source?

I read arXiv:2311.15699v1 (D. M. Chen, *On the Structure of Permutation Invariant Parking*, 27 Nov 2023; only v1 exists) in its HTML version.

- **Parking rule (Def. 1.3).** The paper sets ℕ = {1,2,…} and uses a street of m = Σyᵢ spots. Car i drives to xᵢ ∈ [m]. If its yᵢ spots are free it parks there; "otherwise, it parks in the next yᵢ contiguously available spots (if they exist)."
  - Lean `park` uses 0-based offsets with half-open gaps [l,r) plus a frontier, beyond which every spot is free. It takes the first gap in which start = max(l,pref) satisfies start+len ≤ r. Otherwise it parks at max(frontier,pref) on the infinite tail, opening a new gap if needed.
  - With positive lengths, this is exactly "the first fitting run at or after the preference."
  - The frontier never decreases. So the finite-street condition (no car ever runs past m) is equivalent to `final frontier ≤ m`. A car that would fail on the finite street parks past m on the infinite tail, and the frontier then stays above m.
- **Invariance (Def. 1.5) and W (Theorem E).** The paper defines W(y) = {w ∈ ℕ : (1ⁿ⁻¹, w) ∈ PA^inv_n(y)}. Invariance quantifies over all permutations of the preference entries. For (1,…,1,w), these permutations are exactly "w at position i, 1 elsewhere" for each i.
  - `allPositions` quantifies over every split `lengths = before ++ len :: after`, which gives offset t to one car and offset 0 (preference 1) to all the others. Car lengths and arrival order are never permuted, which is correct.
  - `W` filters offsets in `range m` and applies `succ`, giving w ∈ [1,m]. This matches x ∈ [m]ⁿ. The `succ` is injective, so the card is unaffected.
- **Theorem E(b)–(d).** I quote the source.
  - (b): "|𝒲(y)| ≤ 2^{n−1}".
  - (c): yⱼ > Σ_{i>j} yᵢ for all j ∈ [n−1] is sufficient.
  - (d): equality implies "y₁ ≥ y₂ and yⱼ > Σ_{i=j+1}^n yᵢ for all j∈[n−1]∖{1}".
  - Remark 4.7: "The condition (3) is not sufficient", with the example y=(7,5,3,1), 𝒲={1,2,4,5,6,7,9}.

  How the Lean statement encodes this:
  - `ExtremalClassification` covers every nonempty list of positive lengths. It states the bound `2^(length−1)` and gives an iff with `extremeLengths`.
  - `extremeLengths` is defined from the lengths alone: subset sums and the `dominant` predicate. It never refers to parking.
  - `dominant (b::xs)` is exactly Chen's condition for j ≥ 2. Its last clause "last length > 0" is just positivity.
  - The head of the list is car 1 (y₁ = a) and the second element is y₂ = b, which matches Chen's indexing.
  - n = 1 gives `True`, i.e. W = {1} has card 1 = 2⁰.
  - The `[]` case is excluded by the hypothesis `lengths ≠ []`.
- **FirstLengthCount.** This is an additional result, not one of Chen's statements. Fix b and a tail xs with `dominant (b::xs)`, which is necessary for equality by E(d). It counts first-car lengths a in the closed interval [b, b+Σxs] for which |W(a::b::xs)| = 2^(n−1), and states the count equals 1 + Σ(2^L − 1).
  - Here `jumps` lists h₁ = u₁, h₂ = u₂−u₁, …, from the smallest car up, and `runs` groups maximal runs of consecutive equal values.
  - Both endpoints of the interval are included.
  - With an empty tail the interval is {b} and the count is 1.
  - Outside the interval the answer follows from the classification: a < b never attains equality, and a > b+Σxs always does.
  - So the statement is not vacuous and not weaker than intended.
- **The "open question".** Chen never labels the equality case of E(b) as an open problem; I checked §5 Open Problems 1–3. The problem is the gap between the sufficient condition E(c) and the necessary condition E(d), which Remark 4.7 shows is real. This is a fair target, but see MINOR-1.
- **Hand checks against the paper, using my own Python cell-by-cell simulation of Def. 1.3** (`py/sim.py`):
  - Example 1.4 (lengths (3,4,2), preferences (5,1,6)) parks. Lean `#eval drive ([],0) [(3,4),(4,0),(2,5)]` gives `([], 9)`, i.e. a fully packed street.
  - Lean computable mirror `Wc` (same `drive`, special-car index enumerated) gives:
    - (7,5,3,1) → [1,2,4,5,6,7,9], equal to Remark 4.7;
    - (8,5,3,1) → 8 values, including 10;
    - (6,5,3,1) → 7 values;
    - [5] → [1].
  - Lean `Wc` equals my Python W on all 340 vectors with n ≤ 4 and lengths 1..4 (`py/cmp.py`, 0 differences).
  - Python, theorem vs. simulation:
    - Bound and equality ⇔ `extremeLengths`: 4,679 vectors (n ≤ 4 with lengths ≤ 6, and n = 5 with lengths ≤ 5), 65 equality cases, 0 mismatches.
    - FirstLengthCount: 411 (b, tail) pairs, scanning every a in the band, 0 mismatches.
    - Spot checks that a = b−1 fails and a > b+D attains equality: all passed.

## 2. Is the proof chain clean?

- **CheckParking.lean** contains exactly `theorem check_ExtremalClassification : Challenge.ExtremalClassification := Proof.ExtremalClassification` and the same for `FirstLengthCount`, plus four `#print axioms`.
  - The only module that opens `namespace TaskN.Parking.Challenge` is Challenge.lean, so no frozen name is shadowed.
  - My `Audit.lean` re-types both targets with fully qualified names, `example : TaskN.Parking.Challenge.ExtremalClassification := TaskN.Parking.check_ExtremalClassification` and likewise for the other. Both compile.
- **Forbidden constructs.** I grepped all 12 files for `sorry`, `admit`, `native_decide`, `bv_decide`, `axiom`, `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `set_option`, `initialize`, `run_cmd`, `ofReduceBool` and `instance`. None appear.
  - The only attributes are `@[simp]` on ordinary proved lemmas, which is harmless.
  - There are no `decide` uses at all.
- **Proof route.**
  1. `allPositions_iff` reduces the actual `drive` to the scalar recursion `residual` (ParkGaps).
  2. W ⊆ 1 + subset sums of the tail, which gives the bound (ParkClassification `W_bound`).
  3. Equality ⇔ the card of the subset sums is full and every subset sum is admissible (`card_eq_iff`).
  4. Necessity of `dominant`: `dominant_of_greedy_full`.
  5. Only positions 1 and 2 matter, and position 2 becomes shift-closure (`full_iff_shift`).
  6. Shift-closure ⇔ `prefixSymmetric` (`shift_iff_prefix`).
  7. For the count: a bijection from subset sums to prefix sums of the `ruler` word of `jumps` (ParkWalk, ParkPrefix, ParkBand).
  8. The palindromic-prefix count of `ruler`, by recursion on runs (SpacingPalCount).
  9. Proof.lean ties both targets to the frozen definitions with no extra hypotheses.

## 3. Independent rebuild on this Mac

I built in a new empty directory and did not use any Codex build product.

- **Setup.** I copied the 12 `.lean` files into `src/`, with the same flat module layout as the acceptance `lakefile.toml` roots.
- **Toolchain.** Lean 4.34.1. The `lean` and `leanchecker` SHA-256 values (1b370cfc…, cfde41cb…) equal the receipt.
- **Mathlib.** `research-lean-v434` packages, with mathlib at d13f23b723b8a846827a245b89c10fc7d3f11612. All 9 dependency commits equal the receipt. The prebuilt oleans were used through `LEAN_PATH`, and Mathlib was not rebuilt.
- **Lock.** I took `leanlock.sh acquire any claude-final-parking 60` and got slot B. I released it at 17:26Z (`released B`, exit 0).
- **Compile.** Command: `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -DwarningAsError=true -R src -o out/M.olean -i out/M.ilean src/M.lean`, run sequentially in receipt order.
  - All 12 exited 0 (17:19:14Z–17:20:32Z).
  - Every log was empty except CheckParking's, which holds the four axiom lines.
  - Peak RSS was 6.00 GB.
- **Axioms.** All four declarations depend only on `[propext, Classical.choice, Quot.sound]`.
- **leanchecker.** `leanchecker M` on all 12 modules: all exited 0 with empty output (17:21:25Z–17:26:00Z).
- **Audit.lean** (SHA-256 8e476b19…) exited 0. It did three things:
  - re-checked both targets against the fully qualified frozen names;
  - re-printed the axioms (same three);
  - ran the `#eval` cross-checks in §1.
- **Build products.** My Challenge, ParkClassification, Proof and CheckParking oleans are byte-identical to Codex's `.dev` oleans. That is expected for a deterministic build and confirms the same sources. All my olean hashes are in `logs/olean-sha256.txt`.
- **Machine safety.** Memory stayed at 53–61% free throughout. Only one Lean process of mine ran at a time.

## 4. Mathematics, attribution, novelty

- **Correctness of MATHEMATICS.md.** I read the whole proof and it is correct.
  - **§1, the gap reduction.** A special car at position i leaves a gap r = max(0, t−P). Later cars fill it greedily, and the run succeeds iff the final r = 0. This is exactly `allPositions_iff`.
  - **§2, necessity.** The argument is Chen's E(d), and it is credited to him. Lean proves the same fact by a counting argument instead.
  - **§2, sufficiency.** Positions i ≥ 3 never leave a gap, since a+b > b+D. Position 2 gives the condition (*): s ≥ δ ⇒ s−δ ∈ T. By the D/2 symmetry of T, (*) is equivalent to the prefix of T up to z = D−δ being symmetric. This matches `full_iff_shift` and `shift_iff_prefix`.
  - **Examples.** (7,5,3,1), (6,5,3,1) and (8,5,3,1) agree with my simulation.
- **Paper-only claims, not Lean-verified.** I checked these numerically; all agree:
  - The binary-jump form of condition 3 against `prefixSymmetric`: 50,296 cases, 0 differences.
  - The exact W formula for the whole superincreasing family: 566 cases, 0 differences.
  - The count of all invariant vectors, 1+n(2^(n−1)−1), with 2^(n−1) non-decreasing, in every equality case: exact on (8,5,3,1), (5,5,3,1), (4,4,2,1), (9,5,3,1), (6,6,2,1) and (3,3,1). For contrast, (7,5,3,1) gives 25 and 7.

  §3 discloses that the vector count is paper-only. The other two are not labelled where they appear (MINOR-3).
- **The write-up does not overclaim.** §3 says Lean uses the prefix-subset-sum form and that the binary implementation is only a write-up. It also says the result does not settle Chen's Open Problem 3 or arXiv:2211.01063's Open Problem 2.
- **Attribution.** Credit goes to the right places:
  - the bound, E(c) and E(d) to Chen;
  - the single-gap / sequential-fill idea to arXiv:2211.01063 Cor. 4.4, which I checked exists and concerns exactly the gap before the special car being filled by later cars;
  - the unique-representation counting argument to Chen.
- **No "first" claims.** None of MATHEMATICS.md, G2.md or the handoffs claims "first". G2 explicitly says global priority cannot be asserted ("不能据此断言全球首发"). Words like "首个" and "首车" refer to the first fitting slot and the first car, not to priority.
- **Novelty.** I saw no full classification in the paper. G2's search, including the ReuF2F file, covers only the four-car minimal-invariance problem, which is a different question. I did not repeat the G2 search, and G3 is still pending per G2.

## Items

**BLOCKER:** none. **MAJOR:** none.

**MINOR (write-up only; fix before publication):**

1. **Framing of the question.** Chen does not pose the E(b) equality case as a named open problem. §5 lists only Open Problems 1–3, and none is this. Public text (README, registry, release notes) should say "closes the gap between Chen's sufficient condition E(c) and necessary condition E(d) (Remark 4.7)", not "solves Chen's open problem".
2. **Define "最小不变性" in MATHEMATICS.md §1.** It is used without definition. It means arXiv:2211.01063's "minimally invariant" (i.e. w ∈ W). Also mark the O(n²2^(n−1)) decision-procedure remark as not Lean-verified.
3. **Label the other paper-only statements in §2.** Two claims need a "not Lean-verified (paper argument; checked numerically)" tag where they appear:
   - the binary-jump condition 3 and the decoding of j;
   - the exact W formula "W(y)−1 = T ∪ {b+s : …}" for the whole superincreasing family.

   The project rule is to publish only Lean-verified results. Either label them or move them to a clearly marked remarks section. The same applies to the invariant-vector count, which §3 already discloses.
4. **Say explicitly in the public text that FirstLengthCount is an add-on.** It is not one of Chen's statements. Its hypothesis `dominant (b::xs)` is the necessary condition from E(d). Outside the band [b, b+D] the answer follows from the classification: a < b never attains equality, and a > b+D always does.
5. **Provenance note.** The dev logs cover 14:23Z–14:34Z with only a few failing iterations, and the handoff says Task M produced earlier work. The record should state where the Lean was first drafted. This does not affect correctness.
6. **Outreach.** If Chen is contacted, keep the tone neutral, avoid "first" framing, and follow the per-poser risk notes in POSERS-BACKGROUND.md.
