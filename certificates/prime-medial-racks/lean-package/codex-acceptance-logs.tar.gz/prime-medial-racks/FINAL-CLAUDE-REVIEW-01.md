# Cross-family FINAL review 01: medial racks and quandles of prime order (Task P)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The three frozen targets `RackCount`, `QuandleCount` and `AutomaticIdempotence` state Vojtěchovský–Yang's Conjecture 6.5 faithfully, together with the remark printed right after it. All three are fully Lean-verified: standard axioms only, and my independent rebuild and leanchecker runs pass. The MINOR items below concern `MATHEMATICS.md` only. Fix them before publication. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), a subagent of the user's Claude session. I wrote none of the reviewed files and took no part in Task O/P's proofs, statements, source check or freeze review.
- Review started 2026-11-20T18:28:35Z. Report written at 2026-11-20T18:35:14Z (Mac `date -u`).
- This file is my only write in the task directory. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-racks/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (byte-identical to the frozen snapshot) | 36167e3c9902291eeca9d7aa2ab222655a9d5b3ff939c6ad6a9a1fb527f9c0d5 |
| CheckRack.lean | 06240b6af7267081af36f4ff3b4ff608af28d40ed18bcec7f7894cb7df0a14a5 |
| Proof.lean | 6a50f7c575650bbf1bd247f89fc5be4da470f0c6ef9f3e53b2713e88fdd6f42d |
| IsoTransfer.lean | 3f5677756a4ca088ed394de768508c707ddde12e1296085ccb7c204d44878c60 |
| Affine.lean | 808ca0238e08c6c40cefef96efda0adbee4e97210f27bbddb46c13334162cb76 |
| DisplacementData.lean | d8f51fe0f8a8dee54fe1e8106a835424ceba4ac5d546cdf35e94e2edac536222 |
| ClassCount.lean | 1e40718e4dc6ea7b5a8d9aa09bccebfea6667714d7af3ae7455681aaaced7982 |
| PrimeAction.lean | 5d30a140bf14b46169511f9b686760fef86eceba9cf8d940f134a42e232194aa |
| DisplacementGroup.lean | 1309ba7bd0879a096b8069f9324b6e45cd7c9969135c1d84bbefe8bd08547d87 |
| Enumeration.lean | 941d9ee2d440ef116cb916d8e918a1573468871f2a696dc3c6d7d83082d3c36d |
| PrimeOrbits.lean | 944d21e8c58e5f50b42d621623a944c51ed3f4c8b9293c2bccc55b7d708f7176 |
| CoordinatesCore.lean | 72b252bc56c8d8235db6e4cd76c35809b112c8f35ada1ddaba56581b7c1121f7 |
| Coordinates.lean | 560e4947343d16673efe5589584a738535b157a1c36fddb1f4459ef02e266ea9 |
| FREEZE.json | 0fd0c464578bdfc063d984a3f7d58f10de5b1f3c4b37935badda1aaa9be0f700 |
| FREEZE-REVIEW.md | 9f809f655beb6a38637df3b29056ba869753b39400b7a5777467de57a3e3d804 |
| SOURCE-CHECK.md | a199e7dee793e6d242eae3f42b24050ab0c68e2ac826e67eae1628279869f3fa |
| G2.md | f194f69e01d72e50e742bae0916683aaa48818cdb5171657f401b625f9d35dde |
| MATHEMATICS.md | 55e0ed3bf4eab8873ea1aec684874863aff93fffb857676303a67af335d294fb |
| FINAL-HANDOFF.md | eeaa216a21339574e76bf93b9093eaf587cc5694e14f0ecb9eb993e23b31a69b |
| acceptance/2026-11-20T181646Z/receipt.json | d3776a9554d157e7a5dfaa6ee2f55583ff82c206704ef2c7dc6503a0f5aba6ed |
| ../SELECTION.md / ../BRIEF.md | 6d8b4280…8eaf / eeb3c729…0e7e |
| arXiv 1911.04991v1 PDF (downloaded by me) | 5e53bcd0ac1fa5e40e54c73052a1b3ec27a2c392c92b48eb7bf3cfa9768d7001 |
| My Audit.lean (scratch) | 78c96dcf1264c666284750da5d0fc59bca30b39846fa0fb5dbe28931091db58f |
| My brute.py (scratch) | eaead3beb16e3d173fb43df313f2c2aff7d37774aa9634b98cde44b117e35ac6 |

- All 13 source hashes match `receipt.json.source_sha256`.
- The 13 `.lean` files in the task root are byte-identical to `acceptance/.../root1` and `root2`.
- The Challenge hash matches `FREEZE.json.challenge_sha256` and the `frozen/` snapshot.
- The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`.
- The FREEZE.json hash matches `receipt.freeze_sha256`, and the receipt hash matches FINAL-HANDOFF.

## 1. Are the statements faithful to the source?

I downloaded arXiv:1911.04991v1 myself and extracted its text. It is P. Vojtěchovský and S. Y. Yang, "Enumeration of racks and quandles up to isomorphism", Math. Comp. 88 (2019), DOI 10.1090/mcom/3409. Note that the source's term is "2-reductive", not "2-reduced".

- **Rack.** The source (p. 1) defines a left quasigroup, where each L_x: y ↦ x∗y is a bijection, plus "x ∗ (y ∗ z) = (x ∗ y) ∗ (x ∗ z)". Lean's `IsRack` has exactly these two conditions. It does not require the right translations to be bijective, and it adds no connectedness. The source writes permutations on the right (yL_x). Lean states every identity directly on `op`, so this convention never enters the statement.
- **Quandle, medial and 2-reductive.** The source defines a quandle by x∗x = x. It defines medial by (x∗u)∗(v∗y) = (x∗v)∗(u∗y), and 2-reductive by (1.1) (x∗u)∗v = (y∗u)∗v. `Idempotent`, `Medial` and `TwoReductive` copy these identities exactly, with the same variable order. I checked this against the `#print` output of my rebuild.
- **Isomorphism and counting.** `Isomorphic` asks for an `Equiv` e with e(x∗y) = e(x)∗′e(y). `isoSetoid n` is this relation on *all* binary operations on `Fin n`. `classCount n P` is the cardinality of the set of quotient classes that contain a representative satisfying P. So the count runs over every operation table on a p-element set, modulo isomorphism, and then restricts to a class. It is not restricted to a special family, and it is not defined trivially. All four predicates are invariant under isomorphism (proved in IsoTransfer), so "some representative satisfies P" is the same as "every representative satisfies P". Every p-element rack is isomorphic to a table on `Fin p`. Hence `classCount p (IsRack ∧ Medial)` = r_med(p) and `classCount p (IsRack ∧ TwoReductive)` = r_2-red(p). The two quandle versions add `Idempotent` on both sides.
- **Additive form.** The source states r_med(p) − r_2-red(p) = p − 2 (and the same for q). Lean states r_med = r_2-red + (p − 2) over ℕ. Every 2-reductive rack is medial (source p. 2, and also `reductive_medial` in Lean), so r_2-red ≤ r_med. For a prime p, p − 2 ≥ 0, so truncated subtraction does nothing. The two forms are therefore equivalent. The statement quantifies over all primes, including p = 2.
- **AutomaticIdempotence.** The source says (p. 15, right after Conjecture 6.5): "every medial rack of order p that is not 2-reductive is a quandle". The Lean target states exactly this for all operations on `Fin p`.
- **Edge cases and tables.** I wrote my own Python brute force (`brute.py`). It finds all racks on n points by backtracking over rows that are permutations, then forms isomorphism classes by canonical form under S_n. For n = 1..5 it reproduces Tables 1 and 2 exactly: r = 1, 2, 6, 19, 74; r_med = 1, 2, 6, 18, 68; r_2-red = 1, 2, 5, 17, 65; q_med = 1, 1, 3, 6, 18; q_2-red = 1, 1, 2, 5, 15. The differences at p = 2, 3, 5 are 0, 1, 3 for both racks and quandles, which equals p − 2. No non-2-reductive medial rack of order ≤ 5 is non-idempotent. From the source tables, the differences at p = 7, 11, 13 are 5, 9 and 11, also equal to p − 2. `classCount` is noncomputable, so `#eval` is not possible. Instead, Audit.lean instantiates `RackCount` at p = 5 and gets the concrete equation "count of medial racks = count of 2-reductive racks + 3".

I agree with SOURCE-CHECK and FREEZE-REVIEW. I found no weakening, no extra hypothesis and no vacuity.

## 2. Is the proof chain clean?

- **CheckRack.lean.** It contains exactly three lines, `theorem check_X : Challenge.X := Proof.X` for X = RackCount, QuandleCount and AutomaticIdempotence, plus six `#print axioms`.
- **No shadowing.** Only Challenge.lean opens `namespace TaskP.PrimeMedialRacks.Challenge`. The other files use `TaskP.PrimeMedialRacks` and `...Proof` and only `open Challenge`, so they cannot shadow a frozen name.
- **Audit.lean.** My `Audit.lean` checks `example : TaskP.PrimeMedialRacks.Challenge.X := TaskP.PrimeMedialRacks.check_X` for all three targets, with fully qualified names. It also checks by `Iff.rfl` that `RackCount` unfolds to the explicit statement, and it `#print`s all the frozen definitions.
- **Forbidden constructs.** I grepped all 13 files for `sorry`, `admit`, `native_decide`, `bv_decide`, `decide`, `axiom`, `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `notation`, `set_option`, `initialize`, `run_cmd`, `ofReduceBool`, `instance`, `attribute`, `local`, `scoped` and `@[`. None of them appear. The only hit is one `private def recast` (Coordinates.lean), an ordinary transport of a `MulEquiv` along n = m. The proof does not use `decide` at all.
- **Proof structure (Lean).**
  - DisplacementGroup and PrimeOrbits. D = ⟨L_u L_b⁻¹⟩ consists of automorphisms, is normalized by every L_x, and is abelian under the medial law. Each point stabilizer lies in the centralizer H of L_b. If H = D, the rack is 2-reductive.
  - PrimeAction. An index divisibility argument over the orbit decomposition gives transitivity. Abelian plus transitive gives regularity.
  - Coordinates and CoordinatesCore. A cyclic group of order p gives ℤ/p coordinates, and translation equivariance gives the affine form x∗y = (1−k)x + ky with k ∉ {0, 1}.
  - Affine. The parameter k is unique.
  - ClassCount and Enumeration. The classes split, with a bijection between the non-2-reductive classes and {k ≠ 0, 1}, of size p − 2.
- **Axioms.** All 6 declarations printed in CheckRack, and the 3 in Audit, depend only on `[propext, Classical.choice, Quot.sound]`. This holds both in Codex's receipt and in my rebuild.

## 3. Independent rebuild on this Mac

- **Setup.** I used a new empty directory `.../scratchpad/final-racks/`, copied the 13 `.lean` files to `lean/` and added `Audit.lean`. I did not use lake, `.dev/` or any Codex build product. I compiled each module with `lean -o` in the receipt's order, with `-DautoImplicit=false -DrelaxedAutoImplicit=false -DwarningAsError=true` (as in the acceptance lakefile). `LEAN_PATH` pointed at my own `out/` plus the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
- **Toolchain and dependencies.** Lean 4.34.1. The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…). All 9 package commits (`git rev-parse`), including Mathlib d13f23b723b8a846827a245b89c10fc7d3f11612, equal `receipt.dependency_commits`.
- **Lock.** `leanlock.sh acquire any claude-final-racks 60` gave slot B at 18:32:25Z. I released it ("released B") at 18:34:51Z, and status afterwards showed both slots free. Only one Lean process of mine ran at a time.
- **Result.** All 14 modules compiled with exit 0, 0 warnings and 0 errors. The only output was the `#print`/`#print axioms` info. `leanchecker` ran on each of the 14 modules and every run exited 0 with empty output. Peak RSS for a single command was 5.98 GB.
- **Olean hashes.** My `.olean` hashes differ from the receipt's lake-built ones. This is expected, because the invocation differs (`-R`, options, no lake). It does not affect the kernel check.

## 4. Mathematical sanity of MATHEMATICS.md

I checked every step and the written proof is correct.

- The medial law gives L_{b∗u}L_v = L_{b∗v}L_u, which makes D abelian.
- Stabilizers lie in the centralizer of T. H = D forces commuting left translations, hence 2-reductivity. A proper H has index p dividing every orbit size, so the action is transitive and then regular.
- The affine normal form follows. The rack law L_{c} = L_0 gives c = 0. Uniqueness comes from additivity of f(x) = e(x) − e(0). The test x = 1, y = u = v = 0 shows the affine racks are not 2-reductive.
- 2-reductive implies medial, and the count splits.

The text follows the Lean argument closely. It says it does not assume connectedness or idempotence, and it lists which file formalizes which step. It makes no "first" claim. The final paragraph defers priority to the scoped G2 record. Prior work is credited in substance: the small-order counts to the authors, the connected prime-order classification via HSV Thm 9.3, and the JPSZ medial-quandle theory. My own two web searches found no earlier proof of Conjecture 6.5. G2 itself says that a G3 check is still required before publication.

## MINOR write-up fixes

1. **§一.** It says the displacement-group characterization "属于已有 rack 结构理论" but links only to "原文 §1.1". Cite it the way the source does: medial ⇔ Dis abelian is [Hulpke–Stanovský–Vojtěchovský 2016, Prop. 2.4], quoted in Vojtěchovský–Yang §1.1.
2. **"形式化范围与归属".** Name Etingof–Soloviev–Guralnick (2001) as the origin of the classification of connected quandles of prime order, not only the HSV Thm 9.3 link. SOURCE-CHECK already notes this attribution.
3. **Terminology.** Give the source's term once, e.g. "二约化（2-reductive, 原文式 (1.1)）". Several briefs say "2-reduced", which is not the paper's word. Also note that the paper writes Dis = ⟨L_x⁻¹L_y⟩ with permutations acting on the right. This is the same group as the text's ⟨LᵤT⁻¹⟩ in left-action notation.
4. **Last paragraph.** "这里证明的范围包含所有素数阶 medial racks……" reads as a scope or novelty statement. Add the date scope "据截至 2026-11-20 的 G2 检索", and run the G3 check that G2 requires before release.
5. **Optional, §四.** State explicitly that the quandle count reuses the same classification because every affine model is idempotent. Then restricting to idempotent tables loses no parameter. The current sentence says this, but only briefly.
