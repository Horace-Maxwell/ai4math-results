#!/usr/bin/env python3
"""Copy Task U (H5 integer group determinants, targets A and B) Lean files to lean-staged/Research/TaskU/{H5,H5B}, rewriting only import lines.
TaskU.H5.* (37 files of TaskU/H5) -> Research.TaskU.H5.*, TaskU.H5B.* (26 files of formal-b/TaskU/H5B) -> Research.TaskU.H5B.*.
The file set must equal the 63 sources of the B acceptance receipt, with matching hashes. Writes h5-integration.json. Claude, 2026-11-21."""
import hashlib, json, os, re
P = '<workspace>'; T = f'{P}/work/codex-r3/phase28/taskU/heisenberg125'
ST = f'{P}/work/release-v1250/lean-staged'; sha = lambda b: hashlib.sha256(b).hexdigest(); out = []
rec = json.load(open(f'{T}/acceptance/spectrum/2026-11-21T033317Z/receipt.json'))['source_sha256']
fs = {}
for d, pre in [(f'{T}/TaskU/H5', 'TaskU.H5'), (f'{T}/formal-b/TaskU/H5B', 'TaskU.H5B')]:
    for f in sorted(os.listdir(d)):
        if f.endswith('.lean'): fs[f'{pre}.{f[:-5]}'] = f'{d}/{f}'
assert set(fs) == set(rec), (set(fs) ^ set(rec))
for n, path in sorted(fs.items()):
    b = open(path, 'rb').read(); assert sha(b) == (rec[n] if isinstance(rec[n], str) else rec[n].get('sha256')), n
    t = b.decode()
    def fix(m):
        x = m.group(1)
        if x in fs: return f'import Research.{x}'
        assert x.split('.')[0] in ('Mathlib', 'Lean', 'Std', 'Init', 'Batteries'), (n, x); return m.group(0)
    t2 = re.sub(r'^import (\S+)$', fix, t, flags=re.M)
    assert [l for l in t.split('\n') if not l.startswith('import ')] == [l for l in t2.split('\n') if not l.startswith('import ')]
    target_mod = 'Research.' + n; tgt = f"{ST}/{target_mod.replace('.', '/')}.lean"; os.makedirs(os.path.dirname(tgt), exist_ok=True)
    open(tgt, 'w').write(t2)
    out.append(dict(source=os.path.relpath(path, T), target=f"lean/{target_mod.replace('.', '/')}.lean", module=target_mod,
                    source_sha256=sha(b), target_sha256=sha(t2.encode()), identical=(t == t2)))
json.dump(out, open(f'{P}/work/release-v1250/h5-integration.json', 'w'), indent=1)
print(len(out), 'files;', sum(o['identical'] for o in out), 'byte-identical:', [o['module'] for o in out if o['identical']])
