# Task U（2026-11-21T01:35Z，Claude 代用户下达）：Kotzig K₆₄ 与 H₅ 行列式，两题并行

`$P = <workspace>`。输出目录 `$P/work/codex-r3/phase28/taskU/`，每题一个子目录：`kotzig64/`、`heisenberg125/`。各由一个独立的 Codex 会话负责，互不等待。

## 用户原话
"Kotzig 和 Heisenberg 也让 Codex 开始做"（看完 Task T 报告 `phase27/scout-t/REPORT.md` 之后）

## ① Kotzig K₆₄ 完美一因子分解（`kotzig64/`）
- 起点：`phase27/scout-t/attempts/kotzig64/` 与 REPORT 的 TC01 卡。已知：Z/63 starter 模板随机搜索最多 20/31；Cheng–Sgueglia 2026 命题 2.1 的 61 轮只替换一轮不够（已穷举 2,178,311 个完美匹配）。
- 目标：找到 K₆₄ 的完美一因子分解（63 个完美匹配，任意两个的并是一条 Hamilton 圈）。这是原题的完整解。
- 路线自定，例如：至少两轮同时替换；Pike 56 阶的双固定点构造，模数改为 62；其他群作用的 starter（如 Z₃×Z₂₁、Z₇×Z₉ 或非交换群）；SAT/精确覆盖配合对称性破缺；模拟退火或禁忌搜索换更好的目标函数。不要再扩大已失效的同一随机搜索。
- 找到见证后：照手册第 3.5 节核对原文 → 冻结陈述（零诊断预编译 + 非作者审查）→ Lean 用 Fin 64 与反射或 `decide` 验证 63 个匹配和 1953 对的 Hamilton 性。禁止 `native_decide`、`bv_decide`。
- 竞争高（公开 AI 题库点名 K₆₄）：每 24 小时查一次是否已有人公开 64 阶证书；若有，立即停手并报告。
- 止损：连续两条结构不同的路线都失败、并且有明确的障碍证明时，写报告停手。不硬凑。

## ② 125 阶 Heisenberg 群整数行列式（`heisenberg125/`）
- 起点：`phase27/scout-t/attempts/heisenberg125/LEAST.md`、`prior/REVIEW-H.md`、REPORT 的 TA01 卡。
- **目标 A（先做，必须完成）：** 最小的正 5-整除群行列式恰为 11·5²⁸。核对原文定义 → 冻结陈述（群行列式按 H₅ 的群环、整数取值的原定义写）→ Lean 完整证明：上界用见证 1+x+y+y²+xy²；下界照书面证明。125 阶行列式的计算要用经过证明的算法（例如在 Lean 里证过正确性的无分式消元，再用 `decide` 或反射），不能用 `native_decide`。
- **目标 B（并行书面攻题）：** 完整取值集合（Taussky–Todd 合同）。写到"完整证明"、"可信路线、卡在某一步"或"不可行"，如实写。B 有完整书面证明并经非作者核读后，也可冻结并开 Lean。
- 文献边界：Panraksa 2026 命题 4.7 已涵盖 p≥7 的部分；论文里只主张 p=5 的部分。

## 两题共同的流程与验收
- G2 查重按当前时间重做，写入 `<题>/G2.md`。
- 冻结后不改；写错就新建版本重新审查，旧版保留。
- 验收：两个新空根全闭包编译 + 逐模块 `leanchecker`；公理只有 propext、Classical.choice、Quot.sound；无 sorry/native_decide/bv_decide/axiom；`Check*.lean` 逐条 `theorem check_X : Challenge.X := Proof.X`。验收通过后写 `<题>/FINAL-HANDOFF.md`，由 Claude 安排跨族 FINAL。
- 书面稿 `<题>/MATHEMATICS.md`：写清哪些是前人的、哪些是新的。

## 机器
- Mac：Helly（Task T）也在 Mac 上跑 Lean，三方共用。Lean 编译一律走 `work/tools/leanlock.sh`；搜索计算 ≤6 核（两题合计不超过 8 核）、单任务 ≤60 分钟可分段续跑；内存紧张或 RSS 超 40 GB 降并发。
- **Windows 禁用**：正在跑 v1.25.0 发布重放。等 Claude 在 `CODEX-TASKS.md` 写明"Windows 释放"后，Kotzig 的大规模搜索可以迁到 Windows（按 commit 余量控制并发，这台机器 18 日蓝屏过一次）。

## 限制
- 零对外动作：不推送、不发帖、不开 issue/PR、不联系作者。
- 不碰 `$P/outputs/release/`、`$P/work/release-v*/`、`~/Desktop/AI4Math/我的笔记/`、`phase27/scout-t/attempts/helly-five/`。
- 不读 `~/.codex/auth.json`；请求里不放邮箱；不下载数据集或软件、不安装东西。时间一律 `date -u`。

## 报告
- 每题 `<题>/STATUS.md` 随时更新（一句话进度 + 下一步）。
- 找到见证、冻结陈述、验收通过、卡住或止损这几个节点，在 `CODEX-TASKS.md` 顶部各写一条。
- 该题到"验收通过"或"止损并说明原因"时，在 `<题>/` 写 `DONE`。
