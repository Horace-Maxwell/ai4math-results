# Cross-family FINAL review 01: least positive 5-divisible integer group determinant of H₅ (Task U ②, target A)

**Verdict: APPROVE_FORMAL.** There are no BLOCKER items and no MAJOR items. Both frozen targets are faithful to the Mossinghoff–Pinner definition, and both are fully Lean-verified:

- `TaskU.H5.Challenge.witnessValue`: det(F(gh⁻¹)) = 11·5²⁸ for F = 1+x+y+y²+xy².
- `TaskU.H5.Challenge.leastPositiveMultiple`: 11·5²⁸ is the least positive multiple of 5 among all integer group determinants of the order-125 Heisenberg group.

My independent rebuild compiled all 37 modules plus my audit file. leanchecker passed on all 38, and the only axioms are the standard three. My novelty search found no prior publication of 11·5²⁸ or of the p=5 minimum. The MINOR items below are write-up fixes only and do not affect the Lean result. Target B (full spectrum) is out of scope and is not Lean-verified. MATHEMATICS.md and FINAL-HANDOFF.md both say so correctly.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session. I wrote none of the reviewed files.
- Review started 2026-11-21T03:20:49Z. Report written after 2026-11-21T03:27:10Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-h5/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| TaskU/H5/Challenge.lean (= FREEZE.json value) | 9a9a0e18767ccf7efa7f6ea676d8aab883846444a66f4ffa27f1fdb3982f1343 |
| TaskU/H5/Check.lean | 5142f6c395ba28728c965baf3518e417b7f4bea3d66500a6532ae11140b34025 |
| TaskU/H5/CheckWitness.lean | 16071fdf39bf60a50426e8fd8d060a39d72471eba650e9ec90946bbbb1253c41 |
| TaskU/H5/Witness.lean | f74d43cd327ac66215e6e809da7725480dc71dae7f9c644fa678c22ea98c557c |
| TaskU/H5/WitnessBase.lean | 3d1a1a4f7e728eb63957749e7d7d85ce6e2d41240fe42cb4406f9f6a8fa1412f |
| TaskU/H5/WitnessEval.lean | ceb17279d9229fc243dacb4ff5bbfdae36e4eebcc6ee8fd7f8b697637f088dae |
| TaskU/H5/WitnessRows.lean | fd2faa5996bd3ea84ad81c88af8259f58ba0783c35302abeccb5b675b50987c0 |
| TaskU/H5/Minimum.lean | 7843196fac1f92ae550bb19c85b93b269392e0b34c9cc10bd31c13fb34b97bb9 |
| TaskU/H5/SmallMultiples.lean | 7857f523138fd50a2355daf1f941fe4298ab3a88c7082433bff476519ddca522 |
| TaskU/H5/IntegerFactors.lean | 480aaffccc68dee602b615a6aa795541161120718be892c53b9d6162816b03ae |
| TaskU/H5/Audit.lean | 8aa1cf8d0438410ab7f4c0b3995bdbd9a196e02e463828148ebc9aae9478bf5d |
| the other 26 TaskU/H5/*.lean | all equal to `receipt.json.source_sha256` (checked one by one) |
| FREEZE.json | 3e9b15243a267828cb99af92ef08faa26c04f79b4e74eebc9405c1df32048e9f |
| FREEZE-REVIEW.md | 4f98429d79de1880bd2ba33c10d0a5b361639bec8d25dab1dad9583900a4bdf4 |
| SOURCE-CHECK.md | 581b65fcabc20fa965c6c1c224243e6de5446c0e8b0fa364d4eab8597edad04a |
| G2.md | bd4dbe2048382b25811b5118c9acce6f878c22b1d6031052f979b5469bbb393c |
| MATHEMATICS.md | 82391c546154df843051cb335358e973e3bf8b866164bde46829df2e98b18cbe |
| FINAL-HANDOFF.md (= DONE value) | 4f2506eaef6afefd9901023002a85b8ffa503ed7fe1abeb850aa7c79b84d1092 |
| acceptance/both/2026-11-21T014255Z/receipt.json (= DONE/FINAL-HANDOFF value) | 6422e6e36d19a6498f9fcff1f4fb460fb1762e25b89bba27fe67a8c62a21fbd7 |
| arXiv:2108.04870v1 PDF (downloaded by me) | df8e03096f41fec3bc856d0df5087de585a1a5f760d6e8bde785b16e746ed04a |
| My ReviewAudit.lean (scratch) | ee3dc7cc830b9c3512947a83425c477a50734c24bbe954676f1b660e109d4c09 |

Hash checks:

- All 37 source hashes match `receipt.json`.
- The 37 `.lean` files in `TaskU/H5/` are byte-identical to `acceptance/.../root1` and `root2`.
- The Challenge hash matches `FREEZE.json`. The FREEZE-REVIEW and SOURCE-CHECK hashes also match `FREEZE.json`.
- There is no `frozen/` snapshot folder. FREEZE.json is the only freeze record (MINOR 6).

## 1. Are the statements faithful to the source?

I downloaded and extracted arXiv:2108.04870v1 myself: Mossinghoff–Pinner, "The integer group determinants for the Heisenberg group of order p³", published in Michigan Math. J. 74 (2024).

- **Determinant.** Eq. (1) defines the group determinant as det(a_{g_i g_j⁻¹}), "where i = 1,…,k indexes rows and j = 1,…,k columns". Eq. (2) defines S(G) as the set of these values "when the a_g are all integers". Lean's `groupDet f = det (Matrix.of fun g h => f (g * h⁻¹))` has row g and column h, so it is the same matrix. The coefficient function `f : H → ℤ` is unrestricted and gives one integer to each of the 125 group elements, negatives included. That is exactly the integer group ring.
  - The determinant does not depend on how the rows are ordered: Mathlib's `det` over a Fintype index is basis-free.
  - I also checked the other convention myself. With f(g⁻¹h) the witness determinant is again 409781932830810546875.
- **Group.** The source (p. 4) writes XᵃYᵇZᶜ as the unitriangular matrix with (1,2) = b, (2,3) = a and (1,3) = c, and it gives the relation yx = xyz.
  - Lean's `H` has three independent `ZMod 5` coordinates, so 125 elements. Its product is (a,b,c)(a′,b′,c′) = (a+a′, b+b′, c+c′+b·a′), which is exactly that matrix product. Its inverse is (−a, −b, −c+ba).
  - My Python check: associativity holds (sampled over 125·125·25 triples), the inverses are correct, and every g satisfies g⁵ = 1, so the exponent is 5. yx = xyz and yx ≠ xy, so H is non-abelian. The center is {(0,0,c)}, of order 5.
  - So H is the order-125 Heisenberg group UT₃(𝔽₅) (He₅). Lean also proves this: `Audit.order_check` (card = 125), `relation_check`, `noncommuting`, and in my ReviewAudit `∀ g, g^5 = 1`, `∀ g, g*g⁻¹ = 1 ∧ g⁻¹*g = 1` and non-commutativity, all by `decide +kernel`.
- **Witness.** `witness` is the indicator of {1, x, y, y², xy²} = {(0,0,0), (1,0,0), (0,1,0), (0,2,0), (1,2,0)}. These five points are distinct. `Audit.witness_support` proves this, and my Python agrees. `y^2` uses Monoid npow, and Lean evaluates it to (0,2,0).
- **IsLeast.** The set is `{m : ℤ | 0 < m ∧ 5 ∣ m ∧ ∃ f : H → ℤ, groupDet f = m}`, and Mathlib's `IsLeast` requires both membership and the lower-bound property. This quantifies over all integer f, requires strict positivity, and requires 5 ∣ m, as the task asks. My ReviewAudit checks by `Iff.rfl` that the frozen statement unfolds to this set with the explicit `Matrix.det (Matrix.of …)`. The set is non-empty because the witness is in it, and the statement is not vacuous.
- **Relation to the source.** Theorem 3.4 reads "If p | M_{H_p}(F) then p^{p²+3} | M_{H_p}(F). In addition, there exists a polynomial F with p^{p²+3} ∥ M_{H_p}(F)". The source therefore settles the 5-adic valuation 28 but not the least value.
  - Its own example for p=5 is F = 5 − x + 2y − y² (A = 2). I recomputed its full 125×125 determinant as 5²⁸·7²⁰·11·101·103²⁰·131·181·191·311 ≈ 2.3·10⁶⁹·5²⁸.
  - The new content is the exact minimum 11·5²⁸. SOURCE-CHECK states this boundary correctly.

## 2. Is the proof chain clean?

- **Check.lean** contains exactly `theorem check_witnessValue : Challenge.witnessValue := Proof.witnessValue` and `theorem check_leastPositiveMultiple : Challenge.leastPositiveMultiple := Proof.leastPositiveMultiple`, plus two `#print axioms`.
  - Only Challenge.lean opens `TaskU.H5.Challenge`. No other module defines a `Challenge` namespace, so nothing shadows a frozen name.
  - CheckWitness.lean has the same binding for the witness alone, as `TaskU.H5.check_witnessValue`.
  - My ReviewAudit compiles fully qualified `example`s for both `Check.*` and both `Proof.*` theorems. It also proves `witnessValue ↔ groupDet witness = 409781932830810546875` and `#print`s all frozen definitions. The printed definitions are as in §1.
- **Forbidden constructs.** I grepped all 37 files for `sorry`, `admit`, `native_decide`, `bv_decide`, `axiom`, `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `notation`, `initialize`, `run_cmd`, `ofReduceBool`, `attribute`. None appear. The rest:
  - `@[`: only `@[ext]` and `@[simp]`, in Cyc5.lean.
  - `set_option`: only `maxRecDepth`/`maxHeartbeats`, in CycNorm, CycPhase and WitnessEval.
  - `instance`: only `local instance : Fact (Nat.Prime 5)` (several modules) and two `local instance` Std.Associative/Commutative in CycPhase.
  - One dev log (`dev-logs/TraceOrbit-20261121T013515Z.log`) shows elaborator `sorry` placeholders from a failed development build. That build is not part of the accepted sources.
- **`decide` uses.** All `decide` uses are kernel-evaluated; `native_decide` appears nowhere. The large ones are:
  - WitnessEval: the 125×125 below-diagonal zero check and the two diagonal products, by `decide +kernel`.
  - WitnessBase: the `orderEquiv` round trips.
  - CycPhase:60: `energy v = 4 → ±ζᵏ`.
  - CycNorm: the norm-form identities.
  - Phase and RayMoments: small tables.
  - SmallMultiples: `interval_cases` on m ≤ 10 and n ≤ 10.
  - Audit: the group facts.
  - The other uses are small literal facts over ZMod 5 or ℕ.
- **Witness proof (certificate approach).** It works as follows:
  1. `left` is an explicit integer lower-triangular matrix L, packed as 18-bit digits in `WitnessRows`.
  2. `transformed` is defined from L by the five-term formula T_{ij} = Σ_{s∈supp} L_{i, enc(s·dec j)}.
  3. `transformed_eq : left * regular = transformed` is proven symbolically (simp over the group law), not computed. `regular` is the frozen matrix reindexed by a proven bijection `orderEquiv`, and `regular_det` uses `det_submatrix_equiv_self`.
  4. `transformed_upper` checks all below-diagonal entries are 0 by `decide +kernel`.
  5. With Mathlib's `det_mul`, `det_of_isUpperTriangular` and `det_of_isLowerTriangular`, the result is det L · det R = ∏T_ii.
  6. The two kernel-evaluated diagonal products have quotient exactly 409781932830810546875 with remainder 0 (I checked this in Python), and `linarith` closes the goal.

  This is a genuine kernel-checked computation, it uses proven triangular-determinant lemmas, and it uses no `native_decide`.
- **Independent determinant.** My own fraction-free Bareiss elimination in Python, on the full 125×125 integer matrix built from my own implementation of the group law, gives det = 409781932830810546875 = 5²⁸·11 (factored with sympy). It gives the same value under both conventions f(gh⁻¹) and f(g⁻¹h).
- **Lower-bound proof structure (Lean).** `Fourier` and `Blocks` turn the regular matrix into 25 blocks of size 5×5 via an explicit invertible Fourier matrix. `Factors` and `IntegerFactors` then derive `groupDet f = aug f · N(ray 1 0) · ∏ⱼ N(ray j 1) · N(nonlinear f)⁵` over ℤ. This is the Mossinghoff–Pinner factorization, proven from the matrix itself rather than cited. From there:
  - `Normalize` performs the change of basis that keeps the determinant.
  - `TraceWords`, `TraceIntegral` and `TraceAugment` give the congruence D ≡ c₀ and the trace identities.
  - `CycPhase`, `RayMoments`, `RayCancellation` and `TraceFinal` give the ±ζᵏ phase and the cancellation of the second moment.
  - `Minimum.baseline` gives 5 ∣ det ⇒ 5²⁸ ∣ det.
  - `Minimum.small` gives that det = 5²⁸m with 1 ≤ m ≤ 10 implies 5³³ ∣ det.
  - `SmallMultiples.least_from_small` combines these with `insufficient` (5³³ ∤ 5²⁸m for m ≤ 10) and the witness.

  The proof covers all f : H → ℤ, with no extra hypotheses.
- **Axioms.** In my rebuild, `Check.check_witnessValue`, `Check.check_leastPositiveMultiple`, `Proof.witnessValue`, `Proof.leastPositiveMultiple` and every other `#print axioms` output depend only on `[propext, Classical.choice, Quot.sound]`. Two Audit lemmas use a subset. The 13 axiom records in `receipt.json` agree.

## 3. Independent rebuild on this Mac

- **Setup.** I used a new empty directory `.../scratchpad/final-h5/` and copied the 37 `.lean` files to `src/`, adding `ReviewAudit.lean`. I did not use lake or any Codex build product.
  - Each module was compiled with plain `lean -o` in topological import order, with `-DautoImplicit=false -DrelaxedAutoImplicit=false -DwarningAsError=true` (as in the acceptance lakefile).
  - `LEAN_PATH` was my own `out/` plus the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`. Mathlib was not rebuilt.
- **Toolchain.** Lean 4.34.1. The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…). Mathlib is at `d13f23b723b8a846827a245b89c10fc7d3f11612` (`git rev-parse`, with GIT_NO_LAZY_FETCH=1).
- **Lock.** I ran `leanlock.sh acquire any claude-final-h5-01 60` and got slot A at 03:21:26Z. I released it (`released A`) at 03:27:05Z, after the last checker run. Only one Lean process ran at a time.
- **Result.**
  - All 38 modules compiled with exit 0, 0 warnings and 0 errors. The only output was the `#print`/`#print axioms` info.
  - `leanchecker` ran on each of the 38 modules (37 local + ReviewAudit). Every run exited 0 with empty output.
  - The slowest modules were Cyc5 (46 s), WitnessEval (23 s), Challenge (14 s) and CycNorm (12.5 s). Peak RSS for a single command was 5.58 GB.
  - My plain-`lean` oleans are not byte-identical to the lake-built acceptance oleans. That is expected because the build drivers differ, and it does not matter for correctness.

## 4. Mathematical sanity of MATHEMATICS.md and the handoff

**Target A.** The written proof of A is correct and matches what Lean proves. I checked each step:

- the M = M₁M₂⁵ factorization and Theorem 3.4 baseline;
- that 2, 3 and 7 are inert, so a fourth power would be forced;
- the dichotomy on the linear form (1+12+20 = 33 > 29);
- the conjugate-unit step Tr(ww̄) = 4 = Σ_{i<j}(cᵢ−cⱼ)², which forces w = ±ζᵏ;
- the phase formula k_j = 2B(j)/A − 1 and Σk_j = 0 over 𝔽₅;
- 5c₀ = t·N + Tr β, which gives 25 ∣ c₀ ⇒ π⁵ ∣ D ⇒ v₅ ≥ 33.

I also redid the attainment computation by hand:

- D = 3+2 = 5.
- The trivial factor of M₁ is 275.
- The four conjugates of −5(1+2(ζ²+ζ³)) multiply to 5⁶, because (1+2u)² = 5 with u = ζ²+ζ³.
- So M₁ = 11·5⁸ and M = 11·5²⁸, which agrees with my Bareiss value.

**Attribution and claims.** Attribution is right:

- the factorization, Theorem 3.4 and the coprime values go to Mossinghoff–Pinner;
- the three abelian seeds and C₅² go to Panraksa;
- the p≥7 critical-valuation obstruction is credited to Panraksa 2610.15262 Prop. 4.7;
- the general decidability goes to Bley–Hofmann–Johnston.

The text never claims priority ("first"). The handoff's "首个指数" is a mathematical "smallest exponent" and not a priority claim.

**Target B.** B is not presented as formally verified:

- The FINAL-HANDOFF table says "全谱尚未冻结或通过 Lean" and "B 的正式发表仍需要其完整 Lean 验收".
- MATHEMATICS.md says "此段为目标 B 的书面结果，正式 Lean 范围为目标 A 的两个冻结命题" and "目标 B 未有完整 Lean 验收".

**Novelty (special check 5).** As of 2026-11-21T03:2xZ I found no MAJOR novelty item.

- I searched the web (extended mode) and queried the arXiv API for "group determinant" sorted by date (40 newest entries, through 2026-11-05) and for Heisenberg + "group determinants".
- I read Panraksa arXiv:2610.15262v1 (first 100k characters). It treats only abelian C_p×C_p. It does not mention the Heisenberg group, order 125 or 5²⁸. For p=5 it lists only the abelian least value 5⁸.
- Mossinghoff–Pinner 2108.04870 gives only the valuation, and their example's cofactor is about 2.3·10⁶⁹ (§1). Mossinghoff–Pinner 2609.21224 (ℤ_pⁿ) and Panraksa 2608.04267 / 2609.09542 / 2609.10423 are abelian.
- Only White 2607.14379 is about H₁₂₅, and it treats the Davenport constant.
- Limits of this check: I did not read the paywalled Michigan Math. J. version or the KSU preprint (it returned an HTML page), and I did not search GitHub. G2 covers GitHub.

## MINOR write-up fixes

1. **MATHEMATICS.md, opening paragraph.** Add one explicit sentence on formal status. For example: "目标 A 的两条冻结命题（见证值 11·5²⁸ 与 IsLeast 最小性）已在 Lean 4 中完整验证（标准三公理）；B 部分全部为书面结果，未形式化。" At present the reader has to follow the STATUS.md link to learn what is Lean-verified.
2. **MATHEMATICS.md, "先前工作与下界".** The text says "Mossinghoff–Pinner 给出 M=t·∏ₗ N(α_l)·N(D)⁵". The source literally gives M = M₁M₂ᵖ with M₁ = ∏_{i,j}F(wⁱ,wʲ,1) and M₂ = ∏D(wʲ). The grouping of M₁ into augmentation × six ray norms is a standard regrouping by Galois orbits. Write "由其 M=M₁M₂⁵ 按射线分组得到", or similar.
3. **MATHEMATICS.md, prior work.** Optionally note that the source's own Theorem 3.4 example for p=5, F = 5 − x + 2y − y², has value 5²⁸·7²⁰·11·101·103²⁰·131·181·191·311. This makes clear the source did not already exhibit the minimum, which strengthens the novelty boundary.
4. **FINAL-HANDOFF.md, section "B 的取值判据".** The four bullets state B results without a qualifier. Add "（书面结果，未经 Lean 验证）" to the section heading. The table already says so.
5. **G2/G3 before release.** G2 is dated 2026-11-21T01:33Z, and the Michigan Math. J. journal version was not read (Incapsula block). Before publishing, rerun G3. If possible, also check the journal version for any added p=5 or H₅ examples.
6. **Freeze record.** Unlike earlier tasks, there is no `frozen/` snapshot copy of Challenge.lean. The hash in FREEZE.json and the identical acceptance-root copies are enough, but a snapshot folder would keep the record uniform with other tasks. Optional.
