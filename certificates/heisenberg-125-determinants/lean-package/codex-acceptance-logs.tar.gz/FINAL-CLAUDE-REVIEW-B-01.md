# Cross-family FINAL review B-01: the full integer group determinant spectrum of H₅ (Task U ②, target B)

**Verdict: APPROVE_FORMAL.** There are no BLOCKER items and no MAJOR items. The frozen statement `TaskU.H5.ChallengeB.fullSpectrum` is an exact set equality, stated as an iff for every signed integer m. Its left side quantifies over all f : H → ℤ, using the original Mossinghoff–Pinner group matrix of the exponent-5 Heisenberg group of order 125. The arithmetic predicate on the right encodes the claimed classification faithfully, and it is not vacuous. The statement is fully Lean-verified: my independent rebuild compiled all 63 modules plus my audit file, leanchecker passed on all 64, and the only axioms are propext, Classical.choice and Quot.sound. My literature search found no prior publication of the H₅ spectrum. The MINOR items concern only the write-up and status lines. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), a subagent of the user's Claude session, reviewer B-01 of two. I wrote none of the reviewed files and did not read FINAL-CLAUDE-REVIEW-B-02.md.
- Review started 2026-11-21T03:57:31Z. Report written after 2026-11-21T04:41:40Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/h5b01/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| formal-b/TaskU/H5B/ChallengeB.lean (= FREEZE-B.json and FINAL-HANDOFF-B/DONE-B value) | 2a5066bfefb308bffbf31bdc568709a23f9177cb5ae3298cba198cf28cdf9ea6 |
| formal-b/TaskU/H5B/CheckB.lean | 628d604fd5901aa9ee9e50be382269ed806a90ac1aeaa0d1a4afda4d3b982cf5 |
| formal-b/TaskU/H5B/ProofB.lean | e7f5d25e44f8124cc2222e22026711411f295a7db8edec73a58dfe9596623ff1 |
| TaskU/H5/Challenge.lean (A, unchanged) | 9a9a0e18767ccf7efa7f6ea676d8aab883846444a66f4ffa27f1fdb3982f1343 |
| TaskU/H5/Cyc5.lean (A, unchanged; defines V, mul, norm) | 9061b2ada36d376f82f9985eabbe7460bc66db7c900b11722bbce1ced54e6cf9 |
| FREEZE-B.json | b3fde6ed7973653c03b3e32455e9064ff0b646dfd19fe6a95a25e0f07e0bc239 |
| b/FREEZE-REVIEW-B.md (= FREEZE-B value) | 5a39707d47ef0aa68c1a09855c7414b216e9031b507972ad7962ac45acbeed75 |
| b/FORMAL-SOURCE-B.md (= FREEZE-B value) | ab350b47e5d362824987051050004188bd5b0436970d325095eeb39c795af2e1 |
| b/CLASSIFICATION.md (= FREEZE-B value) | 247f08b0c0d73b695f6678169b8d0d4546db4d10b5eb443b89f94cda2e1abfa3 |
| b/UPPER-TAIL.md | 9d3ebf4bf44bf83eed826ef5baf7833afb60c2551aca6dcbd286916c84744bef |
| b/CLASSIFICATION-REVIEW.md | 6fffd0d4606c9027b2bd4924efac42ed2189dc8a73b259dbe8990a463d29b2a5 |
| b/CLASSIFICATION-SUFFICIENCY-REVIEW.md | 1276673f68139569288b878653c8becda33466d1d189b49b1c5fdb6b0efcc970 |
| G2-B.md | 0695d3549cccdeed12625742dff5702cb91c57f2e93d9a0783d75a9662499894 |
| FINAL-HANDOFF-B.md (= DONE-B value) | d02789058ba1f73a89bc0a6f680446b62ff9b15382379303ef02de28a013f3af |
| acceptance/spectrum/2026-11-21T033317Z/receipt.json (= handoff value) | 76bb2cfd89cf987a6d62c33b3b23b953d93661bfe69b6bfb7252400f0d89d4ef |
| acceptance/spectrum/2026-11-21T033317Z/postcheck.json (= handoff value) | e3bbd75650c702c24ca9fccc6000fd2eee4ad1ad1df6aa24515818877ec52e59 |
| acceptance/both/2026-11-21T014255Z/receipt.json (A acceptance, = FREEZE-B value) | 6422e6e36d19a6498f9fcff1f4fb460fb1762e25b89bba27fe67a8c62a21fbd7 |
| arXiv 2108.04870v1 PDF (I downloaded it) | df8e03096f41fec3bc856d0df5087de585a1a5f760d6e8bde785b16e746ed04a |
| My AuditB01.lean (scratch) | 40d5202a8bfa00e0fc47d1ac345036bcf6e611772c2c530b201000370ce45eb8 |

Hash checks:

- **Receipt sources.** All 63 `source_sha256` entries in the spectrum receipt match the files on disk.
- **The 26 B files.** The copies in formal-b/TaskU/H5B and TaskU/H5B are byte-identical.
- **The 37 A files.** All 37 TaskU/H5 files match the accepted A receipt (`acceptance/both/2026-11-21T014255Z`) exactly. The set of module names is the same, with none missing and none extra. They also match the `immutable_A_modules` list in FREEZE-B.json.
- **Freeze record.** The receipt's `freeze_sha256` equals the SHA of FREEZE-B.json.

## 1. Is the statement faithful to the source?

**Source.** I extracted the arXiv v1 text of Mossinghoff–Pinner myself. Two points from it:

- **Definitions.** The group determinant is D = det(a_{g_i g_j⁻¹}). S(G) is its value set "when the a_g are all integers". The group is H_p = {xᵃyᵇzᶜ} with z central and yx = xyz.
- **Results for p = 5.**
  - Corollary 3.2 reads "S₁(H_p) = T₃ = {x ∈ Z : x^{p−1} ≡ 1 mod p³}". For p = 5 this is m⁴ ≡ 1 (mod 125).
  - Theorem 3.4 reads "If p | M_{H_p}(F) then p^{p²+3} | M_{H_p}(F)". For p = 5 that exponent is 28.
  - The paper determines all values only for p = 3 (Theorem 3.6). It leaves S₀(H₅) open.

**Lean left side.** `groupDet f = det (Matrix.of fun g h => f (g * h⁻¹))` is quantified over all f : H → ℤ, with one free integer per element. There is no positivity or other side condition, and m ranges over all of ℤ.

- **Group law.** In H, ⟨a,b,c⟩·⟨a',b',c'⟩ = ⟨a+a', b+b', c+c'+b·a'⟩. This is exactly xᵃyᵇzᶜ multiplication under yx = xyz. My Python computes g·(g⁻¹) = 1 for all 125 elements.
- **Isomorphism type.** The group is non-abelian of exponent 5 and order 125, so it is H₅.
- **Audit check.** My audit proves by `rfl` that `groupDet` is the displayed determinant, and by `decide +kernel` that the card is 125.

**Lean right side.** It is a disjunction of three branches:

1. `m^4 ≡ 1 [ZMOD 125]`;
2. `5^33 ∣ m`, which covers 0 and every signed multiple;
3. `∃ n ≠ 0, m = 5^28·n ∧ ∃ q : ℕ, visible q ∧ (q:ℤ) ∣ n`.

Here `visible q` means: q is prime, q % 5 = 1, and some x ∈ ℤ[ζ₅] with `Cyc5.norm x = q` is not congruent mod 5R to a global unit. A global unit u is one with an integer inverse v, `mul u v = scalar 1`. This is exactly the handoff's classification, including the 1 ≤ v₅ ≤ 27 exclusion and the value 0. My audit restates `fullSpectrum` and `visible` with every definition unfolded, and closes both with `Iff.rfl`.

**The arithmetic encoding, tested with my own Python** (`py/pred.py`, `py/vis2.py`):

- **Cyc5.mul.** It agrees with multiplication in ℤ[ζ₅] (basis 1, ζ, ζ², ζ³) at all four complex embeddings, on 2000 random pairs.
- **Cyc5.norm.** It equals the product of the four conjugates, so it is the full field norm, which is always ≥ 0.
- **Unit groups.** The image of ⟨−1, ζ, φ⟩ in (R/5R)^× has 100 elements, and the whole unit group has 500. The "outside U" condition is therefore index 5. It is non-trivial, but not everything.
- **Choice-independence.** For every prime q ≡ 1 mod 5 below 2000, I enumerated all norm-q elements in the box |coeff| ≤ 6. Every norm-q element of the same q gave the same verdict, so no choice dependence appeared. This agrees with the theoretical argument: generators differ by units, and the Galois action σ_k sends the class d to k³d.
- **Prime 5.** Without the `q % 5 = 1` guard, q = 5 would count as visible, because π = 1−ζ has norm 5 and is not a unit mod 5. The guard is present.
- **Visible and invisible primes below 600.**
  - Visible: 11, 31, 41, 61, 71, 101, 131, 151, 181, 191, 241, 251, 271, 311, 331, 401, 431, 491, 541, 571.
  - Invisible: 211, 281, 421, 461, 521.
  - An LLL-based generator search agrees with the box search on all 73 primes.
- **Predicate on sample integers.**
  - Values: 0, ±1, ±57, 124, 126, 11·5²⁸, −11·5²⁸, 31·5²⁸, 11·5²⁹, 11·5³², 11·211·5²⁸, 5³³, −5³³, 2·5³³.
  - Non-values: 2, 7, 5, 11·5²⁷, 3·5²⁸, 5²⁸, 211·5²⁸, 5³².
  - All of these match the handoff, including "11·5²⁸ yes, 211·5²⁸ no, 5³² no, 5³³ yes".

**Actual 125×125 determinants.** I computed these with my own fraction-free Bareiss code, using the Lean multiplication law (`py/det.py`):

- **A witness.** 1+x+y+y²+xy² gives exactly 11·5²⁸.
- **Coprime seeds.** I re-implemented the Lean definition `Coprime.coprimeSeed` from the source text. For (e,k) = (T,0), (F,0), (T,1), (F,−2), (T,−1) it gives 57, 1, 182, −249, −68. These equal the values claimed by `seed_det`.
- **The 15 shipped low-layer examples** (b/sufficiency-examples). Each gives exactly n·5²⁸, for n = ±11, −217, ±22, ±55, 1375, 275, 31, 33, 41, 44, 6875, 710.
- **Fresh constructions.** I generated coefficient vectors with the project's constructor (a copy run with `-I`) and checked them with my own Bareiss:
  - Values confirmed: 5³³, −2·5³³, 7·5³⁴, 77·5²⁸, 61·5³⁰, −131·5³², 2321·5²⁹ (where 211 is invisible but 11 is visible), and −123·5²⁸.
  - Coprime values confirmed: 182 and −68.
  - The constructor returns "outside" for 3·5²⁸, 5³², 211·5²⁸, 281·5³¹ and 11·5²⁷.
- **Necessity stress test (`py/rnd.py`).** I computed exact determinants of 4,650 random f of three kinds: random ±1 entries, perturbations of the witness, and sparse vectors. I factored each through the M₁·N(D)⁵ decomposition: the augmentation, six ray norms, and an exact fifth root.
  - Every 5-divisible determinant had v₅ ≥ 28.
  - 1,706 determinants fell in the 28–32 band (v₅ = 28, 29, 30, 31, 32 all occurred). Every one had a visible prime factor.
  - Every coprime determinant satisfied m⁴ ≡ 1 (mod 125).
  - There were 0 counterexamples.

**Non-degeneracy.**

- The statement is an iff for each m, so it fixes membership exactly.
- In my audit, the frozen statement proves that 0 is a value and that 5 is not, by unfolding branch 1 with `decide` and branches 2 and 3 with `omega`. Neither direction is trivial.
- No `Nat.card` or `ncard` is involved.

## 2. Proof chain

- **Check file.** CheckB.lean is exactly `theorem check_fullSpectrum : ChallengeB.fullSpectrum := ProofB.fullSpectrum` inside `namespace TaskU.H5`. My audit uses fully qualified names and confirms that it binds `TaskU.H5.ChallengeB.fullSpectrum` to `TaskU.H5.ProofB.fullSpectrum`. No local file redefines `groupDet`, `H`, `fullSpectrum`, `visible`, `unitImage`, `congrFive`, `Cyc5.mul` or `Cyc5.norm`.
- **Instances.** LiftRing.lean adds `CommRing` and `AddCommGroup` instances on `Cyc5.V`. PrimeRing.lean adds `IsDomain` and `IsPrincipalIdealRing`. The frozen statement uses the explicit functions `Cyc5.mul` and `Cyc5.norm`, not `*`, and it is elaborated before those modules. Its meaning is therefore unaffected, and the `Iff.rfl` restatement confirms this.
- **ProofB.** It splits on 5 ∣ det. It uses `Coprime.coprime_necessary` and `Spectrum.divisible_necessary` for the forward direction. It uses `coprime_sufficient`, `high_sufficient` and `low_sufficient` for the reverse direction. None of these takes a hypothesis beyond the statement's own data.
- **The cited inputs are proved, not assumed.**
  - Mossinghoff–Pinner's coprime layer is proved in both directions: CoprimeCongruence derives the congruence mod 125 from the A factorization, and CoprimeSeeds gives the explicit seeds.
  - The 5²⁸ lower bound comes from the accepted A modules.
  - Panraksa's three seeds are kernel-checked from explicit coefficients in Seeds/SeedMarginals.
  - The class-number-one fact for ℤ[ζ₅] comes from Mathlib's proved theorem (PrimeBasis/PrimeRing).
  - No axiom, opaque constant or hypothesis is threaded into the main theorem.
- **Grep over the 26 B files.** I searched for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, initialize, run_cmd, ofReduceBool and ofReduceNat. There are no hits.
  - `set_option` appears only as scoped `maxRecDepth` and `maxHeartbeats` settings in LiftColumns.lean (2) and UnitTable.lean (3).
  - The only attribute is `@[simp]`.
  - `local instance Fact (Nat.Prime 5)` appears 3 times.
- **`decide` uses.** There are 21 `decide +kernel` and 29 plain `decide` in B. All are kernel-checked, with no native evaluation.
- **Axioms.** The receipt's 16 axiom reports and my rebuild agree: `TaskU.H5.ProofB.fullSpectrum` and `TaskU.H5.check_fullSpectrum` depend only on [propext, Classical.choice, Quot.sound].

## 3. Independent rebuild on this Mac

- **Lock.** Owner `claude-final-h5b-01`. I acquired slot B at 2026-11-21T04:29:23Z after waiting for other agents, and released it at 04:40:46Z. I took it again twice, briefly, to recompile and recheck my corrected audit file, and released it each time by 04:41:20Z. `leanlock.sh status` then showed B free. I ran one Lean process at a time.
- **Inputs.** I copied the 37 A sources and 26 B sources into a new scratch tree after the hash check above. I compiled them in import order with plain `lean -o` (Lean 4.34.1, `-DautoImplicit=false`), using the prebuilt Mathlib d13f23b7 oleans through LEAN_PATH, into a new empty output directory.
- **Results.**
  - 63/63 modules compiled with rc 0, 0 warnings and 0 errors.
  - leanchecker returned rc 0 with empty output on all 63.
  - Peak RSS was 7.12 GB (LiftColumns, 34.5 s). UnitTable took 26.6 s at 6.15 GB.
- **My AuditB01.lean** (under TaskU/H5B, importing CheckB) contains the fully qualified examples described above. It compiled with rc 0 and passed leanchecker with rc 0, and `#print axioms` shows the standard three.
  - The first version used plain `decide` for `Fintype.card H = 125`. That line hit the recursion limit, and the rest of the file was accepted.
  - I changed it to `decide +kernel`, which is how A's `Audit.order_check` proves it, and recompiled.
- **Note.** My .olean hashes differ from the acceptance roots. This is expected, because the acceptance roots were built by Lake and mine by plain `lean -o`. It is not a finding.

## 4. Mathematics and prior work

- **Written proof.** CLASSIFICATION.md §§2–4 and UPPER-TAIL.md §Ⅰ are consistent with the Lean decomposition. I recomputed the trace facts: Tr(πᵏ) = 5, 5, 5, 5, 0, −25, −100, −275, −625 for k = 1..9. So Tr(π⁴) = 5 and Tr(π⁸) = −275 ≡ −25 (mod 125), as claimed. The written argument is not load-bearing, because the full iff is in Lean.
- **Attribution.**
  - The coprime layer (Cor. 3.2) and the 5²⁸ bound (Thm 3.4) are credited to Mossinghoff–Pinner.
  - The three abelian seeds are credited to Panraksa, arXiv:2608.04267 Prop. 3.1. I checked that F₁, F₂, F₅ there have M = 5⁸, 2·5⁸, 5⁹, with ray norms 25 and five times 5.
  - The C₇² cofactor strategy is credited as precedent to arXiv:2609.09542.
  - General decidability is credited to Bley–Hofmann–Johnston.
- **No priority claims.** None of the B docs claims "first" or "首次".
- **Prior-work search.** I ran these myself: an arXiv API search for all "group determinants" titles and abstracts sorted by date (through 2026-11), "group determinant" AND Heisenberg, web searches, and DataCite for "group determinants", "Heisenberg … determinant", "order 125" and creator Radolović. I also used OpenAlex's cited-by list for MP, as recorded in g2-b, because OpenAlex refused me with a rate limit.
  - I found no description of S(H₅) or S₀(H₅), whether partial or complete. MP settles only p = 3.
  - The Panraksa papers (2608.04267, 2609.09542, 2610.15262 for p ≥ 7) and the paper on Z_pⁿ (2609.21224) treat abelian groups only, and cite MP only in passing.
  - White, arXiv:2607.14379, is about the Davenport constant of the same group, not determinants.
  - There are no MAJOR novelty items.
- **Competition risk (no action needed for the formal verdict).** A. Radolović has posted a fast Zenodo series of complete group-determinant classifications: orders 20, 27, 28 and 49 in Sep 2026, plus many circulant papers. Order 27 includes the non-abelian groups. This group is the most likely to post H₅ or order 125 next, so the G3 recheck before publication should look at this series and at DataCite specifically.

## MINOR fixes (write-up only)

1. **Stale header in CLASSIFICATION.md.** Line 3 still reads "作者书面证明，等待独立核读及形式验证", and UPPER-TAIL.md opens with "整套论证尚待非作者数学复核和 Lean". Both should now point to the passed formal acceptance and this FINAL. Without the change, a reader may think the result is unverified.
2. **Outdated A documents.** MATHEMATICS.md and FINAL-HANDOFF.md, which are the A documents, still describe B as an early finite criterion or as not Lean-verified. MATHEMATICS.md says "随后获得了下述按素因子的直接判据" but never states that criterion. Before release, add a B section with the three-branch theorem, the definition of U and of "visible", the examples 11 visible and 211 invisible, and its Lean status. Alternatively, ship CLASSIFICATION.md as the B write-up with an updated header.
3. **Choice-independence wording.** The handoff phrases branch 3 as "范数为 ℓ 的某个圆分整数模 5R 落在 U 外". Add one sentence saying this is independent of which norm-ℓ element is chosen, because units and Galois conjugates preserve the class up to d ↦ k³d. The Lean statement uses ∃, and the write-up should say why ∃ and ∀ agree, so that readers do not suspect a weaker statement.
4. **Name the full set of declarations.** In the publication text, name all four Lean declarations: `TaskU.H5.ChallengeB.fullSpectrum`, `visible`, `unitImage`, `congrFive`. State that `Cyc5.norm` is the full degree-4 field norm, and give the basis 1, ζ, ζ², ζ³ explicitly. The predicate is only meaningful with these definitions in view.
5. **List the competing series in G2/G3.** In the G2/G3 record, add the Radolović Zenodo series (DataCite query "creators.name:Radolovi*") and DataCite searches as standing checks. The order-27 record (10.5281/zenodo.22713315) is already cited, but the series as a whole is the main priority risk for H₅.
