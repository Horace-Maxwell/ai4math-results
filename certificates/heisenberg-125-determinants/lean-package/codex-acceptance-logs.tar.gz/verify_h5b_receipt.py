"""Independent verification of the two roots and the process-level command records."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

import sys
folder = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit('supply a completed B acceptance directory')
run = Path(sys.argv[1]).resolve()
if run.parent != folder/'acceptance/spectrum': raise ValueError(run)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text())
receipt = read(run/'receipt.json')
assert receipt['status']=='MACHINE_PASS_B_PENDING_CLAUDE_FINAL'
assert receipt['checked_targets']==['fullSpectrum']
assert receipt['roots']['root1']==receipt['roots']['root2']
assert digest(folder/'accept_h5b.py')==receipt['runner_sha256']
assert digest(folder/'FREEZE-B.json')==receipt['freeze_sha256']
for f,h in read(folder/'FREEZE-B.json')['verified_inputs'].items():
    assert digest(folder/f)==h
order=receipt['order']
frozen=read(folder/'FREEZE-B.json')
old=set(frozen['immutable_A_modules'])
new={'.'.join(p.relative_to(folder/'formal-b').with_suffix('').parts)
     for p in (folder/'formal-b/TaskU/H5B').rglob('*.lean')}
assert len(old)==37 and len(order)==len(set(order)) and set(order)==new|old
for m,h in frozen['immutable_A_modules'].items():
    assert receipt['source_sha256'][m]==h
for mod,h in receipt['source_sha256'].items():
    assert digest(folder/(mod.replace('.','/')+'.lean'))==h
out={'status':'VERIFIED','utc':subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip(),
     'receipt_sha256':digest(run/'receipt.json'),'dependency_commits':len(receipt['dependency_commits']),
     'local_modules':len(order),'frozen_A':len(old),'new_B':len(new),'source_manifest_rechecked':True,'same_objects_and_axioms':True,
     'roots':{}}
for name,state in receipt['roots'].items():
    r=run/name
    logs=run/(name+'-logs')
    exact={f'{i}-{stage}.json' for i in range(len(order)) for stage in ['build','checker']}|{'all.json'}
    assert {p.name for p in logs.glob('*.json') if p.name!='external-cache-links.json'}==exact
    assert set(state['modules'])==set(order)
    for mod,h in state['modules'].items():
        stem=mod.replace('.','/')
        assert digest(r/'.lake/build/lib/lean'/(stem+'.olean'))==h
        assert digest(r/(stem+'.lean'))==receipt['source_sha256'][mod]
    for h in state['axioms'].values():
        assert set(h)<={'propext','Classical.choice','Quot.sound'}
    for target in receipt['checked_targets']:
        for proof in ['TaskU.H5.check_'+target,'TaskU.H5.ProofB.'+target]:
            assert proof in state['axioms']
    rows=[read(logs/p) for p in exact]
    for row in rows:
        path=Path(row['log'])
        assert row['cwd']==str(r) and path.parent==logs and row['exit']==0
        assert digest(path)==row['log_sha256']
        assert digest(path.with_suffix('.resources'))==row['resource_log_sha256']
        assert not re.search(r'\b(error|warning):',path.read_text(),re.I)
        if path.name.endswith('-checker.log'):
            assert row['command'][-2:] == ['leanchecker',order[int(path.name.split('-')[0])]]
            assert path.stat().st_size==0
    out['roots'][name]={'commands':len(rows),'module_builds':len(order),'leancheckers':len(order),
                        'reported_declarations':state['axioms'],'peak_rss_bytes':max(x['peak_resident_bytes'] for x in rows)}
print(json.dumps(out,ensure_ascii=False,indent=2))
