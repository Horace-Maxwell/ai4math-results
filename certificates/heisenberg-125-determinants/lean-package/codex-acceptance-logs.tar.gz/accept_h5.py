"""Replay a Task U H5 check module and every local import in two independent Mac roots."""
from __future__ import annotations
import argparse
from graphlib import TopologicalSorter
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
os.environ["GIT_NO_LAZY_FETCH"] = "1"
HERE = Path(__file__).resolve().parent
support = HERE.parents[2] / 'phase26/taskS'
sys.path.insert(0,str(support))
from dev import BIN, PACKAGES, WORK, local_slot, utc

old = WORK / 'codex-r3/phase17/taskH/mac-runtime-candidate04'
sys.path.insert(0, str(old))
from canonical_original import lean_code
from contract import ALLOWED, AXIOMS, FORBIDDEN

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(p, obj):
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n')

def run(cmd, cwd, env, log):
    start = utc()
    began = time.monotonic()
    resources = log.with_suffix('.resources')
    # wait4 reports the command's child-accounted maximum RSS in bytes on Darwin.
    with log.open('w') as fp:
        proc = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=fp, stderr=subprocess.STDOUT)
        _, status, usage = os.wait4(proc.pid, 0)
        proc.returncode = os.waitstatus_to_exitcode(status)
        result = proc
    resources.write_text(f'{usage.ru_maxrss} maximum resident set size\n')
    record = {'command': list(map(str,cmd)), 'cwd': str(cwd), 'start_utc': start,
              'end_utc': utc(), 'seconds': time.monotonic()-began, 'exit': result.returncode,
              'log': str(log), 'log_sha256': sha(log)}
    peak = re.search(r'^\s*(\d+)\s+maximum resident set size\s*$',resources.read_text(),re.M)
    record.update(peak_resident_bytes=int(peak[1]) if peak else None, resource_log_sha256=sha(resources))
    save(log.with_suffix('.json'),record)
    if not peak: raise RuntimeError(('missing wait4 maximum RSS',str(resources)))
    if result.returncode:
        raise RuntimeError(f'command failed, exit {result.returncode}: {log}')
    raw = log.read_text()
    if re.search(r'\b(?:warning|error):',raw,re.I):
        raise RuntimeError(f'diagnostics: {log}')
    return raw

def dependency_map(folder, check):
    files, graph = {}, {}
    pending = [check]
    while pending:
        name = pending.pop()
        if name in files:
            continue
        src = folder / (name.replace('.','/')+'.lean')
        code = lean_code(src.read_text())
        if FORBIDDEN.search(code) or re.search(r'\bdecide\s*\+native\b',code):
            raise ValueError(f'forbidden source token in {src}')
        imports = re.findall(r'^\s*(?:public\s+)?import\s+([\w.]+)\s*$',code,re.M)
        if not imports or len(imports)!=len(re.findall(r'^\s*(?:public\s+)?import\s+',code,re.M)):
            raise ValueError(f'unsupported import syntax in {src}')
        parents = [s for s in imports if s != 'Mathlib' and not s.startswith(('Mathlib.','Init.','Std.','Lean.')) and s not in ('Std','Lean','Init')]
        files[name]=src
        graph[name]=parents
        pending += parents
    return files, list(TopologicalSorter(graph).static_order())

def replay(lane, check):
    folder = HERE
    frozen_path = folder/'FREEZE.json'
    freeze = json.loads(frozen_path.read_text())
    for name, pinned in freeze['verified_inputs'].items():
        if sha(folder/name) != pinned: raise RuntimeError(('frozen artifact drift',name))
    files, order = dependency_map(folder,check)
    if 'TaskU.H5.Challenge' not in files: raise RuntimeError('check must import frozen challenge')
    expected_checks = {'witnessValue'} if lane=='witness' else {'witnessValue','leastPositiveMultiple'}
    if not {'TaskU.H5.Challenge.'+t for t in expected_checks} <= set(freeze['targets']):
        raise RuntimeError('check targets missing from frozen contract')
    source = lean_code(files[check].read_text())
    if any(not re.search(r'\btheorem\s+check_'+re.escape(t)+r'\s*:\s*(?:\w+\.)*Challenge\.'+re.escape(t)+r'\s*:=\s*(?:\w+\.)*Proof\.'+re.escape(t)+r'\b',source) for t in expected_checks):
        raise RuntimeError('missing literal typed Check witness')
    if lane == 'both':
        all_sources = {'.'.join(path.relative_to(folder).with_suffix('').parts)
                       for path in (folder / 'TaskU').rglob('*.lean')}
        if all_sources != set(files):
            raise RuntimeError(('source outside documented full closure', sorted(all_sources - set(files))))
    pins = {m:sha(p) for m,p in files.items()}
    stamp = utc().replace(':','')
    dest = folder/'acceptance'/lane/stamp
    dest.mkdir(parents=True,exist_ok=False)
    manifest = WORK/'research-lean-v434/lake-manifest.json'
    dep_pins = {}
    for package in json.loads(manifest.read_text())['packages']:
        path = PACKAGES/package['name']
        commit = subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
        if commit!=package['rev']: raise RuntimeError(('dependency pin',package['name'],commit))
        dep_pins[package['name']]=commit
    env = {'PATH':str(BIN)+':/usr/bin:/bin:/usr/sbin:/sbin', 'HOME':os.environ['HOME'],
           'GIT_NO_LAZY_FETCH':'1','LC_ALL':'C','LEAN_PATH':os.pathsep.join(str(PACKAGES/n/'.lake/build/lib/lean') for n in dep_pins if (PACKAGES/n/'.lake/build/lib/lean').is_dir()),
           'LAKE_ARTIFACT_CACHE':'false','LAKE_RESTORE_ARTIFACTS':'false',
           'GIT_CONFIG_COUNT':'1','GIT_CONFIG_KEY_0':'protocol.allow','GIT_CONFIG_VALUE_0':'never'}
    receipt={'status':'RUNNING','utc':utc(),'source_sha256':pins,'freeze_sha256':sha(folder/'FREEZE.json'),
             'dependency_commits':dep_pins,'dependency_manifest_sha256':sha(manifest),
             'runner_sha256':sha(Path(__file__)), 'prior_lock_wrapper_sha256':sha(support.parents[1]/'phase25/taskR/dev.py'), 'local_support_sha256':sha(support/'dev.py'), 'lane':lane, 'checked_targets':sorted(expected_checks),
             'lean_version':subprocess.check_output([BIN/'lean','--version'],text=True).strip(),
             'tools':{n:sha(BIN/n) for n in ('lean','lake','leanchecker')},'order':order,'roots':{}}
    save(dest/'receipt.json',receipt)
    try:
        with local_slot('taskU-H5-final-'+lane+'-'+stamp) as slots:
            receipt['lock_slots'] = slots
            for label in ['root1','root2']:
                root = dest/label
                root.mkdir(exist_ok=False)
                if list(root.iterdir()): raise RuntimeError('fresh root not empty')
                logs = dest/(label+'-logs');logs.mkdir()
                # Lake builds with its own LEAN_PATH. Expose only the pinned external
                # package namespaces there; no Task S artifacts or project cache enter.
                lib = root/'.lake/build/lib/lean'
                lib.mkdir(parents=True)
                linked = {}
                owned_names = {m.split('.')[0] for m in order}
                for candidate in env['LEAN_PATH'].split(os.pathsep):
                    for ext in Path(candidate).iterdir():
                        if not ext.is_dir() and not any(ext.name.endswith(s) for s in
                            ('.olean','.olean.private','.olean.server','.ir','.ir.sig','.ilean')):
                            continue
                        if ext.name.split('.')[0] in owned_names:
                            raise RuntimeError(('external namespace clashes with local module',str(ext)))
                        link = lib/ext.name
                        if link.exists():
                            raise RuntimeError(('cache namespace collision',str(link),str(ext)))
                        link.symlink_to(ext,target_is_directory=ext.is_dir())
                        linked[ext.name]=str(ext)
                save(logs/'external-cache-links.json',linked)
                (root/'lean-toolchain').write_bytes((WORK/'research-lean-v434/lean-toolchain').read_bytes())
                for m,p in files.items():
                    target=root/(m.replace('.','/')+'.lean');target.parent.mkdir(parents=True,exist_ok=True)
                    target.write_bytes(p.read_bytes())
                    if sha(target)!=pins[m]: raise RuntimeError(('source changed',m))
                opts = 'name = "tasku_h5_'+lane.replace('-','_')+'"\ndefaultTargets = ["TaskU"]\n\n[leanOptions]\nautoImplicit = false\nrelaxedAutoImplicit = false\nwarningAsError = true\n\n[[lean_lib]]\nname = "TaskU"\nroots = '+json.dumps(order)+'\n'
                (root/'lakefile.toml').write_text(opts)
                env['LAKE_CACHE_DIR']=str(root/'.isolated-cache')
                state={'init':'new empty directory','modules':{},'axioms':{}}
                for i,m in enumerate(order):
                    log=logs/(str(i)+'-build.log')
                    info=run([BIN/'lake','--no-cache','--wfail','build','+'+m+':olean'],root,env,log)
                    if not re.search(r'\bBuilt '+re.escape(m)+r'\s*\(',info):
                        raise RuntimeError(('no actual fresh build for module',m))
                    lake_setup = {f'info: tasku_h5_{lane}: no previous manifest, creating one from scratch',
                                  'info: toolchain not updated; already up-to-date'}
                    audit_output = [line for line in info.splitlines()
                                    if line.startswith('info:') and line not in lake_setup]
                    for line in audit_output:
                        if not re.fullmatch(r"info: [^:]+:\d+:\d+: " + AXIOMS.pattern, line):
                            raise RuntimeError(('unparsed compiler message',m,line))
                    expected_prints = re.findall(r'^\s*#print\s+axioms\s+([\w.]+)',lean_code(files[m].read_text()),re.M)
                    module_output = [line for line in audit_output if line.startswith('info: '+m.replace('.','/')+'.lean:')]
                    module_names = [AXIOMS.search(line)[1] for line in module_output]
                    if len(module_names) != len(expected_prints) or any(
                            actual.split('.')[-1] != ref.split('.')[-1]
                            for actual, ref in zip(module_names, expected_prints)):
                        raise RuntimeError(('incomplete module axiom prints',m,expected_prints,module_names))
                    for match in AXIOMS.finditer(info):
                        name=match[1]; ax={s.strip() for s in (match[2] or '').split(',') if s.strip()}
                        if not ax<=ALLOWED:raise RuntimeError(('axioms',name,ax))
                        if name in state['axioms'] and state['axioms'][name]!=sorted(ax):raise RuntimeError(('inconsistent axiom report',name))
                        state['axioms'][name]=sorted(ax)
                    obj=root/'.lake/build/lib/lean'/(m.replace('.','/')+'.olean')
                    if not obj.is_file():raise RuntimeError(('missing olean',m))
                    state['modules'][m]=sha(obj)
                run([BIN/'lake','--no-cache','--wfail','build'],root,env,logs/'all.log')
                for i,m in enumerate(order):
                    raw=run([BIN/'lake','env','leanchecker',m],root,env,logs/(str(i)+'-checker.log'))
                    if raw.strip(): raise RuntimeError(('unexpected checker output',m,raw[:250]))
                for t in expected_checks:
                    check_prefix = 'TaskU.H5.Check.' if lane == 'both' else 'TaskU.H5.'
                    for name in ('TaskU.H5.Proof.'+t,check_prefix+'check_'+t):
                        if name not in state['axioms']:
                            raise RuntimeError(('missing axiom report',name))
                receipt['roots'][label]=state
                save(dest/'receipt.json',receipt)
        if receipt['roots']['root1']!=receipt['roots']['root2']:raise RuntimeError('roots produced different results')
        if any(sha(p)!=pins[m] for m,p in files.items()):raise RuntimeError('author sources changed')
        receipt['status']='MACHINE_PASS_WITNESS_ONLY' if lane=='witness' else 'MACHINE_PASS_PENDING_CLAUDE_FINAL'
    except BaseException as e:
        receipt['status']='INCOMPLETE';receipt['reason']=repr(e)
        raise
    finally:
        receipt['end_utc']=utc();save(dest/'receipt.json',receipt)
    print(dest/'receipt.json')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lane',choices=['witness','both'])
    parser.add_argument('check')
    args=parser.parse_args()
    replay(args.lane,args.check)
