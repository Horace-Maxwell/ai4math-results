# Cross-family FINAL review B-02: full integer group determinant spectrum of H₅ (Task U, target B)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The frozen target `TaskU.H5.ChallengeB.fullSpectrum` faithfully states the complete set S(H₅) of integer group determinants of the order-125 Heisenberg group. It is not vacuous. It is fully Lean-verified: my independent rebuild and leanchecker pass, and only the standard axioms are used. My numerical tests found no counterexample to the classification. That covers about 300,000 random coefficient vectors, 148,000 of them in the borderline layers v₅ = 28…32. My own prior-work search found no earlier complete result for H₅ or for H_p with p ≥ 5. The MINOR items below concern the written documents only and do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), reviewer B-02 of two, subagent of the user's Claude session. I wrote none of the reviewed files and did not read FINAL-CLAUDE-REVIEW-B-01.md.
- Review started 2026-11-21T03:57:31Z; report written after 2026-11-21T04:55:20Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-h5b-02/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| formal-b/TaskU/H5B/ChallengeB.lean (= TaskU/H5B via symlink) | 2a5066bfefb308bffbf31bdc568709a23f9177cb5ae3298cba198cf28cdf9ea6 |
| TaskU/H5B/CheckB.lean | 628d604fd5901aa9ee9e50be382269ed806a90ac1aeaa0d1a4afda4d3b982cf5 |
| TaskU/H5B/ProofB.lean | e7f5d25e44f8124cc2222e22026711411f295a7db8edec73a58dfe9596623ff1 |
| TaskU/H5B/Necessity.lean | 15e06b616f4ad805f75b0350a78d4cebc0c221041c30c2e7a21d4f3aa144dab3 |
| TaskU/H5B/Construct.lean | 6c469bb69b6153740fb4aaea7291f441d8190a68a46fe231088f6f9418234f90 |
| TaskU/H5/Challenge.lean (accepted A) | 9a9a0e18767ccf7efa7f6ea676d8aab883846444a66f4ffa27f1fdb3982f1343 |
| TaskU/H5/Cyc5.lean (accepted A) | 9061b2ada36d376f82f9985eabbe7460bc66db7c900b11722bbce1ced54e6cf9 |
| FREEZE-B.json | b3fde6ed7973653c03b3e32455e9064ff0b646dfd19fe6a95a25e0f07e0bc239 |
| b/FREEZE-REVIEW-B.md | 5a39707d47ef0aa68c1a09855c7414b216e9031b507972ad7962ac45acbeed75 |
| b/FORMAL-SOURCE-B.md | ab350b47e5d362824987051050004188bd5b0436970d325095eeb39c795af2e1 |
| b/CLASSIFICATION.md | 247f08b0c0d73b695f6678169b8d0d4546db4d10b5eb443b89f94cda2e1abfa3 |
| b/UPPER-TAIL.md | 9d3ebf4bf44bf83eed826ef5baf7833afb60c2551aca6dcbd286916c84744bef |
| b/CLASSIFICATION-REVIEW.md | 6fffd0d4606c9027b2bd4924efac42ed2189dc8a73b259dbe8990a463d29b2a5 |
| b/CLASSIFICATION-SUFFICIENCY-REVIEW.md | 1276673f68139569288b878653c8becda33466d1d189b49b1c5fdb6b0efcc970 |
| b/LITERATURE.tsv | f3012cc9e0340618a9d772c83a45bc221c24e94a4516c14217450e4699c883b5 |
| G2-B.md | 0695d3549cccdeed12625742dff5702cb91c57f2e93d9a0783d75a9662499894 |
| MATHEMATICS.md | 82391c546154df843051cb335358e973e3bf8b866164bde46829df2e98b18cbe |
| FINAL-HANDOFF-B.md | d02789058ba1f73a89bc0a6f680446b62ff9b15382379303ef02de28a013f3af |
| acceptance/spectrum/2026-11-21T033317Z/receipt.json | 76bb2cfd89cf987a6d62c33b3b23b953d93661bfe69b6bfb7252400f0d89d4ef |
| acceptance/spectrum/2026-11-21T033317Z/postcheck.json | e3bbd75650c702c24ca9fccc6000fd2eee4ad1ad1df6aa24515818877ec52e59 |
| arXiv 2108.04870v1 PDF (fetched by me) | df8e03096f41fec3bc856d0df5087de585a1a5f760d6e8bde785b16e746ed04a |
| My h5.py (determinants, ℤ[ζ₅], visibility) | fa7201deb215c855402f256dc923b1a3443c9a525e3adab80eca621ee841b114 |
| My AuditB.lean | 440831050b52c8266ee27593150c47785f4465cd6f8a9cef0e7185b310a71603 |

Hash checks:
- **Receipt.** All 63 source hashes in `receipt.json` match the files on disk (37 A modules under `TaskU/H5`, 26 B modules under `formal-b/TaskU/H5B`). `TaskU/H5B` is a symlink to `formal-b/TaskU/H5B`, and the two trees are byte-identical.
- **Freeze.** The 37 A hashes equal `FREEZE-B.json.immutable_A_modules`. The ChallengeB hash equals the frozen value, which is also in `FREEZE-B.json`, `FREEZE-REVIEW-B.md`, `DONE-B` and `FINAL-HANDOFF-B.md`. The `FREEZE-B.json` hash equals `receipt.freeze_sha256`. The receipt hash equals the one in FINAL-HANDOFF-B and DONE-B.
- **Acceptance.** `postcheck.json` reports status VERIFIED. All checker logs in both roots are zero bytes. The outer exit code is 0.

## 1. Is the statement faithful?

**Source.** I fetched arXiv 2108.04870v1 (Mossinghoff–Pinner; Michigan Math. J. 74 (2024) 551–569) myself.
- Its eq. (1) defines the group determinant as det(a_{g_i g_j^{-1}}) with independent integer variables, and (2) defines S(G).
- Its Corollary 3.2 gives the coprime values: S₁(H_p) = {x : x^{p−1} ≡ 1 mod p³}.
- Its Theorem 3.4 says: "If p | M_{H_p}(F) then p^{p²+3} | M_{H_p}(F)". For p = 5 that is 5²⁸.
- The abstract says the paper "determine[s] all values when p = 3". So H₅ is left open there.

**Lean definitions.**
- `groupDet f = det (Matrix.of fun g h => f (g * h⁻¹))`. This is exactly (1) and (2), with one unrestricted integer per group element.
- The group `H` is (ZMod 5)³ with (a,b,c)(a′,b′,c′) = (a+a′, b+b′, c+c′+b·a′), so yx = xyz with z central. This is the order-125 Heisenberg group of exponent 5. My code re-checked the group axioms.
- `Cyc5.V` is ℤ[ζ₅] in the power basis 1, ζ, ζ², ζ³. I checked `Cyc5.mul` and `Cyc5.norm` against my own ℤ[x]/Φ₅ arithmetic and a product-of-four-conjugates norm: they agree on 3,000 random pairs.
- `congrFive` (coordinatewise mod 5) is exactly congruence mod 5R, because the power basis is a ℤ-basis of R.
- `unitImage x` means x ≡ u mod 5R for some u with an actual inverse in V. This is exactly "the residue lies in the image U of the global units".
- `visible q` means q is prime, q ≡ 1 mod 5, and some element of norm q is not in U. An element of norm q generates a prime ideal above q. All primes above q are Galois conjugate, and Galois maps U to itself (it multiplies the class 1+dπ³ by a³). So "some generator" and "every generator" are the same condition, as b/FORMAL-SOURCE-B.md says.
- The clause q % 5 = 1 matters: without it, q = 5 would count as visible, because π has norm 5 and is not a unit mod 5, and the statement would be wrong.

**Quantifiers.**
- `fullSpectrum` reads: ∀ m : ℤ, (∃ f, groupDet f = m) ↔ [m⁴ ≡ 1 mod 125] ∨ [5³³ ∣ m] ∨ [m = 5²⁸n, n ≠ 0, some visible q divides n].
- This covers signed m, zero (through 5³³ ∣ 0), negative cofactors, and arbitrary extra powers of 5 in n.
- For p = 5, m⁴ ≡ 1 mod 125 is exactly the Corollary 3.2 condition, and 28 is the Theorem 3.4 threshold.
- My AuditB.lean shows by `Iff.rfl` that the target unfolds to the fully explicit statement, with every definition inlined.

**Not vacuous.** I checked this in Lean, in AuditB.lean, compiled and leanchecked:
- `audit_visible_exists : ∃ q, ChallengeB.visible q ∧ q ∣ 11`. It follows from `check_fullSpectrum` together with A's accepted witness `groupDet witness = 11·5²⁸`. So the third disjunct is inhabited, and 11 is visible.
- `audit_not_5pow28 : ¬ ∃ f, groupDet f = 5²⁸`. So the right-hand side is not trivially true, and the result agrees with A's least positive multiple 11·5²⁸.
- Numerically, the visible primes I computed match b/visible-primes.log for every split prime below 500. The invisible ones there are 211, 281, 421 and 461.

**Numerical test of the classification (special focus 1).** My code is independent: pure Python, written from the definitions.
- **Exact determinant.** A fraction-free Bareiss determinant of the 125×125 matrix f(g h⁻¹).
- **Fast route.** The factorization M = P(1,1) · ∏₆ N(P(ζ^i,ζ^j)) · N(D)⁵. Here D is the determinant of the 5-dimensional representation x ↦ shift, y ↦ diag(ζ^s), z ↦ ζ, computed by Leibniz expansion in ℤ[x]/(x⁵−1).
- **Visibility.** A norm-q generator is found by LLL on the ideal (q, ζ−r). Its residue is then tested against U = ⟨−1, ζ, φ⟩ mod 5. I enumerated U: it has 100 elements, index 5 in the 500 units.
- **Cross-check.** The full Bareiss determinant equals the factored value in 140 of 140 cases. Those include dense ones and valuations 0, 28…50 and 144, plus the zero determinant.

Results:
- **Coprime layer.** 79,641 coprime determinants, all with m⁴ ≡ 1 (mod 125).
- **Gap.** No determinant with 1 ≤ v₅ ≤ 27 occurred in about 362,000 samples.
- **Borderline layers.** 151,929 determinants with v₅ ∈ {28,…,32}. In the main biased run: 24,179 / 52,390 / 32,789 / 29,667 / 4,814 for v₅ = 28 / 29 / 30 / 31 / 32. Every one has a visible prime factor.
- **Where the visible prime comes from.** In every case it divides the norm of an ordinary ray value. That matches the necessity proof, both CLASSIFICATION §3 and Lean `Necessity.lean`.
- **Mixed cofactors.** 32,636 of these borderline cases also contained invisible split primes, so the "at least one visible prime" quantifier was exercised.
- **Upper tail.** Every v₅ from 33 to 39 was hit.
- **Sufficiency spot checks.** I recomputed with my own Bareiss the 15 low-layer coefficient vectors in b/sufficiency-examples. All have v₅ between 28 and 32 and the claimed values ±11·5²⁸, −217·5²⁸, 6875·5²⁸ and others; all are exact.
- **Six more constructions.** I asked the project's `verify-sufficiency.py` to construct 6 further values: 251·5²⁸, −211·61·5²⁸, 5³⁶, −7·5³³, 57 and −68. My Bareiss reproduced each value exactly. For 4·1951·5²⁸, 211·5²⁸ and 3·281·5³⁰, which have only invisible or non-split cofactor primes, it answered "outside", as the classification says.

## 2. Is the proof chain clean?

**CheckB.lean.** It is exactly `theorem check_fullSpectrum : ChallengeB.fullSpectrum := ProofB.fullSpectrum` in `namespace TaskU.H5`, plus one `#print axioms`.
- Only ChallengeB.lean opens `TaskU.H5.ChallengeB`. The other B modules use `TaskU.H5.{Spectrum, Coprime, PrimeExtract, PrimeRing, PrimeBasis, PrimeOrbit, BTrace, ProofB}`.
- `LiftRing.lean` reopens `TaskU.H5.Cyc5` only to add `AddCommGroup`/`CommRing` instances on V. It cannot shadow an existing name, because Lean rejects redeclarations. The frozen statement uses `Cyc5.mul` explicitly, not `*`, and is elaborated before these instances exist.
- `ProofB.fullSpectrum` splits on 5 ∣ m into `Coprime.coprime_necessary` / `Spectrum.divisible_necessary` and the three constructive branches.

**Forbidden constructs.** I grepped all 63 local files. There is no `sorry`, `admit`, `native_decide`, `bv_decide`, `axiom`, `unsafe`, `implemented_by`, `extern`, `opaque`, `macro`, `elab`, `syntax`, `notation`, `initialize`, `run_cmd` or `ofReduceBool`. The only `@[` attributes are `@[simp]` and `@[ext]`.
- `set_option` appears only as `maxRecDepth`/`maxHeartbeats`, in A's CycPhase, CycNorm and WitnessEval and in B's LiftColumns and UnitTable.
- The instances are A's group structure on H; local `Fact (Nat.Prime 5)` instances (`by decide`); `IsDomain`/`IsPrincipalIdealRing` on V, transported from Mathlib's ring of integers of ℚ(ζ₅) (PrimeRing); and `IsCyclotomicExtension` (PrimeBasis).
- WitnessBase imports `Lean.Elab.Tactic.Omega`, which is only a tactic import.

**`decide` uses in B.** All are kernel-checked; none is native.
- Small finite facts: primality of 5, ZMod 5 inequalities, Finset cardinalities.
- `decide +kernel` tables: the 625-residue unit table (UnitTable `inv_table`, `correction`), unit representatives (Residues, LiftShift), seed norms, residues and marginals (Seeds, SeedMarginals), the compact lift blocks (LiftColumns), the fourth roots of 1 mod 125 (CoprimeSeeds), and (x²⁵)⁴ = 1 or x²⁵ = 0 in ZMod 125 (CoprimeCongruence).

**Axioms.** `check_fullSpectrum` and `ProofB.fullSpectrum` depend on [propext, Classical.choice, Quot.sound]. So do every other printed declaration and my two audit theorems. This holds in the receipt (16 declarations per root) and in my rebuild.

## 3. Independent rebuild on this Mac

**Setup.** New empty directory `.../final-h5b-02/lean/`. I copied all 63 sources as real files (no symlink) and re-checked them against the receipt hashes. I added `Audit/AuditB.lean`. I did not use lake or any Codex build product.
- Each module was compiled with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -DwarningAsError=true -R src -o …`, in the receipt's module order.
- `LEAN_PATH` = my `out/` + the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
- After each compile I ran `leanchecker <module>`.

**Toolchain.** Lean 4.34.1, commit 5045d005. The `lean` and `leanchecker` SHA-256 equal the receipt (1b370cfc…, cfde41cb…). Mathlib `git rev-parse` gives d13f23b723b8a846827a245b89c10fc7d3f11612.

**Lock.** `leanlock.sh acquire any claude-final-h5b-02 75` got slot B at 2026-11-21T04:42:12Z, after waiting for other agents. The script printed `released B` at 04:55:01Z, and a status check then showed A and B free. Only one Lean process ran at a time.

**Result.**
- All 64 modules (63 local + AuditB) compiled with exit 0, 0 warnings and 0 errors. All 64 leanchecker runs exited 0 with empty output.
- Slowest module: LiftColumns, 30 s compile and 63 s total. Peak RSS 7.13 GB, in LiftColumns.
- AuditB prints the frozen definitions shown in §1 and the standard-axiom lists.
- My `.olean` hashes differ from the acceptance roots, because the build route differs (plain `lean -o` against a lake build). That is expected and does not matter here.

## 4. Mathematics, attribution and prior work

**Soundness of CLASSIFICATION.md.** I read §§1–4 critically. The argument is correct, and it is what the Lean proof formalizes.

- **§2, unit quotient.** (R/5R)^× ≅ (𝔽₅[π]/π⁴)^× has order 500. Normalize to 1+dπ³. For a normalized unit, ū/u is a root of unity that is ≡ 1 mod π², so it equals 1. Comparing with ū/u ≡ 1−2dπ³ then forces d = 0, so U has index 5. I confirmed |U| = 100 and that U = ⟨φ, ζ⟩ already contains −1.
- **Even-order primes contribute nothing.** The paragraph showing that primes of even order mod 5 contribute nothing is correct, though Lean does not need it.
- **§3, necessity.** v_π(D) = 4 forces an ordinary first-order ray. Phase matching gives ᾱ_j ≡ −ζ^{k_j}α_j mod π⁵ with k_j = 2B(j)/A − 1. Since deg B ≤ 2 < 4, Σk_j = 0, which gives β̄ ≡ −β mod π⁹. Then Tr(π⁹R) ⊂ 125ℤ gives Tr β ≡ 0 mod 125. Combined with Mossinghoff–Pinner's congruence 5c₀ = tN(γ) + Tr β, this forces v_π(D) ≥ 5, a contradiction.
- **§4, sufficiency.** The Fourier-numerator change t′ − 5a + Tr((η−1)α₀ζ^{−s}) ≡ 0 mod 25 for the chosen a. Then Tr β′ ≡ d·Tr(π⁸) ≡ −25d mod 125. After the generator swap, the exact lift to 5φ^j yields 5⁸n·(5⁴)⁵ = 5²⁸n.
- **Numerical agreement.** All of this agrees with my experiments in §1.

**Coverage.** All of S(H₅), including the coprime layer (Mossinghoff–Pinner Cor. 3.2) and the 5²⁸ threshold (Thm. 3.4), is inside the single Lean theorem. Lean re-proves even the cited results instead of assuming them: the coprime congruence, the Minkowski/PID step via Mathlib, and the trace congruence.

**Attribution.** These are correctly credited to prior work:
- Mossinghoff–Pinner: the factorization, Cor. 3.2, Thm. 3.4 and the D ≡ c₀ congruence.
- Panraksa arXiv 2608.04267: the three C₅² seeds.
- Panraksa arXiv 2609.09542: the precedent of a cofactor criterion for C₇².
- Bley–Hofmann–Johnston: general decidability.

Nothing in b/, G2-B.md or FINAL-HANDOFF-B.md says "first" (首次 or similar).

**Prior-work search (special focus 2).** My own searches, run between 2026-11-21T04:00Z and 04:20Z:
- **arXiv API, abstract search.** The phrases "integer group determinant(s)" and "Lind-Lehmer" returned 24 papers, 2018 to 2026-10. They include all the Yamaguchi–Yamaguchi papers, all the Paudel/Pinner/Serrano/Ostergaard papers, and Panraksa 2608.04267, 2609.09542, 2609.10423 and 2610.15262. The only Heisenberg paper is Mossinghoff–Pinner 2108.04870, which is complete only for p = 3.
- **arXiv, "group determinants" sorted by date.** Read through 53 of 203 results; nothing on H₅.
- **Web searches.** I searched for Heisenberg order 125, for Yamaguchi together with order p³, 125 or Heisenberg, for citing works of the Michigan paper, and for 5²⁸ or multiples-of-5 phrasing. They found nothing beyond Mossinghoff–Pinner and White's Davenport-constant paper on the same group (arXiv 2607.14379, a different invariant).
- **Yamaguchi–Yamaguchi.** Their spectra cover groups of order 16, plus a prime-value criterion for certain p-groups (2310.02297). They do not cover order 125.
- **Two 2026 papers.** I read the full text of Mossinghoff–Pinner arXiv 2609.21224 (ℤ_p^n) and Panraksa 2610.15262 (C_p×C_p). They mention H_p only as a citation, or not at all.
- **Panraksa 2610.15262 on known spectra.** It states that complete spectra are known "for every group of order at most 19". 125 is far beyond that.
- **Limits.** OpenAlex returned HTTP 429 to me, so I could not run a citation-graph check myself. G2-B reports 6 citing works through OpenAlex.

Conclusion: no prior complete result found, so there is no MAJOR item. A G3 re-check at release time is still needed.

## MINOR write-up fixes

1. **b/CLASSIFICATION.md, status lines are stale.**
   - The header still says "作者书面证明，等待独立核读及形式验证".
   - §5 still says "G2 尚需专门查找这三项".
   - Update both to the current state: written proof independently reviewed twice, the full statement Lean-verified as `ChallengeB.fullSpectrum` (pending FINAL), G2-B done, G3 still required.
   - Also state that in Lean the cited results are re-proved rather than assumed: Cor. 3.2 in both directions, the PID step, and the D ≡ c₀ congruence.
2. **MATHEMATICS.md (A write-up), B paragraphs are stale.**
   - Line 33 says "正式 Lean 范围为目标 A 的两个冻结命题".
   - Line 44 says "目标 B 未有完整 Lean 验收".
   - After FINAL, update these to B's status. The corollary "5³² is not attained, so 33 is the least k with 5^kℤ ⊆ S" follows immediately from the Lean theorem (my AuditB derives the analogous ¬5²⁸ fact this way), but it is not itself a separate checked statement. Label it so, or add a one-line Lean corollary.
3. **Citation of Mossinghoff–Pinner.** The numbering used (Cor. 3.2, Thm. 3.4, eqs. (15)/(16)) is that of arXiv v1, which is still the only arXiv version. Give the journal reference (Michigan Math. J. 74 (2024), no. 3, 551–569) next to it, and say which version the numbers refer to.
4. **Novelty wording.** Keep the novelty statement scoped by search date, as G2-B does: "在所查资料中未定位…", with the date. Repeat the search (G3) on the actual release date. I could not run an OpenAlex citation check (rate-limited), so the citing-work check rests on G2-B.
5. **Optional remark on visibility.** For all 563 split primes ℓ < 20,000 (461 visible, 102 invisible), ℓ is visible exactly when the golden-ratio unit ε = 1+ζ+ζ⁻¹ is not a fifth power mod a prime above ℓ, i.e. (1+r+r⁻¹)^{(ℓ−1)/5} ≢ 1 mod ℓ for a primitive fifth root r mod ℓ. Kummer theory and class field theory suggest why: the class field of the order-5 quotient should be K(ε^{1/5}). This gives an elementary test that may help readers. If used, label it a numerical observation or prove it; it is not part of the verified statement.
