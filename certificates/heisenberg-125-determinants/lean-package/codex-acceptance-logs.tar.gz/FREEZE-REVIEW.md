# H₅ 目标 A 陈述独立审查

**APPROVE_FREEZE**，2026-11-21T01:31:57Z。审阅人为未撰写候选 Lean 陈述的 Codex 子代理。核对文件为 `TaskU/H5/Challenge.lean`，SHA-256 `9a9a0e18767ccf7efa7f6ea676d8aab883846444a66f4ffa27f1fdb3982f1343`；对照表 `SOURCE-CHECK.md` 的 SHA-256 为 `581b65fcabc20fa965c6c1c224243e6de5446c0e8b0fa364d4eab8597edad04a`。

1. 原定义取行标 `g`、列标 `h` 对应的系数 `f (g * h⁻¹)`。`Matrix.of` 是从二元函数到矩阵的恒等映射。有限群上任意 `H → ℤ` 等价于给整数群环的全部基元素独立赋予系数，其中包括负数。矩阵正好是左乘算子在群基下的矩阵。[Mossinghoff–Pinner 第 1 页 (1)、(2)](https://arxiv.org/pdf/2108.04870)
2. `H` 是三个独立的 `ZMod 5` 坐标，故有 125 个元素。对照矩阵上三角的三条目 `(12,23,13)=(b,a,c)`，矩阵乘积的第三坐标确为 `c+c′+b*a′`；逆元第三坐标确为 `-c+b*a`。令 `z=(0,0,1)` 得 `y*x=x*y*z`，与原文 `X=I+E₂₃, Y=I+E₁₂` 的选择相合。[原文第 4 页及 (8)](https://arxiv.org/pdf/2108.04870)
3. `witness` 的五个系数函数分别指示 `(0,0,0),(1,0,0),(0,1,0),(0,2,0),(1,2,0)`。均取正号且点两两不同。`witnessValue` 将其整数行列式等同 `11 * 5^28 = 409781932830810546875`。
4. `leastPositiveMultiple` 在整数的通常序中取 `IsLeast`，集合的三个条件分别是严格正、整除 `5 ∣ m`、存在一组无约束整数系数取得 `m`。Mathlib 的 `IsLeast s a` 同时要求 `a ∈ s` 与 `a ∈ lowerBounds s`。零被排除，每个可取的正五倍数都在下界的量词范围内。该合同与见证合同各有独立意义，均与本轮目标一致。
5. 已逐项核对该 SHA 对应的 `dev-logs/Challenge-20261121T013050Z.receipt`（退出 0）和零字节日志。收据 SHA-256 `3ba6ae352883b324fb567e1ed6c8924f2ed58b5f24798acbd5b67c0b57dc6377`，`.olean` SHA-256 `bd29450fb08249bfcad48c43adb7c353f7de4f3f7f80149773b23e38231bfbf9`。早前三次失败属于其他源码哈希，均保留。此审查覆盖陈述忠实性与候选预编译凭据，主证明和跨族 FINAL 各有单独验收。
