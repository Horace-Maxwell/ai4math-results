# 目标 A 双根机器证据事后核对

**PASS**，2026-11-21T01:56:18Z。核对人是本次圆分引理的贡献者。本次复查属于机器证据核对，跨模型数学 FINAL 仍由独立 Claude 安排。

重新从源树、两份构建树、150 份逐命令 JSON、对应日志与资源日志读取数据。运行器 SHA-256 `cc882554f4af01f424c6d119f2f7d38119b95634465e41ae2718b2fa93d1ec26`，收据 SHA-256 `6422e6e36d19a6498f9fcff1f4fb460fb1762e25b89bba27fe67a8c62a21fbd7`。四个冻结/证明对照名为 `TaskU.H5.{Proof.witnessValue,Proof.leastPositiveMultiple,Check.check_witnessValue,Check.check_leastPositiveMultiple}`。

- 当前 `TaskU/` 内全部 37 个自有 Lean 源均在 Check 导入闭包中。各导入均先于依赖方编译，两个副本的源码哈希与当前原件和收据全部一致，冻件及关联文件哈希通过。
- 各根均有 37 个可定位到该模块的真正新建 `Built` 记录和 37 个对应的 `lake env leanchecker` 进程，退出均为 0，检查器的日志逐字节为空。两根默认 `lake --no-cache --wfail build` 也返回 0。总计 `2×(37+1+37)=150` 条实际命令。所有命令的工作目录、参数、退出、原始日志与资源日志哈希已逐一复核。
- 两份根中每个 `.olean` 均重新计算 SHA-256，同份收据与另一份根逐项比较全等。每根 13 个唯一公理记录，所有集合均在 `{propext, Classical.choice, Quot.sound}` 内，四份最终 Proof/Check 的精确全名齐全。记录的单命令最大 RSS 为 `5584994304` 字节。
- 最早一份 `014220Z` 收据保留了对两条 Lake 首建环境消息过严而触发的退出。此次成功批次 `014255Z` 使用另两个新根。01:56:18Z 实读系统锁时 A、B 均属于另一个 Helly 会话；本题未持有两槽。
