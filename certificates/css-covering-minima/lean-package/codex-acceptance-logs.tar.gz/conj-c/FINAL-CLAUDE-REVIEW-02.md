# Cross-family FINAL review 02: CSS Conjecture C (Task S, conj-c)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items.

`TaskS.C.Challenge.conjectureC` states the full Conjecture C of Codenotti–Santos–Schymura (DCG 67 (2022) 65–111, arXiv:1903.02866v2). It is fully Lean-verified, and my independent Mac rebuild with leanchecker passes on standard axioms only. In the statement:
- every dimension d ≥ 1 is covered;
- every d-simplex with the origin in its interior and rational vertex directions is covered, with arbitrary positive real vertex lengths;
- the conclusion is a genuine lattice covering at the conjectured scale;
- the discrete surface area is the normalized volume of the actual projected simplex in the projected lattice.

The proof is short and correct. I checked it by hand, by an exact-rational test of the key lemma, and with adversarial numerics.

The MINOR items concern the write-up only. The main one: the consequences for Conjectures A and B must be stated, marked as not Lean-verified, and phrased precisely. Conjecture A's equality clause is not implied, and it is in fact false.

- Reviewer: Claude (Anthropic, Opus 5.5), the second independent cross-family FINAL reviewer and a subagent of the user's Claude session. I wrote none of the reviewed files. I read FINAL-CLAUDE-REVIEW-01.md only after finishing §§1–4.
- Review started 2026-11-20T22:53:13Z. Report finished 2026-11-20T23:16:16Z. Times are from Mac `date -u`.
- Lean lock owner `claude-final-cssc2`. I took slot A at 23:01:05Z and released it at 23:05:44Z (`released A`). Only one Lean process of mine ran at a time.
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-cssc2/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= frozen/607e…/Challenge.lean = FREEZE.json) | 607e29157a812a0cc1a03d581f882af42766ca55aba9d087ab12a8d20b11a57e |
| CheckC.lean | ba56788a93c6d3836db5924946663a298285f4a19847af122ac268fafeb9a776 |
| Proof.lean | 3520388f4a85da785ffaaad45dd3d70c7d8245dfa9ddf6a1eadb2c44dd2392dd |
| Coordinates.lean | 67cde0a9be503caf5fd6bc620cd423ec6494df9c575f124d2cbb7596402d5c99 |
| Frequencies.lean | 073c2e1fa6ea2c711d944a69164eaf964f6e4872d00576439aa0435f651fcbbc |
| Lift.lean | 41fe40fb6384f910f6298ae3c7fa7323cca1297883addf02312a371624897378 |
| Projected.lean | 7ce488271a4aae1db81a6f8d75d4950b1b397246e64ea3f6446a793bce3948e2 |
| Geometry.lean | 9bbf3c475c3fb068da83cc16ac577175ecc2a44969e5576e5d6b0ebd7c7aae14 |
| TaskS/Shared/Sawtooth.lean (byte-identical to ../shared copy) | f3487fe4b73b29c14c20b1d784943a63850196ab94e2cbf4ad192684122b20dd |
| ProjectionLattice.lean | aecf392f69c4ebed3721dfb35877c06701d87396211006285e2c263a1e60ace8 |
| ProjectionBody.lean | f34cf823f3b8172e12d163c5611aa8efc2b45c31bb08169b51ad3ddc5f1f3d8e |
| SimplexMeasure.lean | 817414c444ca1a487e67f4315b26f8fcdbf6763d44068a7185fea8933093c8dc |
| ProjectionModel.lean | 7c7681612bc7114634b97f624256da1d4b08da4e934f23860dfc71f55093e754 |
| MeasureAudit/CheckC.lean | 52f424fb584201d68b17566bd61216937745c92eacde142c7ac1d1938e511a39 |
| FREEZE.json | c8e899654c6e852425ff786b263e47c46ead61785194af14fc30177c13425584 |
| FREEZE-REVIEW.md / SOURCE-CHECK.md / G2.md (= FREEZE.json) | 5c62370a… / a3af7f58… / 084b40b0… |
| MATHEMATICS.md | 13a4060f27c841b21013cb3461f1f3b0d3b5fb1fef8bf6faa2b67eaa45802041 |
| FINAL-HANDOFF.md | 5e6f608e6b55777e27ab05770acad288ec2559a46ed1d4ce7d21fa3af061a57e |
| acceptance/2026-11-20T223322Z/receipt.json | df9cf4b14d8841085c6639b1889e1bbdebd3eac005d5a77e8b5ad2a794d2368b |
| acceptance/2026-11-20T223851Z/receipt.json | 4f37b40939b778f124471aaa12d2db83adb8dd2ad0c572bac6ce9f9a4e98a4c8 |
| arXiv 1903.02866v2 PDF (downloaded by me; = local css.pdf in SOURCE-CHECK) | 4ece078961e7c03677952249ad8d205b40cf470c64ef51ab55f1f8e9d1a0fd6b |
| My Audit.lean (scratch) | 86988f62cbc6c2529380f961fa2807b302cea3c81d4a6d05097120631f999bd0 |

All 14 local source hashes equal the `source_sha256` tables of both receipts: 9 modules in the first, 14 in the second. Both receipts report `lean_version` 4.34.1 (commit 5045d005) and Mathlib `d13f23b7`.

## 1. Is the statement faithful to the source?

**Source (v2, pp. 1–4).**
- p.1: μ(K) = min{μ ≥ 0 : μK + ℤ^d = ℝ^d}.
- p.3: Vol_Λ is the Euclidean volume "normalized such that a unimodular simplex of Λ has volume one".
- Def. 1.5: S = conv{v_0..v_d} is a d-simplex with the origin in its interior, and has rational vertex directions if the line through 0 and v_i "has rational direction, for every 0 ≤ i ≤ d". Surf(S) = Σ_i Vol_{π_i(ℤ^d)}(π_i(S)), where π_i : ℝ^d → ℝ^{d−1} is a linear projection vanishing at v_i.
- Conjecture C (4): μ(S) ≤ ½ · Surf(S)/Vol(S).

No lattice-vertex hypothesis appears.

**Simplex class.**
- Lean writes v_i = ω_i·u_i, with u_i ∈ ℤ^d primitive (Bézout identity Σ a_k u_k = 1, i.e. gcd = 1) and ω_i > 0 real.
- A vertex of such a simplex is nonzero, so a rational direction means v_i = ω·p for a unique primitive p on the ray and ω > 0.
- The parametrization is therefore exactly the source class, including irrational vertex lengths. Distinct vertices are allowed to share a direction, so nothing is lost.

**Primitive or merely integral?** It matters, and Lean correctly requires primitivity.
- The lattice π_i(ℤ^d) depends only on the line ℝv_i.
- The formula |det[u_i; E]| scales by m if u_i is replaced by m·u_i.
- With merely integral u_i, the frozen RHS would be inflated by the factor m, giving a weaker, wrong statement. The frozen `Primitive` excludes this.

**`volume` = |det[(1, v_j)]_j|.** This equals d!·vol(S) = Vol_{ℤ^d}(S), the normalized volume (det ℤ^d = 1).

**`projectedVolume v u i` = |det[u_i; v_{s(1)}−v_{s(0)}, …, v_{s(d−1)}−v_{s(0)}]|**, with s = `i.succAbove`. I re-derived that this is Vol_{π_i ℤ^d}(π_i S).
- The rows after u_i are the d−1 edge vectors of the facet F_i opposite v_i, all from the base vertex v_{s(0)}.
- Complete u_i = b_1 to a ℤ-basis b_1..b_d (possible because u_i is primitive), and write each row in that basis: M = A·B with |det B| = 1.
- Row 1 of A is e_1. Expanding along it gives |det M| = |det A'|, where A' holds the coordinates of π_i(E_k) in the basis π_i(b_2..b_d) of π_i(ℤ^d).
- That is the normalized (d−1)-volume of the simplex π_i(F_i) in π_i(ℤ^d). It does not depend on the choice of completion, and by CSS Lemma 4.2 not on the choice of π_i with kernel ℝv_i either.

**Facet versus projected simplex.**
- The origin is interior, so 0 = Σβ_j v_j with all β_j > 0. Projecting gives 0 = Σ_{j≠i} β_j π_i(v_j), so π_i(v_i) = 0 lies in conv π_i(F_i). Hence π_i(S) = π_i(F_i), which is CSS's own remark after Def. 1.5.
- π_i is injective on aff(F_i), because the line ℝv_i crosses relint F_i.
- d = 1: the 1×1 determinant is |±1| = 1, the normalized volume of a point in ℤ^0. The bound is then μ ≤ 1/length, which holds with equality.

**`Covers K r`** is ∀x ∃z ∈ ℤ^d ∃y ∈ K, x = z + r·y, i.e. rK + ℤ^d = ℝ^d. It implies μ(S) ≤ r, so the conclusion is (4) or stronger.

**Hypotheses.**
- `0 < volume v` is redundant given the interior hypothesis, and harmless.
- `interior` is the topological interior in `Fin d → ℝ`, whose product topology is the Euclidean topology.

**Lean check that no coercion or instance changes the statement.** My Audit.lean proves by `Iff.rfl` that `conjectureC` is definitionally the fully unfolded statement I wrote by hand (convexHull of `range (ω j • embed (u j))`, explicit determinants, explicit cover). The elaborated target is therefore exactly as read above. In particular `volume` is `Challenge.volume`, not `MeasureTheory.volume`. The supplementary `MeasureModel.measured_conjectureC` also ties `projectedVolume` and `volume` to Lebesgue-measure ratios of the actual projected set p_i(S), with p_i(ℤ^d) = ℤ^{d−1} and p_i(v_i) = 0. I rebuilt it.

**Numerics** (my own Python, `num/cssc.py`, `t1.py`–`t3.py`).
- For each test I computed RHS_lean (the frozen determinant formula), RHS_chord = ½Σ(1−β_i)/ω_i (the CSS Lemma 4.1 chord form), and a lower bound on μ(S). The lower bound is the maximum over a grid plus hill-climbing of min_z gauge_S(x−z).
- **Known cases.**
  - S(1³) = 1 and S(1⁴) = 1.5.
  - S(1, 2.5, 0.7), S(√2, 1, 3.3) and S(0.5, 2, 1.3, π): RHS equals the exact CSS Thm 1.4 value, and μ_lower attains it to 1e-12.
  - The Task R 4-simplex conv(e_1..e_4, −(2,1,1,1)) has RHS = 2.000 and μ_lower = 2.000. The paper-21 simplex is an **equality case of C**.
- **Random adversarial search.**
  - Primitive directions with entries up to ±5. ω ratios up to e^6 (≈ 400), irrational. Thin and skewed shapes included.
  - d = 2: 900 simplices. d = 3: 720 simplices, plus Nelder–Mead maximisation of μ_lower/RHS over ω for fixed non-unimodular ray sets. d = 4: 50 simplices.
  - Results: **no violation in any case**. The maximum μ_lower/RHS was 1.000000 in d = 2 and d = 3. It was attained only at equality cases, which include non-S(ω) lattice simplices with unit ω, e.g. rays (2,−1), (−1,1), (−3,1). For d = 4, the maximum was 0.951 on a coarse 10⁴ grid. Nelder–Mead over ω on nine fixed non-unimodular d = 3 ray sets peaked at a ratio of 0.37–0.61.
  - RHS_lean = RHS_chord to ≤ 1e-14 relative in every non-degenerate case. One "discrepancy" was a degenerate draw with coplanar rays (V ≈ 1e-16), which Lean excludes through `0 < volume`.
- **Exact rational test of the key lemma.** 20 000 random instances of `sawtooth_weighted` were tested by exact enumeration of the events, where the minimum is attained. min/bound was ≤ 0.99656 and never above 1.

## 2. Is the proof chain clean?

- **Check files.**
  - `CheckC.lean` is exactly `theorem check_conjectureC : Challenge.conjectureC := Proof.conjectureC` in `namespace TaskS.C`, plus `#print axioms`.
  - `MeasureAudit/CheckC.lean` has the same line in `TaskS.C.MeasureAudit`.
  - Only Challenge.lean defines names in `TaskS.C.Challenge`, so no frozen name is shadowed.
- **Forbidden constructs.** I grepped all 14 files for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, notation, set_option, initialize, run_cmd, ofReduceBool, `@[`, attribute and instance. The only hit is the English word "admits" in a ProjectionLattice docstring. There is no `decide`.
- **Top level.** `Proof.conjectureC` applies `geometry`, with `TaskS.Shared.sawtooth_weighted` instantiated at weights c_i = 1/ω_i.
- **Chain inside `geometry`.**
  - `coordinates`: positive barycentric coordinates β of 0, and a spanning representation.
  - `frequency_ratio`: q_i := |det(u_j)_{j≠i}| ∈ ℕ satisfies q_i·Πω = V·β_i·ω_i. Hence q_i > 0 and Σ q_i u_i = 0.
  - `projected_eq`: `projectedVolume` = V(1−β_i)/ω_i.
  - `rounded_cover`.
  - The scale identity Surf/(2V) = ½Σ(1−β_i)/ω_i = (Σc_i − Σq_i c_i²/Σq_i c_i)/2.

  All of this is honest algebra on the frozen definitions. Nothing specializes the statement.

### Proof idea (one paragraph)

Write each vertex as v_i = ω_i u_i, and let β_i > 0 be the barycentric coordinates of the origin. Cramer's rule shows that the absolute maximal minors q_i = |det(u_j)_{j≠i}| are positive integers proportional to β_i ω_i, so Σ q_i u_i = 0 is an integer relation with all coefficients positive. A cofactor expansion shows that the projected facet volume equals V(1−β_i)/ω_i, so the conjectured scale is r = ½Σ c_i(1−β_i) with c_i = 1/ω_i. Given any point y = Σ x_i u_i and any real t, the point z = Σ ⌊x_i + q_i t⌋ u_i is a lattice point, and y − z = Σ c_i·frac(x_i + q_i t)·v_i is a nonnegative combination of the vertices. Since 0 = Σβ_i v_i, any such combination with coefficient sum ≤ r lies in rS. It therefore suffices to find a t with Σ c_i frac(x_i + q_i t) ≤ r.

This is done by averaging over the finitely many "reset times" e_{ik} = −(x_i + k)/q_i, giving reset time e_{ik} the weight c_i. Write B = frac − ½. Hermite's identity gives B(x_j + q_j t) = Σ_l B(t − e_{jl}). The cross terms then pair up as B(s) + B(−s) ≤ 0, and the diagonal terms equal −q_i/2. So the weighted average of Σ_j c_j frac(x_j + q_j t) over the reset times is at most ½(Σc_i − Σq_i c_i²/Σq_i c_i), which is exactly r. Some reset time does at least as well as the average.

I verified each step by hand. It is a weighted, Dedekind-sum-style refinement of the trivial average ½Σc_i. The improvement term Σq_i c_i²/W is exactly the barycentric correction ½Σc_iβ_i.

## 3. Independent rebuild on this Mac

- **Setup.**
  - I used a new empty output directory and a fresh copy of the 14 sources (`cmp`-identical) plus my Audit.lean.
  - Each module was compiled with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o out/<M>.olean`.
  - `LEAN_PATH` was out/ plus the prebuilt oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
  - Toolchain: Lean 4.34.1 from `work/toolchains/lean-4.34.1-darwin_aarch64`. No lake and no Codex build products.
- **Build order:** Challenge, TaskS.Shared.Sawtooth, Coordinates, Frequencies, Lift, Projected, Geometry, Proof, CheckC, ProjectionLattice, ProjectionBody, SimplexMeasure, ProjectionModel, MeasureAudit.CheckC, Audit.
- **Result.**
  - All 15 modules compiled with exit 0 and zero diagnostics. The only output was the `#print axioms` lines.
  - `leanchecker <M>` exited 0 with empty output on every module.
  - Each module took about 10–34 s, with peak RSS of about 6.0 GB per command.
  - My first Audit attempt failed on an ambiguous `Lattice` in *my own* restatement (`_root_.Lattice` vs `Challenge.Lattice`). I fully qualified it and recompiled; it then passed with leanchecker exit 0.
- **Axioms.** `Proof.conjectureC`, `check_conjectureC`, `MeasureAudit.check_conjectureC`, `MeasureModel.measured_conjectureC`, `normalized_measure`, `exists_adapted`, `edge_determinant`, `projected_volume`, `image_simplex_eq_image_opposite` and `sawtooth_weighted` all depend only on `[propext, Classical.choice, Quot.sound]`.
- **Audit.lean contains:**
  - the `Iff.rfl` restatement (§1);
  - `example : TaskS.C.Challenge.conjectureC := …` through `TaskS.C.Proof.conjectureC`, `TaskS.C.check_conjectureC` and `TaskS.C.MeasureAudit.check_conjectureC`.
- **Olean hashes.** My olean hashes differ from the receipt's olean hashes. I expected this from the different build invocation and paths. The source hashes match, and the kernel re-check is what matters.

## 4. Mathematics, consequences and literature

**MATHEMATICS.md** is correct.
- It maps each step to the right declarations and marks Task Q's integral version as unformalized.
- It never says "first", and it scopes novelty to the 2026-11-20 G2.
- Prior work is attributed correctly: CSS Thm 1.4 (S(ω), equality), Thm 4.9 (d = 2), Prop 4.4 (factor 2) and Lemma 4.1. Remark 4.5's bound (2d−1)/(2d+2)·Σ1/ℓ_i could also be mentioned.
- It does not state the consequences (see MINOR 1).

**Exact consequences (not Lean-verified; they use CSS's published arguments).**
- **CSS Corollary 4.3** is stated as "Conjecture C ⟹ Conjecture A", but its proof shows only the inequality. For a lattice simplex with interior origin, ω_i ≥ 1 and Σ_i ω_i/ℓ_i = d (because 1 − ω_i/ℓ_i = β_i). Hence μ(S) ≤ ½Σ1/ℓ_i ≤ ½Σω_i/ℓ_i = d/2. The proof says nothing about the equality characterization.
- **CSS Corollary 3.2** (via Lemma 3.1 and Lemma 2.1) reduces Conjecture A in all dimensions ≤ d to lattice simplices. Since C is now proved in every dimension, the conclusion is: **μ(P) ≤ d/2 for every non-hollow lattice d-polytope P, in every dimension d.**
  - This covers all non-hollow lattice polytopes, not only simplices.
  - It is the inequality part of Conjecture A, together with the stronger simplex bound μ(S) ≤ ½Σ1/ℓ_i.
- **The equality "only if" clause of Conjecture A does NOT follow, and it is false.** Paper 21 / Task R gives a 4-dimensional non-hollow simplex with μ = 2 that is not a direct sum or translate of S(1^l). By my numerics it attains equality in C. The "if" direction of A's equality clause was already known (CSS (1) and Cor. 2.2).
- **CSS Theorem 1.2**, direction (i) ⟹ (ii): "μ(P) ≤ ℓ/2 for every non-hollow lattice ℓ-polytope and every ℓ ≤ d" implies Conjecture B for every ℓ ≤ d. With the polytope inequality in all dimensions, this gives **Conjecture B in full: μ_ℓ(S(1^{n+1})) = ℓ/2 for all ℓ ≤ n.** This is the González Merino–Schymura conjecture [GMS17, Rem. 4.10]. The lower bound ≥ ℓ/2 is CSS (2).
- **Conjecture D** (k interior points) is not implied.
- **The boundary-origin extension** (CSS §4.4) is not covered by the frozen statement.

**Literature, 2022–2026.**
- **Krivokuća, arXiv:2601.15173 (Jan 2026).** It gives upper bounds μ_i(T_d) ≤ (i/2)(1 + (d−i)/(d+1)) (Cor. 5.9) and a second bound (Cor. 5.6), "reducing the gap" for Conjecture B. B is still open there, and Conjecture C is not addressed.
- **Codenotti–Freyer–Krivokuća, arXiv:2606.14442.** Minimal covering bodies (≥ 2d facets) and planar Brunn–Minkowski inequalities for μ. They do not address A, B or C.
- **Williams, arXiv:2606.06291; Xue, arXiv:2610.39034.** Unrelated covering inequalities.
- **Web searches.** I ran four queries on the d/2 conjecture, "discrete surface area", Conjecture B / standard terminal simplex covering minima, and "rational vertex directions". None found a proof or refutation of A's inequality, B or C after CSS. Krivokuća 2026 still treats A and B as open.
- **Failed queries.**
  - The arXiv export API returned an empty body. I used the arxiv.org/abs pages instead.
  - Codenotti's 2020 FU Berlin thesis PDF download returned an HTML page and was not read. It predates the DCG version, so a proof there is unlikely, but G3 should open it.
  - From G2's own record: OpenAlex returned 429 and the MathDB search is fuzzy.
- **Assessment.** Given the size of the consequence (all-dimension A-inequality and B), the shortness of the proof is the main residual risk. The risk is not that the Lean is wrong. It is that a short argument like this may already exist in the literature unnoticed by G2. A careful G3 is required before any outward step.

## Comparison with FINAL-CLAUDE-REVIEW-01 (read after the above)

I agree with its verdict and with its analysis of the statement, the proof and the consequences. My independent results match its findings: the hash table, the rebuild, the axioms, the Task R simplex as an equality case of C, and Krivokuća still treating B as open.

**Differences:**
- **Its MINOR 2 is partly stale.** FINAL-HANDOFF.md and STATUS.md already link `acceptance/2026-11-20T223851Z/receipt.json` and give its SHA (4f37b409…). Only MATHEMATICS.md's last paragraph ("另有收据") lacks the link.
- **Primitivity.** It treats primitivity as part of the class description. I add explicitly that primitivity is *load-bearing*: with merely integral u_i the RHS would be inflated by m.
- **Its Audit `sInf` form (μ ≤ RHS)** is a useful complement to my `Iff.rfl` restatement. Neither changes the conclusion.
- **Wording of the consequences.** It writes "CSS prove 'Conjecture C ⇒ Conjecture A' (Cor. 4.3, inequality part)". I would stress more strongly that publication text must never say "settles Conjecture A". It must say "the inequality part of Conjecture A (whose equality clause is false by paper 21)".

## MINOR write-up fixes

1. **MATHEMATICS.md and G2.md: consequences.** Add the consequences paragraph from §4, marked "not Lean-verified; relies on CSS Cor. 3.2, Cor. 4.3 (proof) and Thm 1.2 (i)⇒(ii)". It should cover:
   - μ(P) ≤ d/2 for all non-hollow lattice polytopes in all dimensions;
   - Conjecture B in full.

   State explicitly that A's equality clause is not implied and is false (paper 21), and that the paper-21 simplex is an equality case of C. Never write "proves Conjecture A".
2. **G2.md: Krivokuća.** Reword the Krivokuća sentence. Her 2026 paper narrows exactly the gap in Conjecture B that this result closes, so it is the closest competitor, not a distant neighbour. G3 should cover "Conjecture B", "covering minima of the standard terminal simplex", "non-hollow lattice polytope covering radius d/2" and "discrete surface area" for 2022–2026, and should open Codenotti's 2020 thesis (my download failed).
3. **MATHEMATICS.md: primitivity and redundancy.** Say that primitivity of u_i is essential: a non-primitive generator would scale the projected volume. Also say that `0 < volume v` follows from the interior hypothesis, so it is not an extra restriction.
4. **MATHEMATICS.md: chord form.** State 1/ℓ_i = (1−β_i)/ω_i, so that `projected_eq` is visibly CSS Lemma 4.1's chord form (6). Optionally cite Remark 4.5 as the previous best general constant, (2d−1)/(2d+2).
5. **MATHEMATICS.md: last paragraph.** Link `acceptance/2026-11-20T223851Z/receipt.json` with its SHA-256, as FINAL-HANDOFF already does.
6. **SOURCE-CHECK.md.** It reads "(4) … d ≥ 1" as if the source stated it. CSS gives no explicit range. Note that d = 1 is a harmless inclusion: it holds with equality and adds nothing.
7. **Optional.** Name Hermite's identity Σ_k⌊a + k/q⌋ = ⌊qa⌋ in the sawtooth section, and say that coincident events are counted with multiplicity over labelled pairs (i, k).

Report end: 2026-11-20T23:16:16Z (Mac `date -u`).
