# Cross-family FINAL review 01: CSS Conjecture C (Task S, conj-c)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items.

The frozen target `TaskS.C.Challenge.conjectureC` is the full Conjecture C of Codenotti–Santos–Schymura (DCG 67 (2022) 65–111, arXiv:1903.02866). It is not a weakening, a special case or a proxy:
- every dimension d ≥ 1 is covered;
- every simplex with the origin in its interior and rational vertex directions is covered, with arbitrary positive real vertex lengths;
- the true covering radius is used;
- the discrete surface area is CSS's own quantity, normalized exactly as in the source.

The theorem is fully Lean-verified. It uses only the standard axioms, and my independent Mac rebuild and leanchecker runs pass.

The 7-minute freeze-to-acceptance interval is explained by the proof itself. It is short and elementary: an integer kernel vector plus a weighted circle-rounding (sawtooth) averaging lemma, about 30 KB of Lean in total. I checked the argument by hand (§4) and found it correct.

Because CSS prove "Conjecture C ⇒ Conjecture A" (Cor. 4.3, inequality part), and Conjecture A's inequality is equivalent to Conjecture B (Thm 1.2), this result has large consequences that MATHEMATICS.md does not mention. See MINOR 1. Those consequences are not in Lean.

- Reviewer: Claude (Anthropic, Opus 5.5), a subagent of the user's Claude session. I wrote none of the reviewed files.
- Review started 2026-11-20T22:43:20Z. Report written after 2026-11-20T22:51:03Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-cssc/`.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= frozen/607e…/Challenge.lean, = FREEZE.json) | 607e29157a812a0cc1a03d581f882af42766ca55aba9d087ab12a8d20b11a57e |
| Coordinates.lean | 67cde0a9be503caf5fd6bc620cd423ec6494df9c575f124d2cbb7596402d5c99 |
| Frequencies.lean | 073c2e1fa6ea2c711d944a69164eaf964f6e4872d00576439aa0435f651fcbbc |
| Lift.lean | 41fe40fb6384f910f6298ae3c7fa7323cca1297883addf02312a371624897378 |
| Projected.lean | 7ce488271a4aae1db81a6f8d75d4950b1b397246e64ea3f6446a793bce3948e2 |
| Geometry.lean | 9bbf3c475c3fb068da83cc16ac577175ecc2a44969e5576e5d6b0ebd7c7aae14 |
| TaskS/Shared/Sawtooth.lean (= ../shared copy, byte-identical) | f3487fe4b73b29c14c20b1d784943a63850196ab94e2cbf4ad192684122b20dd |
| Proof.lean | 3520388f4a85da785ffaaad45dd3d70c7d8245dfa9ddf6a1eadb2c44dd2392dd |
| CheckC.lean | ba56788a93c6d3836db5924946663a298285f4a19847af122ac268fafeb9a776 |
| ProjectionBody.lean | f34cf823f3b8172e12d163c5611aa8efc2b45c31bb08169b51ad3ddc5f1f3d8e |
| ProjectionLattice.lean | aecf392f69c4ebed3721dfb35877c06701d87396211006285e2c263a1e60ace8 |
| SimplexMeasure.lean | 817414c444ca1a487e67f4315b26f8fcdbf6763d44068a7185fea8933093c8dc |
| ProjectionModel.lean | 7c7681612bc7114634b97f624256da1d4b08da4e934f23860dfc71f55093e754 |
| MeasureAudit/CheckC.lean | 52f424fb584201d68b17566bd61216937745c92eacde142c7ac1d1938e511a39 |
| FREEZE.json | c8e899654c6e852425ff786b263e47c46ead61785194af14fc30177c13425584 |
| FREEZE-REVIEW.md (= FREEZE.json) | 5c62370a40d075e67c17d9d4643eb4609774f77ed8c5c12ac64157cce426c24b |
| SOURCE-CHECK.md (= FREEZE.json) | a3af7f58c989b6c8ce4f7f5e10b3f5a7a4b9e3a94743054afe685bfda972dfff |
| G2.md (= FREEZE.json) | 084b40b08fd2bf2e40e38615107f5e61df693d8af4b4f6f3d9b3ce3a65c65467 |
| MATHEMATICS.md | 13a4060f27c841b21013cb3461f1f3b0d3b5fb1fef8bf6faa2b67eaa45802041 |
| FINAL-HANDOFF.md | 5e6f608e6b55777e27ab05770acad288ec2559a46ed1d4ce7d21fa3af061a57e |
| STATUS.md | 32dbdbf0f86743c623c44e3d1de261d04b99c3ee9b399f4720de4588d88c36a1 |
| acceptance/2026-11-20T223322Z/receipt.json (= FINAL-HANDOFF) | df9cf4b14d8841085c6639b1889e1bbdebd3eac005d5a77e8b5ad2a794d2368b |
| acceptance/2026-11-20T223851Z/receipt.json (measure audit) | 4f37b40939b778f124471aaa12d2db83adb8dd2ad0c572bac6ce9f9a4e98a4c8 |
| arXiv 1903.02866v2 PDF (downloaded by me; = local css.pdf cited in SOURCE-CHECK) | 4ece078961e7c03677952249ad8d205b40cf470c64ef51ab55f1f8e9d1a0fd6b |
| My Audit.lean (scratch) | 3cc9b91036d0078fd3ea7306890f601a3c812fb1e1da5933bc0c5cddfd613033 |

**Hash cross-checks:**
- All 14 local source hashes equal the `source_sha256` tables of the two receipts. The first receipt lists 9 modules and the second lists 14.
- The 8 root-level modules of the first acceptance are byte-identical in `root1` and `root2`.
- The `lean` and `leanchecker` binary hashes equal `receipt.tools`.
- The Mathlib checkout is at `d13f23b723b8a846827a245b89c10fc7d3f11612` (`git rev-parse`), which equals `receipt.dependency_commits`.

## 1. Is the statement faithful to the source?

I downloaded arXiv 1903.02866v2 myself. Its hash is identical to the copy cited in SOURCE-CHECK. I also checked the journal text (PMC8709830).

**Source, p.1:** μ(K,Λ) = min{μ ≥ 0 : μK + Λ = ℝ^d}.

**Source, p.3:** Vol_Λ is the Euclidean volume "normalized such that a unimodular simplex of Λ has volume one".

**Source, Definition 1.5 (p.4):**
- S = conv{v_0,…,v_d} is a d-simplex with the origin in its interior.
- S has rational vertex directions if "the line through the origin and the vertex v_i has rational direction, for every 0 ≤ i ≤ d".
- Surf_{ℤ^d}(S) := Σ_i Vol_{π_i(ℤ^d)}(π_i(S)), with π_i : ℝ^d → ℝ^{d−1} a linear projection vanishing at v_i.

**Source, Conjecture C (4):** "Let S be a d-simplex with the origin in its interior and with rational vertex directions. Then μ(S) ≤ ½ · Surf_{ℤ^d}(S)/Vol_{ℤ^d}(S)." No lattice-vertex hypothesis appears, and none of rational vertices.

Lean definition by definition (I `#print`ed every frozen definition with `pp.fullNames`):

- **Simplex class.**
  - The vertices are v_i = ω_i·u_i, with u_i ∈ ℤ^d satisfying a Bézout identity (⟺ gcd = 1, primitive) and ω_i > 0 real.
  - Every vertex with rational direction has this form. Such a vertex is nonzero because the origin is interior, so v_i = t·p with p primitive and t ≠ 0, and the sign can be moved into p.
  - Conversely, every such vertex has rational direction.
  - So the class is exactly CSS's class, with arbitrary real (even irrational) vertex lengths.
  - `interior` is the topological interior in `Fin d → ℝ` (product topology = Euclidean topology).
- **Dimension.** d = n+1 ranges over all d ≥ 1, and d = 1 is included.
- **Redundant hypothesis.** `0 < volume v` is implied by the interior hypothesis (`coordinates` derives affine independence from it). It is redundant but restricts nothing.
- **Covering radius.** `Covers K r` is ∀x ∃z ∈ ℤ^d ∃y ∈ K, x = z + r·y, i.e. rK + ℤ^d = ℝ^d. Since 0 ∈ S and S is convex, `Covers S r` ⟺ μ(S) ≤ r. So the conclusion is exactly CSS's (4), not a proxy. I also proved the infimum form in Lean (`audit_covering_radius_le`: `sInf {μ | 0 ≤ μ ∧ Covers S μ} ≤ RHS`).
- **Vol_{ℤ^d}(S).** `volume v = |det[(1, v_i)]_i|`, which is d!·vol(S) = the normalized volume (det ℤ^d = 1).
- **Vol_{π_i ℤ^d}(π_i S).**
  - `projectedVolume v u i = |det[u_i; v_{s(1)}−v_{s(0)}, …, v_{s(d−1)}−v_{s(0)}]|`, with s = `i.succAbove`, i.e. the primitive kernel generator followed by the d−1 edges of the opposite facet F_i.
  - Take U ∈ GL_d(ℤ) with U u_i = e_1. Expanding along the first row then gives the (d−1)-determinant of the projected edges in coordinates where π_i(ℤ^d) = ℤ^{d−1}. That is the normalized volume of π_i(F_i) = π_i(S).
  - It does not depend on which projection with kernel ℝv_i is used (CSS Lemma 4.2).
  - It is not a larger quantity that makes the bound easy. For d = 1 it is 1, the normalized volume of a point.
- **Lean confirmation of the volume identification.** Codex's supplementary `MeasureModel.measured_conjectureC` proves the bound with actual Lebesgue measures. It constructs, in Lean:
  - surjective linear p_i with p_i(v_i) = 0 and p_i(ℤ^d) = ℤ^{d−1};
  - the identity μ_Leb(p_i S)/μ_Leb(unit simplex) = `projectedVolume`, together with the same identity for S.

  I rebuilt this too (§3). So the determinant shortcut in `Challenge.lean` is formally tied to the geometric definition.
- **Not vacuous.** Hypotheses are satisfiable, e.g. S(1^{d+1}) and the d = 1 example [−√2, 3]. Nothing assumes the conclusion, and no kernel vector, barycentric bound or sawtooth bound is a hypothesis.

**Numerical tests** (my own Python, `num/check.py`, independent of Lean). For each case I computed the RHS three ways:
- (a) Lean's determinant formula;
- (b) CSS's Def. 1.5 directly, with *orthogonal* projection, Gram-determinant facet volume and det(π_i ℤ^d) = 1/‖u_i‖;
- (c) CSS Lemma 4.1's chord form ½Σ1/ℓ_i, with ℓ_i from the line–facet intersection.

I also computed a lower bound for the true μ(S) by sampling plus Nelder–Mead on max_x min_z gauge(x−z).

| Case | RHS (all three agree to 1e-8) | μ lower bound |
|---|---|---|
| d=1, [−√2, 3] | 0.226540920 | 0.226540920 (= 1/(3+√2)) |
| S(1³), S(1⁴) | 1, 1.5 | 1, 1.5 (CSS (1)) |
| S(0.7, 1.9, √3), S(1.3, 0.4, 2.2, 0.9) | 0.742637438, 1.560867818 | equal (CSS Thm 1.4 equality) |
| CSS Ex. 4.10(ii), ω = 1.5 | 0.9 | 0.9 |
| Task R 4-simplex conv(e₁..e₄, −(2,1,1,1)) | 2 | 1.99999 (Task R: μ = 2, equality) |
| 25 random triangles, 12 random tetrahedra (random primitive directions, irrational ω) | (a) = (b) = (c) in every case | always ≤ RHS, no violation |

**Consistency with the literature.**
- Conjecture C ⇒ the d/2 inequality of Conjecture A (CSS Cor. 4.3, via Cor. 3.2 and Σω_i/ℓ_i = d).
- Paper 21 / Task R refutes only the "only if" part of A's equality clause: its simplex has μ = d/2. So it is consistent with C, and the Task R simplex is an equality case of C.
- Krivokuća (arXiv:2601.15173, Jan 2026) still treats Conjecture A / Conjecture B (her Conj. 4.1/4.2) as open and narrows the gap for B.
- Codenotti–Freyer–Krivokuća (arXiv:2606.14442), Williams (2606.06291) and Xue (2610.39034, Oct 2026) do not address A, B or C.
- I found no proof or refutation of C up to 2026-11-20. Nothing in the literature contradicts the Lean result.

## 2. Is the proof chain clean?

- **CheckC.lean** contains exactly `theorem check_conjectureC : Challenge.conjectureC := Proof.conjectureC` inside `namespace TaskS.C`, plus `#print axioms`. MeasureAudit/CheckC.lean has the same line in `TaskS.C.MeasureAudit`.
- **No shadowing.** Only Challenge.lean opens `TaskS.C.Challenge`. No other file defines anything in that namespace. Other definitions are `frequency`, `MeasureModel.unit/edges/project`, and private helpers (`event`, `dev`, `join`, `split`).
- **Forbidden constructs.** I grepped all 14 files for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, notation, set_option, initialize, run_cmd, ofReduceBool, `@[`, attribute, instance and `import Lean`. There are no hits, apart from the English word "admits" in a ProjectionLattice docstring. There is no `decide` anywhere.
- **Proof structure.**
  - `coordinates`: positive barycentric coordinates β of 0, and an affine basis.
  - `frequency_ratio`: q_i = |det(u_j)_{j≠i}| = (V/Πω)·β_i·ω_i, so q_i ∈ ℤ_{>0} and Σq_i u_i = 0.
  - `projected_eq`: `projectedVolume_i` = V·(1−β_i)/ω_i, the determinantal form of CSS Lemma 4.1, since 1/ℓ_i = (1−β_i)/ω_i.
  - `rounded_cover`: y = Σ(x_i + q_i t)u_i; the integer parts give z ∈ ℤ^d and the fractional parts give y − z = Σ(frac/ω_i)·v_i ∈ rS.
  - `sawtooth_weighted`: some t has Σc_i·frac(x_i + q_i t) ≤ (Σc_i − Σq_i c_i²/Σq_i c_i)/2.
  - `geometry`: with c_i = 1/ω_i this bound equals ½Σ(1−β_i)/ω_i = Surf/(2Vol).
- **Axioms.** In my rebuild, `Proof.conjectureC`, `check_conjectureC`, `MeasureAudit.check_conjectureC`, `measured_conjectureC`, `normalized_measure`, `exists_adapted`, `edge_determinant`, `projected_volume`, `image_simplex_eq_image_opposite` and my `audit_covering_radius_le` all depend only on `[propext, Classical.choice, Quot.sound]`.

## 3. Independent rebuild on this Mac

- **Lock.** `leanlock.sh acquire any claude-final-cssc 60` gave slot B at 22:46:45Z. I released it at 22:50:15Z (`released B`). Only one Lean process of mine ran at a time.
- **Setup.**
  - I used a new empty scratch directory and a copy of the 14 sources plus my `Audit.lean`. No lake and no Codex build products were used.
  - Each module was compiled with plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o out/<M>.olean`.
  - `LEAN_PATH` was my `out/` plus the prebuilt package oleans in `research-lean-v434/.lake/packages/*/.lake/build/lib/lean`.
  - Toolchain: Lean 4.34.1 (commit 5045d005); Mathlib d13f23b7.
- **Result.**
  - All 15 modules compiled with exit 0 and no warnings or errors. The only output was the `#print axioms` lines.
  - Build order: Challenge, Coordinates, Frequencies, Lift, Projected, Geometry, TaskS.Shared.Sawtooth, Proof, CheckC, ProjectionBody, ProjectionLattice, SimplexMeasure, ProjectionModel, MeasureAudit.CheckC, Audit.
  - `leanchecker <M>` exited 0 with empty output on every module.
  - Peak RSS was 6.00 GB per command, and each module took about 10 s.
- **Audit.lean** compiles:
  - three fully qualified `example : TaskS.C.Challenge.conjectureC := …`, through `Proof.conjectureC`, `TaskS.C.check_conjectureC` and `TaskS.C.MeasureAudit.check_conjectureC`;
  - the `sInf` covering-radius form above.

  A separate `#print` run with `pp.fullNames` confirmed the elaborated statement and definitions quoted in §1. In particular `volume` resolves to `TaskS.C.Challenge.volume`, not to `MeasureTheory.volume`.

## 4. Mathematical sanity of MATHEMATICS.md

I re-derived the argument by hand, and it is correct. Write B(z) = frac(z) − ½ and let the events of label i be e_{ik} = −(x_i + k)/q_i.
- Hermite's identity gives Σ_k B(t − e_{jk}) = B(x_j + q_j t).
- Hence A_{ij} + A_{ji} = Σ_{k,l}[B(z) + B(−z)] ≤ 0, and A_{ii} = −q_i/2.
- Weighting the events of i by c_i (total weight W = Σq_i c_i) shows that some event has Σ_j c_j B(·) ≤ −Σq_i c_i²/(2W).
- The Cramer identity q_i = mβ_iω_i turns this into ½Σ(1−β_i)/ω_i = ½Σ1/ℓ_i.

MATHEMATICS.md states all of this correctly and maps it to the right Lean declarations. Prior-work attributions are accurate: CSS Thm 1.4 (the S(ω) family), Thm 4.9/Cor. 4.11 (d = 2), Prop. 4.4 (factor 2) and Lemma 4.1. Unformalized material (Task Q's integral version) is marked. The text never claims "first", and novelty is scoped to the 2026-11-20 G2. The equality characterization and the boundary-origin extension (§4.4) are correctly excluded, since they are not part of Conjecture C.

Missing context: MATHEMATICS.md does not say what this result implies (MINOR 1).

## MINOR write-up fixes

1. **MATHEMATICS.md and G2.md, consequences (important for publication).** Add a paragraph saying that, through CSS's own published arguments (not formalized here), the theorem implies the following:
   - the inequality μ(P) ≤ d/2 of Conjecture A for every non-hollow lattice d-polytope in every dimension (CSS Cor. 4.3, using Cor. 3.2);
   - by CSS Thm 1.2, Conjecture B of González Merino–Schymura, μ_ℓ(S(1^{n+1})) = ℓ/2 for all ℓ ≤ n.

   Mark both steps "not Lean-verified; relies on CSS Cor. 3.2/4.3 and Thm 1.2". Note consistency with paper 21: the Task R simplex attains μ = d/2 and is an equality case of C, and only A's "only if" clause fails. G2.md's sentence on Krivokuća ("不含本题…半系数体积比") understates the overlap: her paper works on exactly the gap in Conjecture B that this result would close. Reword it, and run G3 with this wider scope (also searching "Conjecture B", "covering minima of the standard terminal simplex", 2022–2026) before release. A result of this size also deserves careful human reading of the prose proof before any outward step.
2. **FINAL-HANDOFF.md / STATUS.md / MATHEMATICS.md, second receipt.** The measure-audit acceptance `acceptance/2026-11-20T223851Z/receipt.json` (SHA 4f37b409…, 14 modules) is not linked. MATHEMATICS only says "另有收据". Link it and give its hash.
3. **MATHEMATICS.md, hypotheses.** Say that the frozen hypothesis `0 < volume v` is implied by the interior hypothesis (`coordinates` proves affine independence from it). It is therefore not an extra restriction relative to CSS.
4. **MATHEMATICS.md, normalization sentence.** Say explicitly that 1/ℓ_i = (1−β_i)/ω_i (CSS Lemma 4.1 together with the barycentric identity in the proof of Cor. 4.3). Then `projected_eq` reads directly as the source's chord form (6), and readers can check it against CSS without the determinant model.
5. **Optional, MATHEMATICS.md, sawtooth section.** Name Hermite's identity Σ_k⌊a + k/q⌋ = ⌊qa⌋, and say once that "事件重合时保留其标签" means coincident events are counted with multiplicity (the Lean sum is over labelled pairs (i,k)).
