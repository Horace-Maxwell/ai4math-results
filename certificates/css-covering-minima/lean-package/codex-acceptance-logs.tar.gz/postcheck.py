"""Check actual replay artifacts and print one receipt summary for the taskbook."""
from pathlib import Path
import argparse, hashlib, json, re, subprocess

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def utc():
    return subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()
def audit(receipt):
    r=json.loads(receipt.read_bytes())
    path=receipt.parent
    folder=path.parents[1]
    order=r['order']
    assert r['status']=='MACHINE_PASS_PENDING_CLAUDE_FINAL' and len(order)==len(set(order))
    assert sha(folder/'FREEZE.json')==r['freeze_sha256']
    f=json.loads((folder/'FREEZE.json').read_bytes())
    assert all(sha(folder/p)==v for p,v in f['artifacts'].items())
    assert all(sha(folder/(m.replace('.','/')+'.lean'))==h for m,h in r['source_sha256'].items())
    ax=r['roots']['root1']['axioms']
    assert r['roots']['root1']==r['roots']['root2']
    expected={f['target'].replace('.Challenge.','.Proof.'), f['target'].replace('.Challenge.','.check_')}
    assert expected <= set(ax)
    assert all(set(a) <= {'propext','Classical.choice','Quot.sound'} for a in ax.values())
    count=0; peak=0
    for rootname in ['root1','root2']:
        root=path/rootname; logs=path/(rootname+'-logs')
        for m in order:
            rel=m.replace('.','/')
            assert sha(root/(rel+'.lean'))==r['source_sha256'][m]
            assert sha(root/'.lake/build/lib/lean'/(rel+'.olean'))==r['roots'][rootname]['modules'][m]
        for p in logs.glob('*.json'):
            if p.name=='external-cache-links.json': continue
            e=json.loads(p.read_bytes()); log=p.with_suffix('.log')
            assert e['exit']==0 and e['log_sha256']==sha(log) and e['resource_log_sha256']==sha(p.with_suffix('.resources'))
            assert not re.search(r'\b(?:warning|error):',log.read_text(),re.I)
            if p.name.endswith('-checker.json'):
                assert log.stat().st_size==0
                idx=int(p.name.split('-')[0]); assert e['command'][-2:]==['leanchecker',order[idx]]
            if p.name.endswith('-build.json'):
                idx=int(p.name.split('-')[0]); assert e['command'][-1]=='+'+order[idx]+':olean'
                assert re.search(r'\bBuilt '+re.escape(order[idx])+r'\s*\(',log.read_text())
            count+=1; peak=max(peak,e['peak_resident_bytes'])
        assert len(list(logs.glob('*-build.json')))==len(order)
        assert len(list(logs.glob('*-checker.json')))==len(order)
    assert count==2*(2*len(order)+1)
    return dict(utc=utc(),receipt=receipt.name,receipt_sha256=sha(receipt),main=f['target'],modules_per_root=len(order),
                total_commands=count,peak_single_command_bytes=peak,proof_check_axioms=ax,status='PASS')
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('receipt',type=Path)
    arg=p.parse_args()
    result=audit(arg.receipt)
    output=arg.receipt.parent/'postcheck.json'
    with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result,ensure_ascii=False))
