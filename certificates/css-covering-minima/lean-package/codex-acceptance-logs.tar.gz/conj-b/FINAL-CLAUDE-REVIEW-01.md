# Cross-family FINAL review 01: covering minima of the standard terminal simplex, CSS Conjecture B (Task S, conj-b)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The frozen target `TaskS.B.Challenge.ConjectureB` is the full Conjecture B of Codenotti–Santos–Schymura (originally González Merino–Schymura, Remark 4.9 of arXiv v1 / Remark 4.10 of the journal version). It covers every n and every 1 ≤ i ≤ n, all real linear surjections whose lattice image is a full lattice, and all target points. It is not a special case, not a finite proxy, not vacuous, and nothing is assumed as a hypothesis. It is fully Lean-verified: my independent Mac rebuild with leanchecker passes, and the axioms are only propext, Classical.choice and Quot.sound. The MINOR items concern the write-up and the G2 coverage only.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session (lock owner `claude-final-cssb`). I wrote none of the reviewed files.
- Review started 2026-11-20T22:43:21Z. Report written after 2026-11-20T22:50:26Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-cssb/`.

**On the speed warning.** The freeze-to-acceptance time (22:30Z to 22:39Z) is explained by the proof, not by a weak statement. Task Q had a written proof since about 18:40Z (`phase24/scout-q/attempts/geometry-terminal-projection/PROOF.md`). Codex's "4–8 weeks" estimate was for that proof's route, which uses Smith normal form and determinant weights. The Lean development uses a different, elementary route of about 350 lines: a one-dimensional sawtooth averaging lemma, plus an induction that splits a rational kernel along the positive support of a vector. I checked the statement against the primary sources independently (section 1). Its strength does not depend on how fast it was produced.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= `frozen/458363…/Challenge.lean`, byte-identical) | 458363b3baaa009cf079091bf9bec502d8740620b3083ffde0e3a4fcecb258b7 |
| CheckB.lean | 19c4742af2afc7345de1ffa4f11fe936e6cf30e9ba523cead681bb3b258eeb0f |
| Proof.lean | cb749dc2afc9857b5f5c3d072d09b175f0a60b18fd96ec9200cde2309b4d937b |
| Upper.lean | 7c9b413d23cb1ff3c5c3bc3b8d4a9c0b45d435873987722f7ad8e2da8b9b483b |
| Lower.lean | fb3c2f6598156eb4d5d288ac47e597b8593147f412d36b98b8814ecc0fa65a02 |
| Balanced.lean | ee6d212d4cf46118047a5975b66297c6e90ce44cd51a93253ec72d5b9f6d7edb |
| KernelRounding.lean | 2e0ed4a36a91ce2d7de43f2147060510565ac0196bcbba7b29a989b40042c8bd |
| Split.lean | ebb9105a70ba3c842a76f14e74194f2253621b82eddb015460c7dc8355d70d58 |
| RationalLine.lean | cdae999ce3563e96d2f7a069a09965302bf37c6011e70c44cb40b91bd9f048bd |
| BasisCoordinates.lean | 60276cfb91b651329c5f6c97f7c3c00c08e66e8e2c4f489538a80c60a4da9357 |
| Hull.lean | f39f9969c3d6b0640365af89565e53a43da393744c56f0f77e927baf847de395 |
| TaskS/Shared/Sawtooth.lean (= ../shared copy, byte-identical) | f3487fe4b73b29c14c20b1d784943a63850196ab94e2cbf4ad192684122b20dd |
| FREEZE.json | 484f776d481b7478e1a50f7b1caf25bb4e02fda3fe5242ecdf453c0169e37af2 |
| FREEZE-REVIEW.md | b0ff02d30b1365b031794d49df4cb2f63794208c93bf8db58393f7d2b79929ae |
| SOURCE-CHECK.md | 50da9c23b51d0731b74383a4d2d7d4c9770a25ab430fbb48cc24d646fc8694da |
| G2.md | 070c62f862d5e2da60b370984334c3fc3027103995e87f8907c19cefe87e74ae |
| MATHEMATICS.md | 580f0f811b3fdaff60ebc9b162672dd2895376c3364fa7ca6a05fbfdd9bf3b9e |
| FINAL-HANDOFF.md | c483eccbfbc2b4fec5aa2ef66d7420686414566f5410009146e27d38ff4a0416 |
| acceptance/2026-11-20T223418Z/receipt.json | a3307acd99c4f0b9f3b94fa486e8ed67649f2c8e0df3b2a362f8450fa9fb11d5 |
| CSS arXiv 1903.02866v2 PDF (local copy, phase24 lanes/graphs/css.pdf) | 4ece078961e7c03677952249ad8d205b40cf470c64ef51ab55f1f8e9d1a0fd6b |
| GMS arXiv 1605.00443v1 PDF (fetched by me) | c3b585d33cd9089bb0ee0dbe098ceb3843cb8a5b02f2f3c53e2a7389e852dce5 |
| My Audit.lean (scratch) | 5682047c9b717788aa394dcf38a1664a98671b6cf77ebf4fbe477936d895814b |

All 12 source hashes match `receipt.json.source_sha256`. The 12 `.lean` files in the task root are byte-identical to `acceptance/…/root1` and `root2`. The Challenge hash matches `FREEZE.json` and the `frozen/` snapshot. The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`. The receipt hash matches FINAL-HANDOFF and postcheck.json.

## 1. Is the statement the actual conjecture?

**Primary sources, quoted by me.**
- GMS, arXiv 1605.00443v1 (author line "González Merino and Henze"; Henze is Schymura's former name), p.8 eq. (14): μ_i(K,Λ) is the max of μ_i(K|L, Λ|L) over i-dimensional lattice planes L (Kannan–Lovász). Proposition 4.8 sets "Tn = conv{e1, . . . , en, −1}". In Remark 4.9 they derive μ_i(T_n) ≥ i/2 and write "We conjecture that this is actually an identity for every for i ∈ [n]".
- CSS, arXiv 1903.02866v2, pp.1–3. The covering radius is μ(K,Λ) = min{μ ≥ 0 : μK + Λ = R^d}, and a lattice is "a full-dimensional linear image of Zd". The covering minimum is μ_d(K,Λ) := max_π μ(π(K), π(Λ)), "where π runs over all linear projections π : Rn → Rd such that π(Λ) is a lattice". The simplex is S(1_{d+1}) := conv({−1_d, e_1, …, e_d}). Conjecture B ([10, Rem. 4.10]) reads "For every n ∈ N and d ≤ n, µd(S(1n+1)) = d/2."

**Definition-by-definition comparison.**

| Source | Lean (Challenge.lean) | Match |
|---|---|---|
| T_n = conv(−1, e_1, …, e_n) ⊂ R^n | `vertex n 0 = fun _ => -1`, `vertex n (succ j) = Pi.single j 1`, `terminal n = convexHull ℝ (range (vertex n))` (checked with `#print`) | yes |
| Λ = Z^n | `embed : (Fin n → ℤ) → (Fin n → ℝ)`, coordinatewise cast | yes |
| π : R^n → R^i linear, π(Z^n) a full lattice | `LatticeProjection p`: p is surjective and range(p ∘ embed) equals the ℤ-span {∑ w_j b_j} of some ℝ-basis b of R^i | yes. This is exactly "full-dimensional linear image of Z^i". All real linear maps are allowed, with oblique kernels and arbitrary target bases. It is not a finite family and not restricted to integer matrices. |
| μ(πK, πΛ) ≤ r ⇔ rπK + πΛ = R^i | `Covers p r : ∀ x, ∃ z y, y ∈ terminal n ∧ x = p (embed z) + r • p y` | yes. Every real point x is quantified. |
| μ_i(T_n) = max over π of μ(πT_n, πZ^n) = i/2 | `ConjectureB : ∀ n i, 0 < i → i ≤ n → (∀ p, LatticeProjection p → Covers p (i/2)) ∧ ∃ p, LatticeProjection p ∧ IsLeast {r | 0 ≤ r ∧ Covers p r} (i/2)` | yes. The first clause gives sup ≤ i/2 over all admissible π. The second gives one π whose covering radius is exactly i/2, so the max is i/2 and it is attained. The range is all n and all 1 ≤ i ≤ n, which is the whole conjecture (i = 0 is trivial and excluded). |

GMS's formulation (orthogonal projection onto i-dimensional lattice planes, or equivalently (n−i)-flats via Kannan–Lovász) is equivalent to CSS's. Every admissible π is a linear isomorphism composed with the orthogonal projection onto (ker π)^⊥. ker π is rational exactly when π(Z^n) is discrete, and μ is invariant under linear isomorphisms. The Lean statement follows CSS, which is the formulation named "Conjecture B".

**No weakening, no degeneracy, nothing assumed.** No `Nat.card`/`ncard` is used. `Covers` cannot hold trivially: `Lower.lean` proves that the coordinate projection fails to cover at every r < i/2. `LatticeProjection` is satisfiable: `coord_admissible` proves it for the coordinate projection. `Challenge.lean` has no hypotheses and no axioms, and no known theorem is taken as a premise. The proof of the upper bound in `Upper.lean` works for an arbitrary `p` and arbitrary `b`. Quantifier order: the universal bound is over every `p`, and the witness `p` comes only in the attainment clause. SOURCE-CHECK rightly notes that "every projection attains i/2" would be false. Its example x+y on T_2 gives the interval [−2,1] with radius 1/3, which I confirmed numerically (0.3333).

**My numerical tests** (`numtest.py`, `numtest.out` in scratch):
- The sawtooth lemma min_t ∑_j {x_j + q_j t} ≤ (m−1)/2 was checked exactly with rationals on 3000 random instances (m ≤ 6, q_j ≤ 6), evaluating every breakpoint. There were no violations, and equality occurs.
- For random admissible integer projections (gcd of maximal minors = 1), I sampled covering radii on a grid. All were ≤ i/2: d=1 (n=3), d=2 (n=2,3,4), d=3 (n=3,4). The coordinate projection gives i/2 (1/2, 1, 1.5). Grid sampling only gives lower estimates, so this is a sanity check, not a proof.

**Prior settlement (item 7).** CSS Theorem 1.3 together with Theorem 1.2 gives B only for i ≤ 3. GMS Prop. 4.8 gives i = n, and i = 1 is known (lattice width 2). Krivokuća arXiv:2601.15173 (Jan 2026) gives only upper bounds with a loss: Cor. 5.6, and Cor. 5.9 μ_i(T_d) ≤ (i/2)(1 + (d−i)/(d+1)). She still treats the conjecture as open (her Conj. 4.2, and Cor. 4.4 is conditional on it). The abstracts of Codenotti–Freyer–Krivokuća arXiv:2606.14442 (minimal covering bodies, planar Brunn–Minkowski), arXiv:2610.39034 (κ-covering minima) and Williams arXiv:2606.06291 make no claim on B or A. Two web searches (extended) found no proof of Conjecture A's d/2 bound or of B in general dimension. I found no prior settlement. This is a G2-level statement only; see MINOR 2.

## 2. Proof chain

- `CheckB.lean` contains exactly `theorem check_ConjectureB : Challenge.ConjectureB := Proof.ConjectureB` (plus `#print axioms`). Inside `namespace TaskS.B` this resolves to `TaskS.B.Challenge.ConjectureB`. My Audit.lean checks both with fully qualified names, and checks the `Iff.rfl` unfolding of the frozen definition.
- No local file defines anything in `TaskS.B.Challenge` besides Challenge.lean. The other namespaces are `TaskS.Shared`, `TaskS.B.Hull`, `.Coordinates`, `.Rounding`, `.Upper`, `.Proof`, and `TaskS.B` (Lower: `exists_projection_lower` and private helpers). There is no shadowing.
- grep over all 12 local `.lean` files for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, set_option, initialize, run_cmd, ofReduceBool, `@[` and `decide`: the only hits are the two `#print axioms` lines. There are no `decide` uses and no attributes.
- Structure of the proof:
  - `Proof.ConjectureB` combines `Upper.upper` (every admissible p covers at i/2) with `exists_projection_lower` (the coordinate projection and an explicit coset with coordinates j/(i+1); Hermite's identity forces r ≥ i/2).
  - The upper bound works as follows. Write any target point as p(∑ x_j v_j). The integer coordinate matrix A has zero row sums, so its rational kernel K contains the all-ones vector and has dim ≥ n+1−i. `Rounding.round` gives h ∈ ker_ℝ A with ∑{x_j+h_j} ≤ (n+1−dim K)/2 ≤ i/2. Then ⌊x+h⌋ gives the lattice point, and `Hull.scaled` turns the fractional parts into a point of (i/2)·T_n.
  - `Rounding.round` is well-founded on |ι|. It takes the sawtooth `LineBound` as an explicit argument, discharged by `TaskS.Shared.sawtooth_unweighted` in `Balanced.lean`, so it is proved and not assumed.

## 3. Independent rebuild on this Mac

- Lock: `leanlock.sh acquire any claude-final-cssb 60` gave slot A at 22:44Z. It was released with `leanlock.sh release A claude-final-cssb` at about 22:49Z (`released A`; status afterwards: A free). Only one Lean process ran at a time.
- Toolchain: Lean 4.34.1 (`work/toolchains/lean-4.34.1-darwin_aarch64`), prebuilt Mathlib d13f23b7 oleans via LEAN_PATH (`work/research-lean-v434/.lake/packages`). I used plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o out/<M>.olean`. The sources were copied into the new empty scratch folder `final-cssb/src`, with output in the new empty `final-cssb/out`.
- Order: TaskS.Shared.Sawtooth, Challenge, Hull, RationalLine, Split, KernelRounding, BasisCoordinates, Balanced, Upper, Lower, Proof, CheckB, plus my Audit. All 13 compiled with exit 0 and **zero diagnostics**. `leanchecker <M>` returned exit 0 with empty output for all 13.
- Axioms (from `#print axioms` in Proof, CheckB and Audit): `TaskS.B.Proof.ConjectureB` and `TaskS.B.check_ConjectureB` depend on [propext, Classical.choice, Quot.sound] only.
- Logs: `final-cssb/compile.log`, `final-cssb/compile.json`.

## 4. Mathematics (MATHEMATICS.md)

- The write-up follows the Lean route accurately. The 1D lemma uses events E_{j,k} = −(x_j+k)/q_j and g(s)+g(−s) ∈ {0, −1}, averaged over ∑q_j events. The rounding lemma uses positive-support splitting with dim K_S + dim K_T = r. The upper bound padding by (i/2−s)/(n+1) uses ∑v_j = 0. The coordinate lower bound is as in Lower.lean. I checked each step and found them correct.
- Attribution is correct. The lower bound is GMS Remark 4.9 (journal 4.10), and i = n is GMS. i ≤ 3 is CSS Thm 1.3 via Thm 1.2. Krivokuća's general bound has an extra factor. CFK is related work.
- Non-Lean content is marked: the equality classification, other simplices and priority are excluded. Novelty is limited to "据截至 2026-11-20 的 G2 检索". There is no "first" claim and no overclaim.
- It omits the most important consequence (MINOR 1).

## MINOR fixes (write-up and G2 only; none affects the Lean result)

1. **State the consequence for CSS Conjecture A, marked as not Lean-verified.** CSS Theorem 1.2 ((ii) ⇒ (i), proved in CSS §3.1 via Corollary 3.2 and a projection of S(1_N)) turns B for all ℓ into the inequality half of Conjecture A in every dimension: μ(P) ≤ d/2 for every non-hollow lattice d-polytope P. MATHEMATICS.md should say this in one sentence, cite CSS Thm 1.2, mark it as not formalized, and keep it separate from the equality characterization. The Task R counterexample shows the stated equality condition of A is false. This makes the result much more significant than "a special covering-minimum formula", which raises the stakes of item 2.
2. **Close the G2 coverage gaps before release.** All three OpenAlex citing-works queries returned HTTP 429 (`g2-evidence/lattice/citing-*.json`), so citing works were covered only by Semantic Scholar (10 items) and Crossref (count 5). Given item 1, G3 should re-run the citing-works search for CSS (journal and arXiv), GMS (DCG 58, 2017) and Krivokuća 2601.15173. It should also check the authors' recent pages (Schymura, Codenotti, Santos, Krivokuća) and the chy4pro/automath lead that G2 already flagged.
3. **Wording in 「投影的上界」.** 「其列和为零」 should be 「各行和为零（即各列向量之和为零，A·1 = 0）」. A is i × (n+1), and what is used is A·1 = 0 (`Coordinates.balanced`: ∑_j A k j = 0).
4. **Source numbering.** Say once in MATHEMATICS.md that GMS arXiv v1 Remark 4.9 is journal Remark 4.10 (the label CSS cites), and that the arXiv v1 second author "Henze" is Schymura. SOURCE-CHECK already notes this.
