# Cross-family FINAL review 02: covering minima of the standard terminal simplex (Task S, Conjecture B)

**Verdict: APPROVE_FORMAL.** I found no BLOCKER and no MAJOR items. The frozen target `TaskS.B.Challenge.ConjectureB` states Conjecture B of Codenotti–Santos–Schymura (CSS) exactly, over its full range. It is fully Lean-verified: the axioms are only `propext`, `Classical.choice` and `Quot.sound`, and my independent Mac rebuild and `leanchecker` pass on every module. The MINOR items below concern the write-up (`MATHEMATICS.md`, G2) and how the result is described. Fix them before publication. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5). I am a second, independent subagent of the user's Claude session. I wrote none of the reviewed files, and I read FINAL-CLAUDE-REVIEW-01.md only after I had written sections 1–5.
- Review started 2026-11-20T22:52:35Z. Sections 1–5 were written at 2026-11-20T23:08Z, and section 6 after that (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/final-cssb2/`.
- Lean lock: I took slot A as owner `claude-final-cssb2` at 22:52:45Z and released it at about 22:57Z. Only one Lean process ran at a time.

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| Challenge.lean (= `frozen/…/Challenge.lean`, byte-identical) | 458363b3baaa009cf079091bf9bec502d8740620b3083ffde0e3a4fcecb258b7 |
| CheckB.lean | 19c4742af2afc7345de1ffa4f11fe936e6cf30e9ba523cead681bb3b258eeb0f |
| Proof.lean | cb749dc2afc9857b5f5c3d072d09b175f0a60b18fd96ec9200cde2309b4d937b |
| Upper.lean | 7c9b413d23cb1ff3c5c3bc3b8d4a9c0b45d435873987722f7ad8e2da8b9b483b |
| Lower.lean | fb3c2f6598156eb4d5d288ac47e597b8593147f412d36b98b8814ecc0fa65a02 |
| Balanced.lean | ee6d212d4cf46118047a5975b66297c6e90ce44cd51a93253ec72d5b9f6d7edb |
| KernelRounding.lean | 2e0ed4a36a91ce2d7de43f2147060510565ac0196bcbba7b29a989b40042c8bd |
| Split.lean | ebb9105a70ba3c842a76f14e74194f2253621b82eddb015460c7dc8355d70d58 |
| RationalLine.lean | cdae999ce3563e96d2f7a069a09965302bf37c6011e70c44cb40b91bd9f048bd |
| BasisCoordinates.lean | 60276cfb91b651329c5f6c97f7c3c00c08e66e8e2c4f489538a80c60a4da9357 |
| Hull.lean | f39f9969c3d6b0640365af89565e53a43da393744c56f0f77e927baf847de395 |
| TaskS/Shared/Sawtooth.lean (= ../shared copy) | f3487fe4b73b29c14c20b1d784943a63850196ab94e2cbf4ad192684122b20dd |
| FREEZE.json | 484f776d481b7478e1a50f7b1caf25bb4e02fda3fe5242ecdf453c0169e37af2 |
| FREEZE-REVIEW.md | b0ff02d30b1365b031794d49df4cb2f63794208c93bf8db58393f7d2b79929ae |
| SOURCE-CHECK.md | 50da9c23b51d0731b74383a4d2d7d4c9770a25ab430fbb48cc24d646fc8694da |
| G2.md | 070c62f862d5e2da60b370984334c3fc3027103995e87f8907c19cefe87e74ae |
| MATHEMATICS.md | 580f0f811b3fdaff60ebc9b162672dd2895376c3364fa7ca6a05fbfdd9bf3b9e |
| FINAL-HANDOFF.md | c483eccbfbc2b4fec5aa2ef66d7420686414566f5410009146e27d38ff4a0416 |
| acceptance/2026-11-20T223418Z/receipt.json | a3307acd99c4f0b9f3b94fa486e8ed67649f2c8e0df3b2a362f8450fa9fb11d5 |
| CSS arXiv v2, local copy `phase24/scout-q/lanes/graphs/css.pdf` (read by me) | 4ece078961e7c03677952249ad8d205b40cf470c64ef51ab55f1f8e9d1a0fd6b |
| GMS arXiv 1605.00443v1 PDF (fetched by me) | c3b585d33cd9089bb0ee0dbe098ceb3843cb8a5b02f2f3c53e2a7389e852dce5 |
| My Audit.lean (scratch) | 40d4a73acb0a930cc1f7fb03a242ced03304e323eb39cd31dfd9802bd00d19f2 |

All 12 source hashes match `receipt.json.source_sha256`. All 11 top-level `.lean` files are byte-identical to `acceptance/…/root1` and `root2`. The Challenge hash matches `FREEZE.json` and the `frozen/` snapshot. The FREEZE-REVIEW, SOURCE-CHECK and G2 hashes match `FREEZE.json`. The receipt hash matches FINAL-HANDOFF and `postcheck.json`.

## 1. Is the statement faithful to the source?

**Source definitions, from my own reading.**

- **CSS (arXiv v2, p. 3).** The d-th covering minimum is μ_d(K,Λ) := max_π μ(π(K), π(Λ)), "where π runs over all linear projections π : Rⁿ → R^d such that π(Λ) is a lattice". On p. 2 they define μ(K,Λ) as the least t ≥ 0 with tK + Λ = Rⁿ, a lattice as an invertible linear image of Zⁿ (so full rank), and S(1_{d+1}) := conv({−1_d, e₁, …, e_d}). Conjecture B ([10, Rem. 4.10]) reads: "For every n ∈ N and d ≤ n, μ_d(S(1_{n+1})) = d/2."
- **GMS (arXiv 1605.00443v1, p. 2).** The arXiv author line says "González Merino and Henze"; Henze is the same person as Schymura. They define μ_i(K,Λ) = inf{μ > 0 : (μK+Λ) ∩ L ≠ ∅ for all L ∈ A_{n−i}(Rⁿ)}, using affine (n−i)-flats. Their eq. (14), p. 8, quotes Kannan–Lovász: μ_i(K,Λ) = max{μ_i(K|L, Λ|L) : L ∈ L_i(Λ)}, an equivalent form via orthogonal projections onto i-dimensional lattice planes. Remark 4.9 gives μ_i(T_n) ≥ μ_i(T_i) = i/2 and then says: "We conjecture that this is actually an identity for every i ∈ [n]".
- **The definitions agree.** A linear map π with π(Zⁿ) a full-rank lattice has rational kernel, and conversely. Composing with a linear isomorphism of the target does not change μ. So the CSS "all π with lattice image" form, the KL/GMS "orthogonal projection onto lattice planes" form, and the GMS affine-flat definition all agree. The Lean formalization follows CSS.

**Lean against the source.**

- **`vertex`, `terminal`.** Label 0 is the all-(−1) vector and label j+1 is `Pi.single j 1`. I confirmed this with `rfl` examples in Audit.lean. `terminal n` is the real convex hull of these n+1 points, which is exactly S(1_{n+1}) = T_n.
- **`LatticeProjection p`.** This means p is surjective and p(Zⁿ) = {Σ w_j b_j : w ∈ Zⁱ} for some ℝ-basis b of ℝⁱ.
  - *Discreteness.* The integer span of an ℝ-basis is discrete and of full rank, so a dense image (for example x+√2·y) is excluded.
  - *No legitimate projection is excluded.* Every full-rank lattice in ℝⁱ is the integer span of some ℝ-basis, and the condition allows any basis, oblique or rescaled.
  - *Surjectivity* is implied by the basis clause, so it is redundant but harmless.
  - *Non-vacuous.* `coord_admissible` in Lower.lean proves that the coordinate projection qualifies. Also, x+y : ℝ²→ℝ qualifies; its image is ℤ.
- **`Covers p r`.** Every x ∈ ℝⁱ equals p(z) + r·p(y) with z ∈ Zⁿ and y ∈ T_n. This is exactly ℝⁱ = π(rT_n) + π(Zⁿ), covering the whole target.
- **`ConjectureB`.** It is quantified over all n and 0 < i ≤ n, with no cutoff, and has two conjuncts:
  - (a) every admissible p satisfies `Covers p (i/2)`, so μ(πT, πZⁿ) ≤ i/2 for every π;
  - (b) some admissible p has `IsLeast {r | 0 ≤ r ∧ Covers p r} (i/2)`. So i/2 is a covering scale for p and every nonnegative covering scale of p is at least i/2. This is a genuine "minimum equals i/2" statement and not just an upper bound.
  - Together, (a) and (b) say exactly that the maximum over π of μ(πT_n, πZⁿ) is i/2 and is attained, which is CSS's μ_i(S(1_{n+1})) = i/2. Clause (b) follows from (a) plus GMS's coordinate projection; it is included because a max must be attained. The SOURCE-CHECK example x+y → [−2,1] has μ = 1/3. I reproduced this numerically. It shows that "every projection has μ = i/2" would be a false strengthening, and the freeze correctly avoids it.
- **No degeneracy.** There are no cardinalities and no `ncard`/`Nat.card`. The radius set in (b) is constrained to r ≥ 0, and i/2 > 0.
- **No instance or coercion tricks.** grep finds no `instance`, `attribute`, `notation`, `macro` or `set_option` in any local file. The only local instances are two `let : Nonempty …` in a proof. My Audit.lean restates the whole theorem fully unfolded, using only Mathlib's standard `Fin n → ℝ`, `convexHull`, `Module.Basis` and `Set.range`, and closes it with `TaskS.B.Proof.ConjectureB`. It compiles, so the proved proposition is the frozen one with standard instances.

## 2. Proof chain and how the proof works

- **Check file.** CheckB.lean is exactly `theorem check_ConjectureB : Challenge.ConjectureB := Proof.ConjectureB` inside `namespace TaskS.B`. No local file reopens `namespace TaskS.B.Challenge`. The other namespaces are `Coordinates`, `Hull`, `Upper`, `Rounding`, `Proof` and `TaskS.Shared`. Audit.lean also uses the fully qualified name, so no name is shadowed.
- **grep.** I searched all 12 local files (636 lines) for sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, set_option, initialize, run_cmd, ofReduceBool, `@[`, instance and decide. The only hits are the two `#print axioms` lines. There are no `decide` calls.

**Why the upper bound holds (my own reading of Upper/Balanced/KernelRounding/Split/RationalLine/Sawtooth).**

1. **Reduce to fractional parts.** Write the vertices of T_n as v₀ = −1, v_j = e_j. Choose a basis of the image lattice. The projected vertices then become the columns of an integer i×(n+1) matrix A whose rows sum to 0, because Σv_j = 0; so the all-ones vector lies in ker A. Every target point is p(Σ_j x_j v_j) for some real x. For any h ∈ ker_ℝ A, split x_j + h_j into its integer part and its fractional part. The integer parts give a lattice point Σ⌊x_j+h_j⌋v_j ∈ Zⁿ. The fractional parts give a nonnegative combination of vertices of total weight s = Σ{x_j+h_j}. Since Σv_j = 0, the weight can be padded up to any r ≥ s, which yields a point of rT_n (Hull.scaled). Hence the target point is covered at scale r as soon as some h ∈ ker A has Σ{x_j+h_j} ≤ r.
2. **Kernel rounding lemma (new core).** Let K ⊆ ℚ^m be a rational subspace of dimension k that contains a strictly positive vector. Then for every x ∈ ℝ^m there is an h ∈ K_ℝ with Σ{x_j+h_j} ≤ (m−k)/2. With m = n+1 and k ≥ n+1−i this gives i/2.
   - *Base case k = 1.* K is spanned by a positive integer vector q. The "sawtooth averaging" lemma (Sawtooth.lean) supplies a t with Σ{x_j+q_j t} ≤ (m−1)/2. It is proved by averaging the deviations {·}−½ over the jump points of all the sawtooth functions; the pairwise terms are ≤ 0 and the diagonal terms equal −q_i/2.
   - *Inductive step k ≥ 2.* Choose a vector v ∈ K that is ≥ 0 and has both a zero coordinate and a positive one: subtract a multiple of the positive vector from a non-proportional element. This splits the coordinates into T = {v_j = 0} and S = {v_j > 0}. Recurse first on the restriction of K to T, which still contains a positive vector. Then recurse on the vectors of K that vanish on T, restricted to S; these contain v|_S > 0. The second correction does not disturb T. By rank–nullity the two dimensions add up to k, so the two bounds add up to (m−k)/2.
3. **Lower bound.** This is GMS's coordinate projection. Lower.lean shows directly that the point (1/(i+1), …, i/(i+1)) is not covered at any r < i/2, using Hermite's identity Σ_k{a+k/N} = {Na} + (N−1)/2.

This argument is elementary and short (636 Lean lines), which is consistent with the ~10-minute formalization. The kernel guarantees correctness. I also checked the steps on paper and found no gap. I noticed that the upper-bound proof uses only p(Zⁿ) ⊆ (some lattice), not equality. That is stronger than needed and does not matter here.

## 3. Independent rebuild on this Mac

- **Setup.** Plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R <task dir> -o …`, Lean 4.34.1 (commit 5045d005…), against the prebuilt Mathlib d13f23b7 oleans via LEAN_PATH, into a new empty output directory `…/final-cssb2/build1/out`.
- **Order.** Challenge, RationalLine, Split, TaskS.Shared.Sawtooth, BasisCoordinates, Hull, KernelRounding, Lower, Balanced, Upper, Proof, CheckB, then my Audit.
- **Results.**
  - All 13 modules compile with rc 0 and print no diagnostics other than the `#print axioms` lines. Each took 8.5–10.4 s.
  - `leanchecker` gives rc 0 with empty output for all 13 modules.
  - `#print axioms` shows `[propext, Classical.choice, Quot.sound]` for both `TaskS.B.Proof.ConjectureB` and `TaskS.B.check_ConjectureB`, in Proof/CheckB and again in Audit.
- **Audit.lean contents.**
  - The target, via `Proof` and via `check_`;
  - the fully unfolded restatement;
  - `rfl` checks of both vertex cases.

## 4. Numerical stress test (my own code, independent of the Lean proof)

- **Method.** Every lattice projection is equivalent, after a change of target basis, to an integer i×n matrix A whose columns generate Zⁱ, meaning the gcd of the i×i minors is 1. Then P = conv(−ΣA_j, A_1, …, A_n) and the lattice is Zⁱ. I computed the facet normals of P (scipy ConvexHull; P contains 0 in its interior) and evaluated F(x) = min_z ‖x−z‖_P on a grid over [0,1)ⁱ. I then refined the eight best grid points by LP hill-climbing over the active facets. This method is a gauge computation that does not use the proof's fractional-part reduction.
- **Calibration.** It returns exactly i/2 for every coordinate projection with n ≤ 4, and 1/3 for x+y. (`num/cov.py`, `num/sweep.py`, `num/exh.py`; outputs `num/*.out`.)
- **Runs.** About 14,000 admissible projections with n ≤ 5 and i ≤ 4. All three families below covered every (n,i) pair that applies to them:
  - random A with entries up to ±3 (3,515 projections);
  - projections along random primitive kernel vectors u with entries up to ±5, for i = n−1 (4,100);
  - adversarial hill-climbing on the entries of A to maximize μ, for (n,i) ∈ {(4,2),(4,3),(5,2),(5,3),(5,4)} (3,775).
- **Exhaustive cases.** All primitive kernel directions with |u_j| ≤ 2 for n = 4, i = 3 (272 up to sign), and with |u_j| ≤ 1 for n = 5, i = 4 (121).
- **Result.** There are zero violations of μ ≤ i/2 at tolerance 1e-7. The maximum ratio μ/(i/2) is exactly 1.0 in every (n,i) class. Equality is common: 15 of 272 cases at (4,3) and 41 of 121 at (5,4), for example u = −1, which projects T_n onto T_{n−1}. Non-extremal values seen include 0.652, 0.8286 and 0.9333.
- **Caveat.** The grid with refinement gives a lower estimate of μ, so this tests for counterexamples. It does not prove the bound. It agrees completely with the Lean theorem, including the new case (5,4), where Krivokuća's best published bound is 7/3.

## 5. Mathematics, attribution and the consequence for Conjecture A

**CSS Theorem 1.2 (arXiv v2, p. 3), quoted:**

"Theorem 1.2 (Equivalence of Conjectures A and B, Section 3.1). For each d ∈ N, the following are equivalent: i) µ(P) ≤ ℓ/2 for every non-hollow lattice ℓ-polytope P and for every ℓ ≤ d. ii) Conjecture B holds for every ℓ ≤ d. That is, µ_ℓ(S(1_{n+1})) = ℓ/2, for every ℓ, n ∈ N with ℓ ≤ d ≤ n."

**What follows from the Lean result.** The Lean result is (ii) for every d. By the published proof of (ii)⇒(i) (CSS §3.1, together with Lemma 3.1, Corollary 3.2 and Lemma 2.1), it implies:

> For every d ≥ 1, every non-hollow lattice d-polytope P ⊂ ℝ^d (one with a lattice point in its interior) has covering radius μ(P, Z^d) ≤ d/2.

That is the **inequality part of Conjecture A in all dimensions**. It holds for all polytopes, not only simplices: Corollary 3.2 reduces polytopes to simplices. Three qualifications:

- **The direction used is B ⇒ A-inequality.** The CSS proof needs μ(P,Zˡ) ≤ μ(π(S(1_N)), π(Z^{N−1})) for an integer projection π with π(S(1_N)) = P and π(Z^{N−1}) ⊆ Zˡ. That image is a full-rank sublattice because P is full-dimensional, so π satisfies `LatticeProjection`. The Lean clause (a) therefore supplies exactly the input that CSS's argument consumes.
- **This implication is not Lean-verified.** It is a published argument in a refereed DCG paper.
- **The equality characterization in Conjecture A does not follow.** Per BRIEF.md, the user's Task R work concerns a counterexample to that equality case. Describe the consequence only as "the bound μ(P) ≤ d/2 of Conjecture A".

**MATHEMATICS.md.** The mathematics is correct and matches the Lean proof. Prior work is attributed correctly:

- GMS for the coordinate lower bound and the full-rank case d = n;
- CSS Theorem 1.3 for d ≤ 3;
- Krivokuća 2601.15173 Cor. 5.9 (i/2)(1+(n−i)/(n+1)) as the best earlier general bound;
- Codenotti–Freyer–Krivokuća 2606.14442 as related work.

It does not say "first", it limits novelty to the G2 search date, and it marks the non-Lean items. However, it never mentions the Conjecture A consequence (MINOR 1), and it has small wording issues (MINORs 2–3).

**Literature (my own searches, 2026-11-20).** None of these found any proof or refutation of Conjecture B, or of the d/2 bound of Conjecture A, from 2022–2026:

- WebSearch, extended: "covering radius non-hollow lattice polytope d/2 conjecture Codenotti Santos Schymura proof". Results: CSS (arXiv/PMC/Springer), Codenotti's thesis, Krivokuća 2601.15173. It found no general proof.
- WebSearch: "covering minima" "terminal simplex" 2026. Only Krivokuća was relevant.
- WebSearch: GMS conjecture "proved all dimensions". Nothing relevant.
- WebSearch: Averkov/Schymura 2024–25. It found Schymura–Wang–Xue 2505.07369, on locally anti-blocking bodies, which is not relevant.
- arXiv API full-text search sorted by date: `all:"covering radius" AND lattice AND polytope` (6 hits) and `abs:"covering minima" OR "covering minimum" OR "non-hollow"` (32 hits, newest Xue 2610.39034 "On κ-covering minima", 2026-10-28). Neither query turned up any proof claim.
- I read Krivokuća 2601.15173v1 HTML. Its Cor. 5.6 and 5.9 are upper bounds equal to i/2 only when i = n. It states the i/2 identity as open, its Conjecture 4.2.
- I read the 2606.14442 abstract. It does not mention Conjecture A or B.
- Failed or limited queries:
  - My first WebFetch of the GMS PDF returned binary only; I extracted the text locally with pdftotext.
  - I did not open full texts for the CSS citing papers. The G2 record shows that the OpenAlex citing queries returned 429 and Semantic Scholar returned only 10 citers (MINOR 4).

## Numbered MINOR fixes

1. **MATHEMATICS.md (and any public description): add the Conjecture A consequence.** Quote CSS Theorem 1.2. State that, through its published (ii)⇒(i) argument, the Lean result implies μ(P) ≤ d/2 for every non-hollow lattice d-polytope in every dimension. Mark this implication as not Lean-verified, and say explicitly that the equality characterization of Conjecture A is not implied (and is the subject of the separate Task R counterexample). Do not call the result "a proof of Conjecture A".
2. **MATHEMATICS.md, upper-bound section.** "列和为零" is ambiguous. Write "A 的每一行之和为零（即 A·𝟙 = 0，因为 Σ_j v_j = 0）".
3. **MATHEMATICS.md.** Avoid presenting the one-variable sawtooth averaging lemma as new in itself unless G3 confirms it. It resembles classical averaging and lonely-runner-type arguments. The claimed novelty should be the full statement (Conjecture B for all d) and the kernel-splitting induction, both qualified by the G2 date.
4. **G2/G3 before publication.** This result settles a published conjecture that is equivalent to the d/2 bound of Conjecture A, a noticeably higher-profile claim than usual. Redo the citing-paper sweep of CSS (DCG 67 (2022), arXiv 1903.02866), since the OpenAlex queries returned 429. Also check the citers of Krivokuća 2601.15173 and Google Scholar "cited by" for both, and recheck arXiv for anything since 2026-11-20.

## 6. Comparison with FINAL-CLAUDE-REVIEW-01 (read after sections 1–5 were written)

**Agreement.** Review 01 reaches the same verdict, APPROVE_FORMAL with no BLOCKER or MAJOR. We agree on the substance:
- the faithfulness analysis of `LatticeProjection`, `Covers` and the max/IsLeast encoding;
- the CSS/GMS/Kannan–Lovász equivalence;
- the proof structure;
- the axioms, with matching hashes;
- the Conjecture A consequence (their MINOR 1 = my MINOR 1);
- the G2 citing-sweep gap (their MINOR 2 = my MINOR 4);
- the "列和为零" wording (their MINOR 3 = my MINOR 2).

**Substantive disagreements:** none.

**Complementary points.**
- (a) **Numerics.** Review 01 tested the sawtooth lemma exactly and sampled covering radii only for d ≤ 3, which CSS had already settled. My stress test adds the cases that were open before this work: (n,i) = (5,3) and (5,4) across random, kernel-direction, hill-climbing and exhaustive small-entry families. It found zero violations, and the maximum μ/(i/2) was exactly 1.
- (b) **I endorse their MINOR 4.** State once that GMS arXiv v1 Remark 4.9 is journal Remark 4.10, and that the arXiv author "Henze" is Schymura. Treat it as my MINOR 5.
- (c) **My MINOR 3, not in Review 01.** Do not claim novelty for the one-variable sawtooth lemma by itself before G3.
- (d) **Trivial wording.** Review 01 says "12 `.lean` files in the task root" and "about 350 lines". There are 11 top-level files plus `TaskS/Shared/Sawtooth.lean`, and 636 lines in total including Challenge, comments and blank lines. Neither point matters.
- (e) **Williams 2606.06291.** Review 01 lists this paper as making no claim. I did not check it independently.

5. (adopted from Review 01, MINOR 4) In MATHEMATICS.md, map GMS arXiv v1 Remark 4.9 to journal Remark 4.10 and note that Henze = Schymura.

Report completed 2026-11-20T23:10:03Z; lock slot A released at about 22:57Z (status: A free, B free).
