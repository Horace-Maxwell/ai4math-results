# Task S（2026-11-20，Claude 代用户下达）：格覆盖猜想 B、C 做到完整 Lean

`$P = <workspace>`。输出目录 `$P/work/codex-r3/phase26/taskS/`，下设两个子目录：`conj-b/` 和 `conj-c/`。

## 用户决定
用户原话："格覆盖 B、C 也让 Codex 开始做 Lean"。

## 题目
依据 Task Q 的书面工作：`phase24/scout-q/REPORT.md`（GEO01 卡）、`attempts/geometry-terminal-projection/`（PROOF.md、DISCRETE-HADWIGER.md、REVIEW-ALGEBRA.md）、`audit/late-prior/NOTE.md`。

**B（`conj-b/`）**
- 内容：标准终端单纯形在各维投影下的覆盖极小值，书面答案 i/2。出处是 González Merino–Schymura 提出、CSS 跟进的问题，以原文为准。
- Codex 先前估计：4–8 周，把握 45–65%。
- 先找最小的完整可冻结陈述，并定好分阶段的里程碑，例如先做小维数，再做一般维数。
- 但冻结的陈述必须是原问题的全范围，不能把它缩成"小维数版"来冒充；小维数只能作为中间里程碑。

**C（`conj-c/`）**
- 内容：用离散表面积控制覆盖半径。范围是有理顶点方向、原点在内部的任意单纯形（CSS Conjecture C）。
- Task Q 还给出了一条"圆周锯齿函数"的短路线。

**已发表的部分**
- 四维反例（论文 21）和 CSS 猜想 A 的取等反例已经完成，就在 `phase25/taskR/css-counterexample/`。
- 可以复用它的 Lean 定义（覆盖半径等），但要按原文重新核对，不得弱化。

## 流程
同 Task N（`phase21/taskN/BRIEF.md`）。
1. SOURCE-CHECK：由非作者逐字核对原文定义，检查"定义可满足、问题非平凡"。
2. G2 刷新，包括 AI 竞争检查：近期 Krivokuća、Codenotti–Freyer–Krivokuća 等相关工作必须查到，并写明本题与它们的边界。
3. 冻结 `Challenge.lean`：经非作者审查，冻结后不改。冻结审查前必须先确认能零诊断编译（这是 Task R 的教训）。
4. 写 Lean：多个作者子代理按模块并行写，开发期间不做逐批审查。基础设施可以大，但要模块化。
5. 验收：两个新的空目录全闭包编译，逐模块跑 `leanchecker`。公理只允许 propext、Classical.choice、Quot.sound；禁止 sorry、native_decide、bv_decide、axiom。`Check*.lean` 逐条写成 `theorem check_X : Challenge.X := Proof.X`。
6. `MATHEMATICS.md`：分清前人工作与新内容，未经 Lean 验证的地方逐条标明，新意限定为"据截至某日的 G2 检索"。
7. 每题验收通过后写 `FINAL-HANDOFF.md`，并在 `CODEX-TASKS.md` 顶部写一条。卡住超过一天就写明卡点，并说明还需要多少工作量。

## 机器
- Mac：Lean 优先，总 RSS 超过 40 GB 或内存紧张时降并发。
- Windows：tree-N 结束（`<windows-workspace>\tree-N\DONE` 出现）之前，最多开 2 个 Lean 进程，commit 余量少于 20 GB 就不开新进程。tree-N 结束后，Claude 还要在同一目录补跑新增模块，补跑结束前仍按这个限制。之后 Windows 全部归你用。
- tree-* 目录都别动。

## 限制
- 零对外动作。
- 不碰 `$P/outputs/release/`、`$P/work/release-v*/`、`~/Desktop/AI4Math/我的笔记/`。
- 不读 `~/.codex/auth.json`；请求里不放邮箱；时间一律 `date -u`。
- 用 Git 一律设 `GIT_NO_LAZY_FETCH=1`。

## 报告
- 每题写 `STATUS.md`，随时更新。
- 冻结、验收通过、卡住三个节点，在 `CODEX-TASKS.md` 顶部各写一条。
- 两题都结束（验收通过或说明放弃原因）后写 `DONE`。
