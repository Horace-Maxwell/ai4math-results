#!/usr/bin/env python3
"""Copy Task S (CSS Conjectures B and C) Lean files to lean-staged/Research/TaskS/{B,C,Shared}, rewriting only import lines.
Local flat modules of conj-b -> Research.TaskS.B.*, conj-c -> Research.TaskS.C.* (MeasureAudit.CheckC -> Research.TaskS.C.MeasureAudit.CheckC),
TaskS.Shared.Sawtooth (identical in both) -> Research.TaskS.Shared.Sawtooth. Writes s-integration.json. Claude, 2026-11-20."""
import hashlib, json, os, re
P = '<workspace>'; T = f'{P}/work/codex-r3/phase26/taskS'
ST = f'{P}/work/release-v1250/lean-staged'; sha = lambda b: hashlib.sha256(b).hexdigest(); out = []
def files(sub):
    r = {}
    for dp, _, fs in os.walk(f'{T}/{sub}'):
        if '/acceptance' in dp or '/frozen' in dp or '/dev-logs' in dp or '.lake' in dp: continue
        for f in fs:
            if f.endswith('.lean'):
                rel = os.path.relpath(os.path.join(dp, f), f'{T}/{sub}')[:-5].replace('/', '.')
                r[rel] = os.path.join(dp, f)
    return r
done_shared = False
for sub, mod in [('conj-b', 'Research.TaskS.B'), ('conj-c', 'Research.TaskS.C')]:
    fs = files(sub)
    for n, path in sorted(fs.items()):
        if n.startswith('TaskS.Shared.'):
            target_mod = 'Research.' + n
            if done_shared:
                assert sha(open(path, 'rb').read()) == out_shared; continue
        else:
            target_mod = f'{mod}.{n}'
        b = open(path, 'rb').read(); t = b.decode()
        def fix(m):
            x = m.group(1)
            if x.startswith('TaskS.Shared.'): return f'import Research.{x}'
            if x in fs: return f'import {mod}.{x}'
            assert x.startswith('Mathlib'), (sub, n, x); return m.group(0)
        t2 = re.sub(r'^import (\S+)$', fix, t, flags=re.M)
        assert [l for l in t.split('\n') if not l.startswith('import ')] == [l for l in t2.split('\n') if not l.startswith('import ')]
        tgt = f"{ST}/{target_mod.replace('.', '/')}.lean"; os.makedirs(os.path.dirname(tgt), exist_ok=True)
        open(tgt, 'w').write(t2)
        out.append(dict(source=f'{sub}/{os.path.relpath(path, T + "/" + sub)}', target=f"lean/{target_mod.replace('.', '/')}.lean", module=target_mod,
                        source_sha256=sha(b), target_sha256=sha(t2.encode()), identical=(t == t2)))
        if n.startswith('TaskS.Shared.'): done_shared = True; out_shared = sha(b)
json.dump(out, open(f'{P}/work/release-v1250/s-integration.json', 'w'), indent=1)
print(len(out), 'files;', sum(o['identical'] for o in out), 'byte-identical'); print([o['module'] for o in out])
