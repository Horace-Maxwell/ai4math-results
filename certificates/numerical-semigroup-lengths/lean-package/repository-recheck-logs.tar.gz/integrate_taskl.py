#!/usr/bin/env python3
"""Copy the 12 Task L semigroup Lean files to a staging tree lean-staged/Research/TaskL/Semigroup/, rewriting only local import lines.
Later copied verbatim into the release tree (after v1.23.0 is committed). Writes taskl-integration.json. Claude, 2026-11-19."""
import hashlib, json, os, re
P = '<workspace>'
SRC = f'{P}/work/codex-r3/phase19/taskL/semigroup'; ST = f'{P}/work/release-v1240/lean-staged'
mod = 'Research.TaskL.Semigroup'; sha = lambda b: hashlib.sha256(b).hexdigest()
names = sorted(f[:-5] for f in os.listdir(SRC) if f.endswith('.lean'))
tdir = f"{ST}/{mod.replace('.', '/')}"; os.makedirs(tdir, exist_ok=True); out = []
for n in names:
    b = open(f'{SRC}/{n}.lean', 'rb').read(); t = b.decode()
    def fix(m):
        x = m.group(1)
        if x in names: return f'import {mod}.{x}'
        assert x.startswith('Mathlib'), (n, x); return m.group(0)
    t2 = re.sub(r'^import (\S+)$', fix, t, flags=re.M)
    assert [l for l in t.split('\n') if not l.startswith('import ')] == [l for l in t2.split('\n') if not l.startswith('import ')]
    open(f'{tdir}/{n}.lean', 'w').write(t2)
    out.append(dict(source=f'semigroup/{n}.lean', target=f"lean/{mod.replace('.', '/')}/{n}.lean", module=f'{mod}.{n}',
                    source_sha256=sha(b), target_sha256=sha(t2.encode()), identical=(t == t2)))
json.dump(out, open(f'{P}/work/release-v1240/taskl-integration.json', 'w'), indent=1)
print(len(out), 'files;', sum(o['identical'] for o in out), 'byte-identical')
