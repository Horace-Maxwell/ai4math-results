"""Finite checks of the Walsh upper-set claims. Standard Python, integer arithmetic only."""
from fractions import Fraction
from math import prod
import json


def walsh_direct(values):
    """Integer dot product with every Walsh character, without a butterfly transform."""
    return [sum(v * (-1 if (s & x).bit_count() % 2 else 1)
                for x, v in enumerate(values)) for s in range(len(values))]


def fwht(values):
    nums = values.copy()
    width = 1
    while width < len(nums):
        for start in range(0, len(nums), 2 * width):
            for x in range(start, start + width):
                a, b = nums[x], nums[x + width]
                nums[x], nums[x + width] = a + b, a - b
        width *= 2
    return nums


def subset(s, t):
    return s & t == s


def divisible(n, walsh, selected):
    """The stronger even-row quotient is tested directly, without a matrix."""
    e = sum(2 * s.bit_count() - (s != 0) for s in selected)
    raw_product = prod(walsh[s] for s in selected)
    numerator = (2 ** e) * raw_product
    return numerator != 0 and numerator % (2 ** (n * len(selected))) == 0


def weighted_entropy_bound(n, walsh, support, distortion, count_nonempty):
    """Check H + count_nonempty * 2(1-p_empty) <= 4*distortion*I after clearing logs."""
    powers = {s: walsh[s] ** 2 for s in support}
    a, b = distortion.as_integer_ratio()
    nonzero_mass = sum(powers[s] for s in support if s)
    exp_left = 2*b*n*sum(powers.values()) + 2*b*nonzero_mass*count_nonempty
    exp_right = 4*a*sum(s.bit_count()*v for s, v in powers.items())
    factor = prod(abs(walsh[s]) ** (2*b*v) for s, v in powers.items())
    return 2**exp_left <= (2**exp_right) * factor


def exact_distortion(walsh, indices):
    return max((Fraction(walsh[s] ** 2, walsh[t] ** 2)
                for s in indices for t in indices if subset(s, t)), default=Fraction(1))


def exhaustive(n):
    size = 2**n
    counts = dict(n=n, functions=0, full_support_products=0,
                  upper_set_products=0, all_comparable_bounds=0,
                  exempt_dc_bounds=0, nonupper_bad_products=0, first_nonupper_failure=None)
    for mask in range(2**size):
        f = [-1 if mask & (1 << x) else 1 for x in range(size)]
        walsh = walsh_direct(f)
        assert sum(w*w for w in walsh) == size*size
        support = [s for s, w in enumerate(walsh) if w]
        counts["functions"] += 1
        assert divisible(n, walsh, support)
        counts["full_support_products"] += 1
        for selection in range(2**len(support)):
            selected = {s for i, s in enumerate(support) if selection & (1 << i)}
            is_upper = all(t in selected for s in selected for t in support if subset(s, t))
            ok = divisible(n, walsh, selected)
            if is_upper:
                assert ok, (n, mask, selected)
                counts["upper_set_products"] += 1
            elif not ok:
                counts["nonupper_bad_products"] += 1
                if counts["first_nonupper_failure"] is None:
                    counts["first_nonupper_failure"] = dict(truth_minus_mask=mask,
                                                             selected=sorted(selected))
        for dc_free, key in [(False, "all_comparable_bounds"), (True, "exempt_dc_bounds")]:
            indices = [s for s in support if not dc_free or s != 0]
            L = exact_distortion(walsh, indices)
            assert weighted_entropy_bound(n, walsh, support, L, not dc_free), (n, mask)
            counts[key] += 1
    return counts


def selector(r, twisted):
    """Build the truth table on address+data variables; transform independently."""
    N = 2**r
    large = [z for z in range(1, N) if z & 1 == 0]
    singleton = [z for z in range(N) if z not in large]
    labels = [0] * N
    for j, z in enumerate(singleton, start=1):
        labels[z] = j
    L = len(singleton) + 1
    control = N - 1
    table = []
    for v in range(2**(r + L)):
        x, y = v & control, v >> r
        exponent = ((y >> labels[x]) & 1) + (x.bit_count() if twisted else 0)
        table.append((-1)**exponent)
    w = fwht(table)
    supp = [s for s, value in enumerate(w) if value]
    assert sum(v*v for v in w) == len(w)**2
    assert all((s >> r).bit_count() == 1 for s in supp)
    assert len(supp) == N*L
    high = [s & control for s in supp if abs(w[s]) > len(table)//N]
    assert sorted(high) == ([control ^ 1, control] if twisted else [0, 1])
    assert all((s >> r) == 1 for s in supp if abs(w[s]) > len(table)//N)
    magnitudes = sorted({Fraction(abs(w[s]), len(w)) for s in supp})
    assert magnitudes == [Fraction(1, N), Fraction(N//2 - 1, N)]
    Kmin = len(supp)*magnitudes[0]**2
    assert Kmin == Fraction(L, N) > Fraction(1, 2)
    dist = exact_distortion(w, supp)
    assert dist == (1 if twisted else (N//2-1)**2)
    return dict(r=r, twisted=twisted, K=len(supp), Kmin=str(Kmin), distortion=str(dist),
                high_control_indices=sorted(high), maximum_to_minimum=str(magnitudes[-1]/magnitudes[0]))


def ordinary_address(r):
    N = 2**r
    vals = [(-1)**((v >> (r + (v % N))) & 1) for v in range(2**(r+N))]
    w = fwht(vals)
    supp = [s for s,v in enumerate(w) if v]
    assert len(supp)==N*N and {Fraction(abs(w[s]),len(w)) for s in supp} == {Fraction(1,N)}
    I = sum(Fraction(s.bit_count()*w[s]**2,len(w)**2) for s in supp)
    assert I == 1 + Fraction(r,2)
    return dict(r=r, K=len(supp), influence=str(I), entropy=2*r)


if __name__ == "__main__":
    print(json.dumps(dict(cubes=[exhaustive(n) for n in range(4)],
                          ordinary=[ordinary_address(r) for r in (1,2,3)],
                          odd_cells=[selector(r, twist) for r in (3,4) for twist in (False,True)]),
                     ensure_ascii=False, indent=2))
