# Task V 续（Claude 代用户下达）：傅里叶熵、Brauer k(B) 与 57 度 Moore 图继续攻

用户原话："傅里叶熵、Brauer 和 Moore 也让 Codex 继续攻"。三题各由一个独立 Codex 会话负责，与 Stanley、Markov、照明、Dürer、Vizing、H₅-B 会话并行，互不等待。

## 共同要求
- 起点：本目录 `REPORT.md`、卡片 `lanes/analysis/card-fei.md` / `lanes/algebra/card-brauer.md` / `lanes/finite/card-moore.md`、`prior/` 下相关复核。
- 先查清文献最新进展与竞争者（近 6 个月 arXiv、AI 团队与公开题库、Epoch 专项等），每 24 小时复查一次；若有人公开解决，立即停手并报告。
- **不设保守止损**：一条路线有障碍就换下一条，直到有结果或用户叫停。每 24 小时在 `attempts/<题>/STATUS.md` 写进度小结（已试路线、最好成绩、下一条路线）。
- 得到完整证明并经非作者核读，或找到反例/构造并独立复核，就按手册第 3.5 节核对原文 → 冻结陈述（零诊断预编译 + 非作者审查）→ Lean（计算证书只用 `decide` 或反射，禁止 `native_decide`/`bv_decide`）→ 两个新空根验收 → `FINAL-HANDOFF.md`，并在 `CODEX-TASKS.md` 顶部报告。
- 部分结果（新的可证大类、改进的常数、新的必要条件或非存在定理）做到完整书面证明并经核读后，同样可以冻结做 Lean，写清它只是部分结果。

## ① Friedgut–Kalai 傅里叶熵–影响猜想：`attempts/fei/`
- 方向：卡片提到的自适应选坐标归纳；新的函数类（如单调函数、对称函数、低深度电路等未覆盖者）的证明；常数改进。

## ② Brauer 的 k(B) 猜想（k(B) ≤ |D|）：`attempts/brauer/`
- 方向：在可做完的特殊情形里推进（特定亏群、特定群族），注意卡片所说 2-块已有完整声称、奇素数稿件已撤回，先核清这些稿件的状态与覆盖范围，不重复已有声称。Lean 依赖重，可先以书面结果为主，写明 Lean 可行性。

## ③ 57 度 Moore 图（3250 点）：`attempts/moore/`
- 方向：对称性约束下的存在/非存在（自同构群可能阶的新排除）、卡片提到的旧非存在稿方程块的修补或推翻、新的必要条件。无约束枚举不可行，不要尝试。

## 机器与限制
- Mac 共 18 核，已有六个会话：本会话计算 ≤2 核、单任务 ≤60 分钟分段续跑；Lean 编译走 `work/tools/leanlock.sh`；内存紧张或 RSS 超 40 GB 降并发。Windows 禁用。
- 零对外动作；不碰 `outputs/release/`、`work/release-v*/`、`我的笔记/` 和其他任务目录；不读 `~/.codex/auth.json`；请求里不放邮箱；不下载数据集或软件、不安装东西；时间用 `date -u`。
- 做完或用户叫停时写 `attempts/<题>/DONE`。
