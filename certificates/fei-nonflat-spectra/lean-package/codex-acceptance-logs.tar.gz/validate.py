"""Two serial clean Lake replays and per-module leanchecker using the pinned local package cache."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = next(path for path in HERE.parents if (path / 'work/tools/leanlock.sh').is_file())
PKGS = REPO / 'work/research-lean-v434/.lake/packages'
SRC = HERE / 'formal'
BIN = REPO / 'work/toolchains/lean-4.34.1-darwin_aarch64/bin'
LOCK = REPO / 'work/tools/leanlock.sh'
MODULES = ['Fei.Challenge', 'Fei.UpperChallenge', 'Fei.Walsh', 'Fei.Determinant',
           'Fei.Analysis', 'Fei.Layer', 'Fei.UpperAnalysis', 'Fei.Check', 'Fei']
AXIOMS = {'Classical.choice', 'propext', 'Quot.sound'}
NAMES = ['check_signedProduct', 'check_supportEntropy', 'check_lowerMassFEI',
         'check_boundedRatioFEI', 'check_upperProduct', 'check_comparableMassFEI']
ENV = dict(os.environ, PATH=f'{BIN}:{os.environ["PATH"]}', LEAN_NUM_THREADS='1',
           LAKE_NO_CACHE='1', GIT_TERMINAL_PROMPT='0', ELAN_OFFLINE='1')
def utc():
    return subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def emit(path, value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def go():
    stamp = utc().replace(':','')
    batch = HERE / 'acceptance' / stamp
    batch.mkdir(parents=True,exist_ok=False)
    names = [m.replace('.','/')+'.lean' for m in MODULES] + ['lakefile.toml','lake-manifest.json','lean-toolchain']
    pins = {f:digest(SRC/f) for f in names}
    emit(batch/'sources.json',pins)
    stable_sources = pins.copy()
    for path in [HERE/'review/FROZEN.json', HERE/'review/FROZEN-UPPER.json']:
        for ref,h in json.loads(path.read_text())['pins'].items():
            if digest(HERE/ref) != h:
                raise ValueError(f'freeze mismatch {ref}')
    hits = []
    banned = re.compile(r'\b(sorry|admit|native_decide|bv_decide|implemented_by|extern|unsafe|axiom|partial|sorryAx)\b|debug\.skipKernelTC|decide\s+\+native')
    for file in names:
        if file.endswith('.lean'):
            hits.extend((file,i,line) for i,line in enumerate((SRC/file).read_text().splitlines(),1) if banned.search(line))
    emit(batch/'banned.json',hits)
    if hits:
        raise ValueError(hits)
    manifest = json.loads((SRC/'lake-manifest.json').read_text())
    deps = {}
    for entry in manifest['packages']:
        p = PKGS/entry['name']
        head = subprocess.check_output(['git','-C',p,'rev-parse','HEAD'],text=True).strip()
        if head != entry['rev']:
            raise ValueError((p,head,entry['rev']))
        deps[entry['name']] = head
    emit(batch/'toolchain.json',{'pinned_dependency_heads':deps,'trusted_cache':str(PKGS),
       'lean':digest(BIN/'lean'),'lake':digest(BIN/'lake'),'leanchecker':digest(BIN/'leanchecker')})
    def run(root, key, args, timeout=600, allow_diag=False, env=None, allow_failure=False):
        logs = root/'logs'
        g=logs/(key+'.log')
        t=utc()
        print(f"{t} {root.name} {key}",flush=True)
        with g.open('wb') as log:
            proc=subprocess.Popen(args,cwd=root,env=env or ENV,stdout=log,stderr=subprocess.STDOUT,
                                  start_new_session=True)
            clock=time.monotonic()
            while True:
                pid,status,usage=os.wait4(proc.pid,os.WNOHANG)
                if pid:
                    proc.returncode=os.waitstatus_to_exitcode(status)
                    break
                if time.monotonic()-clock>=timeout:
                    import signal
                    os.killpg(proc.pid, signal.SIGKILL)
                    _,status,usage=os.wait4(proc.pid,0)
                    proc.returncode=os.waitstatus_to_exitcode(status)
                    break
                time.sleep(0.15)
        raw=g.read_bytes()
        emit(logs/(key+'.json'),{'args':args,'cwd':str(root),'start':t,'end':utc(),'exit':proc.returncode,
             'peak_rss_bytes_macos':usage.ru_maxrss,'sha256':digest(g)})
        if not allow_failure and (proc.returncode or (not allow_diag and re.search(rb'(?im)^.*?\b(?:warning|error):',raw))):
            raise RuntimeError(f'{key} exit={proc.returncode}: {raw[-1800:].decode(errors="replace")}')
        return raw.decode()
    def replay(k):
        root=batch/f'root{k}'
        root.mkdir()
        assert not list(root.iterdir())
        (root/'logs').mkdir()
        for f in names:
            (root/f).parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(SRC/f,root/f)
        (root/'.lake').mkdir()
        (root/'.lake/packages').symlink_to(PKGS)
        assert not (root/'.lake/build').exists()
        owner=f'fei-replay-{stamp}-{k}'
        acquire_cmd = """elapsed=0
until slot=$("$1" acquire any "$2" 40); do
  if (( elapsed >= 5400 )); then exit 75; fi
  sleep 150
  (( elapsed += 150 ))
done
print -r -- "$slot"
"""
        ac=subprocess.run(['/bin/zsh','-c',acquire_cmd,'fei-acquire',str(LOCK),owner],
            capture_output=True,text=True)
        (root/'logs/acquire-stderr.log').write_text(ac.stderr)
        ac.check_returncode()
        slot=ac.stdout.strip()
        (root/'logs/acquire.log').write_text(ac.stdout)
        try:
            run(root,'lean-version',['lean','--version'])
            # The frozen package resolves the external dependency paths. A dependency-free
            # Lake driver consumes just their cached oleans and cannot rebuild a shared package.
            lean_path=run(root,'pinned-path',['lake','env','printenv','LEAN_PATH']).strip().split(os.pathsep)
            # Resolve symlinked package entries relative to this root rather than the controller.
            extern=[]
            for x in lean_path:
                v=(root/x).resolve() if not Path(x).is_absolute() else Path(x).resolve()
                if v.is_relative_to(PKGS.resolve()):
                    extern.append(str(v))
            if not any((Path(x)/'Mathlib.olean').is_file() for x in extern):
                raise ValueError(lean_path)
            (root/'lakefile.cached.toml').write_text('name = "fei"\nversion = "0.1.0"\ndefaultTargets = ["Fei"]\n\n[[lean_lib]]\nname = "Fei"\n')
            env=dict(ENV,LEAN_PATH=os.pathsep.join(extern))
            run(root,'external-cache-preflight',['lake','--old','--no-build','--no-cache','build','+Mathlib:olean'],
                allow_failure=True)
            preflight=json.loads((root/'logs/external-cache-preflight.json').read_text())
            if preflight['exit']==0:
                compile_args=['lake','--old','--no-cache','--wfail','build']
                env=ENV
            else:
                # No external package update or rebuild. Preserve the failed preflight.
                compile_args=['lake','-f','lakefile.cached.toml','--no-cache','--wfail','build']
            for m in MODULES:
                run(root,'build-'+m,compile_args+['+'+m+':olean'],env=env)
            run(root,'build-default',compile_args,env=env)
            for m in MODULES:
                out=run(root,'checker-'+m,['lake','env','leanchecker',m])
                if out.strip(): raise ValueError(('checker output',m,out))
            audit=run(root,'axioms',['lake','env','lean','-j1','-DwarningAsError=true','Fei/Check.lean'])
            match=re.findall(r"'Fei\.(check_\w+)' depends on axioms:\s*\[([^\]]*)\]",audit)
            axmap={name: [a.strip() for a in values.split(',') if a.strip()] for name,values in match}
            if len(match)!=len(NAMES) or set(axmap)!=set(NAMES) or any(not set(xs)<=AXIOMS for xs in axmap.values()):
                raise ValueError(audit)
            artifacts={m:digest(root/'.lake/build/lib/lean'/(m.replace('.','/')+'.olean')) for m in MODULES}
            if any(digest(root/f)!=h or digest(SRC/f)!=h for f,h in pins.items()):
                raise ValueError('source drift')
            emit(root/'result.json',dict(utc=utc(),modules=MODULES,axioms=axmap,oleans=artifacts))
            return artifacts,axmap
        finally:
            rel=subprocess.run([LOCK,'release',slot,owner],capture_output=True,text=True,check=True)
            (root/'logs/release.log').write_text(rel.stdout)
    r1=replay(1)
    r2=replay(2)
    if r1!=r2: raise ValueError('clean roots disagree')
    emit(batch/'PASS.json',dict(utc=utc(),modules=len(MODULES),checks=len(NAMES),roots=2,source_hashes=stable_sources))
    print(batch/'PASS.json',flush=True)
if __name__=='__main__':
    go()
