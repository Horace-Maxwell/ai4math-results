# 傅里叶熵与影响力 · 冻结陈述对照

原猜想定义于所有均匀布尔立方体，函数取 ±1，归一化 Walsh 系数为符号乘积的期望，熵以 2 为底。原问题完整量词为存在绝对常数 C，对每个维数和每个函数有 H≤CI。本批冻结了以下六项。四项基础合同见 formal/Fei/Challenge.lean，两项扩展见 formal/Fei/UpperChallenge.lean。

记 U 为非零系数支撑，p(S) 为系数平方，K=|U|，t 为非空频率的个数，W=Σ_{S∈U}|S|。H 是谱概率的熵，I 是谱概率加权的平均阶数。I 与翻转影响力总和相等的标准表述可见原文，本批合同直接采用 I 的谱定义。[O'Donnell、Wright、Zhou](https://www.cs.cmu.edu/~odonnell/papers/fei.pdf)

| 冻结命题 | 数学含义 |
|---|---|
| SignedProduct | 2^(2W) 乘全部非零的有符号 Walsh 系数之积，是 2^t 的非零整数倍。 |
| SupportEntropy | H≤log₂K，K log₂K≤Σ_U log₂(1/p)，且 Σ_U log₂(1/p)+2t≤4W。 |
| LowerMassFEI | 任意 δ>0；若每个非零谱概率至少为 δ/K，则 δ(H+2t/K)≤4I。 |
| BoundedRatioFEI | 若非零系数的最大绝对值与最小绝对值的比不超过 M≥1，则 H≤4M²I。 |
| UpperProduct | 对 U 中每个相对包含向上封闭子集 V，SignedProduct 的结论对 V 自身的权重、频率积与非空频率数成立。包括 V 为空集。 |
| ComparableMassFEI | 任取 L≥1。只要每对非空的支持指标 S⊆T 均有 p(S)≤L p(T)，则 H≤4L I。允许任意空频率质量。 |

两个合同均允许 n=0、常值、单字符以及不平衡函数。Lean 用 Fin n 的有限子集记录负坐标，布尔值 true 表示输出 −1。下质量界和可比对条件针对不同函数类，整体影响力无正下限假设。两个审查文件列有审查人检查过的退化情形。

[评审过的基础证明](adaptive/PROOF.md) · [向上封闭子集的推导](adaptive/UPPER-SETS.md) · [第一份冻结记录](review/FROZEN.json) · [扩展冻结记录](review/FROZEN-UPPER.json)
