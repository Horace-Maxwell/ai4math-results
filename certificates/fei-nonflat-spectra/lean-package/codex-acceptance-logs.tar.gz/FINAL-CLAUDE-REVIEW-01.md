# Cross-family FINAL review 01: partial Fourier entropy–influence bounds (fei)

**Verdict: APPROVE_FORMAL.** No BLOCKER and no MAJOR items. The six frozen targets `SignedProduct`, `SupportEntropy`, `LowerMassFEI`, `BoundedRatioFEI`, `UpperProduct` and `ComparableMassFEI` are faithful to the stated mathematics. The Fourier conventions match the standard FEI setting. All six targets are fully Lean-verified: only the standard axioms, an independent rebuild on this Mac, and a clean leanchecker run on every module. My literature search found no prior statement of either result (details in section 4). The pre-publication G3 check is still open and must be run before release. The MINOR items concern the write-up and the shape of the check file only. They do not affect the Lean result.

- Reviewer: Claude (Anthropic, Opus 5.5), subagent of the user's Claude session. I wrote none of the reviewed files.
- Review started 2026-11-21T17:03:50Z. Report written after 2026-11-21T17:09:37Z (Mac `date -u`).
- My only write in the task directory is this file. All other work is in `<claude-scratch>/1a281c0e-ef8d-4049-acc3-fc1245000b5f/scratchpad/fei-final/`, plus the paper extract in `.../scratchpad/owz/`.
- Lock: `leanlock.sh acquire any claude-final-fei-01 60` was granted slot B. I released it with `release B claude-final-fei-01` (output `released B`, exit 0) at 2026-11-21T17:08:49Z.

**Where the common-brief files are in this folder.** There is no Challenge.lean, FREEZE.json, MATHEMATICS.md, Proof.lean, G2.md or `frozen/` directory under those names. Their equivalents:

| Common-brief file | Here |
|---|---|
| Challenge.lean | `formal/Fei/Challenge.lean` and `formal/Fei/UpperChallenge.lean` |
| FREEZE.json | `review/FROZEN.json` and `review/FROZEN-UPPER.json` |
| FREEZE-REVIEW.md | `review/STATEMENT.md` and `review/UPPER-STATEMENT.md` |
| Check*.lean | `formal/Fei/Check.lean` |
| Proof.lean | `formal/Fei/{Walsh,Determinant,Analysis,Layer,UpperAnalysis}.lean` |
| MATHEMATICS.md | `adaptive/PROOF.md`, `adaptive/UPPER-SETS.md`, `STATEMENTS.md`, `FINAL-HANDOFF.md` |
| G2.md / SOURCE-CHECK.md | `literature/G1-G2.md`, `literature/G2-UPPER.md`, `classes/PRIOR.md` |
| receipt | `acceptance/2026-11-21T050526Z/PASS.json` and `ROOT-AUDIT.json` |

## Files reviewed (SHA-256)

| File | SHA-256 |
|---|---|
| formal/Fei/Challenge.lean | b277a582080a00a9292544f1c924e82fba110e4c68218d9b306ae5bdfb7753c6 |
| formal/Fei/UpperChallenge.lean | 0731c4d45f85ebd25740e813be95950b9665bfd5bc110047d2cef99014fe03ab |
| formal/Fei/Check.lean | 6a6451b47efc30be1959ab11b7c75f3305260cd81d684dcba4c76fea985c07cb |
| formal/Fei/Walsh.lean | 2b34b5db9450536e4db4a014426f85743d90e27856727c2c946afc5a2c3a51c3 |
| formal/Fei/Determinant.lean | 161ac14fcd816a3fc5bc3e84381d91a3bf3a81e5c79593da0f80ccf9fc75d29e |
| formal/Fei/Analysis.lean | b9169f43cf1cb89bd4cd9267c566ee75a9fe4faec1ae41eddd5668d5ed04b1d3 |
| formal/Fei/Layer.lean | 7ff0c85b6df0d84beffa3ad29edbce4a5cbd3012fd28dd0175534e033d96a317 |
| formal/Fei/UpperAnalysis.lean | c63967ec493da8f3977eb7238470787870ae16cc9c13cf05938e6aedd3c2e244 |
| formal/Fei.lean | df07ab378a57c486955562dc411e73db4e2281f9bcff6dc4ad9207b7e11dc20c |
| formal/lakefile.toml | 6c44fc2058589d4d287a7be4e86f9d5c765809c94ba318464a478f63fe7b0fdd |
| formal/lake-manifest.json | fab714c2f3bfce5925406e1a6211c341691efd31f7f1e92d11592c64b6a990a4 |
| formal/lean-toolchain | d5edba4e4b8faad9c1baeadb265716d20d03be4d1a2647dc5e35b0c0325bea7b |
| review/FROZEN.json | c14e2dfd3c656f9c272666b39151227059c9e4df3cd6936398976588dcb9e094 |
| review/FROZEN-UPPER.json | b8c74cc89b834b774c09e80c016c2cd10133c71b72be54449c8b8d8fffbda367 |
| review/STATEMENT.md | 234cb7bb34af55cdd53c0b3015dc0a124ecd4ae7c6629e09da355d2576b4ffff |
| review/UPPER-STATEMENT.md | ae246b5e03c4f5a0726d6cc4dcf2cbb6a213afb9fa3dc063aeba42aad1f317d2 |
| review/WRITTEN.md | 05e9351916304532d408ca8cee8e40b6444dccef3816a4878b42a0d22a6eddf8 |
| review/UPPER-WRITTEN.md | 34233110cd9f3e05c65d3d9d11422563c659530b65585be363fcc58e6ee56d17 |
| adaptive/PROOF.md | f9463ce806d0d3f97101415c334eb41f73a263d0397f306fdca897590350a31f |
| adaptive/UPPER-SETS.md | 82893a852ab47df72be4175aafe7f884915a16bb4316b3eebdd81154d6fe3b3f |
| STATEMENTS.md | 8aba1da38321e66f003c93014a01982e8dce1a50d43552018b72a168bb3ad60a |
| FINAL-HANDOFF.md | dffa4e77397716a23365eaceeb8f54146562b1e925dd5857f3266e1670e8a1ac |
| literature/G1-G2.md | 97a7e849d6baaa2ee16f23c95e8e3ce0837631a8d7e5e2fcfcb18cac12b63c8c |
| literature/G2-UPPER.md | 33e61e2c3c856f9a805bad925d436c02a51a24338c1da6849d24f58b39d4179f |
| acceptance/2026-11-21T050526Z/PASS.json | 3ed0ea0b318364e2d214d29983b7610d6111864b993d690a2e88c855231ac5a2 |
| acceptance/2026-11-21T050526Z/ROOT-AUDIT.json | 7395a994536db1bb17f71270d8b8a51866d8265f9cfa6c1e36249c29324c373a |
| O'Donnell–Wright–Zhou, fei.pdf (fetched by me from cs.cmu.edu) | fc23b34306d0d859089f68096a05a0645af8eb8e9d3c6f86d65d126f333890f0 |
| My Audit.lean (scratch) | 0a9e14f786e1d06a4d3cd76e6aca3ceed5285999637d365a697972df0c6601bf |
| My test.py (scratch) | ccbe12cc0999b418270b68fdeb2505f97ef24b1496cfacbe0331fda857089dc7 |

All hash checks pass:
- Both challenge hashes match their freeze records. Every pinned document in FROZEN.json and FROZEN-UPPER.json also matches, including the FROZEN.json hash pinned inside FROZEN-UPPER.json.
- All 12 source hashes match `PASS.json`.
- The nine `.lean` files in `formal/` are byte-identical (cmp) to `acceptance/2026-11-21T050526Z/root1/` and `root2/`.
- The 18 per-module leanchecker logs in the two roots are empty, and both `axioms.log` files list exactly the three standard axioms.

## 1. Are the statements faithful to the source?

**Source.** O'Donnell, Wright and Zhou, "The Fourier Entropy–Influence Conjecture" (ICALP 2011). I fetched and extracted the PDF myself.
- They state the conjecture as "∃C ∀f, H[f̂²] ≤ C · I[f]", for f : {−1,1}ⁿ → {−1,1}.
- Entropy is Σ f̂(S)² log₂(1/f̂(S)²), and they note that "I[f] = Σ f̂(S)²|S|" is the total influence.

**Lean definitions** (Challenge.lean):

| Object | Lean | Assessment |
|---|---|---|
| Cube, domain | `Cube n = Finset (Fin n)`, a point is its set of −1 coordinates; `f : Cube n → Bool`, `true` means −1 | A bijection with {−1,1}ⁿ → {−1,1}. Every n is covered, including n = 0, and every one of the 2^(2ⁿ) functions. No balance or monotonicity assumption. This is the ±1 normalisation, not {0,1}. |
| character | `∏ i ∈ x, if i ∈ s then −1 else 1` | (−1)^{|s∩x|} = χ_S(x). Correct. |
| coeff | `(Σ_x value f x · character s x) / 2^n` | f̂(S) = E_x[f(x)χ_S(x)] under the uniform measure. Correct. |
| support | filter `coeff f s ≠ 0` over all of `univ` | The true nonzero spectrum, K = `(support f).card`. Not a defaulted Nat.card or ncard. |
| mass | `coeff^2` | p(S) = f̂(S)². |
| entropy | `Σ_{support} p · (−logb 2 p)` | Base 2. Restricting to the support is exactly the 0·log 0 = 0 convention. |
| influence | `Σ_{support} p · |S|` | The spectral form of total influence, as in OWZ. The identity with Σᵢ Pr[f(x) ≠ f(x^{⊕i})] is standard (O'Donnell's book, Thm 2.38) and is not in Lean. |
| weightSum, nonemptyCount | Σ_U |S| as ℕ, `((support f).erase ∅).card` | W and t = |U∖{∅}|. Correct. |

**The empty set.** ∅ is the constant character, χ_∅ ≡ 1, and f̂(∅) = E f.
- In `SignedProduct`, `SupportEntropy` and `LowerMassFEI`, ∅ belongs to U whenever f̂(∅) ≠ 0. It counts in K and in the product, but not in t, and contributes 0 to W.
- `LowerMassFEI` therefore requires p(∅) ≥ δ/K whenever ∅ ∈ U. That matches the stated hypothesis "every nonzero p(S) ≥ δ/K".
- `ComparableMassFEI` erases ∅ from both quantified indices. The DC mass is unconstrained, which is a stronger result than the brief's version (b).

**Targets and the claimed results.**
- (a) Lean proves δ(H + 2t/K) ≤ 4I for every δ > 0 such that δ ≤ K·p(S) on all of U. Since δ > 0 and 2t/K ≥ 0, this implies H ≤ 4I/δ. My Audit.lean derives δ·H ≤ 4I directly from the frozen statement.
- `BoundedRatioFEI` takes the pairwise condition |f̂(S)| ≤ M|f̂(T)| over all of U. That is exactly "max/min magnitude ≤ M", and the conclusion is H ≤ 4M²I.
- (b) `ComparableMassFEI`: for every L ≥ 1, if p(S) ≤ L·p(T) for all nonempty supported S ⊆ T, then H ≤ 4L·I. S = T is allowed, which already forces L ≥ 1 whenever the nonempty support is nonempty, so the hypothesis L ≥ 1 is harmless.
- `UpperProduct` quantifies over every V ⊆ U that is upward closed relative to U, including V = ∅.
- The orientation (smaller set, smaller mass up to L) is as stated. All quantifiers are universal over n, f, δ, M, L, as in the claims.

**Vacuity check.** Parseval is proved, so K ≥ 1 and K·min p ≤ 1. Both hypotheses are therefore satisfiable non-trivially. Examples:
- Every plateaued function satisfies (a) with δ = 1.
- The written odd-cell selector has K·min p > 1/2 while its magnitude ratio tends to infinity.

**Small cases, my own Python code** (exact `Fraction` Walsh transform, scratch `test.py`):
- All 278 sign functions with n ≤ 3, and 3,998 random functions with n = 4–7 (uniform, biased and small-DNF types).
- For each function I checked:
  - that 2^(2W)·∏_U f̂(S) / 2^t is a nonzero integer;
  - the same for three random relative upper sets V per function;
  - (a) at the sharpest δ = K·min p;
  - (b) at the sharpest L = max(1, max over nonempty comparable pairs of p(S)/p(T)).
- No violation. The largest observed ratios were δH/(4I) = 0.50 and H/(4LI) = 0.935, so neither bound is vacuous on small cases.
- Separately (`examples.py`) I rebuilt the selector examples of PROOF.md and UPPER-SETS.md for r = 3 and 4:
  - For PROOF.md: K = 48 and 160, K·min p = 0.75 and 0.625, magnitude ratios 3 and 7, H ≤ 8I.
  - For UPPER-SETS.md: zero monotonicity violations on the support, and ∅ is not in the support.
  - All of this agrees with the text.

## 2. Proof chain

- **Shape of Check.lean.** It is not literally `theorem check_X : Challenge.X := Proof.X`. Each `check_*` is stated with the frozen Prop name as its type, and its body composes proof lemmas. For example, `check_signedProduct := signedProduct_of_upper check_upperProduct`, and `check_comparableMassFEI := comparableMassFEI_core upper_layer_sum parseval (upper_log … check_upperProduct …)`. The proofs are sound; only the format differs (MINOR 1).
- **No shadowing.** Every module sits in `namespace Fei`. Redeclaring `Fei.SignedProduct` etc. would be a Lean error, and no proof module declares any of the frozen names (checked by reading all nine files). My Audit.lean uses fully qualified `example : Fei.X := Fei.check_X` for all six. It also has two unfolded restatements written directly from `Fei.coeff`, `Fei.support` and `Real.logb`, independent of the frozen Prop names.
- **Grep** of all local .lean files for the brief's list:
  - sorry, admit, native_decide, bv_decide, axiom, unsafe, implemented_by, extern, opaque, macro, elab, syntax, initialize, run_cmd, ofReduceBool, `@[`: no hits.
  - `set_option`: one benign `set_option maxHeartbeats 800000 in` (UpperAnalysis.lean:23).
  - `decide`: no uses at all.
  - The only hits for "axiom" are the `#print axioms` lines in Check.lean.
- **Proof content, read in full.**
  - Walsh.lean proves orthogonality, inversion, Parseval and the integrality of 2^{|R|}·Σ_{W⊇R} f̂(W), with the extra factor 2 for R ≠ ∅.
  - Determinant.lean proves that the inclusion matrix on U, ordered by size, is unitriangular. It builds B = D Z diag(c) Zᵀ D, factors the row multipliers into an integer matrix, and shows the determinant is nonzero.
  - Analysis.lean proves the two Jensen steps via log x ≥ 1 − 1/x and log x ≤ x − 1, and derives (a) and the M-corollary.
  - Layer.lean proves the layer-cake summation.
  - UpperAnalysis.lean proves the DC bound p·log₂(1/p) ≤ 2(1 − p) and the majorant a_S, assembling (b).
  - All of this matches the written proof.

## 3. Independent rebuild on this Mac

- **Toolchain.** Lean 4.34.1 (commit 5045d0056413), Mathlib d13f23b7 oleans from `work/research-lean-v434/.lake/packages` via LEAN_PATH. The build used plain `lean -DautoImplicit=false -DrelaxedAutoImplicit=false -R src -o …` into a new empty `out/` directory, one process at a time.
- **Results** (`build.json`):

| Module | lean rc | leanchecker rc / output | sec |
|---|---|---|---|
| Fei.Challenge | 0 | 0 / empty | 22.0 |
| Fei.UpperChallenge | 0 | 0 / empty | 9.7 |
| Fei.Walsh | 0 | 0 / empty | 10.1 |
| Fei.Determinant | 0 | 0 / empty | 9.8 |
| Fei.Analysis | 0 | 0 / empty | 8.3 |
| Fei.Layer | 0 | 0 / empty | 9.5 |
| Fei.UpperAnalysis | 0 | 0 / empty | 8.7 |
| Fei.Check | 0 | 0 / empty | 9.2 |
| Fei | 0 | 0 / empty | 79.5 |
| Audit (mine) | 0 | 0 / empty | 22.6 |

- No warnings and no errors.
- **Axioms.** `#print axioms` in both Check.lean and Audit.lean gives, for each of `Fei.check_signedProduct`, `check_supportEntropy`, `check_lowerMassFEI`, `check_boundedRatioFEI`, `check_upperProduct` and `check_comparableMassFEI`, exactly [propext, Classical.choice, Quot.sound].
- **Audit.lean**:
  - six `example : Fei.X := Fei.check_X`;
  - `δ·entropy ≤ 4·influence` derived from `check_lowerMassFEI`;
  - (b) restated with `(Fei.coeff f s)^2` written out.

## 4. Mathematics, prior work, claims

**Correctness.** The written proof (PROOF.md, UPPER-SETS.md) is correct and short:
- Integrality of the finite differences 2^{|R|} Σ_{W⊇R} f̂(W), with one extra factor 2 when R ≠ ∅.
- Unitriangular inclusion matrix, so |det B| = 2^{2W−t}·|∏ f̂| ≥ 1.
- Σ_U log₂(1/p) + 2t ≤ 4W.
- AM–GM / Jensen gives K log₂K ≤ Σ_U log₂(1/p), and H ≤ log₂K.
- Under p ≥ δ/K one has I ≥ (δ/K)·W, which gives (a).
- For (b), superlevel sets of the comparable-pair majorant are relative upper sets. The layer-cake sum and the DC bound −p log₂p ≤ 2(1 − p) finish the proof.
- I re-derived each step. Lean checks all of it.

**Triviality and novelty.**
- (a) is not a short corollary of the standard tools I could identify:
  - H ≤ log₂K plus per-coefficient granularity (multiples of 2^{1−deg f}, Gopalan et al.) bounds H by the maximum degree, not by the influence.
  - Hamming-ball counting gives n-dependent bounds such as OWZ's H ≤ (1 + log n)·I + 1.
  - Friedgut/KKLMS-type concentration gives at best log K ≲ I²/δ² or an extra log I factor.
  - Spectral-norm FEI (Shalev, Chakraborty et al.) does not apply: under ratio M, log‖f̂‖₁ can be about ½ log₂K, which is unbounded.
- The new ingredient is the weighted product inequality Σ_U log₂(1/p_S) ≤ 4Σ_U |S| for every Boolean f. Equivalently, log₂K ≤ 4·(mean |S| over the support). I found no such statement.
- Potapov (arXiv 2609.21563 v1, 18 Sep 2026), read by me: his Theorem 2 gives the sharp constant 4 for plateaued functions, i.e. M = 1. That is exactly (a) with δ = 1, and it is credited.
  - His Lemma 1 uses the same triangular order matrix, but only over GF(2): det = 1 mod 2, giving an odd-pairing permutation.
  - He combines it with the degree bound I ≥ (n − deg 1_U)/2 and Proposition 4 (deg 1_U ≤ (n + s)/2 for s-plateaued f).
  - He uses no signed coefficients, no product inequality and no non-plateaued condition, and lists no open questions.
  - So (a) for δ < 1, the M-corollary and (b) are not in Potapov. The shared triangular-matrix idea is acknowledged in PROOF.md and G1-G2.md.
- I also checked:
  - Arunachalam–Chakraborty–Koucký–Saurabh–de Wolf (arXiv 1809.09819): flat *approximating* polynomials and min-entropy; granularity mentioned only in passing.
  - González–MacManus–Pereyra (arXiv 2606.00246 v2): tribes and separation classes, no spectral-mass conditions.
  - Web searches for near-flat or bounded-ratio spectra, products of nonzero Fourier coefficients, and determinant/inclusion-matrix bounds. Only Gopalan et al. and the abelian-group granularity papers came up, neither relevant.
- Conclusion: I found no prior statement of (a) for δ < 1, of the 4M² corollary, of (b), or of the product inequality. This is search evidence, not proof of novelty, and the authors' own logs record gaps (OpenAlex, Crossref and StackExchange returned 429; repository full-text scans are older than the newest commits). So G3 must still run before publication (MINOR 6).
- **Significance.** Modest. The constants degrade as δ → 0 or L → ∞, and standard examples (AND, Tribes) have exponentially small δ. The work never claims general FEI. FINAL-HANDOFF, STATUS and STATEMENTS all say FEI remains open.

**Wording.** No "first", 首次 or 率先 claim about the mathematics (the only matches refer to the first acceptance launch and a save point). Prior work is attributed to Potapov (flat case and matrix idea), to Shmalo (addressing identities and selectors) and to OWZ (definitions).

**Content outside Lean, which the write-up should mark as such** (MINOR 3):
- the identity between spectral I and flip-influence;
- sharpness of the constant 4 in log₂K ≤ 4·mean|S| via the address function;
- both selector examples, including the claims "Km > 1/2", "ratio → ∞" and "monotone amplitudes";
- the statement that general FEI stays open.

## MINOR fixes (numbered)

1. **Check.lean format.** The `check_*` theorems compose lemmas instead of the prescribed `theorem check_X : Fei.X := Proof.X`. Either add a single `Proof.lean` exporting `theorem X : Fei.X` for each target, so Check.lean becomes six one-line aliases, or record in the handoff that the composed form was accepted. My Audit.lean confirms the types are exactly the frozen Props.
2. **Stale status lines.**
   - `adaptive/UPPER-SETS.md` line 3 still says "It has no formal credit and is outside the first frozen package".
   - `adaptive/PROOF.md` line 3 says "Independent review and formal verification are pending".
   - Both are now false. Update them, or add a dated note: both packages frozen and machine-verified 2026-11-21T05:11Z; FINAL review 2026-11-21.
3. **Mark non-Lean content.** In the publication text, label the following explicitly as not Lean-verified:
   - the selector examples and their numeric properties;
   - the sharpness of 4 in log₂K ≤ 4·mean|S| (address function, from Shmalo §8);
   - the spectral-I = flip-influence identity (standard; cite OWZ or O'Donnell's book).
4. **No consolidated MATHEMATICS.md.** The mathematics is split over PROOF.md, UPPER-SETS.md, STATEMENTS.md and FINAL-HANDOFF.md (partly in Chinese). For release, write one English note containing:
   - the six statements;
   - the proof;
   - the Lean declaration names;
   - prior work (Potapov §2–4 with the GF(2) versus integer-determinant distinction; Shmalo; OWZ);
   - the open status of general FEI.
5. **Brief versus frozen statement.** State in the publication that the Lean form of (a) is the stronger δ(H + 2t/K) ≤ 4I, valid for every δ > 0 meeting the hypothesis (which forces δ ≤ 1). PROOF.md's "0 < δ ≤ 1" is redundant. Also state that the Lean form of (b) exempts the empty frequency, and that p(∅) is unconstrained.
6. **Novelty is search-limited.** Run G3 before publishing. In particular, recheck arXiv after 2026-11-21 for Potapov v2 or follow-ups, and Shmalo's newest manuscript versions, for a non-plateaued extension or the product inequality. Keep the "no priority inferred" wording, as PROOF.md already does.
